const moment = require("moment");

  exports.allblogs = async function (req, res, next) {
    try {
      if(req.session.USERTYPE!=1){
        res.status(403).redirect('/')
      }
      else{
      let blogs = await db.query(`select * from blog_tbl order by created_time Desc`);

      res.render("allblogs", {
        allblogs: blogs,
        moment: moment,
      });
     }
    } catch (error) {
      next(error);
    }
  };

  exports.create_blog = async function (req, res, next) {
    try {
      if(req.session.USERTYPE!=1){
        res.status(403).redirect('/')
      }
      else{
      let failed = req.flash("failed");
      let success = req.flash("success");
      res.render("create_blog",{
        success: success,
        failed: failed,
      });
    }
    } catch (error) {
      next(error);
    }
  };

  exports.submit_blog = async function (req, res, next) {
    try {
      if(req.session.USERTYPE!=1){
        res.status(403).redirect('/')
      }
      else{
      let checkBlog = db.query(
        `select count(*) from  blog_tbl where title=:title or slug=:slug`,
        { title: req.body.blogtitle, slug: req.body.blogslug }
      );

      if (checkBlog.length > 0) {
        req.flash("failed", "Blog with title or slug already exists");
        res.redirect("/blogs/create");
      } else {
        let tags = "";
        let meta_tags = "";

        if(req.body.meta_tags.length>0){
          meta_tags = JSON.parse(req.body.meta_tags);
        
        
        console.log(meta_tags);
        for (let i = 0; i < meta_tags.length; i++) {
          if (meta_tags.length - 1) tags += meta_tags[i].value + ",";
          else tags += meta_tags[i].value;
        }
      }
        if(req.file == undefined){
          db.query(
            `insert into blog_tbl (title,slug,description,meta_tags) values (:title,:slug,:description,:meta_tags)`,
            {
              title: req.body.blogtitle,
              slug: req.body.blogslug,
              description: req.body.description,
              meta_tags: tags,
            }
          );
        }
        else{
          let filename = req.file.filename;
        db.query(
          `insert into blog_tbl (title,slug,description,meta_tags,image) values (:title,:slug,:description,:meta_tags,'${filename}')`,
          {
            title: req.body.blogtitle,
            slug: req.body.blogslug,
            description: req.body.description,
            meta_tags: tags,
          }
        );
        }
        res.redirect("/blogs");
      }
    }
    } catch (error) {
      next(error);
    }
  };

  exports.submit_edited = async function(req, res, next){
    
    try {
      
        let tags = "";
        let meta_tags = "";

        if(req.body.meta_tags.length>0){
          meta_tags = JSON.parse(req.body.meta_tags);
        
        console.log(meta_tags);
        for (let i = 0; i < meta_tags.length; i++) {
          if (i<=meta_tags.length - 2) 
           tags += meta_tags[i].value + ",";
          else tags += meta_tags[i].value;
        }
      }
        if(req.file == undefined){
          db.query(
            `update blog_tbl set title=:title, slug=:slug, description=:description, meta_tags=:meta_tags where id=${req.params.id} `,
            {
              title: req.body.blogtitle,
              slug: req.body.blogslug,
              description: req.body.description,
              meta_tags: tags,
            }
          );
        }
        else{
          let filename = req.file.filename;
        db.query(
          `update blog_tbl set title=:title, slug=:slug, description=:description, meta_tags=:meta_tags, image='${filename}' where id=${req.params.id} `,
          {
            title: req.body.blogtitle,
            slug: req.body.blogslug,
            description: req.body.description,
            meta_tags: tags,
          }
        );
        }
        res.redirect("/blogs");
    } catch (error) {
      next(error);
    }
};

  exports.update_blog = async function (req, res, next) {
    try {
      
      if(req.session.USERTYPE!=1){
        res.status(403).redirect('/')
      }
      else{
        let blogDetails = await db.query(`select * from blog_tbl where id=:id`, {
          id: req.params.id,
        });

        console.log(blogDetails);
        blogDetails = blogDetails[0];
        res.render("update_blog", {
          blogDetails: blogDetails,
          id: req.params.id,
        });
      }
    }
    catch{
      next(error);
    }
  };

  exports.blog_publish = async function (req, res, next) {
    
    try {
      if(req.session.USERTYPE!=1){
        res.status(403).redirect('/')
      }
      else{
      await db.query(`update blog_tbl set status=1 where id=${req.params.id}`);

      res.send({ status: true, msg: "blog is published" });
      }
    } catch (error) {
      next(error);
    }
  };

  exports.blog_unpublish = async function (req, res, next) {
    try {
      if(req.session.USERTYPE!=1){
        res.status(403).redirect('/')
      }
      else{
      await db.query(`update blog_tbl set status=2 where id=${req.params.id}`);

      res.send({ status: true, msg: "blog is published" });
      }
    } catch (error) {
      next(error);
    }
  };
