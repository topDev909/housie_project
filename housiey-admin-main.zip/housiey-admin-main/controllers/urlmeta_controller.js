
exports.getAllurl = async function(req,res,next){
    
    try {

        if(req.session.USERTYPE!=1){
            res.status(403).redirect('/')
          }
        else{
        let urls = await db.query(`select * from urlmeta_tbl order by id desc`);

        console.log("ur;ssss", urls);
        res.render('allurl',{
            allurls:urls
        });
       }
    } catch (error) {
       next(error);   
    }
}

exports.setMeta = async function(req,res,next){

    try {
        if(req.session.USERTYPE!=1){
            res.status(403).redirect('/')
          }
        else{
        let failed = req.flash("failed");
          let success = req.flash("success");
         res.render('set_urlmeta',{
            success: success,
            failed: failed,
         });
        }
    } catch (error) {
        next(error)
    }
    
}

exports.submit_urlmeta = async function (req, res, next) {
    try {
      if(req.session.USERTYPE!=1){
        res.status(403).redirect('/')
      }
      else{
      let checkurl = db.query(
        `select count(*) from  urlmeta_tbl where url=:url `,
        { url: req.body.url}
      );

      if (checkurl.length > 0) {
        req.flash("failed", "Meta already exist for this url.");
        res.redirect("/setURLmeta/create");
      } else {
        let tags = "";
        let meta_tags = "";

        if(req.body.meta_tags.length>0){
          meta_tags = JSON.parse(req.body.meta_tags);
        
        console.log(meta_tags);
        for (let i = 0; i < meta_tags.length; i++) {
          if (i<=meta_tags.length - 2) 
           tags += meta_tags[i].value + ",";
          else tags += meta_tags[i].value;
        }
      }

      // console.log(req.body);
        if(req.file == undefined){
          db.query(
            `insert into urlmeta_tbl (url,title,description,meta_tags,alttag) values (:url,:title,:description,:meta_tags,:alt_tag)`,
            {
              url: req.body.url,
              title: req.body.urltitle,
              description: req.body.description,
              meta_tags: tags,
              alt_tag: req.body.alttag,
            }
          );
        }
        else{
          let filename = req.file.filename;
        db.query(
          `insert into urlmeta_tbl (url,title,description,meta_tags,image,alttag) values (:url,:title,:description,:meta_tags,'${filename}',:alt_tag)`,
          {
            url: req.body.url,
            title: req.body.urltitle,
            description: req.body.description,
            meta_tags: tags,
            alt_tag: req.body.alttag,
          }
        );
        }
        res.redirect("/setURLmeta");
      }
    }
    } catch (error) {
      next(error);
    }
  };


  exports.edit_urlmeta = async function (req, res, next) {
    try {
      
      if(req.session.USERTYPE!=1){
        res.status(403).redirect('/')
      }
      else{
        let urlDetails = await db.query(`select * from urlmeta_tbl where id=:id`, {
          id: req.params.id,
        });

        console.log(urlDetails);
        urlDetails = urlDetails[0];
        res.render("editurlmeta", {
          urlDetails: urlDetails,
          id: req.params.id,
        });
      }
    }
    catch{
      next(error);
    }
  };

  exports.submit_editedurlmeta = async function(req, res, next){
    try {
      
        let tags = "";
        let meta_tags = "";

        if(req.body.meta_tags.length>0){
          meta_tags = JSON.parse(req.body.meta_tags);
        
        console.log(meta_tags);
        for (let i = 0; i < meta_tags.length; i++) {
          if (i<=meta_tags.length - 2) 
           tags += meta_tags[i].value + ",";
          else tags += meta_tags[i].value;
        }
      }
        if(req.file == undefined){
          db.query(
            `update urlmeta_tbl set title=:title, url=:url, description=:description, meta_tags=:meta_tags,alttag=:alttag where id=${req.params.id} `,
            {
              title: req.body.urltitle,
              url: req.body.url,
              description: req.body.description,
              meta_tags: tags,
              alttag: req.body.alttag,
            }
          );
        }
        else{
          let filename = req.file.filename;

    
        db.query(
          `update urlmeta_tbl set title=:title, url=:url, description=:description, meta_tags=:meta_tags,alttag=:alttag, image='${filename}' where id=${req.params.id} `,
          {
            title: req.body.urltitle,
            slug: req.body.url,
            description: req.body.description,
            meta_tags: tags,
            alttag: req.body.alttag,
          }
        );
        }
        res.redirect("/setURLmeta");
    } catch (error) {
      next(error);
    }
};


exports.delete_url = async function(req,res,next){
    try {
        await db.query(`delete from urlmeta_tbl where id=${req.params.id}`)     
        res.send({"res":true, "msg": "successfuly deleted"});
    } catch (error) {
        next(error);
    }
};