const express = require('express');
const router = express.Router();
const fileUpload = require("../config/multerDep");

const {setMeta,submit_urlmeta,edit_urlmeta,submit_editedurlmeta,getAllurl,delete_url} = require('../controllers/urlmeta_controller');


router.get('/',getAllurl);
router.get('/create', setMeta);
router.post('/submit',fileUpload.single('urlimage'),submit_urlmeta);
router.get('/update/:id',edit_urlmeta);
router.post('/update_submit/:id',fileUpload.single('urlimage'),submit_editedurlmeta);
router.get('/delete/:id',delete_url)


module.exports = router;