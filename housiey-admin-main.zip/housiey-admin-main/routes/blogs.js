const express = require("express");
const fileUpload = require("../config/multerDep");
const { create_blog,submit_blog,allblogs,update_blog,submit_edited,blog_publish,blog_unpublish } = require("../controllers/blogs_controller");
const router = express.Router();

router.get('/',allblogs)
router.get('/create',create_blog);
router.get('/update/:id',update_blog);
router.post('/update_submit/:id',fileUpload.single('blogimage'),submit_edited);
router.get('/publish/:id',blog_publish)
router.get('/unpublish/:id',blog_unpublish)
router.post('/submit',fileUpload.single('blogimage'),submit_blog);

module.exports = router;