import React from 'react';
import FormComponent from "./component/FormComponent";
import { useState, useEffect } from "react"
const Project_modal = ({  select_projectname}) => {
    
    const [data, setData]           = useState([])
    const [getProjects, products]   = useState([]);

   
    useEffect(()=>{
    },[])
    
  return (
      <>
          <div
              className="modal fade"
              id="Project_modal"
              tabIndex={-1}
              role="dialog"
              aria-labelledby="registermodal"
              aria-hidden="true"
          >
              <div className="modal-dialog modal-xl login-pop-form" role="document">
                  <div className="modal-content overli" id="registermodal" style={{ width: "60%", marginLeft: "10rem" }}>
                      <div className="modal-body p-0">
                          <div className="resp_log_wrap">
                              <div className="resp_log_caption col">
                                  <span className="mod-close" data-dismiss="modal" aria-hidden="true">
                                      <i className="ti-close" />
                                  </span>
                                  <div className="edlio_152">
                                      <ul
                                          className="nav nav-pills tabs_system center"
                                          id="pills-tab"
                                          role="tablist">
                                      </ul>
                                  </div>
                                  <div className="tab-content" id="pills-tabContent">
                                      <div
                                          className="tab-pane fade show active"
                                          id="pills-login"
                                          role="tabpanel"
                                          aria-labelledby="pills-login-tab">
                                          <div className="login-form">
                                              <FormComponent seldata={select_projectname}/>
                                          </div>
                                      </div>
                                      <div
                                          className="tab-pane fade"
                                          id="pills-signup"
                                          role="tabpanel"
                                          aria-labelledby="pills-signup-tab">
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </>
  )
};

export default Project_modal;
