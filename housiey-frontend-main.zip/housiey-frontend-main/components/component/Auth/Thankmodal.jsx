/* eslint-disable @next/next/no-sync-scripts */
import React,{ useState, useEffect } from "react"
import { useRouter } from 'next/router';
import Youramount from "./Youramount";
import SignUpParks from "./SignUpParks";
import { useDispatch,useSelector } from "react-redux";


const Thankmodal = () => {
    const dispatch              = useDispatch();
    const formTitle             = useSelector((state)=>state.signUpModal.signup_title)

    const rangeslider = () => {
        $('#thankyou').modal('hide')
        $('#ammount').modal('show')
    }

 const router = useRouter()

     const check_url =()=>{
        let modal_type = localStorage.getItem("modal_type");
        router.reload(window.location.reload)
    } 
    // 917428730894

    
  return <>
      <div
          className="modal fade"
          id="thankyou"
          tabIndex={-1}
          role="dialog"
          aria-labelledby="thank-you-modal"
          aria-hidden="true"
          data-backdrop="static"
          data-keyboard="false"
          >
          <div className="modal-dialog modal-xl-x login-pop-form" role="document">
              <div className="modal-content overli" >
                  <div className="modal-body p-0">
                  <span className="mod-close" aria-hidden="true" onClick={check_url}>
                      <i className="ti-close" />
                    </span>

                    <SignUpParks/>
                      
                  </div>
              </div>
          </div>
      </div>

      <Youramount/>

  </>
};

export default Thankmodal;


