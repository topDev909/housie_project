/* eslint-disable react/no-unknown-property */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable @next/next/no-sync-scripts */
//validation file start//
import React, { useEffect,useState,useRef } from 'react';
import 'react-phone-number-input/style.css';
import PhoneInput from 'react-phone-number-input';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup                     from 'yup';

import { useDispatch, useSelector } from "react-redux";
import { useRouter }                from 'next/router';
import { select_project }           from '../../../redux/slices/projectsSlice';
import { set_mobile_number,set_modal_state,set_sent_otp,set_thank_u_modal,set_first_time_login,set_show_sign_up_perks,set_open_download_signup } from '../../../redux/slices/signUpModalSlice';

import {set_download_modal} from '../../../redux/slices/MobileSignUpModalSlice';
const DownloadSignUpForm = () => {

    const dispatch                  = useDispatch();
    const router                    = useRouter();
    const modal_step                = useSelector((state)=>state.signUpModal.signUpModalStep)
    const reduxMobile               = useSelector((state)=>state.signUpModal.mobileNumber)
    const thank_modal               = useSelector((state)=>state.signUpModal.show_thanku_modal)
    const downloadFile              = useSelector((state)=>state.signUpModal.downloadFile)
    const download_file_name        = useSelector((state)=>state.signUpModal.download_file_name)
    const is_download               = useSelector((state)=>state.signUpModal.is_login_download)
    const page_type                 = useSelector((state)=>state.signUpModal.page_type)
    const enq_project_id            = useSelector((state)=>state.signUpModal.enq_project_id)
    const SignUpTitle               = useSelector((state)=>state.signUpModal.signup_title)
    const btnTitle                  =  (SignUpTitle!=='video') ? " Download " + SignUpTitle :  " Watch Full Video";


    let time_id                     = useRef();
    const sentOtpcheck              = useSelector((state)=>state.signUpModal.start_sent_otp)

    const [field, setField]         = useState('')
    const [mobile, setMobile]       = useState('')
    const [otpnum, setOtpnum]       = useState('')
    const [checkotp, setCheckotp]   = useState('')
    const [name, setName]           = useState('')
    const [email, setEmail]         = useState('')
    const [otperror, setOtperror]   = useState('')
    const [title, setTitle]         = useState(false)
    const [formErr,setFormErr]      = useState('');
    const [isNumberDisable,setIsNumberDisable] = useState(false);
    const [viewExtraFields,setViewExtraFeilds] = useState(true);

    const Ref = useRef(null);
  
    // The state for our timer
    const [timer, setTimer] = useState(30);

    const getNumberOnchange = (e) => {
        setMobile(e)
        dispatch(set_mobile_number(e))
    }


    


    // validation start//

    const validationSchema = Yup.object().shape({
        firstName: Yup.string()
            .matches(/^[aA-zZ\s]+$/, "Only alphabets are allowed for this field ")
            ,
        email: Yup.string()
        .email('Email is invalid')
        .required('Email is required'),

        otp: Yup.string()
            .required('OTP is required')
            .min(6, 'Password must be at least 6 characters')
            .matches(
                /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/, "Only Number are allowed for this field")
    });

    const formOptions = { resolver: yupResolver(validationSchema) };
    const { register, handleSubmit, reset, formState } = useForm(formOptions);
    const { errors } = formState;
    let baseUrl      = process.env.BASE_URL;

    // Generate Otp//
    const validate = async () => {
        if (mobile && mobile.length) {
            SendOTPFn();
        }
        else{
            setField('')
            setTitle(false)
        }
    }

    // singup for free 
    useEffect(() => {
        if(sentOtpcheck){
            dispatch(set_modal_state(false))
            setField('')
            setTitle(false)
            SendOTPFn();
            dispatch(set_sent_otp(false))
        }
    }, [sentOtpcheck])


    
    const SendOTPFn = async ()=>{
        let send_mobile = reduxMobile;
        if (send_mobile) {
            let obj = {
                mobile: send_mobile
            }
            let send_res = await fetch(baseUrl + "signup", {
                method: 'POST',
                headers: {
                    "Content-Type": 'application/json'
                },
                body: JSON.stringify(obj)
            })

            if (send_res.ok) {
                let res_result = await send_res.json();
                if(res_result.res===true){
                    setOtpnum(res_result.data.otp)
                    setCheckotp(res_result.data.otp)
                    setTitle(true)
                    setMobile(send_mobile)
                    dispatch(set_modal_state(true))
                    setIsNumberDisable(true)
                    if(res_result.data.name && res_result.data.email){
                        setViewExtraFeilds(res_result.signup_status)
                    }else{
                        setViewExtraFeilds(1)
                    }
            

                    if(res_result.signup_status===0){
                        setName(res_result.data.name)
                        setEmail(res_result.data.email)
                        dispatch(set_thank_u_modal(false));
                        dispatch(set_show_sign_up_perks(true));
                    }else{
                        setName('')
                        setEmail('')
                        dispatch(set_thank_u_modal(true));
                        dispatch(set_show_sign_up_perks(false));
                    }

                    let i = 30;
                    
                    clearInterval(time_id.current);

                     time_id.current = setInterval(() => {
                        i = i-1;
                        setTimer(i);
                        if(i <= 0){
                            clearInterval(time_id.current);
                        }
                    }, 1000); 
                    

                }else{
                    setFormErr(res_result.msg);
                    setField('')
                    setTitle(false)
                    dispatch(set_modal_state(false))
                    setIsNumberDisable(false)
                }

                hideMsg();
            }
        }
        else {
            
        }
    }

    // verify Otp and Validation submit-form
    const onSubmit = async (e) => {
        e.preventDefault();
        let field = {
            "name":      name,
            "email":     email,
            "otp":       checkotp,
            "mobile":    mobile,
            "is_signup": viewExtraFields,
            "page_type":  page_type,
            "project_id": enq_project_id
        }

        if(!checkotp || checkotp==='undefined'){
            setFormErr('Please Fill OTP')
            return;
        }

        if(!name || name==='undefined'){
            setFormErr('Please Fill Full-Name')
            return;
        }
        if(!email || email==='undefined'){
            setFormErr('Please Fill Email')
            return;
        }


        let check = await fetch(baseUrl + "verify-otp", {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(field)
        })



        if (check.ok) {
            let check_result = await check.json();
            if (check_result.res === true) {
                localStorage.setItem('housey_token', check_result.token);
                let modal_type = localStorage.getItem('modal_type');
                    modal_type = (modal_type) ? modal_type : '';

                    if(is_download){
                        let downloadUrl = `/api/download?link=${downloadFile}&name=${download_file_name}`;
                        await router.push(downloadUrl);
                        $('#login').modal('hide');
                        $('#download-content-modal').modal('hide');

                        let sendEnq = process.env.BASE_URL+`download-doc/${enq_project_id}`;
                        let req     = await fetch(sendEnq,{
                            headers: {
                                auth: check_result.token
                            }
                        });


                        dispatch(set_open_download_signup(false))
                        dispatch(set_first_time_login(true));
                        if(thank_modal){
                            $('#DownloadThankYou').modal('show');
                            dispatch(set_download_modal(true))
                            dispatch(set_show_sign_up_perks(true));
                        }else{
                            $('#DownloadThankYou').modal('show');
                            dispatch(set_download_modal(true))

                            dispatch(set_show_sign_up_perks(false));
                        }
                    }else if(thank_modal){
                        $('#thankyou').modal('show')
                        $('#login').modal('hide')
                    }else{
                        router.reload(window.location.reload)
                    } 
                    
                
            } else {
                setOtperror(check_result.msg)
            }
            hideMsg();
        }
        else {

            return false

        }

    }
    // validation End

    const makeMobileEdit = ()=>{
        setIsNumberDisable(false);
        dispatch(set_sent_otp(false))
        dispatch(set_modal_state(false));
        // if(time_id){
            clearInterval(time_id.current);
        // }
    }
    const closeTag = () => {
        setField('')
        setName('')
        setEmail('')
        setCheckotp('')
        setTitle(false)
        setMobile('')
        dispatch(select_project([]))
        dispatch(set_mobile_number(''))
        dispatch(set_sent_otp(false))
        setIsNumberDisable(false)
        setFormErr('');
        clearInterval(time_id.current);
        localStorage.removeItem('modal_type');
    }


    const hideMsg = ()=>{
        setTimeout(() => {
            setFormErr('')
        }, 3000);
    }

    return (
        <>


<div className="resp_log_caption p-0">
                                    

                                    {/* <div className="edlio_152">
                                        <ul
                                            className="nav nav-pills tabs_system center"
                                            id="pills-tab"
                                            role="tablist">
                                        </ul>
                                    </div> */}
                                    {/* <div className="tab-content" id="pills-tabContent"> */}
                                        {/* <h6 className='text-center' style={{ color: '#234e70' }}>Sign Up Form</h6> */}
                                        {/* <div
                                            className="tab-pane fade show active"
                                            id="pills-login"
                                            role="tabpanel"
                                            aria-labelledby="pills-login-tab"
                                        > */}
                                            <div className="login-form">
                                                {formErr && <>
                                                    <div className="alert alert-danger" >
                                                        {formErr}    
                                                    </div> 
                                                </>}
                                                <form onSubmit={onSubmit}>

                                                    <div className="form-group">
                                                        <div className="input-with-icon">
                                                        <PhoneInput
                                                            placeholder="Enter phone number"

                                                            disabled={isNumberDisable}
                                                            countryCallingCodeEditable={false}
                                                            defaultCountry="IN"
                                                            style={{ border: "1px solid #e7eaf1" }}
                                                            className="form-control-mobile-input"
                                                            onChange={getNumberOnchange}
                                                            value={reduxMobile}
                                                        />
                                                                {/* isNumberDisable,setIsNumberDisable */}
                                                            {isNumberDisable && <>
                                                                <p className="resend-otp" style={{ top:'0px' }} >
                                                                    <button className="btn btn-default bg-transparent p-0 text-dark m-0 resend-btn" type="button" onClick={makeMobileEdit}  >Edit</button>
                                                                </p>
                                                            </>}
                                                            
                                                        </div>

                                                    </div>
                                                    

                                                    {(modal_step) ? <>
                                                                <>
                                                                    <div className="form-group">
                                                                        
                                                                        <div className="input-with-icon " style={{marginBottom: "-20px"}}>
                                                                            <input type="text"
                                                                                name='otp'
                                                                                value={checkotp}
                                                                                className={`form-control ${errors.otp ? 'is-invalid' : ''}`}
                                                                                placeholder='Enter OTP'
                                                                                onChange={(e) => setCheckotp(e.target.value)}
                                                                            />
                                                                            <i className="ti-key"></i>

                                                                            <p className="resend-otp" >
                                                                            {timer <=0 ? 
                                                                                <>
                                                                                <button className="btn btn-default bg-transparent p-0 text-dark m-0 resend-btn" type="button" onClick={SendOTPFn}  >
                                                                                    Resend OTP
                                                                                </button>
                                                                                </>
                                                                            : 
                                                                            <>
                                                                                Wait {timer} Sec
                                                                            </>
                                                                            }
                                                    
                                                                                
                                                                            </p>
                                                                            <div className="invalid-feedback">{errors.otp?.message}</div>
                                                                            <span className='text-danger' style={{ float:'left' }} >{otperror}</span>
                                                                        </div>
                                                                    </div>

                                                                            
                                                                            {/* <h1>Here we are : {viewExtraFields}</h1> */}

                                                                            {viewExtraFields===1 ?<>
                                                                                <div className="form-group"  >
                                                                                    <div className="input-with-icon my-icon">
                                                                                        <input type="text"
                                                                                            autoComplete='off'
                                                                                            name='firstName'
                                                                                            value={name} 
                                                                                            className={`form-control ${errors.firstName ? 'is-invalid' : ''}`}
                                                                                            placeholder='Enter Name'
                                                                                            onChange={(e) => setName(e.target.value)}
                                                                                        />
                                                                                        <i className="ti-user" />
                                                                                        <div className="invalid-feedback">{errors.firstName?.message}</div>
                                                                                    </div>

                                                                                </div>

                                                                                <div className="form-group"  >
                                                                                    <div className="input-with-icon ">
                                                                                        <input type="email"
                                                                                            name='email'
                                                                                            autoComplete='off'
                                                                                            value={email}
                                                                                            className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                                                                                            placeholder='Enter Email'
                                                                                            onChange={(e) => setEmail(e.target.value)}
                                                                                        />
                                                                                        <i className="ti-email" />
                                                                                        <div className="invalid-feedback">{errors.email?.message}</div>
                                                                                    </div>
                                                                                </div>    
                                                                            </> : '' }
                                                                            {/* <input type="hidden" name="is_sign_up" value={viewExtraFields} /> */}
                                                                        
                                                                    
                                                                    <div className="form-group ">
                                                                        <button type="submit" className="btn btn-md full-width pop-login">
                                                                            {SignUpTitle !=='video' ? <> <i className="fa fa-download fa-bounce" style={{ fontSize: 12, marginRight: 2 }} />
                                                                            </> : ""}
                                                                         {btnTitle ?  btnTitle  :'Sign-Up'}
                                                                        </button>
                                                                    </div>

                                                                </>

                                                            </> :
                                                                <>
                                                                    <div className="form-group ">
                                                                        <button
                                                                            onClick={validate}
                                                                            type="button"
                                                                            className="btn btn-md full-width pop-login"
                                                                        >
                                                                            Continue
                                                                        </button>
                                                                    </div>
                                                                </>
                                                            }

                                                    {/* <div className="form-group text-center">
                                                        By Continuing, you agree to our
                                                        <a href="#"> Terms &amp; Conditions</a>
                                                    </div> */}

                                                </form>
                                            </div>
                                        {/* </div> */}
                                    {/* </div> */}
                                </div>

            {/* modal */}
            {/* <Thankmodal  /> */}

        </>
    )
};

export default DownloadSignUpForm;
