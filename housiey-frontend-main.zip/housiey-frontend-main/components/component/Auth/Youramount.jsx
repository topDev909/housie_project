import React from 'react'
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import NativeSelect from '@mui/material/NativeSelect';
import Typography from '@mui/material/Typography';
import Slider from '@mui/material/Slider';
import { useRouter } from 'next/router';


// Slider function start
function valueLabelFormat(value) {
    const units  = ['laks', 'Cr'];
    

    let unitIndex = 0;
    let scaledValue = value;

   

    unitIndex = 0;
    if (scaledValue === 100){
        unitIndex = 1;
        scaledValue = 1;
    }

    return `${scaledValue} ${units[unitIndex]}`;
}

function calculateValue(value) {
    return value;
}




const Youramount = () => {
    const router = useRouter();
    
    const CloseModal = ()=>{
        $('#ammount').modal('hide');
        router.reload(window.location.reload)
    }
    
    
    const [value, setValue]   = React.useState(10);
    const [getBonus,setBonus] = React.useState([]);
    const handleChange = (event, newValue) => {
        if (typeof newValue === 'number') {
            setValue(newValue);

            let main_price  = newValue;
            // let five_percent_price_nigative = main_price - (main_price * 5 / 100)
            let five_percent_price_nigative = main_price - 5 
            let five_percent_price_positive = main_price + 5
            // let five_percent_price_positive = main_price + (main_price * 5 / 100) 

            let arr = [five_percent_price_nigative * 10 / 100, five_percent_price_positive * 10 / 100 ];
            setBonus(arr)
        }
    };

// sider function End
  return (
    <>
          <div
              className="modal fade m"
              id="ammount"
              tabIndex={-1}
              role="dialog"
              aria-labelledby="know-your-bonus-modal"
              aria-hidden="true"
              data-backdrop="static"
              data-keyboard="false"
          >
              <div className="modal-dialog   ammount-pop-form" role="document">
                  <div className="modal-content overli" id="know-your-bonus-modal" >
                      <div className="modal-body p-0" style={{padding: "1em 2em"}}>
                        <div>
                        <div className="modal-header">
                            <h5 className="modal-title">Know Your Exact Amount</h5>
                            <button type="button" className="close" onClick={CloseModal}>
                            <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div className="modal-body">

                                  <Box sx={{ minWidth: '100%' }}>
                                      <FormControl style={{width:'100%'}}>
                                          <InputLabel variant="standard" htmlFor="uncontrolled-native">
                                              Select Config
                                          </InputLabel>
                                          <NativeSelect
                                              defaultValue={10}
                                              style={{marginTop: "20px"}}
                                              inputProps={{
                                                  name: 'Property',
                                                  className: 'select-property-type',
                                              }}
                                              
                                          >
                                              <option value={10}>1BHK</option>
                                              <option value={20}>2BHK</option>
                                              <option value={30}>3BHK</option>
                                          </NativeSelect>
                                      </FormControl>
                                  </Box>

                                  {/* Dropdown End */}

                                    <br />
                                  {/* slider start*/}
                                  <Box sx={{ minWidth: '100%' }}>
                                  <InputLabel variant="standard" htmlFor="uncontrolled-native" style={{fontSize: "0.75rem"}}>
                                              Estimated Budget
                                          </InputLabel>
                                    
                                      <Slider
                                          value={value}
                                          min={10}
                                          step={1}
                                          max={100}
                                          scale={calculateValue}
                                          getAriaValueText={valueLabelFormat}
                                          valueLabelFormat={valueLabelFormat}
                                          onChange={handleChange}
                                          valueLabelDisplay="on"
                                          aria-labelledby="non-linear-slider"
                                      />
                                  </Box>
                                  

                        </div>
                        <div className="modal-footer-2" style={{border: "1px solid #eee"}}>
                            {getBonus.length > 0 && <>
                                <h6 className="text-center" style={{fontSize: "18px"}}  >
                                    Your Sign-Up Bonus will be:<br/>
                                
                                    <b>{getBonus[0]} Lac  To {getBonus[1]} Lac </b>
                                </h6>
                            </>}
                          
                        </div>
                        </div>

                      </div>
                  </div>
              </div>
          </div>

    </>
  )
}

export default Youramount