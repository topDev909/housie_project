import React from 'react';
import Confetti from 'react-confetti'

const SignUpParks = ()=>{
    return (
        <div id="thank-you-modal">


                <Confetti width={'500px'} />

            <div className="text-center mt-3">
                        <img src="/assets/img/gift.png" width={35} style={{marginBottom: "10px"}} />
                        <h2 className="thank-modal-heading" style={{lineHeight: "0.3",fontSize: "1.3rem"}} >Congratulations,</h2>
                        <p style={{fontSize: "18px"}}>you have successfully <span style={{color: "#0e8744"
                    }}>Sign Up</span></p>
                    <hr></hr>
                    </div>
                    <div className="text-center" style={{margin: "15px"}}>
                        <span className='my_text_signup' style={{fontSize: "15px", background: "#0e8744", padding: "10px", color: "#fff", borderRadius: "50px"}}>Enjoy your exclusive Sign Up Perks</span>
                    </div>
                    

                  <div className="row justify-content-center" id="modal-boxss">
                    <div className="col-lg-3 col-md-6 col-sm-12">
                        <div className="wpk_process">
                        <div className="wpk_thumb">
                            <div className="wpk_thumb_figure">
                            <img src="/assets/img/bonus.svg" className="" alt="" />
                            </div>
                        </div>
                        <div className="wpk_caption">
                            <h4>Referral Bonus
Refer Housiey &#38; get bonus upto Rs 2lac</h4>
                        </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-md-6 col-sm-12">
                        <div className="wpk_process active">
                        <div className="wpk_thumb">
                            <div className="wpk_thumb_figure">
                            <img src="/assets/img/free-cab.svg" className="" alt="" />
                            </div>
                        </div>
                        <div className="wpk_caption">
                            <h4>Free Site Visit</h4>
                        </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-md-6 col-sm-12">
                        <div className="wpk_process">
                        <div className="wpk_thumb">
                            <div className="wpk_thumb_figure">
                            <img src="/assets/img/bottom-rate.svg" className="" alt="" />
                            </div>
                        </div>
                        <div className="wpk_caption">
                            <h4>Bottom Rate Guarantee</h4>
                        </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-md-6 col-sm-12">
                        <div className="wpk_process">
                        <div className="wpk_thumb">
                            <div className="wpk_thumb_figure">
                            <img src="/assets/img/manager.svg" className="" alt="" />
                            </div>
                        </div>
                        <div className="wpk_caption">
                            <h4>Relationship Manager</h4>
                        </div>
                        </div>
                    </div>
                  </div>

        </div>
    )
}
export default SignUpParks