import React, { useEffect,useState,useRef } from 'react';
import 'react-phone-number-input/style.css';
import PhoneInput from 'react-phone-number-input';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup                     from 'yup';

import { useDispatch, useSelector } from "react-redux";
import { useRouter }                from 'next/router';
import { select_project }           from '../../../redux/slices/projectsSlice';
import { set_mobile_number,set_modal_state,set_sent_otp,set_thank_u_modal,set_enq_data} from '../../../redux/slices/signUpModalSlice';


const SignUpForm  = ()=>{

    const dispatch    = useDispatch();
    const router      = useRouter();
    const modal_step  = useSelector((state)=>state.signUpModal.signUpModalStep)
    const reduxMobile = useSelector((state)=>state.signUpModal.mobileNumber)
    // const reduxMobile = useSelector((state)=>state.signUpModal.set_sent_otp)
    let time_id;
    const sentOtpcheck = useSelector((state)=>state.signUpModal.start_sent_otp)
    const enq_data     = useSelector((state)=>state.signUpModal.enq_data)

    
        let baseUrl      = process.env.BASE_URL;
        // const baseUrl      = 'http://185.227.134.103:9001/api/';

    const [field, setField]         = useState('')
    const [mobile, setMobile]       = useState('')
    const [otpnum, setOtpnum]       = useState('')
    const [checkotp, setCheckotp]   = useState('')
    const [name, setName]           = useState('')
    const [email, setEmail]         = useState('')
    const [otperror, setOtperror]   = useState('')
    const [title, setTitle]         = useState(false)
    const [formErr,setFormErr]      = useState('');
    const [isNumberDisable,setIsNumberDisable] = useState(false);
    const [viewExtraFields,setViewExtraFeilds] = useState(true);
    const [isFormLoad,setFormLoad]             = useState(false); 

    const Ref = useRef(null);
  
    // The state for our timer
    const [timer, setTimer] = useState(30);

    const getNumberOnchange = (e) => {
        setMobile(e)
        dispatch(set_mobile_number(e))
    }


    


    // validation start//

    const validationSchema = Yup.object().shape({
        firstName: Yup.string()
            .matches(/^[aA-zZ\s]+$/, "Only alphabets are allowed for this field "),
        email: Yup.string()
        .email('Email is invalid')
        .required('Email is required'),

        otp: Yup.string()
            .required('OTP is required')
            .min(6, 'Password must be at least 6 characters')
            .matches(
                /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/, "Only Number are allowed for this field")
    });

    const formOptions = { resolver: yupResolver(validationSchema) };
    const { register, handleSubmit, reset, formState } = useForm(formOptions);
    const { errors } = formState;

    // Generate Otp//
    const validate = async () => {
        console.log(mobile)
        if (mobile && mobile.length) {
            SendOTPFn();
        }
        else{
            setField('')
            setTitle(false)
        }
    }

    // singup for free 
    useEffect(() => {
        if(sentOtpcheck){
            dispatch(set_modal_state(false))
            setField('')
            setTitle(false)
            SendOTPFn();
            dispatch(set_sent_otp(false))
        }
    }, [sentOtpcheck])



    
    const SendOTPFn = async ()=>{
        let send_mobile = reduxMobile;
        if (send_mobile) {
            let obj = {
                mobile: send_mobile
            }
            let send_res = await fetch(baseUrl + "signup", {
                method: 'POST',
                headers: {
                    "Content-Type": 'application/json'
                },
                body: JSON.stringify(obj)
            })

            if (send_res.ok) {
                let res_result = await send_res.json();
                if(res_result.res===true){
                    setOtpnum(res_result.data.otp)
                    setCheckotp(res_result.data.otp)
                    setTitle(true)
                    setMobile(send_mobile)
                    dispatch(set_modal_state(true))
                    setIsNumberDisable(true)
                    if(res_result.data.name && res_result.data.email){
                        setViewExtraFeilds(res_result.signup_status)
                    }else{
                        setViewExtraFeilds(1)
                    }
            

                    if(res_result.signup_status===0){
                        setName(res_result.data.name)
                        setEmail(res_result.data.email)
                        dispatch(set_thank_u_modal(false));
                    }else{
                        setName('')
                        setEmail('')
                        dispatch(set_thank_u_modal(true));
                    }

                    let i = 30;
                    
                  /*   if(time_id){
                        clearInterval(time_id);
                    }

                     time_id = setInterval(() => {
                        i = i-1;
                        console.log('Here we are Now')
                        setTimer(i);
                        if(i <= 0){
                            clearInterval(time_id);
                        }
                    }, 1000); */

                }else{
                    setFormErr(res_result.msg);
                    setField('')
                    setTitle(false)
                    dispatch(set_modal_state(false))
                    setIsNumberDisable(false)
                }

                hideMsg();
            }
        }
        else {
            
        }
    }

    // verify Otp and Validation submit-form
    const onSubmit = async (e) => {
        setFormLoad(true)
        e.preventDefault();
        let field = {
            "name":      name,
            "email":     email,
            "otp":       checkotp,
            "mobile":    mobile,
            "is_signup": viewExtraFields
        }

        if(!checkotp || checkotp==='undefined'){
            setFormErr('Please Fill OTP')
            return;
        }

        if(!name || name==='undefined'){
            setFormErr('Please Fill Full-Name')
            return;
        }
        if(!email || email==='undefined'){
            setFormErr('Please Fill Email')
            return;
        }


        // check enq data


        // console.log(JSON.stringify(field));
        let check = await fetch(baseUrl + "verify-otp", {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(field)
        })



        if (check.ok) {
            let check_result = await check.json();
            if (check_result.res === true) {
                localStorage.setItem('housey_token', check_result.token);
                let modal_type = localStorage.getItem('modal_type');
                    modal_type = (modal_type) ? modal_type : ''

                    if (modal_type === 'ola_modal') {
                        $('#olamodal').modal('show');
                        $('#login').modal('hide');
                        return;
                    }
                    else if(viewExtraFields){
                        $('#thankyou').modal('show')
                        $('#login').modal('hide')
                        return;
                    }else{
                        // router.reload(window.location.reload)
                    }
                
            } else {
                setOtperror(check_result.msg)
            }
            hideMsg();
        }
        else {

            return false

        }

    }
    // validation End

    const makeMobileEdit = ()=>{
        setIsNumberDisable(false);
        dispatch(set_sent_otp(false))
        dispatch(set_modal_state(false));
    }

    const closeTag = () => {
        setField('')
        setName('')
        setEmail('')
        setCheckotp('')
        setTitle(false)
        setMobile('')
        dispatch(select_project([]))
        dispatch(set_mobile_number(''))
        dispatch(set_sent_otp(false))
        setIsNumberDisable(false)
        setFormErr('');
        if(time_id){
            clearInterval(time_id);
        }
        localStorage.removeItem('modal_type');
    }


    const hideMsg = ()=>{
        setTimeout(() => {
            setFormErr('')
        }, 3000);
    }

    const save_enq = ()=>{
        // set_enq_data

    }

    return (
        <>
           <div className="login-form">
                {formErr && <>
                    <div className="alert alert-danger" >
                        {formErr}    
                    </div> 
                </>}
                <form onSubmit={onSubmit}>
                    <div className="form-group">
                        <div className="input-with-icon">
                        <PhoneInput
                            placeholder="Enter phone number"
                            disabled={isNumberDisable}
                            countryCallingCodeEditable={false}
                            defaultCountry="IN"
                            style={{ border: "1px solid #e7eaf1" }}
                            className="form-control"
                            onChange={getNumberOnchange}
                            value={reduxMobile}
                            autoComplete={'off'}
                        />
                                {/* isNumberDisable,setIsNumberDisable */}
                            {isNumberDisable && <>
                                <p className="resend-otp" style={{ top:'0px' }} >
                                    <button className="btn btn-default bg-transparent p-0 text-dark m-0 resend-btn" type="button" onClick={makeMobileEdit}  >Edit</button>
                                </p>
                            </>}
                            
                        </div>

                    </div>
                    

                    {(modal_step) ? <>
                                <>
                                    <div className="form-group">
                                        
                                        <div className="input-with-icon " style={{marginBottom: "-20px"}}>
                                            <input type="text"
                                                name='otp'
                                                value={checkotp}
                                                className={`form-control ${errors.otp ? 'is-invalid' : ''}`}
                                                placeholder='Enter OTP'
                                                onChange={(e) => setCheckotp(e.target.value)}
                                            />
                                            <i className="ti-key"></i>

                                            <p className="resend-otp" >
                                            {timer <=0 ? 
                                                <>
                                                <button className="btn btn-default bg-transparent p-0 text-dark m-0 resend-btn" type="button" onClick={SendOTPFn}  >
                                                    Resend OTP
                                                </button>
                                                </>
                                            : 
                                            <>
                                                Wait {timer} Sec
                                            </>
                                            }
                    
                                                
                                            </p>
                                            <div className="invalid-feedback">{errors.otp?.message}</div>
                                            <span className='text-danger'>{otperror}</span>
                                        </div>
                                    </div>

                                            
                                            {/* <h1>Here we are : {viewExtraFields}</h1> */}

                                            {viewExtraFields===1 ?<>
                                                <div className="form-group"  >
                                                    <div className="input-with-icon my-icon">
                                                        <input type="text"
                                                            autoComplete='off'
                                                            name='firstName'
                                                            value={name} 
                                                            className={`form-control ${errors.firstName ? 'is-invalid' : ''}`}
                                                            placeholder='Enter Name'
                                                            onChange={(e) => setName(e.target.value)}
                                                        />
                                                        <i className="ti-user" />
                                                        <div className="invalid-feedback">{errors.firstName?.message}</div>
                                                    </div>

                                                </div>

                                                <div className="form-group"  >
                                                    <div className="input-with-icon ">
                                                        <input type="email"
                                                            name='email'
                                                            autoComplete='off'
                                                            value={email}
                                                            className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                                                            placeholder='Enter Email'
                                                            onChange={(e) => setEmail(e.target.value)}
                                                        />
                                                        <i className="ti-email" />
                                                        <div className="invalid-feedback">{errors.email?.message}</div>
                                                    </div>
                                                </div>    
                                            </> : '' }
                                            {/* <input type="hidden" name="is_sign_up" value={viewExtraFields} /> */}
                                        
                                    
                                    <div className="form-group ">
                                        <button type="submit" className="btn btn-md full-width pop-login">
                                            Continue
                                        </button>
                                    </div>

                                </>

                            </> :
                                <>
                                    <div className="form-group ">
                                        <button
                                            onClick={validate}
                                            type="button"
                                            className="btn btn-md full-width pop-login"
                                        >
                                            Continue
                                        </button>
                                    </div>
                                </>
                            }

                    <div className="form-group text-center">
                        By Continuing, you agree to our
                        <a href="#"> Terms &amp; Conditions</a>
                    </div>

                </form>
            </div>
            
        </>
    )
}
export default SignUpForm;