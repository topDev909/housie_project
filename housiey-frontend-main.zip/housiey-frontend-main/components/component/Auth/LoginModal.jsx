import React,{useState,useEffect} from 'react';
import PhoneInput from 'react-phone-number-input';
import {useSelector} from 'react-redux';


const LoginModal = ()=>{
    const [mobile,setModile] = useState('');

    const [isMobileActive,setMobileActive]  = useState(false);
    const [isShowOTP,setIsSetOTP]           = useState(false)
    const [getOTP,setOTP]                   = useState('');
    const [otperror,setOtpError]            = useState('');
    const [formErr,setFormErr]              = useState('');

    

    const getNumberOnchange = (value)=>{
        // let value = e.target.value;
        setModile(value);
    }

    const SendOTPFn = async ()=>{
        if (mobile) {
            let obj = {
                mobile: mobile
            }
            let send_res = await fetch(process.env.BASE_URL + "signin", {
                method: 'POST',
                headers: {
                    "Content-Type": 'application/json'
                },
                body: JSON.stringify(obj)
            })

            if (send_res.ok) {
                let res_result = await send_res.json();
                if(res_result.res){
                    setMobile(mobile)
                    setIsSetOTP(true)
                }else{
                    setFormErr(res_result.msg)

                }

                hideMsg();
            }
        }
        else {
            return false
        }
    }

    const handleSubmit = (e)=>{
        e.preventDefault();
    }

    const hideMsg = ()=>{
        setTimeout(() => {
            setFormErr('')
        }, 5000);
    }

    return (
        <>  
            <div
                className="modal fade"
                id="login-modal-main"
                tabIndex={-1}
                role="dialog"
                aria-labelledby="login-modal"
                aria-hidden="true"
            >
                <div className="modal-dialog modal-xl login-pop-form" role="document">
                    <div className="modal-content overli" id="login-modal">
                    <div className="modal-body p-0">
                        <div className="resp_log_wrap">
                        <div
                            className="resp_log_thumb"
                            style={{
                            padding: "100px 50px",
                            background: "rgba(39, 174, 96,0.1)"
                            }}
                        >
                            

                            <img src="/assets/img/login.webp" width="40%" />
                            <h6>Login / Sign up</h6>
                            <ul style={{ paddingLeft: 0 }}>
                            <li>
                                <i style={{ fontSize: 11 }} className="fas fa-check" /> Free
                                Site Visit.
                            </li>
                            <li>
                                <i style={{ fontSize: 11 }} className="fas fa-check" /> Bottom
                                Rate Guarantee.
                            </li>
                            <li>
                                <i style={{ fontSize: 11 }} className="fas fa-check" /> Signup
                                Bonus Upto Rs. 2Lac.
                            </li>
                            <li>
                                <i style={{ fontSize: 11 }} className="fas fa-check" />{" "}
                                Dedicated Relationship Manager.
                            </li>
                            </ul>
                        </div>
                        <div className="resp_log_caption">
                            <span className="mod-close" data-dismiss="modal" aria-hidden="true">
                            <i className="ti-close" />
                            </span>
                            


                            <div
                                className="tab-pane fade show active"
                                id="pills-login"
                                role="tabpanel"
                                aria-labelledby="pills-login-tab"
                            >
                                <div className="login-form">
                                    {formErr && <>
                                        <div className="alert alert-danger" >
                                            {formErr}
                                        </div>
                                    </>}
                                <form action="" onSubmit={handleSubmit}>


                                    <div className="form-group">
                                        <div className="input-with-icon">
                                            <PhoneInput
                                                placeholder="Enter phone number"
                                                international
                                                disabled={isMobileActive}
                                                countryCallingCodeEditable={false}
                                                defaultCountry="IN"
                                                style={{ border: "1px solid #e7eaf1" }}
                                                className="form-control"
                                                onChange={getNumberOnchange}
                                                value={mobile}
                                            />
                                        </div>
                                    </div>


                                    {isShowOTP?
                                    <>
                                        <div className="form-group">                   
                                            <div className="input-with-icon my-click">
                                                <input type="number"
                                                    name='otp'
                                                    autoComplete="off"
                                                    value={getOTP}
                                                    placeholder='Enter OTP'
                                                    onChange={(e) => setOTP(e.target.value)}
                                                />
                                                <i className="ti-key"></i>

                                                <p className="resend-otp" >
                                                    <button className="btn btn-default bg-transparent p-0 text-dark m-0 resend-btn" type="button" onClick={SendOTPFn}  >
                                                        Resend OTP
                                                    </button>
                                                </p>
                                                <span className='text-danger'>{otperror}</span>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                        <button
                                            type="submit"
                                            className="btn btn-md full-width pop-login"
                                        >
                                            Continue
                                        </button>
                                        </div>

                                    </>    


                                : <>

                                        <div className="form-group">
                                        <button
                                            type="button"
                                            onClick={SendOTPFn}
                                            className="btn btn-md full-width pop-login"
                                        >
                                            Continue
                                        </button>
                                        </div>

                                </>}
                                        
                                    
                                    <div className="form-group text-center">
                                    By Continuing, you agree to our
                                    <a href="#"> Terms &amp; Conditions</a>
                                    </div>
                                </form>
                                </div>
                            </div>
                            

                        </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>

        </>
    )
}
export default LoginModal;