
import React, { useEffect,useState } from "react";
import {parseJwt} from '../../utils/BasicFn';
import {
  Box,
  Grid,
  Paper,
  withStyles,
  Stepper,
  Step,
  StepLabel,
} from "@material-ui/core";
import Step1 from "./Steps/step1";
import Step2 from "./Steps/step2";


import { styles } from "./common/styles";
import SignUpForm from "./Auth/SignUpForm";
import {set_enq_data} from '../../redux/slices/signUpModalSlice';

const NewMultiStepForm = ()=>{

    const [data,setData]             = useState('');
    const [errors,setError]          = useState('');
    const [steps,setSteps]           = useState([]);
    const [stepCount,setStepCount]   = useState(0);
    const [session,setSession]       = useState('');

    useEffect(()=>{
        const checkFn = ()=>{
            let token  = localStorage.getItem('housey_token');
            if(token){
                let sesData = parseJwt(token);
                setSession(sesData)
            }
        }
        checkFn();
    },[]);


    const handleOnChange = ({ target }) => {
        let err = '';
        target.value.length <= 3 ? (err = `${target.name} have at least 3 letter`) : (err = "");
        setError(err);
        let old_data  = data;
        let name      = target.name;
        old_data.push({name : target.value})
        setData(old_data)
      };
  
      const handleNextStep = () => {
        let newStep  = stepCount + 1;
        setStepCount(newStep);
      };
  
      const handleBackStep = () => {
        let newStep  = stepCount - 1;
        setStepCount(newStep);

      };
  
      const getStepContent = (step) => {
        switch (step) {
       
          case 1:
            return (
              <>

              {session ? <>
                <Step2
                    getData={data}
                    state={setData}
                    handleChange={handleOnChange}
                    handleNext={handleNextStep}
                    handlePrev={handleBackStep}
                />
                </> : 
                <>
                <SignUpForm />
                </>
                }
              </>
            );
        
          default:
            return (
              <Step1
                getData={data}
                state={setData}
                handleChange={handleOnChange}
                handleNext={handleNextStep}
              />
              //               // selectName={this.props.selname}
            );
        }
      };

    return (
        <>
          <div   id="step-form" >
            {getStepContent(stepCount)}
        </div>
        </>
    )
}
export default withStyles(styles)(NewMultiStepForm);
