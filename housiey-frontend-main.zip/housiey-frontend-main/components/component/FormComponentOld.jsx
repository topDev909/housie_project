import React, { Component } from "react";
import PropTypes from "prop-types";
import {
  Box,
  Grid,
  Paper,
  withStyles,
  Stepper,
  Step,
  StepLabel,
} from "@material-ui/core";
import Step1 from "./Steps/step1";
import Step2 from "./Steps/step2";
import { renderText } from "./common/DisplayComponent";
import { styles } from "./common/styles";
import SignUpForm from './Auth/SignUpForm';
import { useSelector } from "react-redux";
class FormComponent extends Component {
  state = {
    data: {
    
    },
    
    errors: {},
    steps: [
 
    ],
    stepCount: 0,
  };
  render() {
      const { classes,session,stepsCount } = this.props;
    // this.state.stepCount = stepsCount;
    const handleOnChange = ({ target }) => {

      const { data, errors, seldata} = this.state;
      // console.log("hello")
      target.value.length <= 3
        ? (errors[target.name] = `${target.name} have at least 3 letter`)
        : (errors[target.name] = "");

      data[target.name] = target.value;
      this.setState({ data, errors });
    };

    const handleNextStep = () => {
      let { stepCount } = this.state;
      stepCount = stepCount + 1;
      this.setState({ stepCount });
    };

    const handleBackStep = () => {
      let { stepCount } = this.state;
      stepCount         = stepCount - 1;
      this.setState({ stepCount });
    };

    const getStepContent = (step) => {
      switch (step) {
     
        case 1:
          return (
            <>
            {session?<>
                <Step2
                  state={this.state}
                  handleChange={handleOnChange}
                  handleNext={handleNextStep}
                  handlePrev={handleBackStep}
                  />
                </>  : 
                <>
                  <SignUpForm/>
                </>}
            </>
          );
      
        case 3:
        default:
          return (
            <Step1
              state={this.state}
              handleChange={handleOnChange}
              handleNext={handleNextStep}
              selectedData={this.props.seldata}
            />
            //               // selectName={this.props.selname}
          );
      }
    };

    // const handleSubmit = (e)=>{
    //   e.preventDefault();
    //   let visit_type = e.target.visit_type.value;
    //   let selected_date = e.target.selected_data.value;
    // }

    return (
      <>
       <div   id="step-form" >
         {getStepContent(this.state.stepCount)}
       </div>
      </>
      
    );
  }
}

FormComponent.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(FormComponent);
