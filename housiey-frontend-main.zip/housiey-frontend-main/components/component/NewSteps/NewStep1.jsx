import React from 'react';
const NewStep1 = ()=>{
    return (
        <>
        </>
    )
}
export default NewStep1;