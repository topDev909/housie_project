
import React,{useState} from 'react';
// import { Parser } from 'html-to-react'

const LongDescription = ({content,wordlength})=>{
    const [showMore,setShowMore] = useState(false);

    const toShow = content.substring(0, wordlength) + "...";


    const getContent = ()=>{
        if (content.length <= wordlength) {
            return <div>
                    <div dangerouslySetInnerHTML={ {__html: content} } />

            </div>
          }
          
          if (showMore) {
            // We show the extended text and a link to reduce it
            return <div> <div dangerouslySetInnerHTML={ {__html: content} } />
              <button onClick={()=>setShowMore(false)} className="read-more-btn" >Read less</button> 
            </div>
          }else{

            return <div> 
            <div dangerouslySetInnerHTML={ {__html: toShow} } />
            <button onClick={()=>setShowMore(true)} className="read-more-btn" >Read More</button> 
          </div>


          }
    }
    return (
        <>
            {/* {getContent))} */}
            {getContent()}

        </>
    )
}
export default LongDescription;