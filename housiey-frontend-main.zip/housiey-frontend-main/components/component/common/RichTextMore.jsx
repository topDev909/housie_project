import React from 'react';


const RichTextMore = ({content,wordlength})=>{
    const toShow = content.substring(0, wordlength) + "...";
    
    return (
        <>

        </>
    )
}
export default RichTextMore;