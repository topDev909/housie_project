
import { Box, Grid, Paper } from "@material-ui/core";
import { styles } from "../common/styles";
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import React,{ useState, useEffect } from "react"
import Radio from '@mui/material/Radio';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';

import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { makeStyles } from "@material-ui/core/styles";





// import DateTimePicker from '@mui/lab/DateTimePicker';

// import DateFnsUtils from '@date-io/date-fns';
// import { DateTimePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";

// import DateTimePicker from '@mui/lab/DateTimePicker';
// import LocalizationProvider from '@mui/lab/LocalizationProvider';
// import AdapterDateFns from '@mui/lab/AdapterDateFns';






import { useDispatch, useSelector } from "react-redux";
import { searchProjects,select_project } from "../../../redux/slices/projectsSlice";
import { set_active_tab,set_signup_title,set_thank_u_modal,set_modal_state,set_enq_data,set_form_step } from "../../../redux/slices/signUpModalSlice";

import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";

const useStyles = makeStyles({
  paper: {
    border: "0px solid black",
    borderRadius: "0px !important",
    marginTop: "11px",
    
  }
});

// selectName
const Step1 = ({state,handleNext}) => {
  const dispatch          = useDispatch();
  const selectedProject   = useSelector((state)=>state.projects.selectedProject) 
  const projectList       = useSelector((state)=>state.projects.projectList.projects) 
  const isTabView         = useSelector((state)=>state.signUpModal.ola_modal_type);
  const activeTab         = useSelector((state)=>state.signUpModal.activeTab);
  const classes           = useStyles();


  // const [mylist, setMylist]         = useState([])
  // const [data, setData]             = useState([])

  
  const [mylist, setMylist]             = useState((projectList)?projectList:[]);
  const [data, setData]                 = useState((selectedProject)?selectedProject[0]:[]);
  const [startDate, setStartDate]       = useState(new Date());

  const [checkedRadio,setCheckedRadio]  = useState(()=>{
    let cr_act_tb = parseInt(activeTab); 
    return cr_act_tb===1?'ola':'zoom';
  });


  // useEffect(()=>{
  //   // projectList
  //   let selected_p = (selectedProject)?selectedProject[0]:[];
  //   setMylist(projectList)
  //   setData(selected_p)
  //   // setActiveTab('1');
  // },[projectList,selectedProject])


  

  
  const [formOneErr,setFormOneErr] = useState('');
  const checkform=()=>{
    setFormOneErr('');
    if(selectedProject.length===0){
        setFormOneErr('Please Select Any Project')
        hideMsg();
        return;
    }
    if(!startDate){
        setFormOneErr('Please Select Date-Time')
        hideMsg();
        return;
    }

    let getSession =  localStorage.getItem('housey_token')
    dispatch(set_thank_u_modal(false))

   /*  
   if(!getSession){  
      let MainTopTitle = '';
      let actTb = parseInt(activeTab); 
      if(actTb===1){
        MainTopTitle = 'Free Site Visit Scheduled Successfully';
      }else{
        MainTopTitle = 'Online Presentation  Scheduled Successfully';
      }
      dispatch(set_signup_title(MainTopTitle))
      dispatch(set_thank_u_modal(true))
      localStorage.setItem('modal_type', 'ola_modal')
      dispatch(set_modal_state(false))
      $('#login').modal('show');
      return;
    } */
    let mData = moment(startDate).format('YYYY-MM-DD HH:MM');

    

    let arr = [];
    arr.push(selectedProject);
    arr.push(mData);
    arr.push(checkedRadio);
    dispatch(set_enq_data(arr));
    dispatch(set_form_step(1));
}
// handleNext()

  
  const onSelectHandler = (value)=>{
    let cr_act_tb = parseInt(activeTab); 
    if(value.length >3){
      let msg = (cr_act_tb===1)?"Upto 3 projects allowed in one Site Visit Tour":'Upto 3 projects allowed in one Online Presentation';
      setFormOneErr(msg)
      hideMsg();
      return;
    }
    dispatch(select_project(value))
    setData(value)
  } 




//   const removeDuplicates = arr => {
//     let map = {};
//     let res = [];
//     res = arr.filter(item => !res.has(item.slug) && res.add(item.slug))
//     return res;
//  };



const [searchKeywords,setSearchKeywrods] = useState('');

const mykey = async (keyword)=>{
  setSearchKeywrods(keyword)

  if(keyword!==''){
    let cityDataLocal = JSON.parse(localStorage.getItem('houseiy_location'));
    let obj  = {
      keywords: keyword,
      city_id: cityDataLocal.city_id
    }
    let search_projects = await dispatch(searchProjects(obj)); // this is for redux
    if(search_projects.payload){
      setMylist(search_projects.payload.projects)
    }
  }else{
    setMylist([])
  }

}



  // const mykey = async (keyword)=>{
  //   if(keyword!==''){
  //     let search_projects = await dispatch(searchProjects(keyword)); // this is for redux
  //     if(search_projects.payload){
  //       setMylist(search_projects.payload.projects)
  //     }
  //   }else{
  //     setMylist([])
  //   }
  // }
  
  const hideMsg = ()=>{
      setTimeout(() => {
        setFormOneErr('')
      }, 3000);
  }



  const handleTabChange = (event, newValue) => {
        setFormOneErr('');
        dispatch(set_active_tab(newValue))

        let cr_act_tb = parseInt(newValue); 
        let val       = (cr_act_tb===1) ? 'ola' : 'zoom';
        setCheckedRadio(val)
  };
  
  const checkRadioBtn = (event)=>{
    // let is_checked = event.target.checked;
    let val = event.target.value;
    setCheckedRadio(val)
  }



  return (
    <>

    <Paper style={styles.steps}>
        
        <Box sx={{ width: '100%', typography: 'body1' }}>
          <TabContext value={activeTab}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}  style={{ display:isTabView?'block':'none'}}  id="tab-item-btns"  >
              <TabList onChange={handleTabChange} aria-label="lab API tabs example">
                <Tab label="Book Free Site Visit" value="1" />
                <Tab label="Online Presentation" value="2" />
              </TabList>
            </Box>
            <TabPanel value="1">
            <div className="box-title text-center" style={{ display:isTabView?'none':'block', fontSize: "18px",
              marginBottom: "10px", fontWeight: "600"}} >Free Site Visit</div>
  
              {formOneErr && <>
                <div className="alert alert-danger" >
                    {formOneErr}
                </div>
              </>}

                <div className="form-group ">
                <div className="input-with-icon"> 
                  <Stack>
                    <Autocomplete 
                      multiple
                      limitTags={1}
                      value={selectedProject}
                      getOptionLabel={(option) => option.project_name}
                      options={(projectList)?projectList:[]}
                      classes={{ paper: classes.paper }}
                      onChange={(event,value)=>onSelectHandler(value)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="standard"
                          placeholder={(selectedProject.length)?"":"Search multiple projects for site visit"}
                          className="form-control search-field"
                          onChange={(e)=>{mykey(e.target.value)}}
                          />
                      )}
                    />
                  <i className="ti-search" style={{top: "-24px"}}/>
                  </Stack>
                  <input type="hidden" name="tour_data" value={selectedProject}  />
                </div>
              </div>

            <div className="form-group calander-box"  >
                <DatePicker selected={startDate} 
                  dateFormat="MM-dd-yyyy h:mm aa" 
                onChange={(date) => setStartDate(date)} 
                minDate={new Date()}
                showTimeSelect
                />
                <i className="ti-calendar"></i>
                <input type="hidden" name="selected_data" value={startDate} />
            </div>

              <div className="form-group mt-2">
                <label>Preferred Source</label>
                <br />
                <RadioGroup style={styles.radio} defaultValue="OLA" name="visit_type" className="row" >
                  <span className="col-6" >
                        <FormControlLabel value="OLA" control={<Radio style={styles.radiobtn}/>} label={<img src="/assets/img/ola-logo1.png" width="90" />}  onClick={checkRadioBtn}/>
                  </span>
                  <span className="col-6" >
                        <FormControlLabel value="Not-Required" control={<Radio />} label="Not Required" onClick={checkRadioBtn} />
                  </span>
                </RadioGroup>
              </div>

              <ul style={{ paddingLeft: "10px" }} className="listing-rights" >
                <li>
                  <i className="fas fa-check" /> Free Pick Up &amp; Drop - Book Personal Ola
                </li>
                <li>
                  <i className="fas fa-check" /> Visit your selected 3 projects in one Tour
                </li>
                <li>
                  <i className="fas fa-check" /> Just Visit &amp; decide later
                </li>
              </ul>


              
              <div className="form-group">
                <button
                  type="button"
                  className="btn btn-md full-width pop-login"
                  data-toggle="modal"
                  data-target="#visitlogin"
                  style={{marginBottom: "15px"}}
                  onClick={checkform}
                    >
                  Book Site Visit
                  
                </button>
              </div>

              
            </TabPanel>

            <TabPanel value="2">

            <div className="box-title text-center" style={{ display:isTabView?'none':'block', fontSize: "18px",
              marginBottom: "10px", fontWeight: "600"}} >Online Presentation</div>


            {formOneErr && <>
                <div className="alert alert-danger" >
                    {formOneErr}
                </div>
              </>}

            <div className="form-group">
                <div className="input-with-icon"> 
                  <Stack>
                    <Autocomplete 
                      multiple
                      limitTags={1}
                      value={selectedProject}
                      getOptionLabel={(option) => option.project_name}
                      options={(projectList)?projectList:[]}
                      onChange={(event,value)=>onSelectHandler(value)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="standard"
                          placeholder={(selectedProject.length)?"":"Search multiple projects for site visit"}
                          className="form-control search-field"
                          onChange={(e)=>{mykey(e.target.value)}}
                          />
                      )}
                    />
                  <i className="ti-search"/>
                  </Stack>
                </div>
              </div>


              <div className="form-group calander-box"  >
                <DatePicker selected={startDate} 
                  dateFormat="MM-dd-yyyy h:mm aa" 
                  onChange={(date) => setStartDate(date)} 
                  minDate={new Date()}
                  showTimeSelect
                />
                <i className="ti-calendar"></i>
            </div>



              <div className="form-group">
                <label>Preffered Source</label> <br />
                <div style={{ display: "flex" }}>
                  <RadioGroup
                      aria-labelledby="demo-radio-buttons-group-label"
                      defaultValue="zoom"
                      name="visit_type"
					          className="row p-3"
                    >
                    <span className="col-4 p-0" >
                          <FormControlLabel value="zoom" onClick={checkRadioBtn}   control={<Radio  />} label={<img src="/assets/img/zoom.jpeg" width="60" />} id="ola_lebel"/>
                    </span>
                    
                    <span className="col-4 p-0" >
                        <FormControlLabel value="gmeet" onClick={checkRadioBtn}   control={<Radio  />} label={<img src="/assets/img/gmeet.jpeg" width="60" />} id="gmeet_label"/>
                    </span>

                    <span className="col-4 p-0">
                        <FormControlLabel value="teams" onClick={checkRadioBtn}   control={<Radio  />} label={<img src="/assets/img/teams.jpeg" width="60" />} id="m_teams" />
                    </span>
                  </RadioGroup>
                </div>
              
              </div>

              <ul style={{ paddingLeft: 12 }} className="listing-rights">
                <li>
                  <i className="fas fa-check" /> Directly form Builder
                  Salesperson
                </li>
                <li>
                  <i className="fas fa-check" /> Latest Offer &amp;
                  Payment Schemes
                </li>
                <li>
                  <i className="fas fa-check" /> Live Sample Flat Tour
                </li>
              </ul>


              

              <div className="form-group">
                <button
                  type="button"
                  className="btn btn-md full-width pop-login"
                  data-toggle="modal"
                  data-target="#visitlogin"
                  onClick={checkform}
                    >
                  Book Site Tour
                  
                </button>
              </div>


            </TabPanel>
          </TabContext>
        </Box>
        
          
      
    </Paper>
    </>
  );
};

export default Step1;
