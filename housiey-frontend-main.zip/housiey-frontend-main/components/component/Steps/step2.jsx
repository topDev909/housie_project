import React from "react";
import { Box, Grid, Paper } from "@material-ui/core";
import { styles } from "../common/styles";
import { useState, useEffect } from "react"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';

import moment                                  from 'moment';
import { useDispatch }                         from "react-redux";
import { set_modal_details,set_signup_title,set_thank_u_modal,set_modal_state,set_form_step,set_first_time_login,set_after_login_modal,set_show_sign_up_perks}  from "../../../redux/slices/signUpModalSlice";
import {set_step1_modal,set_thanks_modal} from '../../../redux/slices/MobileSignUpModalSlice';



const Step2 = ({ state, handleChange, handleNext, handlePrev }) => {
  const dispatch = useDispatch();
  const router = useRouter()
  const [mobile, setMobile]     = useState('');
  const [data, setData]         = useState([])
  const [name, setName]         = useState(''); 
  const [email,setEmail]        = useState('');
  const [getvlaue, setGetvlaue] = useState('');
  const [timer, setTimer] = useState(30);

  // const [otp, setOtp] = useState('');

  const open_thank_modal = useSelector((state)=>state.signUpModal.show_thanku_modal)
  const activeTab        = useSelector((state)=>state.signUpModal.activeTab);
  const enq_data         = useSelector((state)=>state.signUpModal.enq_data);



  const [formMsg,setFormMsg]        = useState('');
  const [is_open_otp,set_open_otp]  = useState(false);
  const [checkotp,setCheckotp]      = useState('');
  const [viewExtraFields,setViewExtraFeilds] = useState(true);
  const [otperror,setOtperror] = useState('');
  const [openThankModal,setOpenThankModal] = useState(false)
  let time_id = React.useRef();

  const baseUrl      = process.env.BASE_URL;
        // const baseUrl      = 'http://185.227.134.103:9001/api/';

  

  const ValidateForm = async() => {

    let CityInfoData       = JSON.parse(localStorage.getItem('houseiy_location')) 
    let selectedProjects   = enq_data[0];
    let SelectedDateTime   = enq_data[1];
    let meeting_type       = enq_data[2];
    let selectedProjectIDs = [];

    selectedProjects.forEach(element => {
      selectedProjectIDs.push(element.id)
    });

    let strID   = selectedProjectIDs.toString();
    var dateStr = moment(SelectedDateTime).format('YYYY-MM-DD HH:mm:ss');
    let fields ={
      "name":             name,
      "email":            email,
      "mobile":           mobile,
      "project_id":       strID,
      "enquiry_datetime": dateStr,
      "source":           meeting_type,
      "type":             activeTab,
      "city_id":          CityInfoData.city_id
    }

    let token          = localStorage.getItem('housey_token'); 

    if(token){
      
      let cityData     = JSON.parse(localStorage.getItem('houseiy_location')); 

      let save_res     = await fetch(baseUrl+'save-enquiry',{
        method:'POST',
        headers:{
          'Content-Type':'application/json',
          auth: token
        },
        body: JSON.stringify(fields)
      })

      if(save_res.ok){
          let retult_res = await save_res.json();
          if(retult_res.res===true){

            let sellerInfo       = retult_res.seller_info[0]?retult_res.seller_info[0]:'';
            let projects_details = retult_res.projects_details;
            $("#olamodal").modal('hide')
            localStorage.removeItem('modal_type');


           
            if(open_thank_modal){
              $("#login-thank-you-modal").modal('show')
              dispatch(set_after_login_modal(true))// for mobile
              dispatch(set_thanks_modal(false)) // for mobile
              dispatch(set_thank_u_modal(true));
              dispatch(set_show_sign_up_perks(true))
              // dispatch(set_first_time_login(true));

            }else{
              $('#login-thank-you-modal').modal('show');
              dispatch(set_thank_u_modal(false));
              // dispatch(set_first_time_login(false));
              dispatch(set_show_sign_up_perks(false))
              dispatch(set_after_login_modal(true)) // for mobile 
              dispatch(set_thanks_modal(false)) // for mobile
            }

            
            

            let MainTopTitle = '';
            let actTb = parseInt(activeTab); 
            if(actTb===1){
              MainTopTitle = 'Free Site Visit Scheduled Successfully';
            }else{
              MainTopTitle = 'Online Presentation  Scheduled Successfully';
            }


            let obj = {
              name:             fields.name,
              email:            fields.email,
              mobile:           fields.mobile,
              enquiry_datetime: fields.enquiry_datetime,
              source:           fields.source,
              projects:         selectedProjects,
              city_id:          cityData.city_id,
              cityName:         cityData.name,
              sellerInfo:       sellerInfo,
              projectDetails:   projects_details
            }

            dispatch(set_modal_details(obj));
            dispatch(set_signup_title(MainTopTitle))
            dispatch(set_form_step(0));
            dispatch(set_step1_modal(false))

            // dispatch(set_thanks_modal(true))
            


          }else{
            let msg = <div className="text-danger">Something Went Wrong Please Try Again</div>
            setFormMsg(msg)
          }
      }
    }else{
      set_open_otp(true)
      dispatch(set_first_time_login(true));
      SendOTPFn();
    }

  }


  const EditNumber = ()=>{
    set_open_otp(false)
    
  }

  const SetDataVal = (val) => {
    let str = '';
    for (let v_i = 0; v_i < val.length; v_i++) {
      str += val[v_i].title + ',';
    }
    setData(str)
  }

  // get  user data fetch localstorage
  useEffect(() => {
    let jwt_get_data = localStorage.getItem('housey_token')
    if(jwt_get_data){
      let get_data = parseJwt(jwt_get_data);
      setName(get_data.name);
      setMobile(get_data.mobile)
      setEmail(get_data.email)
    }
  },[])
  
  function parseJwt(token) {
    if (!token) { return; }
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace('-', '+').replace('_', '/');
    return JSON.parse(window.atob(base64));
  }

  const myvalue =()=>{
    if ((name.length > 1 && mobile.length > 1) && email.length > 1  ){ 
      ValidateForm()
    }
    else{
        let err =<span className="text-danger"> Kindly Fill The Field</span>
       setGetvlaue(err)
    }
  }
  

  const SendOTPFn = async ()=>{
    let send_mobile = mobile;
    if (send_mobile) {
        let obj = {
            mobile: send_mobile
        }
        let send_res = await fetch(baseUrl + "signup", {
            method: 'POST',
            headers: {
                "Content-Type": 'application/json'
            },
            body: JSON.stringify(obj)
        })

        if (send_res.ok) {
            let res_result = await send_res.json();
            if(res_result.res===true){
                setCheckotp(res_result.data.otp)
                // dispatch(set_modal_state(true))

                 if(res_result.signup_status===0){
                    dispatch(set_thank_u_modal(false));
                    // dispatch(set_after_login_modal(true))// for mobile 
                    // dispatch(set_thanks_modal(false)) // for mobile
                }else{
                    // dispatch(set_after_login_modal(false))// for mobile
                    // dispatch(set_thanks_modal(true)) // for mobile
                    dispatch(set_thank_u_modal(true));
                } 

                let i = 30;
                clearInterval(time_id.current);
                time_id.current = setInterval(() => {
                    i = i-1;
                    setTimer(i);
                    if(i <= 0){
                        clearInterval(time_id.current);
                    }
                }, 1000); 
                

            }else{
                // setFormMsg(res_result.msg);
                // setField('')
                // setTitle(false)
                // dispatch(set_modal_state(false))
                // setIsNumberDisable(false)
            }

            hideMsg();
        }
    }
    else {
        
    }
}



const verifyOTP = async (e) => {
  // setFormLoad(true)
  e.preventDefault();
  let field = {
      "name":      name,
      "email":     email,
      "otp":       checkotp,
      "mobile":    mobile,
      "is_signup": viewExtraFields
  }

  if(!checkotp || checkotp==='undefined'){
      setFormMsg('Please Fill OTP')
      return;
  }

  if(!name || name==='undefined'){
      setFormMsg('Please Fill Full-Name')
      return;
  }
  if(!email || email==='undefined'){
      setFormMsg('Please Fill Email')
      return;
  }


  // check enq data


  // console.log(JSON.stringify(field));
  let check = await fetch(baseUrl + "verify-otp", {
      method: 'POST',
      headers: {
          "Content-Type": "application/json"
      },
      body: JSON.stringify(field)
  })



  if (check.ok) {
      let check_result = await check.json();
      if (check_result.res === true) {
          localStorage.setItem('housey_token', check_result.token);
          let modal_type = localStorage.getItem('modal_type');
              modal_type = (modal_type) ? modal_type : ''

              ValidateForm();
              /* 
              if (modal_type === 'ola_modal') {
                  $('#olamodal').modal('show');
                  $('#login').modal('hide');
                  return;
              }
              else if(viewExtraFields){
                  $('#thankyou').modal('show')
                  $('#login').modal('hide')
                  return;
              }else{
                  // router.reload(window.location.reload)
              } */
          
      } else {
          setOtperror(check_result.msg)
      }
      hideMsg();
  }
  else {

      return false

  }

}

const hideMsg = ()=>{
  setTimeout(() => {
      setFormMsg('')
  }, 3000);
}


  return (
    <Paper style={styles.steps}>
        <div className="step-2">
            <FontAwesomeIcon icon={faArrowLeft} onClick={handlePrev} className={'my-arrow'} style={{cursor: "pointer"}}/>


              <div className="row form-group">
                  <div className="form-group col-6">
                      <label>Name </label>
                      <div className="input-with-icon">
                      <input
                          type="text"
                      placeholder="Enter Name"
                          className="form-control my-input"
                          onChange={(e) => setName(e.target.value)}
                          value={name}
                          style={{width: "100%"}}
                      />
                      <i className="ti-user"/>
                      </div>
                  </div>

                  <div className="form-group col-6" >
                      <label>Mobile Number </label>
                      <div className="input-with-icon">
                      <input
                          type="text"
                          id="txtPhone"
                          // defaultvalue={myuserdata.mobile}
                          placeholder="Enter Mobile Number "
                          className="form-control my-input"
                          onChange={(e) => setMobile(e.target.value)}
                          name ='mobile'
                          value={mobile}
                          style={{width: "100%"}}
                      />
                      <i className="ti-mobile"/>

                      </div>
                  {getvlaue}
                  </div>
              </div>
              <div className="row form-group" style={{marginTop: "-18px"}}>
                <div className="form-group col-12">
                  <label>Email</label>
                  <div className="input-with-icon">
                  <input type="email" className="form-control" placeholder="Enter Email"
                      name="email"
                      onChange={(e) => setEmail(e.target.value)}
                      value={email}
                      defaultvalue={email.email}
                  />
                  <i className="ti-email" style={{top: "-27px"}}/>
                  </div> 
                  {getvlaue}
                </div>
              </div>


              {is_open_otp ? 
            <>
              <div className="form-group">
                
                <div className="input-with-icon " style={{marginBottom: "-20px"}}>
                    <input type="text"
                        name='otp'
                        value={checkotp}
                        className={`form-control`}
                        placeholder='Enter OTP'
                        onChange={(e) => setCheckotp(e.target.value)}
                    />
                    <i className="ti-key"></i>

                    <p className="resend-otp" >

                        {timer <=0 ? 
                            <>
                            <button className="btn btn-default bg-transparent p-0 text-dark m-0 resend-btn" type="button" onClick={SendOTPFn}  >
                                Resend OTP
                            </button>
                            </>
                        : 
                        <>
                            Wait {timer} Sec
                        </>
                        }
                        

                        
                    </p>
                    {/* <div className="invalid-feedback">{errors.otp?.message}</div> */}
                    <span className='text-danger'>{otperror}</span>
                </div>
            </div>

            <div className="row form-group " >
                <div className="form-group col-12">
                <button
                type="button"
                onClick={verifyOTP}
                className="btn btn-md full-width pop-login">
                Continue
                </button>
                </div>
              </div>   


            </> : <>

              <div className="row form-group" style={{marginTop: "-15px"}}>
                <div className="form-group col-12">
                <button
                type="button"
                onClick={myvalue}
                className="btn btn-md full-width pop-login">
                Continue
                </button>
                </div>
              </div>            
            </>}
            <div className="form-group text-center">
                By Continuing, you agree to our <a href="#"> Terms &amp; Conditions</a>
            </div>

        </div>
    </Paper>
  );
};

export default Step2;
