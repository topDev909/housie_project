import React from 'react';
import SignUpForm from "../Auth/SignUpForm";
const Step3 = ()=>{
    return (
        <>
        <SignUpForm/>
        </>
    )
}
export default Step3;