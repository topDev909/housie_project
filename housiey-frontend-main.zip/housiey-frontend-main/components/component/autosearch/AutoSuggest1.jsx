import React,{useState}  from 'react';


const AutoSuggest1 = ({set_cat,setSelectedVal,getSelectedVal,setopenCatModal,get_cat})=>{


    
    const [value,setvalue]              = useState((getSelectedVal)?getSelectedVal.label:'');
    const [suggestions,setSuggestions]  = useState([]);

    const [allCategory,setAllCategory] = useState([]);
    // Teach Autosuggest how to calculate suggestions for any given input value.
    const getSuggestions = async value => {
        const inputValue = value.trim().toLowerCase();
        setvalue(inputValue)
        // let response     = await fetch("/api/SelectCat?query=" + inputValue + "");
        // let data         = await response.json()
        // return data;


        // let {query}    = req.query;
        let cat_data   = await fetch(process.env.BASE_URL+'api/search-cat?s='+inputValue);
        cat_data       = await cat_data.json();
        
        if(cat_data.status===true){
            setAllCategory(cat_data.parent_category)
        }
        // setSuggestions(all_cat_arr)
        
      /*   let all_cat_arr = [];
        if(cat_data.status===true){
          let all_cat_data = cat_data.all_categories;
          if(all_cat_data.length > 0){
            for (let cat_i = 0; cat_i < all_cat_data.length; cat_i++) {
              
              if(all_cat_data[cat_i].parent && all_cat_data[cat_i].parent.child_1_data)
              {
              let child_data  = all_cat_data[cat_i].parent.child_1_data;
              let parent_json = {
                label: all_cat_data[cat_i].parent.cat_title,
                value: all_cat_data[cat_i].parent.cat_id,
                parent_id: all_cat_data[cat_i].parent.parent_id,
                img      : all_cat_data[cat_i].parent.cat_img,
              }
              console.log(parent_json);
              all_cat_arr.push(parent_json)
    
                // if(child_data.length > 0)
                // {
                //   for (let sub_cat_i = 0; sub_cat_i < child_data.length; sub_cat_i++) {
                //     let child_json = {
                //       label: child_data[sub_cat_i].cat_title,
                //       value: child_data[sub_cat_i].cat_id,
                //       parent_id: child_data[sub_cat_i].parent_id,
                //       img         : child_data[sub_cat_i].cat_img,
                //     }
                //     all_cat_arr.push(child_json)
                //   }
                // }

            }else{
              let sibling_json = {
                label: all_cat_data[cat_i].cat_title,
                value: all_cat_data[cat_i].cat_id,
                parent_id: all_cat_data[cat_i].parent_id,
                img  : child_data[sub_cat_i].cat_img,
              }
              all_cat_arr.push(sibling_json)
            }
            }
          }
        }


        // return all_cat_arr;
 */
    };
  
    
    // Trigger suggestions
    const getSuggestionValue = suggestion => suggestion.label;

    const img = 'admin/assets/images/default_category_icon.svg';
    // Render Each Option
    const renderSuggestion = suggestion => (
        <span className="sugg-option">
            <span className="icon-wrap" >
                <img src={(suggestion.img) ? process.env.BASE_URL + suggestion.img : process.env.BASE_URL + img} alt=''/>
            </span>
            <span className="name">
                {suggestion.label}
            </span>
        </span>
    );

    const onChange = (event, { newValue }) => {
         setvalue(newValue); 
    };

    const onSuggestionsFetchRequested = ({ value }) => {
        // setSuggestions(getSuggestions(value));


        getSuggestions(value)
            .then(data => {
                setSuggestions(data)
                // if (data.Error) {
                //     setSuggestions([])
                // } else {
                // }
            });
    };


     // Autosuggest will pass through all these props to the input.
     const inputProps = {
        placeholder: 'for example painter, plumber...',
        value,
        onChange: onChange,
        autoFocus:true,
      };
 

       // Autosuggest will call this function every time you need to clear suggestions.
        const onSuggestionsClearRequested = () => {
            setSuggestions([]);
        };


        const onSuggestionSelected = (event, { suggestion, suggestionValue, index, method }) => {
            event.preventDefault();
            setSelectedVal(suggestion);
            set_cat(suggestion.value);
            setopenCatModal(false);
        }   


        const onClickHandler = (suggestion)=>{
            // e.preventDefault();
            // console.log(suggestion)
            setvalue(suggestion.cat_title);
            let setsug = {
                value: suggestion.cat_id,
                label: suggestion.cat_title,
                parent_id: suggestion.parent_id
            }
            setSelectedVal(setsug);
            set_cat(suggestion.cat_id);
            setopenCatModal(false);
        }
        // const buttonTextRef = useRef();
        // // Update the ref to ButtonText every time ButtonText changes:
        // useEffect(() => {
        //   buttonTextRef.current = value;
        // }, [value]);

    return(
        <>
        
        <input type="text" className='select-cat' id="cate-select"  list='cat-search-list' placeholder='Search by Category Name' onChange={(e)=>getSuggestions(e.target.value)} autoComplete="off" autoFocus/>
        <ul className='cat-suggestions'>
            {allCategory.map(single_seg=>{
            return (

                <li   onClick={()=>onClickHandler(single_seg)} key={single_seg.cat_id}   >
                    <span className="sugg-option"  >
                        <span className="icon-wrap" >
                            <img src={(single_seg.cat_img) ? process.env.BASE_URL + single_seg.cat_img : process.env.BASE_URL + img} alt=''/>
                        </span>
                        <span className="name">
                            {single_seg.cat_title}
                        </span>
                    </span>
                </li>
            )
            })}
        </ul>

        {/* <Autosuggest
                suggestions={suggestions}
                onSuggestionsFetchRequested={onSuggestionsFetchRequested}
                onSuggestionsClearRequested={onSuggestionsClearRequested}
                getSuggestionValue={getSuggestionValue}
                renderSuggestion={renderSuggestion}
                onSuggestionSelected={onSuggestionSelected}
                defaultValue={(getSelectedVal)?getSelectedVal.label:''}
                inputProps={inputProps}
                
                
        /> */}
        </>
    )
}
export default AutoSuggest1;