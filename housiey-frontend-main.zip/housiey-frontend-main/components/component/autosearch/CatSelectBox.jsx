import React from 'react';
import AutoSuggest1 from './AutoSuggest1';



// get like search Category API from shivam

const CatSelectBox = ({set_cat,get_cat,setopenCatModal,openCatModal,setSelectedVal,SelectedVal})=>{

    
    
    const SelectHandler  = async (param)=>{
      
    
    } 

    const closeModal = ()=>{
      // setopenCatModal(false)
    }


    function expand() {    
      // setopenCatModal(true)
    }


    return (
        <>
          
          <div id="mybottam_nav1" className="container-fluid bottam_nav bttm-open-modal" style={{ height:openCatModal?'60%':'0%'}}
            tabIndex={0} onFocus={expand}
            onBlur={closeModal}>
            <div className="row p_top_10" style={{overflowY: "hidden;", position: "fixed"}}>
              <hr onClick={()=>setopenCatModal(false)}></hr>

              <div className="col-12 button_filter_clic p_top_20">
                <div className="filter_box-da">Choose Your Profession 
                <img onClick={() => setopenCatModal(false)} src="assests/images/icone/close.svg" width="3%" alt=''/>
                </div>
                    

                <i className="fa fa-times" onClick={()=>setopenCatModal(false)}></i>

              </div>             
          </div>
          <div className="row p_top_20" style={{marginTop: "70px"}}>
            {/* <div className="col-12 p_top_20 location-text">
              <h6>Choose Your Profession</h6>
                <span className='close-btn' onClick={()=>setopenCatModal(false)}> &times; </span>
                <i className="fa fa-times" onClick={()=>setopenCatModal(false)}></i>
            </div> */}
            <div className="col-12 location-text">
                {openCatModal?
                <div id="new-autocomplete">
                      <AutoSuggest1  setSelectedVal={setSelectedVal} getSelectedVal={SelectedVal} setopenCatModal={setopenCatModal} set_cat={set_cat} get_cat={get_cat}  />
                </div>
                :""}
            </div>
          </div>
        </div>
        </>
    )
}
export default CatSelectBox;