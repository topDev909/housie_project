import React from 'react'

const Unique_Features = () => {
    return (
        <div>
             <section className="min" id="unique-features">
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-lg-7 col-md-8">
          <div className="sec-heading center">
            <h2>Housiey Unique Features</h2>
          </div>
        </div>
      </div>
      <div className="row justify-content-center mt-4 features">
        {/* Single Category */}
        <div className="col-lg-3 col-md-6 col-sm-6">
          <div className="_category_box">
            <a href="#">
              <div className="_category_elio">
                <div className="_category_thumb">
                  <img
                    src="/assets/img/unboxing.svg"
                    className="img-fluid hover"
                    alt=''
                  />
                  <img
                    src="/assets/img/unboxing.svg"
                    className="img-fluid simple"
                    alt=''
                  />
                </div>
                <div className="_category_caption">
                  <h5>Project Unboxing</h5>
                  <span>
                  Complete Project analysis with overview, location, amenities, plans, carpet area, payment schemes, pros & cons, builder profile etc..
                  </span>
                </div>
              </div>
            </a>
          </div>
        </div>
        {/* Single Category */}
        <div className="col-lg-3 col-md-6 col-sm-6">
          <div className="_category_box">
            <a href="#">
              <div className="_category_elio">
                <div className="_category_thumb">
                  <img
                    src="/assets/img/pros-cons.svg"
                    className="img-fluid hover"
                    alt=''
                  />
                  <img
                    src="/assets/img/pros-cons.svg"
                    className="img-fluid simple"
                    alt=''
                  />
                </div>
                <div className="_category_caption">
                  <h5>Pros &amp; Cons</h5>
                  <span>
                  First time in Indian Real Estate, Get unbiased views of 
                  projects with Pros & Cons by in depth analysis from our experts.
                  
                  </span>
                </div>
              </div>
            </a>
          </div>
        </div>
        {/* Single Category */}
        <div className="col-lg-3 col-md-6 col-sm-6">
          <div className="_category_box">
            <a
              href="#"
           
            >
              <div className="_category_elio">
                <div className="_category_thumb">
                  <img
                    src="/assets/img/tour.svg"
                    className="img-fluid hover"
                    alt=''
                    // style={{ filter: "brightness(10)" }}
                  />
                  <img
                    src="/assets/img/tour.svg"
                    className="img-fluid simple"
                    alt=''
                  />
                </div>
                <div className="_category_caption">
                  <h5 >Virtual 360 Tour</h5>
                  <span>
                  Experience the 3D Tour  & feel the view, facing, & amenities of 
                  the projects by sitting in your home only.
                  </span>
                </div>
              </div>
            </a>
          </div>
        </div>
        {/* Single Category */}
        <div className="col-lg-3 col-md-6 col-sm-6">
          <div className="_category_box">
            <a href="#">
              <div className="_category_elio">
                <div className="_category_thumb">
                  <img
                    src="/assets/img/rtc.svg"
                    className="img-fluid hover"
                    alt=''
                  />
                  <img
                    src="/assets/img/rtc.svg"
                    className="img-fluid simple"
                    alt=''
                  />
                </div>
                <div className="_category_caption">
                  <h5>Real Time Calling</h5>
                  <span>
                  Get instant resolution of your queries  by our 24/7 Property experts.
                  <br></br>
                  </span>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>
        </div>
    )
}

export default Unique_Features
