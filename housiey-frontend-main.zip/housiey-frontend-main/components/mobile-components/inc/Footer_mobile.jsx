import react, {useState} from 'react';
import Link from 'next/link';

const Footer_mobile = () => {

	const [hide, toggleShow] = useState(false);

    return(
        <>
        <footer className="dark-footer skin-dark-footer style-2">
				<div className="footer-middle">
					<div className="container">
						<div className="row" style={{margin:"0 auto"}}>
							<div className="col-12">
								<ul className="show-menu">
									<li>
										<Link href="/" ><a  >Home </a></Link>
									</li>
									<li>
										<Link href="/about-us" ><a  >About-Us </a></Link>
									</li>
									<li>
										<Link href="/contact-us" ><a  >Contact-Us</a></Link>
									</li>
									<li><a href="#">Careers Us</a></li>
								</ul>
								<ul className="show-menu-policy">
									<li><a href="#">RERA Policy</a></li>
									<li><Link href="/privacy-policy"><a>Policy of Use</a></Link></li>
									<li><Link href="/disclaimer"><a>Disclaimer</a></Link></li>
								</ul>
							</div>
						</div>
						
						
						
						<div className="row">
						<div className="col-lg-3 col-md-5">
							<div className="footer_widget">
							<img
								src="/assets/img/logo1.png"
								className="img-footer small mb-2"
								alt='footer-logo'
							/>
							<p>RERA No. - A51900001761</p>
							<p>C.I. Number: U74140MH1984PLC033397</p>
							<p>Write to us : support@housiey.com</p>
							{/* <p>Call / WhatsApp - 8097452839</p> */}
							<p />
							<ul className="top-social">
								<li>
								<a target='_blank' rel="noreferrer" href="https://www.facebook.com/housiey">
									<i className="lni-facebook" />
								</a>
								</li>
								<li>
								<a target='_blank' rel="noreferrer" href="https://www.linkedin.com/company/housiey">
									<i className="lni-linkedin" />
								</a>
								</li>
								<li>
								<a target='_blank' rel="noreferrer" href="https://www.youtube.com/c/Housiey">
									<i className="lni-youtube" />
								</a>
								</li>
								<li>
								<a target='_blank' rel="noreferrer" href="https://www.instagram.com/housiey">
									<i className="lni-instagram" />
								</a>
								</li>
								{/* <li><a href="#"><i class="lni-twitter"></i></a></li> */}
							</ul>
							<p />
							<h4 className="extream">REGISTERED &amp; CORPORATE OFFICE</h4>
							Unit 21/B, Vasudev Chambers Old Nagardas Road Andheri East Mumbai Maharashtra - 400069 India
							</div>
						</div>
						<div className="col-sm-12 text-center">
							<div className="col-12" style={{textAlign:"center",marginTop:"10px", marginBottom: '50px'}}>
							<button style={{background:'#1d2636', border:'none', color: '#fff', fontSize: '18px'}} className="show show-more" onClick={() => toggleShow(!hide)}>
									{hide ? 'Show Less' : 'Show More'}
								</button>								
							</div>
						</div>
						</div>
						{hide ?
						<div className="row">
							<div className="col-lg-9 col-md-7 ml-auto">
								<div className="row">
								<div className="col-lg-4 col-md-4">
									<div className="footer_widget">
									<h4 className="widget_title">PROJECTS BY LOCALITY</h4>
									<ul className="footer-menu">
										<li>
										<a href={"/in/pune/hinjewadi/projects"}>Top Projects in Hinjewadi</a>
										</li>
										<li>
										<a href={"/in/pune/wakad/projects"}>Top Projects in Wakad</a>
										</li>
										<li>
										<a href={"/in/pune/kharadi/projects"}>Top Projects in  Kharadi</a>
										</li>
										<li>
										<a href={"/in/pune/baner/projects"}>Top Projects in  Baner</a>
										</li>
									</ul>
									</div>
								</div>
								<div className="col-lg-4 col-md-4">
									<div className="footer_widget">
									  <h4 className="widget_title">PROJECTS BY PRICE RANGE</h4>
									<ul className="footer-menu">
										<li>
										<a href="#">1BHK Flat in Hinjewadi less than 45 lacs</a>
										</li>
										<li>
										<a href="#">1BHK Flat in Wakad less than 45 lacs</a>
										</li>
										<li>
										<a href="#">2BHK Flat in Kharadi less than 70 lacs</a>
										</li>
										<li>
										<a href="#">2BHK Flat in Hinjewadi less than 60 lacs</a>
										</li>
									</ul>
									</div>
								</div>
								<div className="col-lg-4 col-md-4">
									<div className="footer_widget">
									<h4 className="widget_title">PROJECTS BY TOP DEVELOPERS</h4>
									<ul className="footer-menu">
										<li>
										<a href={"/builders/vtp-realty"}>Projects by VTP Realty in Pune</a>
										</li>
										<li>
										<a href={"/builders/godrej-properties"}>Projects by Godrej Properties in Pune</a>
										</li>
										<li>
										<a href={"/builders/vilas-javdekar-developers"}>Projects by Vilas Javdekar in Pune</a>
										</li>
										<li>
										<a href={"/builders/kohinoor-group"}>Projects by Kohinoor Group in Pune</a>
										</li>
									</ul>
									</div>
								</div>
								</div>
							</div>
							<div className="footer-bottom">
								<div className="container">
									<div className="row align-items-center">
									<div className="col-lg-6 col-md-12">
										<ul className="menu">
										<li>
											<Link href={"/privacy-policy"}>
											<a> Privacy Policy</a>
											</Link>
										</li>
										<li>
											<Link href={"/disclaimer"}>
											<a>Disclaimer</a>
											</Link>
										</li>
										</ul>
									</div>
									<div className="col-lg-6 col-md-12" style={{ textAlign: "right" }}>
										<p className="mb-0">
										© 2022 Housiey 
										{/* Designd By <a href="#">TechCarrel</a>. */}
										</p>
									</div>
									</div>
								</div>
							</div>
						</div>
						
						
						:""}
						
					</div>
				</div>
				
			</footer>
           
        </>
    )
}

export default Footer_mobile;