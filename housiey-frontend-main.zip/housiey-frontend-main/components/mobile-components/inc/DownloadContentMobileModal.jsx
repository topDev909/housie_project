import React,{useState,useEffect}   from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {set_open_download_signup}      from '../../../redux/slices/signUpModalSlice';
import { useRouter }                from 'next/router';
import DownloadSignUpForm           from '../../component/Auth/DownloadSignUpForm';

const DownloadContentMobileModal = ({project})=>{


    const dispatch                  = useDispatch();
    const router                    = useRouter();

    const title                     = useSelector((state)=>state.signUpModal.signup_title)
    const openModal                 = useSelector((state)=>state.signUpModal.open_download_signup)
    const is_refreash               = useSelector((state)=>state.signUpModal.is_first_time_login);

    const MainTitle  = (title!=='video') ?  `Get ${project.project_name} ${title}` : ` Watch ${project.project_name} Full Video`;


    const closeModal = ()=>{
        if(is_refreash){
            router.reload(window.location.reload)
        }
        dispatch(set_open_download_signup(false))
    }

    const display       = (openModal)?'block':'none';
    const heightCount   = '56%';  
    return (
        <>
            <div className="bottomFotter DownloadContentMobileModal" style={{ height: openModal ? heightCount : "0",display:display}}>
                <h3>{MainTitle}</h3>
                <span className="mod-close" onClick={closeModal} aria-hidden="true" >
                    <i className="ti-close" />
                </span>
                <DownloadSignUpForm />
            </div>
        </>
    )
}
export default DownloadContentMobileModal;