/* eslint-disable @next/next/no-img-element */
import { useDispatch } from "react-redux";
import {  set_Sort_modal, set_Filter_modal } from '../../../redux/slices/MobileSignUpModalSlice';
function Listing_static_footer() {
    const dispatch = useDispatch();
    const myshort = () => {
        dispatch(set_Sort_modal(true))
    }
    const myfilter = () => {
        dispatch(set_Filter_modal(true))

    }

    return (
        <>

                <div className="fixed-bottom" id="fixed-footer">
                    <footer className="footer">
                        <div className="footer-btns">
                            <bottom className="btn  btn-secondary w-50 reset-filters" onClick={myshort} >
                                <img src="/assets/img/sort.png" className="short-icon" alt={'icon'}  /> Sort
                            </bottom>
                            <bottom className="btn w-50 apply-filters" onClick={myfilter} style={{ background:'#234e70',border:'none' }}  >
                                <img src="/assets/img/filter.png" className="short-icon" alt={'filter'}  /> Filter
                            </bottom>
                        </div>
                    </footer>
                </div>
        </>
    )
}

export default Listing_static_footer