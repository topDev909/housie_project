import React,{useState,useEffect}   from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {set_after_login_modal}      from '../../../redux/slices/signUpModalSlice';
import BookingSuccessMsg           from '../../inc/BookingSuccessMsg';
import ThanksContent from '../home-page/ThanksContent';
import { useRouter } from 'next/router';
import Confetti from 'react-confetti'

const AfterLoginThanksModal = ()=>{
    const dispatch                  = useDispatch();
    const router                    = useRouter();
    const openModal                 = useSelector((state)=>state.signUpModal.afterLoginModal)
    const show_sign_up_perks        = useSelector((state)=>state.signUpModal.show_sign_up_perks)
    const is_refreash               = useSelector((state)=>state.signUpModal.is_first_time_login);


    const closeModal = async()=>{
        if(is_refreash){
           await  router.reload(window.location.reload)
        }
        dispatch(set_after_login_modal(false))
    }

    const heightCount = show_sign_up_perks?'100%': '100%';  
    return (
        <>
            <div className="bottomFotter AfterLoginThanksModal" style={{ height: openModal ? heightCount : "0",overflowX:'auto' }}>
                <Confetti width={'400px'} />
                <span className="mod-close" onClick={closeModal} aria-hidden="true" >
                    <i className="ti-close" />
                </span>
                {show_sign_up_perks ? <><BookingSuccessMsg /><ThanksContent/></> : <><BookingSuccessMsg /> </>} 
            </div>
        </>
    )
}
export default AfterLoginThanksModal;