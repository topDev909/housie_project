/* eslint-disable @next/next/no-img-element */
/* eslint-disable @next/next/no-css-tags */

import React, { useState, useEffect } from 'react';
import { set_sign_up_modal } from '../../../redux/slices/MobileSignUpModalSlice';
import { useDispatch } from 'react-redux';
import Link from 'next/link';
import Stack from '@mui/material/Stack';
import { useRouter } from 'next/router';
import { AppBar, Toolbar, Avatar, Box, Divider, IconButton, List, ListItem,  ListItemText, makeStyles, CssBaseline, Drawer }
	from "@material-ui/core";
import { Menu } from "@material-ui/icons";
import { createTheme, ThemeProvider, styled } from '@mui/material/styles';

import CloseIcon from '@mui/icons-material/Close';


const theme = createTheme({
	typography: {
	  fontFamily: 'Raleway, Arial',
	},
  });

const useStyles = makeStyles((theme) => ({
	menuSliderContainer: {

		background: "#234e70",
		height: "100%"
	},
	listItem: {
		color: "white"
	},
	AppBar:{
		color: '#fff',
		background: 'transparent',
		padding:'0px',
	},
	hamIcon: {
		padding:'0px'
	},
	tooBar: {
		padding: '0px !important',
		boxShadow:'none',
	}
}));



const listItems = [
	{
		listText:  <Link href="/" ><a className="text-light" >Home</a></Link>
	},
	{
		listText:  <Link href="/about-us" ><a className="text-light" >About-Us</a></Link>
	},
	{
		listText:  <Link href={"/in/pune/projects"} ><a className="text-light" >Buy Property in Pune </a></Link>
	},
	{
		listText:  <Link href="/contact-us" ><a className="text-light" >Contact-Us</a></Link>
	},	
	{
		listText: <Link href="/privacy-policy" ><a className='text-light' >Privacy Policy</a></Link>
	},
	{
		listText: <Link href="/disclaimer" ><a className='text-light' >Disclaimer</a></Link>
	},
	

];

const HeaderMobile = () => {
	

	
	// drawer end
	const dispatch 			= useDispatch();
	const router 			= useRouter();
	const classes 			= useStyles();
	const [open, setOpen] 	= useState(false);

	const toggleSlider = () => {
		setOpen(!open);
	};



	const sideList = () => (
		<Box className={classes.menuSliderContainer} component="div"
			style={{ width: "300px" }}
		>



			<CloseIcon style={{ float: "right", color: "white" }} onClick={toggleSlider} />
			<Divider />
			<div>
			<img src="/assets/img/logo3.png" alt='Logo' width='50%' style={{textAlign: 'center'}} />
			</div>
			
			<List style={{ marginTop: "6%" }}>

				{listItems.map((listItem, index) => (
					<ListItem className={classes.listItem} button key={index} style={{borderBottom: '1px solid #cccccc45'}} >

						<ListItemText primary={listItem.listText} />

					</ListItem>

				))}

			</List>
			<ul className="text-center" style={{padding: "15px", color: "#fff"}}>
				<li>
					<a target='_blank' rel="noreferrer" href="https://api.whatsapp.com/send?phone=918097452839&text=Hello Housiey, Need assistance with home buying" style={{background: '#0e8744', padding: '10px', borderRadius: '5px', color: '#fff', justifyContent: 'center'}}>
					Support - <i className='fab fa-whatsapp' style={{top: 0, marginLeft:'4px'}}></i> 8097452839
					</a>
				</li>
				<li style={{marginTop: '15px'}}>
					<span className="text-center" style={{display: "flex", justifyContent: 'space-evenly'}}>
					<a href="https://www.facebook.com/housiey" 			target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-facebook" style={{color: "#fff" }}></i></a>
					<a href="https://www.linkedin.com/company/housiey" 	target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-linkedin" style={{color: "#fff"}}></i></a>
					<a href="https://www.youtube.com/c/Housiey" 		target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-youtube" style={{color: "#fff"}}></i></a>
					<a href="https://www.instagram.com/housiey/" 		target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-instagram" style={{color: "#fff"}}></i></a>
					</span>
				</li>
			</ul>
		</Box>
	);

	// const [getdata, setGetdata] = useState(get_user_data)
	const logoutsession = () => {
		localStorage.removeItem('housey_token')
		router.reload(window.location.reload)
	}

	const [userSession, setUserSession] = useState('');
	useEffect(() => {
		let jwt_get_data = localStorage.getItem('housey_token')
		let get_data = parseJwt(jwt_get_data);
		setUserSession(get_data);
	}, [])

	function parseJwt(token) {
		if (!token) { return; }
		const base64Url = token.split('.')[1];
		const base64 = base64Url.replace('-', '+').replace('_', '/');
		return JSON.parse(window.atob(base64));
	}


	return (
		<>
	

			<div id="main-wrapper">
				<div className="header header-transparent change-logo">
					<div className="container">
						<nav id="navigation" className="navigation navigation-landscape">
							<ThemeProvider theme={theme} >
								<div className="nav-header">
								
									{/* <CssBaseline    /> */}
									<Box component="nav"    >
										<AppBar position="static" className={classes.AppBar} style={{ background: 'transparent',padding:'0px',boxShadow: 'none'  }} >
											<Toolbar className={classes.tooBar} style={{ padding:'0px',background:'transparent' }}>
												<IconButton onClick={toggleSlider} className={classes.hamIcon}  >
													<Menu   />
												</IconButton>
												<Drawer open={open} anchor="left" onClose={toggleSlider}>
													{sideList()}
												</Drawer>
											</Toolbar>
										</AppBar>
									</Box>
									<a className="nav-brand static-logo" href="#">
										<img src="/assets/img/logo3.png" className="logo" alt="" style={{ borderRadius: "10px" }} />
									</a>
									<Link href={'/'} >
									<a className="nav-brand fixed-logo p-0">
										<img src="/assets/img/logo.png" className="logo" alt="" />
									</a>
									</Link>
									{/* <div className="nav-toggle"></div> */}



									<div className="mobile_nav ml-auto">
										<ul>
											{(userSession) ?
												<>
													{/* User Option Start */}
													<li>
														<div className="btn-group account-drop">
															<button
																type="button"
																className="btn btn-order-by-filt login"
																data-toggle="dropdown"
																aria-haspopup="true"
																aria-expanded="false"
															>
																{/* <FontAwesomeIcon icon={faBars} /> */}

																<Stack direction="row" spacing={2}>
																	<Avatar
																		src="/static/images/avatar/1.jpg"
																		sx={{ width: 32, height: 32 }}
																	/>
																	<span className="user-name">{userSession.name} <i className="ti-angle-down"></i></span>
																</Stack>

															</button>
															<div className="dropdown-menu pull-right animated flipInX">
																<ul>
																	<li onClick={logoutsession}>
																		<a href="#" >Logout</a>
																	</li>
																</ul>
															</div>
														</div>
													</li>
												</>
												:
												<li>
													<a href="#" onClick={() => {
														dispatch(set_sign_up_modal(true))
														}}>
														<b>Signup</b>
													</a>
												</li>
											}
										</ul>
									</div>
								</div>
							</ThemeProvider>
						</nav>
					</div>
				</div>
			</div>



		</>
	)
}
export default HeaderMobile; 