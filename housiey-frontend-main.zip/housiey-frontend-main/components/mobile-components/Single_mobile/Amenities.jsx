import React, { useState } from 'react'


const Amenities = ({ setamenities, setexamenities, setproject }) => {



    const amenitestdata     = setamenities;
    const examenitiesdata   = setexamenities;

    

    return (
        <>
            
                <div className="col-sm-12" id="amenities" >
                    <div className="_prtis_list mb-2 " style={{ paddingBottom: 10 }}>
                        <div className="_prtis_list_header min">
                            <h4 className="m-0"><span className="theme-cl">{(setproject) ? setproject.project_name : ""} </span>Amenities

                            </h4>
                        </div>
                        <div className="_prtis_list_body" style={{ padding: '0rem 0.5rem 0rem' }}>
                            <ul className="nav nav-tabs floor_plans" id="myTab" role="tablist">
                                <li className="nav-item">
                                    <a className="nav-link active" id="internal-tab" data-toggle="tab" href="#internal" role="tab" aria-controls="internal" aria-selected="false">Internal Amenities</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" id="external-tab" data-toggle="tab" href="#external" role="tab" aria-controls="external" aria-selected="false">External Amenities</a>
                                </li>
                            </ul>
                            <div className="tab-content" id="myTabContent">
                                <div className="tab-pane fade show active" id="internal" role="tabpanel" aria-labelledby="internal-tab">
                                    <div className="_prtis_list_body" id="internal-amenities" style={{ padding: '1rem 0rem' }}>
                                        <div className="col-sm-12">
                                            <div className="internal-amenities">

                                                <div className='row'>

                                                    {amenitestdata.map((items, index) => {
                                                        return (
                                                            <>
                                                                <div className="stats ml-2">
                                                                    <div>
                                                                        <div className="box">
                                                                            <span className="value">
                                                                                <img className='ame_img' src={process.env.BASE_URL + items.img} style={{width: '2rem', height: '2rem', objectFit: 'cover'}} /> 
                                                                            </span>
                                                                            <span className="parameter">{items.name} </span>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                            </>
                                                        )
                                                    })}
                                                </div>


                                                {amenitestdata.length>9?<>
                                                    <p style={{ textAlign: 'right' }}>
                                                        <a href="javascript:void(0)" className="show show-more1" style={{ fontSize: 13 }}>Show More</a>

                                                    </p>
                                                </>:""}
                                                


                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="tab-pane fade" id="external" role="tabpanel" aria-labelledby="external-tab">
                                    <div className="_prtis_list_body" id="master-plan" style={{ padding: '1rem 0rem' }}>
                                        <div className="col-sm-12">
                                            <div className="external-amenities">
                                                <div className='row'>

                                                    {examenitiesdata.map((item, index) => {
                                                        return (
                                                            <>
                                                                <div className="stats ml-2">
                                                                    <div>
                                                                        <div className="box">
                                                                            <span className="value"><img src={process.env.BASE_URL + item.img} style={{ width: "2rem", height: "2rem", objectFit: "cover" }} /> </span>
                                                                            <span className="parameter">{item.name}   </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </>
                                                        )
                                                    })}
                                                </div>

                                                {examenitiesdata.length >9?<>
                                                    <p style={{ textAlign: 'right' }}>
                                                        <a href="javascript:void(0)" className="show show-more2" style={{ fontSize: 13 }}>Show More</a>
                                                    </p>
                                                </>:""}
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </>
    )
}

export default Amenities