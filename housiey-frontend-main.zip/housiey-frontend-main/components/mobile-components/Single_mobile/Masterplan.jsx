import { useState, useEffect } from 'react'
import { useDispatch } from 'react-redux';
import { useRouter } from 'next/router';

// import { set_sign_up_modal, set_sign_up_next_step } from '../../../redux/slices/MobileSignUpModalSlice';


import { set_download_file, set_signup_title, set_open_download_signup } from '../../../redux/slices/signUpModalSlice';
import { set_download_modal } from '../../../redux/slices/MobileSignUpModalSlice';
import ImageGallery from 'react-image-gallery';
import {useSelector} from 'react-redux';


import Lightbox from 'react-image-lightbox';
import "react-image-lightbox/style.css";





const Masterplan = ({ setbrocher, setmaster_plan, setfloor_plan, setproject,plan_kit }) => {

    const masterplandata                        = setmaster_plan;
    const floorplandata                         = setfloor_plan;
    
    const [sliderImage, setSliderImage]         = useState([]);
    const masterPlaceSliderImg                  = setmaster_plan.map(element=>{return ( { original: process.env.BASE_URL+element.img })})
    const flourPlaneSliderImg                   = setfloor_plan.map(element=>{return ( { original: process.env.BASE_URL+element.img })})
    const enq_project_id                        = useSelector((state)=>state.signUpModal.enq_project_id)


    const [isOpen,setIsOpen]                    = useState(false)
    const [PhoneIndex,setPhotoIndex]            = useState(0);
    const [lightBoxImg,setLightBoxImg]          = useState([]);


    const dispatch = useDispatch();
    const router = useRouter();



    const masterfloor = (image) => {

        let img = [];
        let lightImg = [];
        image.forEach(element => {
            let obj = {
                original: process.env.BASE_URL + element.img
            }
            img.push(obj)
            lightImg.push(process.env.BASE_URL + element.img)
        });
        setSliderImage(img);
        setLightBoxImg(lightImg)
        setPhotoIndex(0)
        setIsOpen(true)

    }



    const DownloadPlanKit = async () => {
        let title = 'Plan Kit';
        dispatch(set_signup_title(title));
        const token = localStorage.getItem('housey_token')
        if(token){
          let url = `/api/download?link=` + plan_kit + `&name=plan-kit`;
          await router.push(url);
          dispatch(set_download_modal(true))


          let sendEnq = process.env.BASE_URL+`download-doc/${enq_project_id}`;
            let req     = await fetch(sendEnq,{
                headers: {
                    auth: token,
                    source: "plan kit"
                }
            });
            
        }else{
          let obj = {
            file: plan_kit,
            status: true,
            name: 'plan-kit'
          }

          dispatch(set_download_file(obj));
          dispatch(set_open_download_signup(true))
        }
    }



    return (
        <>

            
                <div className="col-sm-12" id="plan" style={{marginTop: '15px'}}>
                    <div className="_prtis_list mb-2 " style={{ paddingBottom: 10 }}>
                        <div className="_prtis_list_header min">
                            <h4 className="m-0"><span className="theme-cl">{(setproject) ? setproject.project_name : ""} </span>Master Floor Plan

                            </h4>
                        </div>
                        <div className="_prtis_list_body" style={{ padding: '0rem 0.5rem 0rem' }}>
                            <ul className="nav nav-tabs floor_plans" id="myTab" role="tablist">
                                <li className="nav-item">
                                    <a className="nav-link active" id="1bed-tab" data-toggle="tab" href="#1bed" role="tab" aria-controls="1bed" aria-selected="false">Master PLan</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" id="2bed-tab" data-toggle="tab" href="#2bed" role="tab" aria-controls="2bed" aria-selected="false">Floor Plan</a>
                                </li>
                            </ul>
                            <div className="tab-content" id="myTabContent">
                                <div className="tab-pane fade show active" id="1bed" role="tabpanel" aria-labelledby="1bed-tab">
                                    <div className="_prtis_list_body" id="master-plan" style={{ padding: '0rem 0rem 1rem' }}>
                                        <div className="property_video">

                                            <div className="thumb">
                                                <div  onClick={() => masterfloor(masterplandata)} >

                                                    <ImageGallery items={masterPlaceSliderImg} showPlayButton={false}  />

                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div className="tab-pane fade" id="2bed" role="tabpanel" aria-labelledby="2bed-tab">
                                    <div className="_prtis_list_body" id="master-plan" style={{ padding: '1rem 0rem' }}>
                                        <div className="property_video">
                                            <div className="thumb">
                                                <div  onClick={() => masterfloor(floorplandata)} >
                                                        <ImageGallery items={flourPlaneSliderImg} showPlayButton={false}  />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-12">
                            <div className="button-container">
                                <div className="button-block">
                                    <i className="fas fa-download button-image" />
                                    <button className="block-button-1" style={{ width: 80 }} onClick={() => DownloadPlanKit(setbrocher)} > Plan Kit</button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            {/* Modal */}
            <div>
                <div className="modal fade" id="exampleModal" tabIndex={-1} role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog modal-xl" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLabel"></h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body p-0">
                                <ImageGallery items={sliderImage} showPlayButton={false} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            {isOpen && (
          <Lightbox
            mainSrc={lightBoxImg[PhoneIndex]}
            nextSrc={lightBoxImg[(PhoneIndex + 1) % lightBoxImg.length]}
            prevSrc={lightBoxImg[(PhoneIndex + lightBoxImg.length - 1) % lightBoxImg.length]}

            mainSrcThumbnail={lightBoxImg[PhoneIndex]}

            onCloseRequest={() => setIsOpen(false)}
            onMovePrevRequest={() =>
                setPhotoIndex((PhoneIndex + lightBoxImg.length - 1) % lightBoxImg.length)
            }
            onMoveNextRequest={() =>
                setPhotoIndex((PhoneIndex + 1) % lightBoxImg.length)
            }
          />
        )}


        </>
    )
}

export default Masterplan