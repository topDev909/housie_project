import React from 'react';


import ReactPlayer from 'react-player'
import { useState } from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import SwipeableViews from 'react-swipeable-views';
import AppBar from '@mui/material/AppBar';
import Typography from '@mui/material/Typography';  
import PropTypes from 'prop-types';


const  TabPanel = (props)=>{
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`full-width-tabpanel-${index}`}
            aria-labelledby={`full-width-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

const  a11yProps = (index)=>{
    return {
        id: `full-width-tab-${index}`,
        'aria-controls': `full-width-tabpanel-${index}`,
    };
}



    const MobileVideosSection = ({setproject_videos})=>{


        const [video, setVideo]                 = useState(setproject_videos)
        const [isVideoPlay, setVideoPlay]       = useState(false)
        const [playingVideo,setPlayingVideo]    = useState('');
        const [value, setValue]                 = React.useState(0);

        const handleChange = (event, newValue) => {
            setValue(newValue);
        };

        const openvideo = (vLink) => {
            console.log('we clicked')
            if (localStorage.getItem('housey_token')) {
                $('#popup-video').modal('show')
                setPlayingVideo(vLink);
                setVideoPlay(true);
            }
            else {
                setPlayingVideo(vLink);
                setVideoPlay(true);
                $('#popup-video').modal('show')
                startVideoForSec()
                // $('#login').modal('show')
            }
        }


        // const startVideoForSec = ()=>{
        //     console.log('Here we are ')
        //     setTimeout(() => {
        //         setVideoPlay(false);
        //         $('#login').modal('show')       
        //     }, 15000);
        // }


        
const [isPlayer,setIsPlayingV] = useState(false);

const CheckLogin = ()=>{
    console.log('--------------- here  ------------------')
    if (localStorage.getItem('housey_token')) {
        setIsPlayingV(true)   
    }
    else{
        setIsPlayingV(true)
        setTimeout(() => {
            setIsPlayingV(false);
            dispatch(set_sign_up_modal(true))
        }, 15000);
    }
}


    return (
        <>
            <Box>

                          <AppBar position="static">
                                  
                          <Tabs
                              value={value}
                              onChange={handleChange}
                              variant="scrollable"
                              scrollButtons="auto"
                              allowScrollButtonsMobile={true}
                              aria-label="scrollable auto tabs example"
                          >
                              {video.map((content, index) =>  <Tab label={content.type} onClick={(e) => setValue(index)} className='tab-style' key={index} />  )
                          }
                          </Tabs>
                          </AppBar>



                          <SwipeableViews index={value} >
                              {video.map((content, index) => (
                                      <TabPanel value={value} key={index} >
                                      <div className="property_video mobile-video-overlay" onClick={CheckLogin}>
                                          <div className="thumb" >
                                              <ReactPlayer url={content.video} controls={true}  width={507} playing={isPlayer} />
                                              <div className="overlay_icon" style={{display: 'none'}}>
                                                  <div className="bb-video-box">
                                                      <div className="bb-video-box-inner">
                                                          <div className="bb-video-box-innerup">
                                                              <button 
                                                                  className="link-btn theme-cl "
                                                              >
                                                                  <i className="ti-control-play" />
                                                              </button>
                                                          </div>
                                                      </div>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                      </TabPanel>
                                  )
                                )}

                          </SwipeableViews>    
                      </Box>

        </>
    )
}
export default MobileVideosSection;