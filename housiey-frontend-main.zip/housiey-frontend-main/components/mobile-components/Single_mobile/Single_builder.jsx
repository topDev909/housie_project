import LongDescription                from '../../component/common/LongDescription';
import React, { useEffect, useState } from 'react'
import { slugGenrator }               from '../../../utils/BasicFn';
import Link                           from 'next/link';
const Single_builder = ({ setproject }) => {



  const [mydata, setMydata] = useState([])

  const fetchUseEfect = async ()=>{
    const response  = await fetch(process.env.BASE_URL + `builder-info/`+setproject.builder_id);
      let data      = await response.json();
      if (data.res === true) {  
        setMydata(data.builder_info)
      }
  }

  useEffect(()=>{
    fetchUseEfect()
  },[setproject.builder_id])


  return (
    <>
    <div className="container">
      <div className="_prtis_list mb-2" id="top-builders">
      { mydata.map((items,index) => {
        return (
        <div className="_prtis_list_header min" key={index} >
          <h4 className="m-0" ><span className="theme-cl">About {items.builder_name}</span>
          </h4>
        </div>
        )})}
        {
          mydata.map((items,index) => {
            return (
              <div className="_prtis_list_body builder-details" key={index} style={{ padding: "1rem 1rem 3rem 1rem" }}>
                <div className="builder-overview">
                  <div className="col-4 builder-img">
                    <img src={process.env.BASE_URL+items.logo} />
                  </div>
                  <div className="col-8 builder-states">
                    <ul className="text-center">
                      <li>
                        <span>{items.experience}yrs</span>
                        <p>Experience</p>
                      </li>
                      <li>
                        <span>{items.projects_comp}</span>
                        <p>Total Projects</p>
                      </li>
                      <li>
                        <span>{items.happy_families}</span>
                        <p>Happy Families</p>
                      </li>
                    </ul>

                  </div>
                </div>
                <div className="builder-description">
                  <h4 className="builder-name">{items.builder_name}</h4>
                  <p className="builder-city">{items.cities}</p>
                  <div className="_rate_stio">
                    <i className="fa fa-star" />
                    <i className="fa fa-star" />
                    <i className="fa fa-star" />
                    <i className="fa fa-star" />
                    <i className="fa fa-star" />
                  </div>
                  <div>
                  <LongDescription content={items.description} wordlength={250} />
                  </div>
                  <div className="button-block" style={{ float: "right" }}>
                    <Link href={"/builders/"+slugGenrator(items.builder_name)} >
                      <button className="block-button-1" style={{ width: 119, textAlign: 'center' }} >View Project</button>
                    </Link>
                  </div>
                </div>
              </div>
            )})}
      </div>
    </div>

    </>
  )
}

export default Single_builder