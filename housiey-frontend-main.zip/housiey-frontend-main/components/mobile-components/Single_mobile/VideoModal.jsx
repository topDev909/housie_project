import React,{useState,useEffect} from 'react';
import { useDispatch,useSelector } from 'react-redux';
import ReactPlayer from 'react-player';
import { set_video } from '../../../redux/slices/projectsSlice';
const VideoModal = ({project})=>{
    // set_video
    const video_src  = useSelector((state)=>state.projects.video_modal_src)
    const [isVideoPlay,setIsVideoPlay] = useState(false);
    const dispatch = useDispatch();
    const  closeModal  = ()=>{
        $('#video-modal').modal('hide')
        setIsVideoPlay(false)
        dispatch(set_video(''));
    }   
    return (
        <>
            <div
            className="modal fade"
            id="video-modal"
            aria-hidden="true"
            aria-labelledby="video-modalLabel"
            tabIndex={-1}
            data-backdrop="static"
            data-keyboard="false"
            >
            <div className="modal-dialog modal-dialog-centered">
                <div className="modal-content">
                <div className="modal-header">
                    <h5 className="modal-title" id="video-modalLabel">
                    {project.project_name} Videos
                    </h5>
                    <button
                    type="button"
                    className="btn-close"
                        onClick={closeModal}
                    >
                        &times;
                    </button>
                </div>
                <div className="modal-body p-0">
                    <ReactPlayer url={video_src} controls={true}  width={'100%'}   playing={isVideoPlay} />
                </div>
                </div>
            </div>
            </div>
        </>
    )
}
export default VideoModal