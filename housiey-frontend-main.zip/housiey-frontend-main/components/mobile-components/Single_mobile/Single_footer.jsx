import React,{useState,useEffect} from 'react';
import { useDispatch }            from 'react-redux';
import { useRouter }              from 'next/router';
import { set_download_file, set_signup_title,set_active_tab,set_open_download_signup  } from '../../../redux/slices/signUpModalSlice';
import { select_project } from "../../../redux/slices/projectsSlice";
import Link from 'next/link';
import { set_download_modal, set_step1_modal } from '../../../redux/slices/MobileSignUpModalSlice';

const Single_footer = ({setbrocher, project,sellerInfo}) => {



  
  let msg = ` Hello, *${sellerInfo ? sellerInfo[0].name:''}* Need More Details about the *${project.project_name}* `;
    

  const dispatch  = useDispatch();
  const router    = useRouter();
  const DownloadBrochure = async () => {
    let title = 'Brochure';
    dispatch(set_signup_title(title));
    const token = localStorage.getItem('housey_token')
    if(token){
      let url = `/api/download?link=` + setbrocher + `&name=brochure`;
      await router.push(url);
      dispatch(set_download_modal(true))
    }else{
      let obj = {
        file: setbrocher,
        status: true,
        name: 'brochure'
      }
      dispatch(set_download_file(obj));
      dispatch(set_open_download_signup(true))
    }
}

    
const openmodal = async () => {

  let arr = [];
    let obj = {
      project_name: project.project_name,
      slug:         project.slug,
      id:           project.id
    }
    arr.push(obj);
    dispatch(select_project(arr));
    // dispatch(set_ola_modal_tab(true));
    dispatch(set_active_tab('1'))
    dispatch(set_step1_modal(true))
}


  return (
    <>
         <div className="fixed-bottom" id="fixed-footer">
          <footer className="footer">
            <div className="row">
              <div className="col-12 text-center" style={{display: 'flex'}}>
                <div className="col-4" style={{borderColor: '#fff', fontSize: 18, padding: 15, color: '#fff', borderRight: '1px solid #ccc'}}
                  onClick={openmodal}
                >
                  <i className="fa fa-desktop" style={{fontSize: 13}} /> | <i className="fa fa-car" style={{fontSize: 15}} /> Tour
                </div>
                <div className="col-4" style={{borderColor: '#fff', fontSize: 18, padding: '15px 0px', color: '#fff', borderRight: '1px solid #ccc'}} onClick={DownloadBrochure}>
                  <i className="fas fa-download" style={{fontSize: 15}} /> Brochure
                </div>
                <div className="col-4" style={{borderColor: '#fff', fontSize: 18, padding: 15, color: '#fff', borderLeft: '1px solid #ccc'}}>
                  {/* <i className="fab fa-whatsapp" style={{fontSize: 15}} /> Live Chat
                   */}

                    <Link href={`https://api.whatsapp.com/send?phone=91${(sellerInfo) && sellerInfo[0].phone}&text=${msg}`}>
                        <a  className="reply" target={'_blank'} style={{ color: '#fff' }} >
                            <i className="fab fa-whatsapp"  style={{fontSize: 15}} /> Live Chat
                        </a>
                    </Link>

                </div>
              </div>
            </div>
          </footer>
        </div>


    </>
  )
}

export default Single_footer