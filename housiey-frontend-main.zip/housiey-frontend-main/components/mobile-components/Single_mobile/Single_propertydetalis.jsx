
import TabList from '@mui/lab/TabList';
import TabContext from '@mui/lab/TabContext';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import TabPanel from '@mui/lab/TabPanel';

import { useState, useEffect } from 'react'
import Single_Location from './Single_Location'
import { useDispatch,useSelector } from 'react-redux';
import ReactPlayer from 'react-player'
import { useRouter } from 'next/router';
import { set_download_file, set_signup_title,set_open_download_signup } from '../../../redux/slices/signUpModalSlice';
import { set_download_modal } from '../../../redux/slices/MobileSignUpModalSlice';
import {set_video} from '../../../redux/slices/projectsSlice';
import LongDescription from '../../component/common/LongDescription';
import Sitevisit_mobile from '../home-page/Sitevisit_mobile';
import Amenities from './Amenities';

import Masterplan from './Masterplan';

const Single_propertydetalis = ({ setbrocher, setproject_videos, setcons, setpros, setfloor_plan, setlocation, setdetalis, setamenities, setproject, setexamenities, setmaster_plan, plan_kit, rera_details }) => {

  const [value, setValue] = useState(0);

  const enq_project_id        = useSelector((state)=>state.signUpModal.enq_project_id)


  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const defaultProps = {
    center: {
      lat: (setlocation.length) ? setlocation[0].lat : '',
      lng: (setlocation.length) ? setlocation[0].lng : ''
    },
    zoom: 11
  };
  const dispatch = useDispatch();
  const router = useRouter();
  const [isVideoPlay, setVideoPlay]     = useState(false);
  const [videoSrc, setVideoSrc]         = useState('');
  const [userSession, setUserSession]   = useState('');


  const project           = [setproject]
  const projectvideo      = setproject_videos;


  const Brochuredata = async (link) => {
    let title = 'Brochure';
    dispatch(set_signup_title(title));
    let token = localStorage.getItem('housey_token')
    if(userSession){
      let url = `/api/download?link=` + link + `&name=brochure`;
      await router.push(url);


      let sendEnq = process.env.BASE_URL+`download-doc/${enq_project_id}`;
      let req     = await fetch(sendEnq,{
          headers: {
              auth: token,
              source: "brochure"
          }
      });

      dispatch(set_download_modal(true))
    }else{
      let obj = {
        file: link,
        status: true,
        name: 'brochure'
      }
      dispatch(set_download_file(obj));
      dispatch(set_open_download_signup(true))
    }
  }


  const openvideo = (link) => {
    $('#video-modal').modal('show')
    dispatch(set_video(link))
}


  useEffect(() => {
    let jwt_get_data = localStorage.getItem('housey_token')
    setUserSession(jwt_get_data);
  }, [])



  
const [isPlayer,setIsPlayingV] = useState(false);

const CheckLogin = ()=>{
    if (localStorage.getItem('housey_token')) {
        setIsPlayingV(true)   
    }
    else{
        setIsPlayingV(true)
        setTimeout(() => {
            setIsPlayingV(false);            
            dispatch(set_signup_title('video'))
            dispatch(set_open_download_signup(true))
        }, 15000);
    }
}

  return (
    <>


      <section className="pt-4" style={{ paddingBottom: 0 }}>
        <div className="container">
          <div className="row">
            {/* property main detail */}
            <div className="col-lg-12 col-md-12 col-sm-12">
              {/* <h4>Overview & Description</h4> */}
              <div className="_prtis_list mb-4" id="overview" >
                <div className="_prtis_list_header min">
                  <h4 className="m-0"><span className="theme-cl"> {(setproject) ? setproject.project_name : ""} Overview</span>
                  </h4>
                </div>
                <div className="_prtis_list_header config" style={{padding: '1.5rem 0rem 1.5em'}}>
                  {project.map((data) => {
                    return (
                      <>

                        <div className="row">
                          <ul>
                            <div className="col-6">
                              <li>
                                <div className="content">
                                  <span className="dark">{data.land_parcel}</span>
                                  <span className="title">Land Parcel</span>
                                </div>
                              </li>
                            </div>
                            <div className="col-6">
                              <li>
                                <div className="content">
                                  <span className="dark">{data.no_of_towers}</span>
                                  <span className="title">Towers</span>
                                </div>
                              </li>
                            </div>
                            <div className="col-6">
                              <li>
                                <div className="content">
                                  {data.no_of_floors ? <>
                                    <span className="dark">{data.no_of_floors}</span>
                                    <span className="title">Floors</span>
                                  </> : ''}
                                </div>
                              </li>
                            </div>
                            <div className="col-6 ">
                              <li>
                                <div className="content">
                                  {data.config ? <>
                                    <span className="dark">{data.config}</span>
                                    <span className="title">Config</span>
                                  </> : ''}
                                </div>
                              </li>
                            </div>
                            <div className="col-6">
                              <li>
                                <div className="content">
                                  {data.area_range_max ? <>
                                    <span className="dark">{data.area_range_min}-{data.area_range_max} Sq.Ft.</span>
                                    <span className="title">Carpet Area</span>
                                  </> : ''}
                                </div>
                              </li>
                            </div>
                            <div className="col-6">
                              <li>
                                <div className="content">
                                  {rera_details && rera_details.map((single_rera) => (
                                    <>
                                      <span className="dark">
                                        <a href={single_rera.rera_link} rel="noreferrer" target={"_blank"} style={{ color: "blue" }}>{single_rera.rera_no}</a>
                                      </span>
                                    </>
                                  ))}

                                  <span className="title">RERA No.</span>
                                </div>
                              </li>
                            </div>
                            <div className="col-6">
                              <li>
                                {/* <div class="content_thumb"><img src="assets/img/area.svg" alt="" /></div> */}
                                {data.target_possession ? <>
                                  <div className="content">
                                    <span className="dark">{data.target_possession}</span>
                                    <span className="title">Target Possession</span>
                                  </div>
                                </> : ''}
                              </li>
                            </div>

                            <div className="col-6">
                              <li>
                                {/* <div class="content_thumb"><img src="assets/img/area.svg" alt="" /></div> */}
                                {data.rera_possession ? <>
                                  <div className="content">
                                    <span className="dark">{data.rera_possession}</span>
                                    <span className="title">RERA Possession</span>
                                  </div>
                                </> : ''}
                              </li>
                            </div>

                          </ul>
                        </div>
                      </>
                    )
                  })
                  }
                </div>
                {project.map((name) =>
                    <div key={name} className="_prtis_list_body" style={{padding: '1.5rem 1rem'}}>
                      <h5>About {name.project_name} </h5>
                      <LongDescription content={name.about} wordlength={210} />


                      <div className="button-container">
                        <div className="button-block">
                          <i className="fas fa-download button-image" />
                          
                          <button onClick={() => Brochuredata(setbrocher)} className="block-button-1" style={{ width: 85 }}> Brochure</button>
                        </div>
                      </div>
                    </div>
                )}


              </div>
            </div>

            {/*Location Start & Pros */}
            <Single_Location setlocation={setlocation} setVideoSrc={setVideoSrc} setIsPlaying={setVideoPlay} setproject={setproject} setcons={setcons} setpros={setpros} />
            {/*Location End & Pros */}

            {/* video section start */}


              <div className="col-sm-12 mobile-video-section"  id="video" >
                <div className="_prtis_list mb-2">
                  <div className="_prtis_list_header min">
                    <h4 className="m-0"><span className="theme-cl">{(setproject) ? setproject.project_name : ""} </span>Video
                    </h4>
                  </div>

                  <div className="_prtis_list_body" style={{padding: '0rem 1rem 1rem'}}>
                    <Box>
                      <TabContext value={value}>
                        <Box sx={{ bgcolor: 'background.paper' }}>
                          <TabList onChange={handleChange} aria-label="lab API tabs example" variant="scrollable" scrollButtons={'auto'} allowScrollButtonsMobile={true}>
                            {projectvideo.map((content, index) => {
                              return (
                                <>
                                  <Tab label={content.type} onClick={(e) => setValue(index)} className='tab-style'
                                    scrollButtons="auto" style={{ marginRight: '12px'  }} />
                                </>
                              )
                            })
                            }
                          </TabList>
                        </Box>
                        {projectvideo.map((content, index) => (
                          <TabPanel value={index} key={index} style={{padding: '0px'}}>
                            <div className={`  ${isPlayer?" property_video mt-2 ": " property_video mt-2 mobile-video-overlay"}`}  onClick={CheckLogin}  >
                              <div className="thumb" >
                                <ReactPlayer className="react-mobile-player" url={content.video} controls={true}  playing={isPlayer} width="100%" heigth="240px" />
                              </div>
                            </div>
                          </TabPanel>
                        ))}
                      </TabContext>
                    </Box>
                  </div>
                </div>
              </div>



            {/* video section End */}

            {/* amenities start */}
            <Amenities setamenities={setamenities} setexamenities={setexamenities} setproject={setproject} />
            {/* amenities End */}

              <div className="col-md-12  p-0" >
                <Sitevisit_mobile/>
              </div>
 
            {/* Master plan start */}
            <Masterplan setproject={setproject} setmaster_plan={setmaster_plan} setfloor_plan={setfloor_plan} plan_kit={plan_kit} />
            {/* Master plan End */}
            {/* ============================ Our Counter End ================================== */}
          </div>
        </div>
      </section>

    </>
  )
}

export default Single_propertydetalis