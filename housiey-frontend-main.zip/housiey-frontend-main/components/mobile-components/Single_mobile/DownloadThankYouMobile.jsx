import React from 'react';
import { useSelector,useDispatch }  from 'react-redux';
import DownloadModalContent         from '../../inc/DownloadModalContent';
import ThanksContent                from '../home-page/ThanksContent';
import { set_download_modal }       from '../../../redux/slices/MobileSignUpModalSlice';
import { useRouter } from 'next/router';

// import useWindowSize from 'react-use/lib/useWindowSize'
import Confetti from 'react-confetti'


const DownloadThankYouMobile  =({sellerInfo,project})=>{
    const dispatch = useDispatch();
    const router                    = useRouter();

    const openModal                 = useSelector((state)=>state.MobileSignUpModal.openDownloadModal)
    const show_sign_up_perks        = useSelector((state)=>state.signUpModal.show_sign_up_perks)
    const is_refreash               = useSelector((state)=>state.signUpModal.is_first_time_login);
    const heightCount               = show_sign_up_perks?'80%': '40%';  
    // const { width, height } = useWindowSize()


    const closeModal  =()=>{
        if(is_refreash){
            router.reload(window.location.reload)
        }
        dispatch(set_download_modal(false))
    }
    return (
        <>

            
            <div className="bottomFotter AfterLoginThanksModal" style={{ height: openModal ? heightCount : "0"}}>
                {openModal ? <><Confetti width={'400px'} /></> : <></>}
                <span className="mod-close" onClick={closeModal} aria-hidden="true" >
                    <i className="ti-close" />
                </span>
                {show_sign_up_perks ? <><DownloadModalContent sellerInfo={sellerInfo} project={project} /><ThanksContent/></> : <><DownloadModalContent sellerInfo={sellerInfo} project={project} /> </>} 
            </div>
        </>
    )
}
export default DownloadThankYouMobile;