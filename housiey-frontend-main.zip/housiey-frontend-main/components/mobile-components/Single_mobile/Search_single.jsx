import React from 'react'

const Search_single = () => {
  return (
    <>
     
                <div className="container top-search">
        <div className="row" style={{background: '#000'}}>
            <div className="col-12">
            <div className="form-group" style={{marginTop: 8}}>
                <span><a href="#"><i className="fa fa-search" style={{position: 'absolute', right: 15, top: 10, color: '#000'}} /></a></span>
              <input type="text" className="form-control search_input b-0" style={{ height: "30px",padding:"0px 0 0 15px"}} placeholder="Enter location, builder, project*" />
            </div>
            </div>
        </div>
        </div>

      <div id="navbar">
  <div className="example-three">
    <nav className="vertical-align-middle scroll">
      <span className="nav-item"><a href="#overview" > Overview</a></span>
      <span className="nav-item active"><a href="#"> Location</a></span>
      <span className="nav-item"><a href="#"> Amenities</a></span>
      <span className="nav-item"><a href="#"> Master Floor Plan</a></span>
      <span className="nav-item"><a href="#"> Price UNit Plan</a></span>
      <span className="nav-item"><a href="#"> Payment Scheme</a></span>
    </nav>
  </div>
</div>


    </>
  )
}

export default Search_single