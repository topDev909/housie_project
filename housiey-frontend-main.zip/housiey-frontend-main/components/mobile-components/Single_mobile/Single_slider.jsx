import "react-responsive-carousel/lib/styles/carousel.min.css"
import { Carousel } from 'react-responsive-carousel';
import { useState } from "react";
import { slugGenrator } from "../../../utils/BasicFn";
import Link from 'next/link';

import Lightbox from 'react-image-lightbox';
import "react-image-lightbox/style.css";
const Single_slider = ({ setproject, address, images, location }) => {

  const mylocation                                = location[0];

  const [maxSliderImg,setMaxSliderImg]            = useState([]);

  const [isOpen,setIsOpen]                        = useState(false)
  const [PhoneIndex,setPhotoIndex]                = useState(0);




  function numDifferentiation(value) {
    var val = Math.abs(value)
    if (val >= 10000000) {
      val = (val / 10000000).toFixed(2) + ' Cr';
    } else if (val >= 100000) {
      val = (val / 100000).toFixed(2) + ' Lac';
    }
    return val;
  }


  
const openModal = ()=>{
    let lightBox = []
    images.map((singleImg)=>{
        lightBox.push(process.env.BASE_URL+singleImg.img)
    })
    setMaxSliderImg(lightBox)
    setIsOpen(true)
    setPhotoIndex(0)
}


  return (
    <>


    <section id="detail" style={{ background: '#f4f8fa', padding: '25px 0 15px', marginTop: '50px' }}> 
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div className="row">
                <div className="col-lg-12 col-md-12">
                  <div className="property_lexible-1">
                    <div className="pr-price-into flex-1">
                      <div className="_card_list_flex">
                        <div className="_card_flex_01">
                          <h4 className="listing-name verified" style={{ fontSize: 12, lineHeight: 0 }}>
                            <a href="single-property-1.html" className="prt-link-detail" />
                                <Link href={'/'}><a  >Home</a></Link>&gt;
                                <Link href={slugGenrator(mylocation.city)}><a> {(mylocation) ? mylocation.city : ""}</a></Link>
                               &gt; 
                               <Link href={slugGenrator(mylocation.locality)} >
                                <a>{(mylocation) ? mylocation.locality : ""} </a>
                               </Link>  
                             </h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-sm-12" style={{margonTop: '8px'}}>
                  <div className="product-images demo-gallery" id="mobile-detail-banner-slider">
                    <div className="_exlio_129">Save {numDifferentiation((setproject) ? setproject.saving_amt : "")}</div>

                    <div className='slider-overlay hero' onClick={openModal}  ></div>
                    <Carousel
                      autoPlay={false}
                      showArrows={true}
                      showThumbs={false}
                      showStatus={false}
                      showIndicators={false}
                    >
                      {images.map((item, index) =>
                        <img src={process.env.BASE_URL + item.img} key={index} className="mobile-slider-img-112"alt={(setproject) ? 'banner-'+setproject.project_name : "Banner"} />
                      )}
                    </Carousel>


                  </div>
                </div>
                <div className="col-lg-12 col-md-12">
                  <div className="property_lexible-1">
                    <div className="pr-price-into flex-1">
                      <h2 className="project_name">{(setproject) ? setproject.project_name : ""}</h2>
                      <p className="builder_location" style={{marginBottom: 0}}><span>By <a href="#">{(setproject) ? setproject.builder_name : ""}</a></span> | <span><a href="#">{(address) ? address : ""}</a></span></p>
                    </div>
                    <div className="price_into_last" style={{ margin: 0, padding: 0 }}>
                      <h2 className="project_price"><i className="fas fa-rupee-sign" />  {(setproject) ? setproject.overall_price_range : ""} <span style={{ fontSize: 12 }}>  All Inc.</span> </h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="special-offer mt-2">
            <span><b className="offer">OFFER</b>Save Upto Rs.{numDifferentiation((setproject) ? setproject.saving_amt : "")}*</span>
          </div>
        </div>
      </section>

      {isOpen && (
          <Lightbox
            mainSrc={maxSliderImg[PhoneIndex]}
            nextSrc={maxSliderImg[(PhoneIndex + 1) % maxSliderImg.length]}
            prevSrc={maxSliderImg[(PhoneIndex + maxSliderImg.length - 1) % maxSliderImg.length]}

            mainSrcThumbnail={maxSliderImg[PhoneIndex]}

            onCloseRequest={() => setIsOpen(false)}
            onMovePrevRequest={() =>
                setPhotoIndex((PhoneIndex + maxSliderImg.length - 1) % maxSliderImg.length)
            }
            onMoveNextRequest={() =>
                setPhotoIndex((PhoneIndex + 1) % maxSliderImg.length)
            }
          />
        )}

    </>
  )
}

export default Single_slider