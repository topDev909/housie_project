import React,{useState,useEffect} from 'react';

import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import {numFormatter} from '../../../utils/BasicFn';

import Lightbox from 'react-image-lightbox';
import "react-image-lightbox/style.css";





const PriceSheet = ({detalisdata,project,conigsdata})=>{

    const [value, setValue]                         = React.useState(0);
    const [isOpen,setIsOpen]                        = useState(false)
    const [PhoneIndex,setPhotoIndex]                = useState(0);
    const [lightBoxImg,setLightBoxImg]              = useState([]);



    useEffect(()=>{
        setValue(conigsdata[0].config_id);
        getCarpetArea(conigsdata[0].config_id)
    },[])

    const [carpetAreas,setCarpetAreas]              = useState([]);
    const [activeCarpetArea,setActiveCarpetArea]    = useState('');
    const getCarpetArea  = async (cid)=>{
        setValue(cid);
        const req = await fetch(process.env.BASE_URL+'get-config-by-id/'+project.id+'/'+cid)
        if(req.ok){
            const res       = await req.json();
            const mainData  = res.data[0];
            setActiveCarpetArea(mainData.carpet_area)
            getCarpetDetaisl(cid,mainData.carpet_area)
            setCarpetAreas(res.data)
        }
    }

    const handleChangeCarpetArea = (e,area)=>{
        setActiveCarpetArea(area)
        getCarpetDetaisl(value,area)
    }
    const [MainTebContent,setMainTebContent] = useState([]);

    const getCarpetDetaisl = async (cid,carpet_area)=>{
        const req = await fetch(process.env.BASE_URL+'get-config-by-id/'+project.id+'/'+cid+"?carpet_area="+carpet_area)
        if(req.ok){
            const res = await req.json();
            if(res.res){
                setMainTebContent(res.data)
            }
        }
    }


    const openImageModal = (src)=>{
        setLightBoxImg([src])
        setIsOpen(true)
        setPhotoIndex(0)
    }


    return (
        <>





        {detalisdata && <>                    
            <div className="_prtis_list_body" id="mobile-unit-plan" style={{ padding: '0rem 0.6rem' }}>
                <div className="row">
                    <div className="col-12">
                            <Tabs
                                value={value}
                                onChange={(e,val)=>getCarpetArea(val)}
                                textColor="secondary"
                                indicatorColor="secondary"
                                variant="scrollable"
                                scrollButtons="auto"
                                allowScrollButtonsMobile
                                aria-label="scrollable auto tabs example"
                            >
                                {conigsdata.map((bhk, index) => {
                                    return (<Tab value={bhk.config_id} label={bhk.config_name} key={index} /> 
                                )})}
                            </Tabs>

                            <div className="" >
                                
                            <Tabs
                                value={activeCarpetArea}
                                onChange={handleChangeCarpetArea}
                                textColor="secondary"
                                indicatorColor="secondary"
                                variant="scrollable"
                                scrollButtons="auto"
                                aria-label="scrollable auto tabs example"
                            >
                                {carpetAreas.map((singleCarpet,index)=>(<Tab value={singleCarpet.carpet_area} label={singleCarpet.carpet_area+" Sq.Ft"} key={index} />))}
                            </Tabs>
                                {MainTebContent.map((item,index)=>(
                                    <>
                                    <div className="mt-3" key={index} >
                                        <div className="col-12 overlay1 "  
                                            onClick={()=>openImageModal(process.env.BASE_URL+item.unit_plan_img)}
                                        >
                                        <a href="#" className="theme-cl "  >
                                            <img src={process.env.BASE_URL+item.unit_plan_img} width="100%" alt={'plat-img'} style={{height: '200px'}}  />
                                        </a>
                                        </div>
                                        <div className="row" style={{ padding: '25px 10px 10px' }}>
                                        <div className="col-6 mb-3">
                                            <h4 style={{ fontSize: 14, color: '#234e70', marginBottom: 0 }}><i className="fas fa-rupee-sign" style={{ fontSize: 11 }} /> {numFormatter(item.price)} <small  className='all-inc'>All In</small> </h4>
                                            <span style={{ fontSize: 13 }}>Price</span>
                                        </div>
                                        <div className="col-6 mb-3">
                                            <h4 style={{ fontSize: 14, color: '#234e70', marginBottom: 0 }}><i className="fas fa-rupee-sign" style={{ fontSize: 11 }} /> {numFormatter(item.down_payment)} </h4>
                                            <span style={{ fontSize: 13 }}>Downpayment</span>
                                        </div>
                                        <div className="col-6 mb-2">
                                            <h4 style={{ fontSize: 14, color: '#234e70', marginBottom: 3 }}>{item.parking_type}</h4>
                                            <span style={{ fontSize: 13 }}>Parking</span>
                                        </div>

                                        <div className="col-6 mb-2">
                                            <h4 style={{ fontSize: 14, color: '#234e70', marginBottom: 3 }}>
                                                {item.builtup_area ?  item.builtup_area+ ' sq.ft.' : '-'} 
                                            </h4>
                                            <span style={{ fontSize: 13 }}>Buildup Area</span>
                                        </div>

                                        </div>
                                    </div>
                                    </>
                                ))} 
                            </div>
                    </div>
                </div>
            </div>
        </>}





        {isOpen && (
          <Lightbox
            mainSrc={lightBoxImg[PhoneIndex]}
            nextSrc={lightBoxImg[(PhoneIndex + 1) % lightBoxImg.length]}
            prevSrc={lightBoxImg[(PhoneIndex + lightBoxImg.length - 1) % lightBoxImg.length]}

            mainSrcThumbnail={lightBoxImg[PhoneIndex]}

            onCloseRequest={() => setIsOpen(false)}
            onMovePrevRequest={() =>
                setPhotoIndex((PhoneIndex + lightBoxImg.length - 1) % lightBoxImg.length)
            }
            onMoveNextRequest={() =>
                setPhotoIndex((PhoneIndex + 1) % lightBoxImg.length)
            }
          />
        )}




        </>
    )
}
export default PriceSheet;