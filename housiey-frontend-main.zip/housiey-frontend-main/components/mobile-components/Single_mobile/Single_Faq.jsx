import { useState } from 'react'
const Single_Faq = ({ faqs}) => {
  // const [que, setQue] = useState(faqs)
  const que = faqs;

  console.log("faqsfaqs",faqs)
  return (
    <>
      <div className='container'>
        <div className="_prtis_list mb-2" id="top-builders">
          <div className="_prtis_list_header min" style={{padding: '0.3rem 0.5rem 0.3rem'}}>
            <h4 className="m-0"><span className="theme-cl">FAQ&apos;S</span>
            </h4>
          </div>
          <div className="_prtis_list_body" style={{padding: 0}}>
            {/* Single Basics List */}
            <div className="faq_wrap">
              <div className="faq_wrap_body ">
                <div className="accordion" id="generalac">

                        {
                          que.map((question, index) =>

                            <>
                              {question.qus ? <>
                  <div className="card">
                    <div className="card-header" id="headingOne">
                      <h2 className="mb-0">
                        <button className={(index === 0) ? "btn btn-link " : "btn btn-link collapsed"}
                        type="button"
                          data-toggle="collapse"
                            data-target={"#collapseOne-" + index}
                            aria-expanded="true"
                            aria-controls="collapseOne">
                                        {question.qus}
                        </button>
                      </h2>
                    </div>
                      <div id={"collapseOne-" + index}  
                        className={(index === 0) ? "collapse show" : "collapse"}
                        aria-labelledby="headingOne"
                        data-parent={"#generalac-"+index}>
                      <div className="card-body" style={{fontSize: 12, padding: '0.5rem'}}>
                        <p className="ac-para">
                                        {question.ans}
                        </p>
                      </div>
                    </div>
                  </div>
                              </> : ""}
                            </>
                          )
                        }
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>

    </>
  )
}

export default Single_Faq