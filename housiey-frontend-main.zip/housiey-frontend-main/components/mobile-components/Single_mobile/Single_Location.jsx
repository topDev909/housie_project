import { useDispatch, useSelector } from 'react-redux';
import { useRouter }                from 'next/router';
import PhoneInput                   from 'react-phone-number-input';
import { Markup }                   from 'interweave';
import { useEffect, useState }      from 'react';
import ReactPlayer                  from 'react-player'
import KeyPoints                    from '../../single/KeyPoints';
import {parseJwt}                   from '../../../utils/BasicFn';
import MapContent                   from '../../inc/MapContent';

import Signupperks_mobile           from '../home-page/Signupperks_listing_mobile'

import { set_download_file, set_signup_title, set_open_download_signup } from '../../../redux/slices/signUpModalSlice';

import { set_mobile_number, set_sign_up_modal, set_sign_up_next_step } from '../../../redux/slices/MobileSignUpModalSlice';
import {set_video} from '../../../redux/slices/projectsSlice';
const Single_Location = ({ setpros, setcons, setlocation, setVideoSrc, setIsPlaying, setproject }) => {

const reduxMobile = useSelector((state) => state.MobileSignUpModal.mobileNumber)

const dispatch = useDispatch();
const router = useRouter();


const location  = setlocation;
const pros      = setpros;
const cons      = setcons;



const [formErr, setFormErr] = useState('')
const [viewExtraFields, setviewExtraFeilds] = useState(true);
const [mobile, setMobile] = useState('')
const [otpnum, setOtpnum] = useState('')


const [useSession,setUserSession] = useState('');
useEffect(()=>{
const token = localStorage.getItem('housey_token');
if(token){
const userSessData = parseJwt(token)
setUserSession(userSessData)
}
},[])

const NextStep = () => {
dispatch(set_sign_up_modal(true))
dispatch(set_sign_up_next_step(true))
}


// sign up process start

const getNumberOnchange = (e) => {
setMobile(e)

dispatch(set_mobile_number(e))
}

const validate = async () => {

if (reduxMobile && reduxMobile.length) {
let send_mobile = reduxMobile;
let obj = {
mobile: reduxMobile
}
let send_res = await fetch(process.env.BASE_URL + "signup", {
method: 'POST',
headers: {
"Content-Type": 'application/json'
},
body: JSON.stringify(obj)
});

// console.log(send_res);

if (send_res.ok) {
let res_result = await send_res.json();
setOtpnum(res_result.data.otp)
setMobile(reduxMobile)
NextStep();

if (res_result.signup_status == 0) {
setviewExtraFeilds(false);
}

}
else {
setFormErr('Cannot Able To Send OTP On This Number')
}
} else {
setFormErr('Mobile number is required')

}
}
// Signup process End


const openvideo = (link) => {
    // console.log(link)
    $('#video-modal').modal('show')
    dispatch(set_video(link))

    // if (localStorage.getItem('housey_token')) {
    //     // setVideoSrc(link)
    //     // setIsPlaying(true)
    // }
    // else {
    //     dispatch(set_sign_up_modal(true))
    // }
}

const openMap  = ()=>{
    $('#mobile-map-modal').modal('show')
}
const closeModal = ()=>{
    $('#mobile-map-modal').modal('hide')

}

const [isPlayer,setIsPlayingV] = useState(false);

const CheckLogin = ()=>{
    if (localStorage.getItem('housey_token')) {
        setIsPlayingV(true)   
    }
    else{
        setIsPlayingV(true)
        setTimeout(() => {
            setIsPlayingV(false);
            
            dispatch(set_signup_title('video'))
            dispatch(set_open_download_signup(true))
        }, 15000);
    }
}



return (

<div className='col-sm-12 p-0'>
<div className='container'>
<div className='row'>
<div className='col-lg-12 col-md-12 col-sm-12'>

<div id="location">
<div className="col-lg-12 col-md-12 col-sm-12 div1">
<div className="_prtis_list">
<div className="_prtis_list_header min px-2">
<h4 className="m-0"><span className="theme-cl">{(setproject) ? setproject.project_name : ""} </span>Location
</h4>
</div>
<div className="property_info_detail_wrap mb-2 _prtis_list_body div2 p-0" >
{location.map((detalis) => {
return (
<>


<div className="property_info_detail_wrap_first px-2">
    <div className="pr-price-into">
        <span style={{ fontSize: 13, color: '#000' }}><i className="lni-map-marker" />{detalis.street}</span>
        <ul style={{ paddingLeft: 10, marginTop: '5px' }}>
            <KeyPoints data={detalis.highlights} />
        </ul>
    </div>
</div>
{detalis.link && <>
    <div className="property_detail_section">
        <div className="prt-sect-pric">
            <div className="property_video"  >
                <div className={`  ${isPlayer?" thumb ": " thumb mobile-video-overlay"}`} onClick={CheckLogin} >
                    <ReactPlayer className="react-mobile-player" width="100%" heigth="240px" url={detalis.link} controls={true}  playing={isPlayer} />

                </div>
            </div>
            
        </div>
    </div>
</>}
<p className="mt-2" style={{ textAlign: 'right' }}>
    <a href="#" className="btn" style={{ background: '#0e8744', lineHeight: '0.3', borderRadius: 5, padding: '9px 12px', border: 'none', fontSize: 13 }} data-toggle="modal" onClick={openMap}><i className="fas fa-map" style={{ fontSize: 12, marginRight: 2 }} /> View on Map</a>
</p>
</>
)
})}
</div>
</div>

<div className="_prtis_list" id="procandcons">
<div className="_prtis_list_header min">
<h4 className="m-0"><span className="theme-cl">{(setproject) ? setproject.project_name : ""} </span>Pros &amp; Cons
</h4>
</div>
<div className="mb-2">
<div className="col-lg-12" style={{ padding: 0 }}>
<div className="faq_wrap">
<div className="faq_wrap_body ">
<div className="accordion" id="generalac1">
    <div className="card" style={{ borderRadius: 0 }}>
        <div className="card-header" id="headingPros" style={{ background: '#0080002b', borderRadius: 0 }}>
            <h2 className="mb-0">
                <button className="btn btn-link" type="button" data-toggle="collapse" data-target="#collapsePros" aria-expanded="true" aria-controls="collapsePros">
                    <i className="fas fa-thumbs-up" /> Pros
                </button>
            </h2>
        </div>
        <div id="collapsePros" className="collapse show" aria-labelledby="headingPros" data-parent="#generalac1">
            <div className="card-body" style={{ padding: '0.2rem 1rem' }}>
                <ul style={{ paddingLeft: 0 }}>
                    {pros.map((items) => {
                            return (
                                <>
                                {items.tag ? <>
                                    <li style={{ fontSize: 12 }}><Markup content={items.tag} /></li>
                                </> : 
                                    <li><Markup /></li>}
                                </>
                        )})}

                </ul>
            </div>
        </div>
    </div>
    <div className="card" style={{ borderRadius: 0 }}>
        <div className="card-header" id="headingCons" style={{ background: '#ff000030', borderRadius: 0 }}>
            <h2 className="mb-0">
                <button className="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseCons" aria-expanded="false" aria-controls="collapseCons">
                    <i className="fas fa-thumbs-down" /> Cons
                </button>
            </h2>
        </div>
        <div id="collapseCons" className="collapse" aria-labelledby="headingCons" data-parent="#generalac1">
            <div className="card-body" style={{ padding: '0.2rem 1rem' }}>
                <ul style={{ paddingLeft: 0 }}>
                    {cons.map((item) => {
                            return (<>
                                {item.tag ? <>
                                    <li style={{ fontSize: 12 }}><Markup content={item.tag} /></li>
                                </> : <>   <li><Markup /></li> </>}
                            </>)
                    })}
                </ul>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>







{/* SignupPerks Start */}
{useSession ? <></> : <><Signupperks_mobile/></>}
{/* SignupPerks End */}







{/* MapContent */}


<div
  className="modal fade"
  id="mobile-map-modal"
  aria-hidden="true"
  aria-labelledby="mobile-map-modal-Label"
  tabIndex={-1}
>
  <div className="modal-dialog modal-dialog-centered">
    <div className="modal-content">
      <div className="modal-header">
        <h5 className="modal-title" id="mobile-map-modal-Label">
          {setproject.project_name} Location
        </h5>
        <button
          type="button"
          onClick={closeModal}
          className="btn-close"

        >
            &times;
        </button>
      </div>
      <div className="modal-body">
            <MapContent lat={location[0].lat}  lng={location[0].lng} />
      </div>

    </div>
  </div>
</div>



</div>
</div>
</div>
</div>
</div>
</div>


)
}

export default Single_Location