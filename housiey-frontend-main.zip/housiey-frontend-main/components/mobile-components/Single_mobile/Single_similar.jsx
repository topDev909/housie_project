// import Carousel from 'react-multi-carousel';
// import 'react-multi-carousel/lib/styles.css';
// import "react-responsive-carousel/lib/styles/carousel.min.c	ss"; // requires a loader
// import { Carousel } from 'react-responsive-carousel';

import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import { useEffect, useState } from 'react'
import Link from 'next/link';
import { slugGenrator } from "../../../utils/BasicFn";

import { useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { set_step1_modal } from '../../../redux/slices/MobileSignUpModalSlice';
import { select_project }  from "../../../redux/slices/projectsSlice";
import {set_ola_modal_tab,set_active_tab} from '../../../redux/slices/signUpModalSlice';

const Single_similar = ({ setbrocher, project,location }) => {

  const [detalis, setDetalis] = useState([])
  const mylocation = location[0];


  const dispatch = useDispatch();
  const router   = useRouter();

  const viewproject = async (EnqProject) => {

   let obj = {
      id: EnqProject.id,
      project_name: EnqProject.project_name,
      slug: EnqProject.slug
    }
    dispatch(select_project(obj))
    dispatch(set_step1_modal(true));
    dispatch(set_ola_modal_tab(true));
    dispatch(set_active_tab('1'));
  }



  useEffect(() => {
    if (project) {
      fetch(`${process.env.BASE_URL}get-similer-projects/${project.id}`)
        .then((result) => {
          result.json().then((response) => {
            setDetalis(response.projects)
          })
        })
    }
  }, [project]);

  return (
    <>

      <section className="min light-bg" id="new-launches" style={{ padding: '15px 0 28px' }}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-7 col-md-8">
              <div className="sec-heading center">
                <h2 style={{ fontSize: 18 }}>Similar Projects</h2>
              </div>
            </div>
          </div>

          {/* </Carousel>  */}
          <div className="block-bodys">
            <div className="sidetab-content">
              <div className="tab-content" id="pills-tabContent">

                <div className="tab-pane fade show active" id="pills-property" role="tabpanel" aria-labelledby="pills-property-tab">
                  <div className="item-slide-5 space">

                    <Carousel autoPlay={false} infiniteLoop={true} showArrows={false} showThumbs={false} thumbWidth={50} useKeyboardArrows={false}
                      showIndicators={false} interval={3000} showStatus={false} swipeable={true} preventMovementUntilSwipeScrollTolerance={true}
                    >
                      {detalis && detalis.map((items) => {
                        return (

                          <>

                            <div className="single_items">
                              <div className="property-listing list_view">
                                <Link href={"/in/" + mylocation.city + "/" + items.location + "/" + items.slug} >
                                  <div className="listing-img-wrapper">
                                    <div className="_exlio_125"><i className="fas fa-street-view"></i></div>
                                    <div className="_exlio_126"><i className="far fa-play-circle"></i></div>
                                    <div className="_exlio_128" data-toggle="tooltip" data-placement="top" data-original-title="Save property">
                                      <a href="#"><i className="far fa-heart"></i></a>
                                    </div>
                                    <div className="list-img-slide">
                                      <img src={process.env.BASE_URL + items.images} className="mx-auto" alt="project-image" />
                                    </div>
                                  </div>
                                </Link>

                                <div className="list_view_flex">

                                  <div className="listing-detail-wrapper mt-1">
                                    <div className="listing-short-detail-wrap">

                                      <div className="_card_list_flex">
                                          <div className="_card_flex_01">
                                        <Link href={"/in/" + mylocation.city + "/" + items.location + "/" + items.slug} >
                                            <h4 className="listing-name verified"><span  className="prt-link-detail"> {items.project_name}</span></h4>
                                        </Link>
                                        <div className="d-flex w-100" >

                                            <div className="builder-name">By 
                                            <Link href={"/in/" + mylocation.city + "/" + slugGenrator(items.builder)} >
                                                <span > {items.builder} </span> 
                                            </Link>
                                            </div>

                                            <div className="location ml-auto">
                                              <Link href={"/in/" + mylocation.city + "/" + slugGenrator(items.location)} >
                                                <span><i className="fas fa-map-marker-alt"></i> {items.location}</span>
                                              </Link>
                                            </div>
                                        </div>
                                          </div>
                                      </div>
                                    </div>
                                  </div>

                                  <div className="price-features-wrapper">
                                    <div className="list-fx-features">
                                      <div className="listing-card-info-icon">
                                        <div className="inc-fleat-icon"><i className="fas fa-bed"></i></div> {items.config}
                                      </div>

                                      <div className="listing-card-info-icon" style={{ textAlign: "right" }}>
                                        <div className="inc-fleat-icon"><i className="fas fa-vector-square"></i></div>{items.area_range_max} sqft
                                      </div>
                                    </div>
                                    <div className="list-fx-features">

                                      <div className="listing-card-info-icon">
                                        <div className="inc-fleat-icon"><i className="far fa-file-alt"></i></div>Possession
                                      </div>
                                    </div>
                                  </div>
                                  <div className="_card_list_flex mb-2">

                                    <div className="_card_flex_last">
                                      <h6 className="listing-card-info-price mb-0"><i className="fas fa-rupee-sign"></i> {items.overall_price_range}<small style={{ fontSize: "60%" }}> (All Inc.)</small></h6>
                                    </div>
                                  </div>


                                  <div className="listing-detail-footer">
                                    <div className="footer-first">
                                      <button className="schedule-view" onClick={() => viewproject(items)}><i className="fa fa-desktop"></i>  &nbsp; | &nbsp; <i className="fa fa-car"></i> &nbsp; Tour</button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </>
                        )
                      }

                      )}
                    </Carousel>
                  </div>
                </div>
              </div>

            </div>

          </div>


        </div>
      </section>

    </>
  )
}

export default Single_similar