import React,{useState,useEffect} from 'react';

import Online_presentation_mobile               from '../home-page/Online_presentation_mobile';
// import Sitevisit_mobile                         from '../home-page/Sitevisit_mobile';
import Single_price                             from './Single_price'
import Single_propertydetalis                   from './Single_propertydetalis'
import Single_slider                            from './Single_slider'
import Single_Faq                               from './Single_Faq'
import Single_similar                           from './Single_similar'
import Single_footer                            from './Single_footer'
import Single_builder                           from './Single_builder'
import Signup_modal                             from '../home-page/Signup_modal';
import DownloadThankYouMobile                   from './DownloadThankYouMobile';
import DownloadContentMobileModal               from '../inc/DownloadContentMobileModal';
import { select_project }                       from '../../../redux/slices/projectsSlice';
import { set_ola_modal_tab, set_active_tab }    from '../../../redux/slices/signUpModalSlice';
import HideAppBar               from '../listing-page/filter-files/StickyNavbar';
import { useDispatch } from 'react-redux';
import VideoModal from './VideoModal';


const MainSingleMobilePage = ({SingleProjectData,search_query,page_type,details})=>{
    const {faqs,conigs,plan_kit,brocher,cons,pros,schemes,floor_plan,location,ext_amenities,int_amenities,conigs_deatils,project_videos,tour_video,project,address,banks,images,master_plan,rera_details,price_sheet,sellerInfo,payment_schedule}  = SingleProjectData; 
    
    const [opensignup, setOpensignup]   = useState(false);
    
    const dispatch                      = useDispatch();
    
    useEffect(()=>{
      let arr = [];
      let obj = {
        project_name:   SingleProjectData.project.project_name,
        slug:           SingleProjectData.project.slug,
        id:             SingleProjectData.project.id
      }
      arr.push(obj);
      dispatch(select_project(arr));
      dispatch(set_ola_modal_tab(true));
      dispatch(set_active_tab('1'))
    },[SingleProjectData])
    return (
        <>
        

         <HideAppBar search_query={search_query} page_type={page_type} details={details} />
        <Single_slider setproject={project} address={address} images={images} location={location}/>
        
        <Single_propertydetalis 
            setproject_videos={project_videos}
            rera_details={rera_details}
            setpros={pros} 
            setcons={cons} 
            setbrocher={brocher} 
            setdetalis={conigs_deatils} 
            setamenities={int_amenities}
            setexamenities={ext_amenities}
            setproject={project}
            setmaster_plan={master_plan} 
            setlocation={location} 
            plan_kit={plan_kit}
            setfloor_plan={floor_plan}
        />  
    
        <Online_presentation_mobile/>
        <Single_price  
          setbank={banks} 
          setproject={project}  
          setconigs={conigs}  
          setdetalis={conigs_deatils} 
          setschemes={schemes} 
          tour_video={tour_video} 
          price_sheet={price_sheet} 
          plan_kit={plan_kit} 
          payment_schedule={payment_schedule}
        />
        
        <Single_builder setproject={project}/>
        <Single_Faq faqs={faqs}/>
        <Single_similar  project={project} location={location} />
        <Single_footer setbrocher={brocher}   project={project}  sellerInfo={sellerInfo}  />
        <Signup_modal />   
        <DownloadThankYouMobile  sellerInfo={sellerInfo} project={project}  />
        <VideoModal project={project} />
        <DownloadContentMobileModal project={project}/>
        </>
    )
}
export default MainSingleMobilePage