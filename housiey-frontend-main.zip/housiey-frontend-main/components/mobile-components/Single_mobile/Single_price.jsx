import { useEffect, useState } from "react";
import Marquee from "react-fast-marquee";
import { useRouter } from 'next/router';
import { useDispatch,useSelector } from 'react-redux';

import { set_download_file, set_signup_title,set_open_download_signup } from '../../../redux/slices/signUpModalSlice';
import { set_download_modal } from '../../../redux/slices/MobileSignUpModalSlice';
import PriceSheet from "./PriceSheet";

const Single_price = ({ setproject, setdetalis, setschemes, setconigs, setbank, tour_video, price_sheet, plan_kit, payment_schedule }) => {


  const dispatch = useDispatch();
  const router = useRouter();

  const enq_project_id        = useSelector((state)=>state.signUpModal.enq_project_id)

  const conigsdata             = setconigs;
  const detalisdata            = setdetalis;
  const setschemesdata         = setschemes;
  const tourvideodata          = tour_video;
  const bankdata               = setbank;


  

  const DownloadPriceSheet = async () => {
    let title = 'Price Sheet';
    dispatch(set_signup_title(title));
    const token = localStorage.getItem('housey_token')
    if(token){
      
      let url = `/api/download?link=` + price_sheet + `&name=plan-kit`;
      await router.push(url);

      let sendEnq = process.env.BASE_URL+`download-doc/${enq_project_id}`;
      let req     = await fetch(sendEnq,{
          headers: {
              auth: token,
              source: "Price Sheet"
          }
      });

      dispatch(set_download_modal(true))
    }else{
      let obj = {
        file: price_sheet,
        status: true,
        name: 'plan-kit'
      }
      dispatch(set_download_file(obj));
      dispatch(set_open_download_signup(true))
    }
}

/* payment_schedule */


const DownloadPriceSchems = async () => {
  let title = 'Payment Scheme';
  dispatch(set_signup_title(title));
  const token = localStorage.getItem('housey_token')
  if(token){
    let url = `/api/download?link=` + payment_schedule + `&name=Payment-Scheme`;
    await router.push(url);

    let sendEnq = process.env.BASE_URL+`download-doc/${enq_project_id}`;
    let req     = await fetch(sendEnq,{
        headers: {
            auth: token,
            source: "payment scheme"
        }
    });
    
    dispatch(set_download_modal(true))
  }else{
    let obj = {
      file: payment_schedule,
      status: true,
      name: 'plan-kit'
    }
    dispatch(set_download_file(obj));
    dispatch(set_open_download_signup(true))
  }
}


  return (
    <>

      <section style={{ padding: '10px 0 0', marginTop: '10px' }}>
        <div className="container">
          <div className="row">
            {/* property main detail */}
            <div className="col-lg-12 col-md-12 col-sm-12">
              <div className="_prtis_list mb-2" id="pricing" style={{ paddingBottom: 10 }}>
                <div className="_prtis_list_header min">
                  <h4 className="m-0"><span className="theme-cl">{setproject?.project_name} </span>Price Unit Plan
                  </h4>
                </div>
                
                <PriceSheet detalisdata={detalisdata} project={setproject} conigsdata={conigsdata}/>


                <div className="col-12">
                  <div className="button-container">
                    <div className="button-block">
                      <i className="fas fa-download button-image" />

                      <button className="block-button-1" style={{ width: 100 }} onClick={() => DownloadPriceSheet()} > Price Sheet</button>
                    </div>
                  </div>
                </div>
              </div>
              {/* Payment scheme  start*/}


              <div className="_prtis_list mb-2" id="payment-scheme" style={{ paddingBottom: 10 }}>
                <div className="_prtis_list_header min">
                  <h4 className="m-0"><span className="theme-cl">{(setproject) ? setproject.project_name : ""} </span> Payment Scheme
                  </h4>
                </div>
                <div className="_prtis_list_body" style={{ padding: '0rem 0rem' }}>
                  <div className="accordion" id="floor-option">

                    {setschemesdata.map((scheme, index) => {
                      return (
                        <>
                          <div className="card">
                            <div className="card-header" id="groundFloor">
                              <h2 className="mb-0">
                                <button type="button" className="btn btn-link" data-toggle="collapse" data-target={"#groundfloor-" + index}>{scheme.scheme_name}</button>
                              </h2>

                            </div>
                            <div id={"groundfloor-" + index} className={(index === 0) ? "collapse show" : "collapse"} aria-labelledby={"groundFloor-" + index} data-parent="#floor-option">
                              <div className="card-body" style={{ padding: '0.5rem' }}>
                                <p className="mb-0">{scheme.description}</p>
                              </div>
                            </div>
                          </div>
                        </>
                      )
                    })}
                  </div>
                </div>
                <div className="col-12">
                  <div className="button-container">
                    <div className="button-block" style={{ marginTop: 10 }}>
                      <i className="fas fa-download button-image" />
                      <button className="block-button-1" style={{ width: 135 }} onClick={() => DownloadPriceSchems()}>Payment Scheme</button>
                    </div>
                  </div>
                </div>
              </div>
              {/* Payment scheme  End*/}

              {tourvideodata &&
                <>
                  <div className="_prtis_list mb-2">
                    <div className="_prtis_list_header min">
                      <h4 className="m-0"><span className="theme-cl">{(setproject ? setproject.project_name : "")}</span>360 Tour
                      </h4>
                    </div>
                    <div className="_prtis_list_body" id="master-plan" style={{ padding: '0.5rem 0.3rem' }}>
                      <div className="">
                        <div className="thumb">
                          <iframe src={tourvideodata} height={'300'} title="Iframe Example" style={{ width: "100%" }}></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              }


              {/* 360 Tour  End*/}

              <div className="_prtis_list mb-2" id="bank">
                <div className="_prtis_list_header min">
                  <h4 className="m-0"><span className="theme-cl">{setproject && setproject.project_name} </span>approved by
                  </h4>
                </div>

                
                <div className="_prtis_list_body" id="logo-slider">
                  <div className="slider1" style={{ overflow: "hidden" }} id="">
                    <div className="slide-track">
                      <Marquee >
                        {bankdata.map((shows, index) =>
                          <div className="bank-img" key={index} style={{marginRight:"30px"}}>
                            <img src={process.env.BASE_URL + shows.logo} alt='bank-logo' />
                          </div>
                        )}
                      </Marquee>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>



    </>
  )
}

export default Single_price