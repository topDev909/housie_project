import React from 'react';
import 'react-phone-number-input/style.css';
import PhoneInput from 'react-phone-number-input';
import { useState } from 'react';
import {useSelector,useDispatch} from 'react-redux';
import {set_sign_up_modal,set_sign_up_next_step,set_mobile_number} from '../../../redux/slices/MobileSignUpModalSlice';
import SignUpForm from './SignUpForm';

const Signup_modal = () => {
  const dispatch          = useDispatch();
  const[value,setValue]   = useState('')
  const openModal         = useSelector((state)=>state.MobileSignUpModal.openModal)
  let   signup_next       = useSelector((state)=>state.MobileSignUpModal.signup_next)

    console.log(openModal)
  const CloseModal = ()=>{
    dispatch(set_mobile_number(''))
    dispatch(set_sign_up_modal(false))
  }

  const NextStep = ()=>{
    dispatch(set_sign_up_next_step(false))
  }
  
  return (
    <>      
      <div id="mybottam_nav" className="container-fluid bottam_nav " style={{ height: openModal ? "77%" :"" ,overflowY: openModal ? "scroll":'' }}>
        <div className="row text-right">
          <div className="col-12" style={{padding: '10px 30px'}}>
              <a href="javascript:void(0)" onClick={CloseModal}>
                <i className="fa fa-times"/>
              </a>
          </div>
        </div>
        <div className="row" style={{padding: 10}}>
          <div className="col-12">
            <h6 style={{fontSize: 20}}>Login / Sign up</h6>
            <ul style={{paddingLeft: 0}}>
              <li><i style={{fontSize: 11}} className="fas fa-check" /> Free Site Visit.</li>
              <li><i style={{fontSize: 11}} className="fas fa-check" /> Bottom Rate Guarantee.</li>
              <li><i style={{fontSize: 11}} className="fas fa-check" /> Referral Bonus </li>
              <li><i style={{fontSize: 11}} className="fas fa-check" /> Dedicated Relationship Manager.</li>
            </ul>
          </div>
        </div>
        <div className="row p_top_10" style={{padding: 10}}>
          <div className="col-12 button_filter_clic">
            <div className style={{padding: 6, overflowY:'auto'}}>
              <div className="call_action_wrap-head">
                <div className="row">
                  <div className="col d-lg-block" id="mobile-form"> 
                      <SignUpForm/> 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>         
    </>
  )
}
export default Signup_modal