import React,{ useState, useEffect }      from "react"
import { makeStyles }                     from "@material-ui/core/styles"; 
import { useDispatch, useSelector }       from "react-redux";
import { searchProjects,select_project }  from "../../../redux/slices/projectsSlice";
import {set_ola_modal_tab,set_active_tab} from '../../../redux/slices/signUpModalSlice';

import {  set_step1_modal } from '../../../redux/slices/MobileSignUpModalSlice';
import DatePicker from "react-datepicker";
import {useRouter} from 'next/router';
import FormComponent  from  '../../component/FormComponent';

import "react-datepicker/dist/react-datepicker.css";

const useStyles = makeStyles({
  paper: {
    border: "0px solid black",
    borderRadius: "0px !important",
    marginTop: "11px",
    
  }
});

// selectName
const Step1_modal = ({handleNext}) => {
  const dispatch          = useDispatch();
  const selectedProject   = useSelector((state)=>state.projects.selectedProject) 
  const projectList       = useSelector((state)=>state.projects.projectList.projects) 
  const openModal         = useSelector((state)=>state.MobileSignUpModal.openStep1Modal)
  const page_type         = useSelector((state)=>state.signUpModal.page_type)
  const router            = useRouter();

  
  const [mylist, setMylist]             = useState((projectList)?projectList:[]);
  const [data, setData]                 = useState((selectedProject)?selectedProject[0]:[]);

  useEffect(()=>{
    let selected_p = (selectedProject)?selectedProject[0]:[];
    setMylist(projectList)
    setData(selected_p)
  },[projectList,selectedProject])


  const CloseModal = ()=>{
    if(page_type!=='details'){
      dispatch(select_project([]));
    }
  dispatch(set_step1_modal(false));
  dispatch(set_ola_modal_tab(true));
  dispatch(set_active_tab('1')); 
}  



  return (
    <> 
    <div className="bottomFotter" style={{ height: openModal ? "77%" : "0"}}>
      <span className="mod-close" onClick={CloseModal} aria-hidden="true" >
        <i className="ti-close" />
      </span>
      
      <FormComponent/>
    </div>
    </>
  );
};

export default Step1_modal;
