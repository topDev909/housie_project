/* eslint-disable @next/next/no-img-element */
import React from 'react';
import 'react-phone-number-input/style.css';

import Confetti from 'react-confetti'


import { useState } from 'react';
import {useSelector,useDispatch} from 'react-redux';
import {set_sign_up_modal,set_sign_up_next_step,set_thanks_modal,set_step1_modal} from '../../../redux/slices/MobileSignUpModalSlice';
import SignUpForm from './SignUpForm';
import {useRouter} from 'next/router';
import ThanksContent from './ThanksContent';

const Thankyou_modal = () => {
  const dispatch          = useDispatch();
  const[value,setValue]   = useState('')
  const openModal         = useSelector((state)=>state.MobileSignUpModal.openThankyouModal)
  let   signup_next       = useSelector((state)=>state.MobileSignUpModal.signup_next)
  const router      = useRouter();

  const CloseModal = ()=>{
     
    dispatch(set_thanks_modal(false));
    router.reload(window.location.reload)

  }

  const NextStep = ()=>{
    dispatch(set_sign_up_next_step(false))
  }



  return (
    <>  

       <div id="mobile_thankyou" className="bottam_nav bottomFotter" style={{ height: openModal ? "45%" : "0"}}>
        
        <div className="modal-dialog modal-xl-x login-pop-form" role="document">
              <div className="modal-content overli" id="thank-you-modal"  >

                  <div className="modal-body p-0">

                   <span className="mod-close" onClick={CloseModal} aria-hidden="true" >
                      <i className="ti-close" />
                    </span>

                    <Confetti width={'400px'} />
                    

                    <div className="" >
                        <ThanksContent/>
                    </div>
                  </div>
              </div>
          </div> 
       </div>        
    </>
  )
}
export default Thankyou_modal