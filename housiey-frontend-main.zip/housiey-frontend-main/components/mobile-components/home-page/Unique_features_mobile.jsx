/* eslint-disable @next/next/no-img-element */
const Unique_features_mobile = () => {
    return (
        <>
        <section className="min" id="unique-features" style={{padding:"10px 0 0"}}>

				<div className="container">
					
					<div className="row justify-content-center">
						<div className="col-lg-7 col-md-8">
							<div className="sec-heading center">
								<h2 style={{lineHeight:"30px"}}>Housiey Unique Features</h2>
							</div>
						</div>
					</div>
					<div className="row">
						<div className="col-6">
							<div className="_category_box">
								<a href="javascript:void(0)">
									<div className="_category_elio">
										<div className="_category_thumb">
											<img src="assets/img/unboxing.svg" className="img-fluid hover" alt="" />
											<img src="assets/img/unboxing.svg" className="img-fluid simple" alt="" />
										</div>
										<div className="_category_caption">
											<h5>Project Unboxing</h5>
										</div>
									</div>
								</a>
							</div>
						</div>
						<div className="col-6">
							<div className="_category_box">
								<a href="javascript:void(0)">
									<div className="_category_elio">
										<div className="_category_thumb">
											<img src="assets/img/pros-cons.svg" className="img-fluid hover" alt="" />
											<img src="assets/img/pros-cons.svg" className="img-fluid simple" alt="" />
										</div>
										<div className="_category_caption">
											<h5>Pros & Cons</h5>
										</div>
									</div>
								</a>
							</div>
						</div>
						<div className="col-6">
							<div className="_category_box">
								<a href="javascript:void(0)" >
									<div className="_category_elio">
										<div className="_category_thumb">
											<img src="assets/img/tour.svg" className="img-fluid hover" alt="" />
											<img src="assets/img/tour.svg" className="img-fluid simple" alt="" />
										</div>
										<div className="_category_caption">
											<h5>Virtual 360 Tour</h5>
										</div>
									</div>
								</a>
							</div>
						</div>
						<div className="col-6">
							<div className="_category_box">
								<a href="javascript:void(0)">
									<div className="_category_elio">
										<div className="_category_thumb">
											<img src="assets/img/rtc.svg" className="img-fluid hover" alt="" style={{maxWidth:"40px"}} />
											<img src="assets/img/rtc.svg" className="img-fluid simple" alt="" style={{maxWidth:"40px"}} />
										</div>
										<div className="_category_caption">
											<h5>Real Time Calling</h5>										
										</div>
									</div>
								</a>
							</div>
						</div>
					</div>
				</div>
				
			</section>
        </>
    )
}

export default Unique_features_mobile;