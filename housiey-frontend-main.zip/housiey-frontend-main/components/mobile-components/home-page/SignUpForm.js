import React,{useState,useEffect} from 'react';
import PhoneInput from 'react-phone-number-input';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import {useRouter} from 'next/router';

import {useDispatch,useSelector} from 'react-redux';
import {set_mobile_number,set_sign_up_next_step,set_thanks_modal,set_sign_up_modal,set_step1_modal,set_download_modal} from '../../../redux/slices/MobileSignUpModalSlice';
import {set_modal_state,set_sent_otp,set_show_sign_up_perks } from '../../../redux/slices/signUpModalSlice';

const SignUpForm = ()=>{
  const dispatch            = useDispatch();
  const router              = useRouter();
  let   signup_next         = useSelector((state)=>state.MobileSignUpModal.signup_next)
  const reduxMobile         = useSelector((state)=>state.MobileSignUpModal.mobileNumber)
  const sentOtpcheck        = useSelector((state)=>state.signUpModal.start_sent_otp)
  const thank_modal         = useSelector((state)=>state.signUpModal.show_thanku_modal)

  const downloadFile        = useSelector((state)=>state.signUpModal.downloadFile)
  const download_file_name  = useSelector((state)=>state.signUpModal.download_file_name)
  const is_download         = useSelector((state)=>state.signUpModal.is_login_download)
  const page_type           = useSelector((state)=>state.signUpModal.page_type)
  const enq_project_id      = useSelector((state)=>state.signUpModal.enq_project_id)

  const [viewExtraFields,setviewExtraFeilds] = useState(true);
  const NextStep = ()=>{
        dispatch(set_sign_up_next_step(true))
  } 

    // singup for free 
    useEffect(() => {
        if(sentOtpcheck){
            dispatch(set_thanks_modal(false))
            dispatch(set_modal_state(false))
            validate()
            dispatch(set_sent_otp(false))
        }
        
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [sentOtpcheck])


    const [mobile, setMobile]           = useState('')
    const [otpnum, setOtpnum]           = useState('')
    const [checkotp, setCheckotp]       = useState('')
    const [name, setName]               = useState('')
    const [email, setEmail]             = useState('')
    const[otperror,setOtperror]         = useState('')
    const [formErr,setFormErr]          = useState('')
   

    

    const getNumberOnchange = (e) => {
        setMobile(e)
     
        dispatch(set_mobile_number(e))
    }


    // validation start//
    const validationSchema = Yup.object().shape({
        otp: Yup.string()
        .required('OTP is required')
        .min(6, 'Password must be at least 6 characters')
        .matches(
            /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/, "Only Number are allowed for this field")
            ,
         firstName: Yup.string()
            .required('firstName is required')
            .matches(/^[aA-zZ\s]+$/, "Only alphabets are allowed for this field "),

        email: Yup.string()
            .required('Email is required')
            .email('Email is invalid'),

       
    });

    const formOptions = { resolver: yupResolver(validationSchema) };
    const { register, handleSubmit, reset, formState } = useForm(formOptions);
    const { errors } = formState;

    

    const onSubmit = async(data)=>{
        data.preventDefault();

          let field = {
            "name":name,
            "email":email,
            "otp": checkotp,
            "mobile":mobile,
            "is_signup": viewExtraFields,
            "page_type": page_type,
            "project_id": enq_project_id
        }

        if(!checkotp || checkotp==='undefined'){
            setFormErr('Please Fill OTP')
            hideMsg()
            return;
        }

        if( (!name || name==='undefined') && viewExtraFields===true ){
            setFormErr('Please Fill Full-Name')
            hideMsg()
            return;
        }
        if((!email || email==='undefined') && viewExtraFields===true ){
            setFormErr('Please Fill Email')
            hideMsg()
            return;
        }



        let check =   await fetch(process.env.BASE_URL +"verify-otp",{
            method:'POST',
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify(field)
        })
        if(check.ok){
            let check_result = await check.json();
            if(check_result.res === true){

                localStorage.setItem('housey_token', check_result.token);

                let modal_type = localStorage.getItem('modal_type');
                modal_type = (modal_type) ? modal_type : ''


                if(is_download){
                    dispatch(set_sign_up_modal(false))
                    let downloadUrl = `/api/download?link=${downloadFile}&name=${download_file_name}`
                    await router.push(downloadUrl);
                    if(viewExtraFields){
                        dispatch(set_show_sign_up_perks(true));
                    }
                    dispatch(set_download_modal(true))
                }else if(thank_modal){
                    dispatch(set_sign_up_modal(false))
                    dispatch(set_thanks_modal(true))
                }else{
                    router.reload(window.location.reload)
                }

            }else{
                setFormErr(check_result.msg)
            }
            
        }
        else{
            setFormErr('Something Went Wrong Please Try Again');
        }
        hideMsg()
    }

    // validation End

    const validate = async() => {

       if (reduxMobile && reduxMobile.length) {
            let send_mobile = reduxMobile;
            let obj = {
                mobile: reduxMobile
            }
            let send_res = await fetch(process.env.BASE_URL +"signup",{
                method:'POST',
                headers:{
                    "Content-Type":'application/json'
                },
                body: JSON.stringify(obj)
            });

            if (send_res.ok){
                let res_result = await send_res.json();
                setOtpnum(res_result.data.otp)
                setCheckotp(res_result.data.otp) 
                setMobile(reduxMobile)
                if(res_result.signup_status===0){
                    setviewExtraFeilds(false);
                }   
                NextStep();
            }
            else{
                setFormErr('Cannot Able To Send OTP On This Number')
            }
        }else{
            setFormErr('Mobile number is required')
        }
    }
   
    const hideMsg = ()=>{
        setTimeout(() => {
            setOtperror('')
            setFormErr('')
        }, 3000);
    }

    return (
        <>

            <form  onSubmit={onSubmit}  > 
                {formErr && 
                    <div className='alert alert-danger' >
                        {formErr}    
                    </div>
                }

                <div className="form-group">
                    <label>Mobile Number</label>
                    <PhoneInput
                        placeholder="Enter phone number"
                        countryCallingCodeEditable={false}
                        defaultCountry="IN"
                        style={{ border: "1px solid #e7eaf1" }}
                        className="form-control"
                        onChange={getNumberOnchange}
                        value={reduxMobile}
                    />
                </div>


                <div className="form-group" style={{ display:signup_next?'none':'block' }} >
                    <button
                        onClick={validate}
                        type="button"
                        className="btn btn-md full-width pop-login"
                    >
                        Continue
                    </button>
                </div>

                <div className="" style={{ display:signup_next?'block':'none' }} >

                <div className="form-group" style={{marginTop: "10px", marginBottom: "0px"}}>
                        <label>OTP</label>
                        <div className="input-with-icon" style={{marginBottom: "-12px"}}>
                            <input type="text"
                                name='otp'
                                value={checkotp}
                                {...register('otp')}
                                className={`form-control ${errors.otp ? 'is-invalid' : ''}`}
                                placeholder='Enter OTP'
                                onChange={(e)=>setCheckotp(e.target.value)}
                                style={{background: "transparent", borderRadius: "5px", borderColor: "#ccc"}}
                                />
                            <i className="ti-key"></i>
                            <div className="invalid-feedback">{errors.otp?.message}</div>   
                            <span className='text-danger'>{otperror}</span>
                        </div>
                    </div>
                    {viewExtraFields ?<>
                    <div className="form-group">
                        <label>Name</label>
                        <div className="input-with-icon" style={{marginBottom: "-12px"}}>
                            <input type="text" 
                                name='firstName'
                                {...register('firstName')} 
                                className={`form-control ${errors.firstName ? 'is-invalid' : ''}`}
                                placeholder='Enter Name'
                                onChange={(e) => setName(e.target.value)}
                                autoComplete={false}
                                style={{background: "transparent", borderRadius: "5px", borderColor: "#ccc"}}
                                />
                            <i className="ti-user" />
                            <div className="invalid-feedback">{errors.firstName?.message}</div>
                        </div> 
                    </div> 
                    <div className="form-group">
                        <label>Email</label>
                        <div className="input-with-icon">
                            <input type="email" 
                                name='email'
                                {...register('email')}
                                className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                                placeholder='Enter Email'
                                onChange={(e) => setEmail(e.target.value)}
                                style={{background: "transparent", borderRadius: "5px", borderColor: "#ccc"}}
                                />
                            <i className="ti-email" />
                            <div className="invalid-feedback">{errors.email?.message}</div>
                        </div>
                    </div>
                    </>
                    :''
                    }

                    <div className="form-group icon-my">
                        <button type="submit" className="btn btn-md full-width pop-login" > 
                            Continue
                        </button>
                    </div>
                    
                </div>

                
                <div className="form-group text-center">
                    By Continuing, you agree to our
                    <a href="#"> Terms &amp; Conditions</a>
                </div>
                    
            </form>

        </>
    )
}
export default SignUpForm;