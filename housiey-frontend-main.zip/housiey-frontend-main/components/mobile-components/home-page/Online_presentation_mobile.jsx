/* eslint-disable @next/next/no-img-element */
import React, { useState, useEffect } from 'react';
import { set_sign_up_modal,  set_sign_up_next_step, set_mobile_number, set_step1_modal } from '../../../redux/slices/MobileSignUpModalSlice';
// import { set_sent_otp } 	from '../../../redux/slices/signUpModalSlice';
import { select_project } from "../../../redux/slices/projectsSlice";
import {set_ola_modal_tab,set_active_tab } from '../../../redux/slices/signUpModalSlice';

import { useDispatch } from 'react-redux';
import { useRouter } from 'next/router';



const Online_presentation_mobile = () => {

	const dispatch = useDispatch();
	const router = useRouter();

	const validate = async () => {
		// dispatch(select_project([]));
		dispatch(set_step1_modal(true))
		dispatch(set_ola_modal_tab(false));
		dispatch(set_active_tab('2'));
	}
	return (
		<>
			<div className="hero_banner text-center" id="free-visit" style={{ background: "url(/assets/img/online-presentation2.png) no-repeat 100%", paddingTop: "0", minHeight: "240px", backgroundPosition: "right !important" }} data-overlay="0">
				<div className="container">
					<div className="row">
						<div className="col-xl-10 col-lg-12 col-md-12" style={{ marginTop: "50px" }}>
							<h1 className="big-header-capt" style={{ fontSize: "1.5rem", color: "#fff", marginBottom: "0px" }}>Online project Presentation</h1>
							<p className="font-weight-normal text-light" style={{ fontSize: "12px" }}>Directly by Builder Team | Latest Offers | Live Flat Tour</p>
							<div className="full_search_box nexio_search" style={{ background: "transparent", padding: "0 0 0" }}>
								<div className="search_hero_wrapping">
									<div className="row">
										<div className="col-lg-8">
											<a href="javascript:void(0)" onClick={validate} className="btn" style={{ background: "#234e70", width: "45%", height: "35px", padding: "6px 0px", borderRadius: "50px", fontSize: "14px" }}>Schedule Presentation</a>
										</div>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</>
	)
}

export default Online_presentation_mobile;