/* eslint-disable @next/next/no-img-element */

import React, { useState, useEffect } from 'react';
import { set_sign_up_modal,  set_sign_up_next_step, set_mobile_number, set_step1_modal } from '../../../redux/slices/MobileSignUpModalSlice';

import {set_ola_modal_tab,set_active_tab } from '../../../redux/slices/signUpModalSlice';


import { select_project } from "../../../redux/slices/projectsSlice";

import { useDispatch } from 'react-redux';	
import { useRouter } from 'next/router';
const Sitevisit_mobile = () => {

	const dispatch = useDispatch();
	const router = useRouter();

	const validate = async () => {
		// dispatch(select_project([]));
		dispatch(set_step1_modal(true))
		dispatch(set_ola_modal_tab(false));
		dispatch(set_active_tab('1'));
	}

	
    return(
        <>
		
        <div className="image-cover hero_banner" id="free-visit-mobile" style={{background:"url(/assets/img/mobile-view1.webp) no-repeat",paddingTop: "0"}} data-overlay="0">
				<div className="container">
					<div className="row justify-content-center">
						<div className="col-xl-10 col-lg-12 col-md-12" style={{marginTop:"60px"}}>
							<h1 className="big-header-capt mb-2" style={{fontSize:"1.7rem"}}>Book Free Site Visit</h1>
							<div className="row" >
								
								<div className="col-sm-12 d-lg-block">
									{/* <div className="form-group">
										<button onClick={() => dispatch(set_ola_modal_tab(true))} className="btn otp-btn sitevisit-btn">Book <img src="assets/img/ola-logo1.png" width="65%" style={{marginLeft:"5px"}} alt="" /></button>
									</div> */}

									<div className="form-group">
										<button onClick={validate} className="btn otp-btn sitevisit-btn">Book <img src="/assets/img/ola-logo1.png" width="50%" style={{ marginLeft: "5px" }} alt="" /></button>
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
        </>
    )
}

module.exports = Sitevisit_mobile;