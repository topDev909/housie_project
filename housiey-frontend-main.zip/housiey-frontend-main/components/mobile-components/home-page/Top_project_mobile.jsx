/* eslint-disable @next/next/no-img-element */
/* eslint-disable react/jsx-key */
import React, { useEffect, useState } from 'react'
import Signup_modal from "./Signup_modal";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import { useDispatch,useSelector } from "react-redux";
import Tabs,{ tabsClasses } from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { set_sign_up_modal, set_step1_modal } from '../../../redux/slices/MobileSignUpModalSlice';
import {set_ola_modal_tab, set_active_tab} from '../../../redux/slices/signUpModalSlice';

import { select_project } from "../../../redux/slices/projectsSlice";
import {slugGenrator} from '../../../utils/BasicFn';
import Link from 'next/link';


import Skeleton,{SkeletonTheme} from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'

const Top_project_mobile = ({SendLocationLink,SendBuilderLink}) => {
	const [opensignup, setOpensignup]   = useState(false)
	const [value, setValue]             = useState('');
	const [cityname, setCityname]       = useState([])
	const [city_id,setCityId]           = useState();
	const [cityproduct, setCityproduct] = useState([])
	const [projectname,setProjectname]  = useState([])
	const [getRangeID,setRangeId]       = useState('');
	const [cityInfo,setCityInfo] 		= useState('');
	const [isLoading,setisLoading] 		= useState(false);
	const dispatch = useDispatch();


	const handleChange = (event, newValue) => {
		

		setRangeId(newValue);
	};

	
	
	// eslint-disable-next-line react-hooks/exhaustive-deps
	useEffect(async () => {
		let cityData = JSON.parse(localStorage.getItem('houseiy_location'));
		if(cityData){
			fetchData(cityData)
			setCityInfo(cityData)
		}else{
			fetchCity()
		}
	  }, [])


	  const fetchCity = async ()=>{
		let fetcheCity       = await fetch(process.env.BASE_URL+'get-default-city');
		if(fetcheCity.ok){
			let cityFetchData  = await fetcheCity.json();
			let cityID = cityFetchData.data[0].city_id;
			fetchData(cityFetchData.data[0])
			setCityInfo(cityFetchData.data[0])
		}
	  }


	  const fetchData = async (cityData)=>{
		setisLoading(true)
		if(cityData){
			// console.log('here we hare',cityData);
			setCityId(cityData.city_id);
			const response = await fetch(process.env.BASE_URL+"top-range-tabs/"+cityData.city_id);
			let result     = await response.json();
			if(result.tabs.length > 0){
			  setCityname(result.tabs) 
			  if (result.tabs[0].range_id)
			  {
				let range_id = result.tabs[0].range_id;
				setRangeId(range_id)
			  }
			} 
		  }

		  setisLoading(false)
	  }

	
	
	  useEffect(()=>{
		if(getRangeID){
		  rangedataid()
			// setValue(cityname[0].range_id)
		}
	  },[getRangeID])
  
	//   console.log(getRangeID)
	  const rangedataid = async()=>{
		setisLoading(true)
		const response = await fetch(process.env.BASE_URL +`/top-range-projects/${city_id}/${getRangeID}/`);
		let result     = await response.json();
	    	setCityproduct(result.projects)
			setValue(getRangeID);
		setisLoading(false)
	   }


	    // Open MOdal function
  const openmodal = (value)=>{ 
    let arr = [];
    let obj = {
		id: value.p_id,
      project_name: value.project_name,
      slug: value.slug
    }
    arr.push(obj);
    dispatch(select_project(arr));
    dispatch(set_ola_modal_tab(true));
    dispatch(set_active_tab('1')); 
	dispatch(set_step1_modal(true))
	
    // if (localStorage.getItem('housey_token')) {
	//    dispatch(set_step1_modal(true))
    // }else{
    //   localStorage.setItem('modal_type', 'ola_modal')
	//   dispatch(set_sign_up_modal(true));
    // }


  }


    return(
        <>
        <section className="min" id="top-projects" style={{padding:"10px 0 0"}}>
				<div className="container">
					
					<div className="row justify-content-center">
						<div className="col-lg-7 col-md-8">
							<div className="sec-heading center">
								<h2>Top Projects</h2>
							</div>
						</div>
					</div>
					
				<div className="property_block_wraps"> 
					<div className="property_block_wrap_header"> 
						<div className="row" >
							 
							<Box className="top-project-mobile-tab"  sx={{ marginBottom:'15px', bgcolor: 'background.paper',borderBottom: 1, borderColor: 'divider' }} >
								

									<Tabs
										onChange={handleChange} 
										value={value}
										variant="scrollable"
										scrollButtons="auto"
										aria-label="scrollable auto tabs example"
										allowScrollButtonsMobile={true}

										sx={{
											[`& .${tabsClasses.scrollButtons}`]: {
											  '&.Mui-disabled': { opacity: 0.3 },
											},
										  }}

									>
									{cityname.map((city) =>
										<Tab label={city.price_raneg} value={city.range_id} className="mr-3"/>	
										)}
									</Tabs>

							</Box>
						</div>
					</div>
					<div className="block-bodys">
						<div className="sidetab-content">
							<div className="tab-content" id="pills-tabContent">
						
								<div className="tab-pane fade show active" id="pills-property" role="tabpanel" aria-labelledby="pills-property-tab">
									<div className="item-slide-5 space">

										{isLoading ? 
									<SkeletonTheme baseColor="#c9c9c9" highlightColor="#f3f5f8" style={{ display:'flex' }} >
									<Skeleton count={1} height={'250px'} style={{ margin:'1rem 0rem'}} />
									</SkeletonTheme>
									
									 : 
										 <Carousel autoPlay={true} infiniteLoop={true} showArrows={false} showThumbs={false} thumbWidth={50} useKeyboardArrows={false}
												showIndicators={false} interval={3000} showStatus={false} swipeable={true} preventMovementUntilSwipeScrollTolerance={true}
											> 
											  {cityproduct && cityproduct.map((product)=>	
												<div className="single_items">
													<div className="property-listing list_view">												
															<div className="listing-img-wrapper">
																<div className="_exlio_125"><i className="fas fa-street-view"></i></div>
																<div className="_exlio_126"><i className="far fa-play-circle"></i></div>
															
																<div className="_exlio_128" data-toggle="tooltip" data-placement="top" data-original-title="Save property"><a href="#"><i className="far fa-heart"></i></a></div>
																<div className="list-img-slide">
																	<Link href={`/in/`+cityInfo.name+'/'+slugGenrator(product.location)+`/`+product.slug} >
																	<a>
																		<img src={process.env.BASE_URL+product.image} className="img-fluid mx-auto" alt="" />
																	</a>
																	</Link>
																</div>
															</div>
															
															<div className="list_view_flex">
															
																<div className="listing-detail-wrapper mt-1">
																	<div className="listing-short-detail-wrap">
																		
																		<div className="_card_list_flex">
																			<div className="_card_flex_01">
																				<h4 className="listing-name verified">
																					<Link href={`/in/`+cityInfo.name+'/'+slugGenrator(product.location)+`/`+product.slug} >
																						<a  className="prt-link-detail"> {product.project_name}</a>
																					</Link>
																				</h4>
																					<p className="builder-name">By 
																				<button className='link-btn' 
																					onClick={() => SendBuilderLink(product.builder, product.builder_id)}
																				>
																				{product.builder} 
																				</button> 
																				<button className='link-btn' style={{ float: 'right' }} onClick={() => SendLocationLink(product.location, product.locality_id)} >
																					<i className="fas fa-map-marker-alt"></i> {product.location}
																				</button>
																				</p>
																				
																			</div>
																		</div>
																	</div>
																</div>
																
																<div className="price-features-wrapper">
																	<div className="list-fx-features">
																		<div className="listing-card-info-icon">
																			<div className="inc-fleat-icon"><i className="fas fa-bed"></i></div> {product.config}
																		</div>
																		
																		<div className="listing-card-info-icon" style={{textAlign:"right"}}>
																			<div className="inc-fleat-icon"><i className="fas fa-vector-square"></i></div>{product.area_range_max} sqft
																		</div>
																	</div>
																	<div className="list-fx-features">
																	
																		<div className="listing-card-info-icon">
																			<div className="inc-fleat-icon"><i className="far fa-file-alt"></i></div>Possession 
																		</div>
																	</div>
																</div>
																<div className="_card_list_flex mb-2">
																		
																			<div className="_card_flex_last">
																				<h6 className="listing-card-info-price mb-0"><i className="fas fa-rupee-sign"></i> {product.overall_price_range}<small style={{fontSize:"60%"}}> (All Inc.)</small></h6>
																			</div>
																		</div>

																
																<div className="listing-detail-footer">
																	<div className="footer-first">
																			<button className="schedule-view" onClick={() => openmodal(product)}><i className="fa fa-desktop"></i>  &nbsp; | &nbsp; <i className="fa fa-car"></i> &nbsp; Tour</button>												
																	</div>
																</div>
															</div>
															
													</div>
												</div>
											  )}
										</Carousel>	 
									}
									</div>	
								</div> 
							</div>
							
						</div>
						
					</div>
				</div>
					
				</div>
			</section>
			<Signup_modal  />
        </>
    )
}

export default Top_project_mobile;