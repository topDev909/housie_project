import * as React from 'react';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import { useState, useEffect } from "react"
import {useDispatch} from 'react-redux'; 
import {do_select_city,set_filters, selectFilter} from '../../../redux/slices/filterSlice';
import { useRouter } from 'next/router'; 
import { makeStyles } from "@material-ui/core/styles";
import { GenrateSearchURL,slugGenrator } from '../../../utils/BasicFn';
 
const useStyles = makeStyles({
	paper: {
	  border: "0px solid black",
	  borderRadius: "0px !important",
	  marginTop: "11px"
	},
  });

  
const SearchMobile = () => {


	
    const dispatch = useDispatch();
    const classes  = useStyles(); 
    const [cityData,setCityData] = useState([]);
    const [selectedCity,setSelectedCity] = useState([]);

    useEffect(()=>{
      const FnCall =  async ()=>{
        let defaultCities  = localStorage.getItem('houseiy_location');
        if(defaultCities){
          defaultCities = JSON.parse(defaultCities);
        }
        let fetchCity = await fetch(process.env.BASE_URL+'getCities');

        if(fetchCity.ok){
          let city_result = await fetchCity.json();
          setCityData(city_result.cities);
          for (let city_i = 0; city_i < city_result.cities.length; city_i++) {
            if(defaultCities){
              if(defaultCities.city_id===city_result.cities[city_i].city_id){
                setSelectedCity(city_result.cities[city_i].city_id)
                dispatch(do_select_city(city_result.cities[city_i]))
                let obj = {
                  type: 'city_id',
                  filter: city_result.cities[city_i].city_id
                }
                dispatch(set_filters(obj));
                localStorage.setItem('houseiy_location',JSON.stringify(city_result.cities[city_i]))
                break;
              }
            }else if(city_result.cities[city_i].default_city){
                setSelectedCity(city_result.cities[city_i].city_id)
                dispatch(do_select_city(city_result.cities[city_i]))
                let obj = {
                  type: 'city_id',
                  filter: city_result.cities[city_i].city_id
                }
                dispatch(set_filters(obj));
                localStorage.setItem('houseiy_location',JSON.stringify(city_result.cities[city_i]))
                break;
              }
            } 
        } 
      }
      FnCall();
    },[])

  


   const router                     = useRouter();
   const [query, setQuery]          = useState([])
   const [mykeyword, setMykeyword]  = useState('')
   const [filterdata,setFilterdata] = useState([]) 
   
   const findcat = (e,value)=>{

    if(value===null){
    }
    else{
      let obj={
        id:value.id,
        type:value.type,
        title:value.title,
        option_title:value.option_title
      }
      setFilterdata(obj)
      sendUrl(value)
    }
  }

   const sendUrl = async (value)=>{

    let   url         = '';
    let   city_data   = JSON.parse(localStorage.getItem('houseiy_location'));
    let   city_name   = city_data.name.toLowerCase();
    let   url_id      = (value.id)?value.id:city_data.city_id; 

    // console.log(value);

      // console.log(query);
    let type = 'builder_id';
    let filter =  url_id.substring(url_id.lastIndexOf("/") + 1, url_id.length);
    let searchTextVal = query.find(x => x.id === url_id).option_title;

    if(searchTextVal){
      let SearchText = {
        type:   'searchText',
        filter: searchTextVal,
        id:     filter,
        value:  {
          id:           value.id,
          type:         value.type,
          title:        searchTextVal,
          option_title: value.option_title
        }
      }
      localStorage.setItem('serchText',JSON.stringify(SearchText))
    }
    let reset_filter = {
      type: 'reset_filter',
      filter: 0,
      make_search: 0,
    }
    
    dispatch(selectFilter(reset_filter));
    // console.log({value,query})
    url = GenrateSearchURL(value,query)
    await router.push(url);
   }



   const SearchHandler = async (e)=>{
     e.preventDefault();
    let  city_data  = JSON.parse(localStorage.getItem('houseiy_location'));
    let   url       = "/in/"+city_data.name.toLowerCase()+"/projects";  
    await router.push(url);
   }

   const myvalue = (e)=>{


     setMykeyword(e)
     let key = e;

     if (key){
       fetch(process.env.BASE_URL + `search/${selectedCity}/${key}`).then(result => {
         result.json().then((response) => {
           let opt_arr = [];
           if (response.builders.length > 0) {
             for (let b_i = 0; b_i < response.builders.length; b_i++) {
               let title  = <p className='search-list' ><span className="title">{response.builders[b_i].builder_name}</span> <span className="side-title" > Builder</span></p>
               let b_slug = slugGenrator(response.builders[b_i].builder_name)
               let b_obj  = {
                 title:         title,
                 option_title:  response.builders[b_i].builder_name,
                 id:            b_slug,
                 type:          "builders"
               }
               opt_arr.push(b_obj)
             }
           }
           if (response.locality.length > 0) {
             for (let l_i = 0; l_i < response.locality.length; l_i++) {
               let title  = <p className='search-list' ><span className="title">{response.locality[l_i].name}</span> <span className="side-title" > Locality</span></p>
               let b_slug = slugGenrator(response.locality[l_i].name)
               let l_obj = {
                 title: title,
                 option_title: response.locality[l_i].name,
                 id: b_slug,
                 type: "locality"
               }
               opt_arr.push(l_obj)
             }

           }
           if (response.projects.length > 0) {
             for (let p_i = 0; p_i < response.projects.length; p_i++) {

               let title = <p className='search-list' ><span className="title">{response.projects[p_i].project_name}</span> <span className="side-title" > Project</span></p>
               let locality_clug = slugGenrator(response.projects[p_i].locality,'');
              let project_id  = locality_clug+'/'+response.projects[p_i].slug;
               let p_obj = {
                 title: title,
                 option_title: response.projects[p_i].project_name,
                 id: project_id,
                 type: "projects"
               }
               opt_arr.push(p_obj)
             }

           }
           else {
           
          }
           setQuery(opt_arr)
         })
       })
    }else{
       setQuery([])
    }
     

}




  const SelectCities = (e)=>{
    let city_id = parseInt(e.target.value);
    let filteredArray = cityData.filter(item => {
      if(item.city_id === city_id){
           return item;
      }
    });
    setSelectedCity(city_id)
    localStorage.setItem('houseiy_location',JSON.stringify(filteredArray[0]))
    router.reload(window.location.reload)   
}



    return(
        <>
        <div className="image-cover hero_banner mobile-hero-banner" style={{background:"url(assets/img/main-banner.webp) no-repeat"}} data-overlay="0">
				<div className="container">
					
					<h1 className="big-header-capt" style={{marginBottom:"0"}}>Home Buying Simplified</h1>
					<h5 style={{textAlign:"center",marginBottom:"2.5rem"}}><img src="assets/img/no-brokerage.svg" className="img-fluid" alt="" width="5%" style={{filter: "brightness(100)"}} /> No Brokerage | <img src="assets/img/bottom-rate.svg" className="img-fluid" alt="" width="5%" style={{filter: "brightness(100)"}} /> Bottom Rate Policy</h5>
					
					<div className="row justify-content-center">
						<div className="col-xl-10 col-lg-11 col-md-12">
							<div className="full_search_box nexio_search lightanic_search hero_search-radius modern">
								<div className="search_hero_wrapping">
								<form action="#" onSubmit={SearchHandler}>  
									<div className="row">
										<div className="col-sm-12" style={{display:"flex"}}>
											
											<div className="form-group" style={{width:"40%",borderRadius:"20px 0px 0px 20px"}}>
												
												<div className="input-with-icon">
												<select id="main-cities" className="form-control" name="city_name" onChange={SelectCities} >
													{cityData.map((singleCity,keyID)=>(
													<option value={singleCity.city_id} key={keyID} selected={(selectedCity===singleCity.city_id)?1:0} >{singleCity.name}</option>
													))}
												</select> 
												</div>
											</div>
											<div className="form-group" style={{position:"relative",width:"100%",borderRadius:"0px 20px 20px 0px"}}>
											<Stack>
                              <Autocomplete
                                options={query}
                                freeSolo={true}
                                onChange={findcat}
                                getOptionLabel={(option) => option.option_title}
                                classes={{ paper: classes.paper }}
                                renderOption={(props, option) => (
                              <>
                                   <div className='option-list'  {...props} >
                                      {option.title}
                                   </div>
                              </>
                            )}
                                renderInput={(params) => (
                                  <TextField
                                    {...params}  
                                    id="main-search-box-input"
                                    variant="standard"
                                    className="form-control search_input b-0"
                                    placeholder='Search Project, locality or builder'
                                    name="project_slug"
                                    onChange={(e)=>{
                                    myvalue(e.target.value)}}
                                  />
                                  
                                )}
                                
                              />
                              </Stack>
											</div>
										</div>	
										
									</div>
							    </form> 
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
        </>
    )
}
export default SearchMobile;