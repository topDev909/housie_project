/* eslint-disable @next/next/no-img-element */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react/jsx-key */
import React, { useState,useEffect } from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import { useDispatch,useSelector } from "react-redux";
const Top_builders_mobile = ({SendLocationLink,SendBuilderLink}) => {  
 
	const [cityname, setCityname]       = useState([])
	const [city_id,setCityId]           = useState();
 
	const [builderData,setbuilderData]  = useState([])
	const [getRangeID,setRangeId] = useState('');
	const dispatch = useDispatch();
	

	useEffect(async () => {
		let cityData = JSON.parse(localStorage.getItem('houseiy_location'));
		if(cityData){
			fetchData(cityData)
		}else{
			fetchCity()
		}
	  }, [])

	  const fetchCity = async ()=>{
		let fetcheCity       = await fetch(process.env.BASE_URL+'get-default-city');
		if(fetcheCity.ok){
			let cityFetchData  = await fetcheCity.json();
			let cityID = cityFetchData.data[0].city_id;
			fetchData(cityFetchData)
		}
	  }

	  const fetchData = async (cityData)=>{
		if(cityData){
			setCityname(cityData.name)
		  setCityId(cityData.city_id);
		  const response = await fetch(process.env.BASE_URL+"get-builder-for-mobile/"+cityData.city_id);
		  let result     = await response.json();
		  if(result.res){
		    setbuilderData(result.builder_info);
			  ;
		  }
		}
	  }
	 

    return(
        <>
        <section className="gray-simple" id="top-builders" style={{padding:"10px 0 40px"}}>
				<div className="container">
					<div className="row justify-content-center">
						<div className="col-lg-7 col-md-8">
							<div className="sec-heading center">
								<h2>Top Builders in {cityname}</h2>
							</div>
						</div>
					</div>
					<div className="item-slide-6 space">
						<Carousel autoPlay={true} infiniteLoop={true} showArrows={false} showThumbs={false} thumbWidth={50} useKeyboardArrows={false}
							showIndicators={false} interval={3000} showStatus={false} swipeable={true} preventMovementUntilSwipeScrollTolerance={true}
						>
							
                 {builderData && builderData.map((builder) =>	
						<div className="single_items builder-details">
							<div className="story-wrap explore-content text-center" style={{boxShadow:"0 0 20px 0 rgb(62 28 131 / 10%)"}}>
								<div className="builder-name">
									<div className="row">
										<div className="col-6">
											<img src={process.env.BASE_URL+builder.logo} className="img-fluid" alt="" />											
										</div>
										<div className="col-6" style={{borderLeft:"1px solid #c9cbd1"}}>
											<h4 className="builder-name">{builder.builder_name}</h4>
											<div className="_rate_stio">
												<i className="fa fa-star"></i>
												<i className="fa fa-star"></i>
												<i className="fa fa-star"></i>
												<i className="fa fa-star"></i>
												<i className="fa fa-star"></i>
											</div>										
										</div>
									</div>
										
								</div>
								<div className="experience">
									<div className="row">
										<div className="col-6 exp">
											<span>Experience {builder.experience} Yrs</span>										
										</div>
										<div className="col-6 pro">
											<span>Total Projects {builder.projects_comp}</span>
										
										</div>
									</div>
								</div>
								<div className="about">
									<p>
										{builder.description.substring(0,200)}
										<button type="button" className='link-btn' 
                            				onClick={()=>SendBuilderLink(builder.builder_name,builder.id)} >Read More</button>
										{/* <a href="#"><br/>Read More</a> */}
									</p>
									<button type="button" className='link-btn' 
										onClick={()=>SendBuilderLink(builder.builder_name,builder.id)} >
										View all Projects <i className="fas fa-arrow-right"></i>
									</button>
								</div>								
							</div>
						</div>
						
)}
						</Carousel>
					</div>
					
									
					
				</div>
						
			</section>
        </>
    )
}

export default Top_builders_mobile;