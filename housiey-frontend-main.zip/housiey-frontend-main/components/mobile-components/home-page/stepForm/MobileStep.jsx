import React from 'react';
const MobileStep = ()=>{
    return (
        <>
        </>
    )
}
export default MobileStep;