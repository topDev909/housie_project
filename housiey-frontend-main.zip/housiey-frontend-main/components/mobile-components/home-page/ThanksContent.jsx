import React from 'react';
const ThanksContent = ()=>{
    return (
        <>

<div className="text-center mt-2">
                        <h2 className="thank-modal-heading"></h2>
                        <img src="/assets/img/gift.png" width={35} style={{marginBottom: "10px"}} />
                        <p className='my_text_done' style={{color: "#0e8744"}}>Congratulation,</p>
                        <span className='my_text_signup'>you have successfully <span style={{color: "#0e8744"}}>Sign Up</span></span>
                    </div>
                    <hr style={{background: "#234E70"}}></hr>
                    
        <div style={{textAlign: "center", marginBottom: "10px"}}>
                        <span style={{background: "#0e8744", padding: "5px 10px", color:"#fff", borderRadius: "50px"}}>Enjoy your exclusive Sign Up Perks</span>
                    </div>
                    <ul style={{listStyle:"none",display:"flex",padding:"10px 10px 0px 10px"}}>
                        <li style={{fontSize:"14px",width:"45%",fontWeight:"600",marginRight:"5%",background:"#f3f5f8",padding:"10px",borderRadius:"10px",boxSshadow:"0px 1px 2px 0 rgb(105 96 122 / 33%)"}}>
                            <span style={{display:"flex"}}>
                                <img src="/assets/img/bonus.svg" className="img-fluid" alt="" width="20%" style={{marginRight:"7px"}} />
                                <p style={{lineHeight:"1.2",marginBottom:"0"}}>Referral Bonus
Refer Housiey &#38; get bonus upto Rs 2lac</p>
                            </span> 
                            
                        </li>
                        <li style={{fontSize:"14px",width:"45%",fontWeight:"600",marginLeft:"5%",background:"#f3f5f8",padding:"10px",borderRadius:"10px",boxShadow:"0px 1px 2px 0 rgb(105 96 122 / 33%)"}}>
                            <span style={{display: "flex"}}>
                                <img src="/assets/img/free-cab.svg" className="img-fluid" alt="" width="20%" style={{marginRight:"7px"}} />
                                <p style={{lineHeight:"2.2",marginBottom:"0"}}>Free Site Visit</p>
                            </span> 
                            
                        </li>

                    </ul>
                    <ul style={{listStyle:"none",display:"flex",padding:"10px"}}>
                        <li style={{fontSize:"14px",width:"45%",fontWeight:"600",marginRight:"5%",background:"#f3f5f8",padding:"10px",borderRadius:"10px",boxShadow:"0px 1px 2px 0 rgb(105 96 122 / 33%)"}}>
                            <span style={{display:"flex"}}>
                                <img src="/assets/img/bottom-rate.svg" className="img-fluid" alt="" width="18%" style={{marginRight:"7px"}} />
                                <p style={{lineHeight:"1.2",marginBottom:"0"}}>Bottom Rate Guarantee</p>
                            </span> 
                            
                        </li>
                        <li style={{fontSize:"14px",width:"45%",fontWeight:"600",marginLeft:"5%",background:"#f3f5f8",padding:"10px",borderRadius:"10px",boxShadow:"0px 1px 2px 0 rgb(105 96 122 / 33%)"}}>
                            <span style={{display:"flex"}}>
                                <img src="/assets/img/manager.svg" className="img-fluid" alt="" width="18%" style={{marginRight:"7px"}} />
                                <p style={{lineHeight:"1.2",marginBottom:"0"}}>Relationship Manager</p>
                            </span> 
                            
                        </li>

                    </ul>
  
        </>
    )
}
export default ThanksContent;