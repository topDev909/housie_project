/* eslint-disable @next/next/no-img-element */

import React, { useState, useEffect } from 'react';
import { set_sign_up_modal,set_sign_up_next_step,set_mobile_number } 	from '../../../redux/slices/MobileSignUpModalSlice';
import {set_sent_otp} from '../../../redux/slices/signUpModalSlice';
// import Signup_modal from "./Signup_modal";
// import Signup_modal                             from '../home-page/Signup_modal';

import PhoneInput from 'react-phone-number-input';
import {useDispatch,useSelector} from 'react-redux';

const Signupperks_listing_mobile = () => {


	const dispatch = useDispatch();
	const [mobile, setMobile]           = useState('')
    const [otpnum, setOtpnum]           = useState('')
    const [checkotp, setCheckotp]       = useState('')
    const [name, setName]               = useState('')
    const [email, setEmail]             = useState('')
    const [otperror,setOtperror]        = useState('')
    const [formErr,setFormErr]          = useState('')
	const [opensignup, setOpensignup]   = useState(false)
	const reduxMobile = useSelector((state)=>state.MobileSignUpModal.mobileNumber)
	const[checkfree,setCheckfree]  = useState(true);
  

	const validate = async () => {
		if(mobile>3)
		{
			dispatch(set_sign_up_modal(true));
			dispatch(set_sent_otp(true)); 
			// console.log('Demo',mobile)
		}
		else{
			let err =<span style={{color:'red'}}>Number is required</span>
			setOtperror(err)
		}
    }

	const getNumberOnchange = (e) => {
        setMobile(e)
       // console.log(e);
        dispatch(set_mobile_number(e))
    }


    return(
        <>
        <section style={{padding:"30px 0 0px"}}>
				<div className="container">
					<div className="row">
						<div className="col-12">
							<div className="card" style={{border:"none",boxShadow:"0 0 20px 0 rgb(62 28 131 / 10%)",padding:"10px",borderBottom:"4px solid #234e70"}}>
								<h4 className="text-center" style={{fontSize:"18px"}}>Sign Up Perks</h4>
							
								<ul style={{listStyle:"none",display:"flex",padding:"10px 10px 0px 10px"}}>
									<li style={{fontSize:"14px",width:"45%",fontWeight:"600",marginRight:"5%",background:"#f3f5f8",padding:"10px",borderRadius:"10px",boxSshadow:"0px 1px 2px 0 rgb(105 96 122 / 33%)"}}>
										<span style={{display:"flex"}}>
											<img src="/assets/img/bonus.svg" className="img-fluid" alt="" width="20%" style={{marginRight:"7px"}} />
											<p style={{lineHeight:"1.2",marginBottom:"0"}}>Refer Housiey &amp; Get Bonus Upto Rs 2lac </p>
										</span> 
										
									</li>
									<li style={{fontSize:"14px",width:"45%",fontWeight:"600",marginLeft:"5%",background:"#f3f5f8",padding:"10px",borderRadius:"10px",boxShadow:"0px 1px 2px 0 rgb(105 96 122 / 33%)"}}>
										<span style={{display: "flex"}}>
											<img src="/assets/img/free-cab.svg" className="img-fluid" alt="" width="20%" style={{marginRight:"7px"}} />
											<p style={{lineHeight:"2.2",marginBottom:"0"}}>Free Site Visit</p>
										</span> 
										
									</li>

								</ul>
								<ul style={{listStyle:"none",display:"flex",padding:"10px"}}>
									<li style={{fontSize:"14px",width:"45%",fontWeight:"600",marginRight:"5%",background:"#f3f5f8",padding:"10px",borderRadius:"10px",boxShadow:"0px 1px 2px 0 rgb(105 96 122 / 33%)"}}>
										<span style={{display:"flex"}}>
											<img src="/assets/img/bottom-rate.svg" className="img-fluid" alt="" width="18%" style={{marginRight:"7px"}} />
											<p style={{lineHeight:"1.2",marginBottom:"0"}}>Bottom Rate Guarantee</p>
										</span> 
										
									</li>
									<li style={{fontSize:"14px",width:"45%",fontWeight:"600",marginLeft:"5%",background:"#f3f5f8",padding:"10px",borderRadius:"10px",boxShadow:"0px 1px 2px 0 rgb(105 96 122 / 33%)"}}>
										<span style={{display:"flex"}}>
											<img src="/assets/img/manager.svg" className="img-fluid" alt="" width="18%" style={{marginRight:"7px"}} />
											<p style={{lineHeight:"1.2",marginBottom:"0"}}>Relationship Manager</p>
										</span> 
										
									</li>

								</ul>

								<div className="call_action_wrap" style={{padding:"6px",height:"100px"}}>
									<div className="call_action_wrap-head">
										<h3 style={{fontSize:"12px"}}>Sign Up For Free</h3>
										<div className="row">
											
											<div className="col d-lg-block">
												
												<div className="form-group" style={{display:"flex"}}>
													<PhoneInput
													defaultCountry="IN"
													countryCallingCodeEditable={false}
													placeholder="Enter phone number"
													onChange={getNumberOnchange}
													value={reduxMobile}
													/>
													<a  onClick={validate} className="btn otp-btn singupfree-btn" >Sign Up </a>
												</div>
											</div>
											
										
										</div>
									
										
									</div>
								</div>
							</div>
						
						</div>
					</div>
				</div>
			</section>
        </>
    )
}
{/* <style>
    .iti--separate-dial-code .iti__selected-flag {
        height: 33px;
    }
</style> */}

export default Signupperks_listing_mobile;