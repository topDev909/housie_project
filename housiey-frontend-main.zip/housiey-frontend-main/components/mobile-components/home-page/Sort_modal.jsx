import { useDispatch, useSelector } from "react-redux";
import React, { useState, useEffect } from "react"
import DatePicker from "react-datepicker";
import { set_Sort_modal } from '../../../redux/slices/MobileSignUpModalSlice';

import Box from '@mui/material/Box';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';

const Sort_modal = () => {
    const dispatch = useDispatch();
    const openSortModal = useSelector((state) => state.MobileSignUpModal.openSortModal)
    
    const CloseModal = () => {
        // console.log('tesat tesatset');
        dispatch(set_Sort_modal(false));
        // router.reload(window.location.reload)

    }

  return (
    <>
    
          <div className="bottomFotter" style={{ height: openSortModal ? "30%" : "0" }}>
            
              <span className="mod-close" onClick={CloseModal} aria-hidden="true" >
                  <i className="ti-close" />
              </span>
     
        <Box sx={{ flexGrow: 1 }}>
          <FormControl>
            <FormLabel id="demo-radio-buttons-group-label">Gender</FormLabel>
            <hr />
            <RadioGroup
              aria-labelledby="demo-radio-buttons-group-label"
              defaultValue="female"
              name="radio-buttons-group"
            >
              <FormControlLabel value="female" control={<Radio />} label="Female" />
              <FormControlLabel value="male" control={<Radio />} label="Male" />
              <FormControlLabel value="other" control={<Radio />} label="Other" />
            </RadioGroup>
          </FormControl>
        </Box>
          </div>
    </>
  )
}

export default Sort_modal