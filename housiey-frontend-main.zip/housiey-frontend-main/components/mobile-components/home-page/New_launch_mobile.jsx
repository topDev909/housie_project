/* eslint-disable @next/next/no-img-element */
import React, { useEffect, useState } from 'react'
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import { slugGenrator } from '../../../utils/BasicFn';
import { useDispatch }                from "react-redux";
import { set_sign_up_modal,set_step1_modal } from '../../../redux/slices/MobileSignUpModalSlice';
import {set_ola_modal_tab,set_active_tab} from '../../../redux/slices/signUpModalSlice';
import { select_project } from "../../../redux/slices/projectsSlice";
import TouchCarousel from 'react-touch-carousel'
import Link from 'next/link';



const New_launch_mobile = ({SendLocationLink,SendBuilderLink}) => {

	// let locality = slugGenrator(item.location);
  	// let singleProjectSlug = `/in/${cityName}/${locality}/${item.slug}`;
  
	const [opensignup, setOpensignup] = useState(false)
	const data = []; // myproject.projects;

	const dispatch                  = useDispatch();
	const [myproject,setMyProjects] = useState([]);
	const [cityData,setCityData]    = useState('');

	useEffect(()=>{
		const FetchFn  =  async ()=>{
		  let cityData = JSON.parse(localStorage.getItem('houseiy_location'));
		  let cityID   = '';
		  if(cityData){
			cityID   = cityData.city_id;
			setCityData(cityData);
		  }else{
			let fetcheCity       = await fetch(process.env.BASE_URL+'get-default-city');
			if(fetcheCity.ok){
			  let cityFetchData  = await fetcheCity.json();
			  cityID = cityFetchData.data[0].city_id;
			  setCityData(cityFetchData.data[0]);
			}
		  }
	
		  if(cityID){
			  const response = await fetch(process.env.BASE_URL+'top-launches-projects/'+cityID)
				if(response.ok){
				// console.log
				let result = await response.json();
				if(result.projects){
				  setMyProjects(result.projects)
				}
				// setMyProjects()
			  }
		  }
		}
		FetchFn();
	  },[])

	   // Open MOdal function
  const openmodal = (value)=>{ 
    let arr = [];
    let obj = {
		    id: value.p_id,
			project_name: value.project_name,
			slug: value.slug
    	}
    arr.push(obj);
    dispatch(select_project(arr));
    dispatch(set_ola_modal_tab(true));
    dispatch(set_active_tab('1')); 
	dispatch(set_step1_modal(true))


	
  }

    return(

        <> 
        <section className="min light-bg" id="new-launches" style={{padding:"20px 0 0px"}}>
				<div className="container">					
					<div className="row justify-content-center">
						<div className="col-lg-7 col-md-8">
							<div className="sec-heading center">
								<h2>Top New Launches in  {cityData && cityData.name}</h2>
							</div>
						</div>
					</div>
					<div className="row">
						<div className="col-lg-12 col-md-12" style={{padding:"0px"  }}>
							<div className="item-slide-4 space">
								 
								<Carousel autoPlay={true} infiniteLoop={true} showArrows={false} showThumbs={false} thumbWidth={50} useKeyboardArrows={false}
									showIndicators={false} interval={3000} showStatus={false} swipeable={true} preventMovementUntilSwipeScrollTolerance={true}
								> 
								
	              	  {myproject && myproject.map((item) =>
					<>
					<div>
					<div className="single_items">
					<div className="property-listing list_view">
					<div className="listing-img-wrapper">
					<div className="_exlio_125"><i className="fas fa-street-view"></i></div>
					<div className="_exlio_126"><i className="far fa-play-circle"></i></div>

					<div className="_exlio_128" data-toggle="tooltip" data-placement="top" data-original-title="Save property">
					<a href="#"><i className="far fa-heart"></i></a>
					</div>
					<div className="list-img-slide">
					<Link href={`/in/`+cityData.name+'/'+slugGenrator(item.location)+`/`+item.slug} >
					<a ><img src={process.env.BASE_URL+item.image} className="img-fluid mx-auto" alt="" /></a>
					</Link>
					</div>
					</div>

					<div className="list_view_flex">

					<div className="listing-detail-wrapper mt-1">
					<div className="listing-short-detail-wrap">

					<div className="_card_list_flex">
					<div className="_card_flex_01">
						<h4 className="listing-name verified">
							<Link href={`/in/`+cityData.name+'/'+slugGenrator(item.location)+`/`+item.slug} >
								<a  className="prt-link-detail" >  {item.project_name} </a>
							</Link>
						</h4>
						<p className="builder-name">By 
						<button className='link-btn'
                        onClick={() => SendBuilderLink(item.builder, item.builder_id)} >
                        {item.builder}
                      </button> 
					  <button className='link-btn' style={{ float: 'right' }} onClick={() => SendLocationLink(item.location, item.locality_id)} >
					  <i className="fas fa-map-marker-alt"></i>  {item.location} 
					  </button>
					  </p>

					</div>
					</div>
					</div>
					</div>

					<div className="price-features-wrapper">
					<div className="list-fx-features">
					<div className="listing-card-info-icon">
					<div className="inc-fleat-icon"><i className="fas fa-bed"></i></div> {item.config}
					</div>

					<div className="listing-card-info-icon" style={{ textAlign: "right" }}>
					<div className="inc-fleat-icon"><i className="fas fa-vector-square"></i></div>{item.area_range_max} sqft
					</div>
					</div>
					<div className="list-fx-features">

					<div className="listing-card-info-icon">
					<div className="inc-fleat-icon"><i className="far fa-file-alt"></i></div>  {item.possession}
					</div>
					</div>
					</div>
					<div className="_card_list_flex mb-2">

					<div className="_card_flex_last">
					<h6 className="listing-card-info-price mb-0"><i className="fas fa-rupee-sign"></i>  {item.overall_price_range}<small style={{ fontSize: "60%" }}> (All Inc.)</small></h6>
					</div>
					</div>


					<div className="listing-detail-footer">
					<div className="footer-first">
					<button  className="schedule-view" onClick={() => openmodal(item)}><i className="fa fa-desktop"></i>  &nbsp; | &nbsp; <i className="fa fa-car"></i> &nbsp; Tour</button>
					</div>
					</div>
					</div>
					</div>
					</div> 
					</div>
					</>
		  )}
									 
								</Carousel>
							</div>
						</div>
					</div>
					
				</div>

				
			</section>
        </>
    )
}

export default New_launch_mobile;
