/* eslint-disable @next/next/no-img-element */

import React, { useState, useEffect } from 'react';
import { set_sign_up_modal,set_sign_up_next_step,set_mobile_number } 	from '../../../redux/slices/MobileSignUpModalSlice';
import {set_sent_otp} from '../../../redux/slices/signUpModalSlice';
// import Signup_modal from "./Signup_modal";
import PhoneInput from 'react-phone-number-input';
import {useDispatch,useSelector} from 'react-redux';
const Signupperks_mobile = () => {
	const dispatch = useDispatch();
	const [mobile, setMobile]           = useState('')
    const [otpnum, setOtpnum]           = useState('')
    const [checkotp, setCheckotp]       = useState('')
    const [name, setName]               = useState('')
    const [email, setEmail]             = useState('')
    const [otperror,setOtperror]        = useState('')
    const [formErr,setFormErr]          = useState('')
	const [opensignup, setOpensignup]   = useState(false)
	const reduxMobile = useSelector((state)=>state.MobileSignUpModal.mobileNumber)
	const[checkfree,setCheckfree]  = useState(true);
  

	const NextStep = ()=>{
		dispatch(set_sign_up_next_step(true))
	}

	const validate = async () => {

		if(mobile>3)
		{
			dispatch(set_sign_up_modal(true));
			dispatch(set_sent_otp(true)); 
		}
		else{
			let err =<span style={{color:'red'}}>Number is required</span>
			setOtperror(err)

		}
       
    }

	const getNumberOnchange = (e) => {
        setMobile(e)
       // console.log(e);
        dispatch(set_mobile_number(e))
    }


	useEffect(()=>{
		let item = localStorage.getItem('housey_token')
		 if(item){
		  setCheckfree(false)
		 }
	  },[])

    return (
        <>
			<section className="min" style={{padding: "10px 0 0px"}}>
				<div className="container">
					
					<div className="row justify-content-center">
						<div className="col-lg-12 col-md-12">
							<div className="sec-heading center" style={{marginBottom:"0"}}>
								<h2>Sign Up Perks</h2>
							</div>
						</div>
					</div>
					<div className="row signup-perks justify-content-center">
						
							<div className="wpk_process p-0">
								<div className="wpk_thumb">
									<div className="wpk_thumb_figure">
										<img src="assets/img/bonus.svg" className="img-fluid" alt="" />
									</div>
								</div>
								<div className="wpk_caption">
									<h4>Refer Housiey &amp; Get Bonus Upto Rs 2lac </h4>
								</div>
							</div>

							<div className="wpk_process p-0 active">
								<div className="wpk_thumb">
									<div className="wpk_thumb_figure">
										<img src="assets/img/free-cab.svg" className="img-fluid" alt="" />
									</div>
								</div>
								<div className="wpk_caption">
									<h4>Free Site Visit</h4>
								</div>
							</div>

							<div className="wpk_process p-0">
								<div className="wpk_thumb">
									<div className="wpk_thumb_figure">
										<img src="assets/img/bottom-rate.svg" className="img-fluid" alt="" />
									</div>
								</div>
								<div className="wpk_caption">
									<h4>Bottom Rate Guarantee</h4>
								</div>
							</div>
							
							<div className="wpk_process p-0">
								<div className="wpk_thumb">
									<div className="wpk_thumb_figure">
										<img src="assets/img/manager.svg" className="img-fluid" alt="" />
									</div>
								</div>
								<div className="wpk_caption">
									<h4>Relationship Manager</h4>
								</div>
							</div>
					</div>
				</div>
			</section>
			
		 <div className="clearfix"></div>
         {checkfree ? 
            <section style={{padding:"0px 0 10px"}}>
				<div className="container">
					<div className="call_action_wrap" style={{height:"100px"}}>
						<div className="call_action_wrap-head">
							<h3 style={{fontSize:"12px"}}>Sign Up For Free</h3>
							<div className="row">	
								<div className="col d-lg-block">
									<div className="form-group" style={{display:"flex"}}>

										{/* <PhoneInput
												placeholder="Enter phone number"
												countryCallingCodeEditable={false}
												defaultCountry="IN"
												international
												style={{ height:"35px"}}
												onChange={getNumberOnchange}
												value={reduxMobile}  
										/>  */}

										<PhoneInput
										defaultCountry="IN"
										countryCallingCodeEditable={false}
										placeholder="Enter phone number"
										onChange={getNumberOnchange}
										value={reduxMobile}
										/>


										<a  onClick={validate} className="btn otp-btn singupfree-btn" >Sign Up </a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
					<span>{otperror}</span>
			</section>
			:''}
		 
			
			{/* <Signup_modal opensignup={opensignup} setOpensignup={setOpensignup} /> */}
        </>
        
    )
}
{/* <style>
    .iti--separate-dial-code .iti__selected-flag {
        height= 33px;
    }
</style> */}

export default Signupperks_mobile;
