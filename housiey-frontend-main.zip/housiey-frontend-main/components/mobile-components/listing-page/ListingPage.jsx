import Listing_card             from './Listing_card';
import Header_mobile            from '../inc/Header_mobile';
// import StickyNavbar from './filter-files/StickyNavbar';
import Footer_mobile            from '../inc/Footer_mobile';
import Listing_static_footer    from '../inc/Listing_static_footer';
import Step1_modal              from '../home-page/Step1_modal';
import Sort_modal               from './filter-files/Sort_modal';
import HideAppBar               from './filter-files/StickyNavbar';
import Filter_modal             from './Filter_modal'

import Signup_modal from "../home-page/Signup_modal";


const ListingPage  =({search_query,page_type,details})=>{
    // console.log({search_query,page_type,details})
    return (
        <>
            {/* <Header_mobile /> */}
            <HideAppBar search_query={search_query} page_type={page_type} details={details} />
            <Listing_card  search_query={search_query} page_type={page_type} details={details} />
            <Listing_static_footer />
            <Step1_modal/>
            <Sort_modal/>
            <Signup_modal/>
            <Filter_modal/>
        </>
    )
}
export default ListingPage;