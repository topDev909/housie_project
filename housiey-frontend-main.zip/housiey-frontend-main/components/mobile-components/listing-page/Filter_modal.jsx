import * as React from 'react';
import Drawer from '@mui/material/Drawer';
import AllFilters from './AllFilters';
import {useSelector} from 'react-redux';
export default function TemporaryDrawer() {

    const openFilterModal   = useSelector((state) => state.MobileSignUpModal.openFilterModal)
    const [state, setState] = React.useState({
        sort: false,
        filters: false,
    });

  React.useEffect(()=>{
    setState({ ...state, ['filters']: openFilterModal}) 
  },[openFilterModal])

  const toggleDrawer = (anchor, open) => (event) => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }

    setState({ ...state, [anchor]: open });
  };


  const renderFun = ()=>{
      if(state.filters){
        return <AllFilters/>
      }
      if(state.sort){
          return <><h1>This is testing from gautam</h1></>
      }
  }
  

  return (
    <div className='filter-modal-content-mobile012'>
      {['sort','filters'].map((anchor) => (
        <React.Fragment key={anchor}>
            
          <Drawer

          sx={{
            width: '100%',
            minWidth: '100%',
            maxHeight: '100%',
            flexShrink: 0,
            backgroundColor: '#ecf7f3',
            '& .MuiDrawer-paper': {
              paddingTop:'15px',
              maxWidth: '100%',
              minWidth: '100%',
              maxHeight: '100%',
              minHeight: '100%',
              boxSizing: 'border-box',
              backgroundColor: '#ecf7f3',
            },
          }}

            anchor={'bottom'}
            open={state[anchor]}
            onClose={toggleDrawer(anchor, false)}
          > 
          

          <AllFilters toggleModal={toggleDrawer} anchor={anchor}   />

                

          </Drawer>
        </React.Fragment>
      ))}
    </div>
  );
}
