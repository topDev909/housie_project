import * as React       from 'react';
import PropTypes        from 'prop-types';
import AppBar           from '@mui/material/AppBar';
import Toolbar          from '@mui/material/Toolbar';
import CssBaseline      from '@mui/material/CssBaseline';
import useScrollTrigger from '@mui/material/useScrollTrigger';
import Slide            from '@mui/material/Slide';
import Header_mobile    from '../../inc/Header_mobile';
import SearchProjectBox from './SearchProjectBox';
import { makeStyles }   from '@material-ui/core';


function HideOnScroll(props) {
  const { children, window } = props;
  // Note that you normally won't need to set the window ref as useScrollTrigger
  // will default to window.
  // This is only being set here because the demo is in an iframe.
  const trigger = useScrollTrigger({
    target: window ? window() : undefined,
  });

  return (
    <Slide appear={false} direction="down" in={!trigger}>
      {children}
    </Slide>
  );
}

HideOnScroll.propTypes = {
  children: PropTypes.element.isRequired,
  /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */
  window: PropTypes.func,
};


const useStyles = makeStyles({
  
  appBar:{
    top:'0px'
  },
  searchBox:{

    width: '100%', paddingLeft: '0', padding: '10px', background: '#234e70'

  }
});



export default function HideAppBar(props) {
    const {search_query,page_type,details} =  props;
    const classes = useStyles();


    


  return (
    <>

        <HideOnScroll {...props} style={{ top:'0px !important' }} >
            <AppBar   style={{ top:'0px !important' }}  >
                <Header_mobile/>
                <Toolbar sx={{ width:'100%',background:'#234e70' }}>
                        <SearchProjectBox search_query={search_query} page_type={page_type} details={details} style={{ borderRadius: '5px'}} />
                </Toolbar>
            </AppBar>
        </HideOnScroll>
      <Toolbar />
    </>
  );
}
