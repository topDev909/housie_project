import React,{useEffect, useState} from 'react';
import {numFormatter} from '../../../../utils/BasicFn';
import Slider from '@mui/material/Slider';

import { useDispatch, useSelector } from "react-redux";
import { selectFilter,applyFilters } from "../../../../redux/slices/filterSlice";
const BudgetSlider = ({budgetRange,setBudget})=>{


    const dispatch      = useDispatch();
    const reset_filter  = useSelector((state)=>state.filter.allFilters.reset_filter)
    const make_search   = useSelector((state)=>state.filter.make_search)
    const appliedBudget = useSelector((state)=>state.filter.budgetRange)


    const [value, setValue]        = React.useState([1000000, 400000]);
    let [selectedStr,setSelectStr] = React.useState('');

    let minVal            = (budgetRange.length) ? (budgetRange[0]) : 1000000;
    let maxVal            = (budgetRange.length) ? (budgetRange[1]) : 15000000;
    let steps             = 100000;
  



    const handleChange = (event, newValue) => {
      setValue(newValue);
    };

    
    React.useEffect(()=>{
        if(budgetRange && selectedStr===''){
          let arr = [minVal, maxVal]
          setValue(arr)
        }
    },[budgetRange])


    

    React.useEffect(()=>{
        if(reset_filter){
          let arr = [minVal, maxVal]
          setValue(arr)
          setSelectStr('')
        }
      },[reset_filter,make_search]);



      
  const updateBudgetFilter = ()=>{
    let priceRangeMin = value[0];
    let priceRangeMax = value[1];
    let selStr     = numFormatter(priceRangeMin,1)+'-'+numFormatter(priceRangeMax,1);
    setSelectStr(selStr)
    let obj = {
      filter: priceRangeMin+','+priceRangeMax,
      type: 'budget'
    }
    setBudget(value);
    // dispatch(selectFilter(obj))
  }

  useEffect(()=>{
    console.log('Here we Are For Filters: ',appliedBudget)
  },[])

    return (
        <>

            <Slider
                getAriaLabel={() => 'Temperature range'}
                value={value}
                onChange={handleChange}
                valueLabelDisplay="on"
                style={{marginTop:'15px'}}
                step={steps}
                min={minVal}
                max={maxVal}
                valueLabelFormat={(num)=>numFormatter(num,1)}
                onChangeCommitted={updateBudgetFilter}
            />

            <p style={{ fontSize: '13px',lineHeight:'1' }}>
                <span>
                Min
                <b> {numFormatter(minVal,1)} </b>
                </span>
                <span> to </span>
                <span>Max
                <b> {numFormatter(maxVal,2)} </b>
                </span>
            </p>
        
        </>
    )
}
export default BudgetSlider;