import { useDispatch, useSelector } from "react-redux";
import React, { useState, useEffect } from "react"
import { set_Sort_modal } from '../../../../redux/slices/MobileSignUpModalSlice';
import { selectFilter } from '../../../../redux/slices/filterSlice';


const Sort_modal = () => {
    const dispatch = useDispatch();
    const openSortModal = useSelector((state) => state.MobileSignUpModal.openSortModal)
    const [sortVal,setSortVal] = useState('');
    const CloseModal = () => {
        dispatch(set_Sort_modal(false));
    }

    const applySort = (val)=>{

      let obj = {
        type: "oder_by",
        filter: val
      }
      dispatch(selectFilter(obj))    
      setSortVal(val);
      dispatch(set_Sort_modal(false));
    }
    

  return (
    <>
    
          <div className="bottomFotter" style={{ height: openSortModal ? "35%" : "0" }}>
              <span className="mod-close" onClick={CloseModal} aria-hidden="true" >
                  <i className="ti-close" />
              </span>
     
        <div className="mt-5" id="sorting-box">
              <h4 className="ml-3">Sorting</h4>
              <div className="row" >

          <div className="col-12 mt-2">
            <div className="container">

            <ul className="ks-cboxtags">
              <li >
                <label onClick={()=>applySort('')} htmlFor={`top_projects`} className={`${sortVal===''?'checked':''}`} >
                  <input type="radio" name="short_input" id={"top_projects"} value={''} checked   />
                  Top Projects
                </label>
              </li>

              <li >
              <label onClick={()=>applySort('ASC')} htmlFor="low_to_heig" className={`${sortVal==='ASC'?'checked':''}`}>
                  <input type="radio" name="short_input" id={"low_to_heig"} value={'ASC'}   />
                  Low To High
              </label>
              </li>

              <li >
              <label onClick={()=>applySort('DESC')} htmlFor="high_to_low" className={`${sortVal==='DESC'?'checked':''}`} >
                  <input type="radio" name="short_input" id={"high_to_low"} value={'DESC'}  />
                  High To Low
                  </label>
              </li>
            </ul>

              

              </div>
            </div>
          </div>
        </div> 
          </div>
    </>
  )
}

export default Sort_modal