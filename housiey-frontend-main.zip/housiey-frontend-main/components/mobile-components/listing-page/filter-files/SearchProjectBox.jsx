import React,{useState,useEffect}       from 'react';
import Autocomplete                     from '@mui/material/Autocomplete';
import TextField                        from '@mui/material/TextField';
import Stack                            from '@mui/material/Stack';
import {slugGenrator,GenrateSearchURL}  from '../../../../utils/BasicFn';

import { makeStyles }                   from "@material-ui/core/styles";
import { useRouter }                    from 'next/router';
import { useDispatch, useSelector }     from "react-redux";
import { getFilters,set_min_max_budget,selectFilter,getCities,applyFilters } from "../../../../redux/slices/filterSlice";

const useStyles = makeStyles({
    paper: {
      border: "0px solid black",
      borderRadius: "0px !important",
      marginTop: "11px"
    }
  });
  
  

const SearchProjectBox = ({search_query,page_type,details})=>{


    // console.log('Here wew are ',{search_query,page_type,details})
    
  const [query, setQuery]                  = useState([]);
  const [mykeyword, setMykeyword]          = useState('');

  const dispatch          = useDispatch();
  const router            = useRouter();
  const ResetFilter       = useSelector((state)=>state.filter.allFilters.reset_filter)
  const classes           = useStyles();


    const myvalue = (e)=>{
        setMykeyword(e)
        let cityLocalData  =  JSON.parse(localStorage.getItem('houseiy_location'));
        let selectedCity   =  cityLocalData.city_id;
        let key = e;
        if (key){
          fetch(process.env.BASE_URL + `search/${selectedCity}/${key}`).then(result => {
            result.json().then((response) => {
              let opt_arr = [];
              if (response.builders.length > 0) {
                for (let b_i = 0; b_i < response.builders.length; b_i++) {
                  let title  = <>{response.builders[b_i].builder_name} <span className="side-title" > Builder</span></>
                  let b_slug = slugGenrator(response.builders[b_i].builder_name)
                  let b_obj  = {
                    title:         title,
                    option_title:  response.builders[b_i].builder_name,
                    id:            b_slug,
                    type:          "builders"
                  }
                  opt_arr.push(b_obj)
                }
              }
              if (response.locality.length > 0) {
                for (let l_i = 0; l_i < response.locality.length; l_i++) {
                  let title  = <>{response.locality[l_i].name} <span className="side-title" > Locality</span></>
                  let b_slug = slugGenrator(response.locality[l_i].name)
                  let l_obj = {
                    title: title,
                    option_title: response.locality[l_i].name,
                    id: b_slug,
                    type: "locality"
                  }
                  opt_arr.push(l_obj)
                }
   
              }
              if (response.projects.length > 0) {
                for (let p_i = 0; p_i < response.projects.length; p_i++) {
                  let title         = <>{response.projects[p_i].project_name} <span className="side-title" > Project</span></>
                  let locality_clug = slugGenrator(response.projects[p_i].locality);
                  let project_id    = locality_clug+'/'+response.projects[p_i].slug;
                  let p_obj = {
                    title: title,
                    option_title: response.projects[p_i].project_name,
                    id: project_id,
                    type: "projects"
                  }
                  opt_arr.push(p_obj)
                }
              }
              else {
                
              }
              setQuery(opt_arr)
            })
          })
       }else{
          setQuery([])
       }
        
   
   }
   

   const findcat = (e,value)=>{
    console.log("Hello : ",value)
    if(value===null){ }
    else{
      setMykeyword(value.option_title)
      sendUrl(value)
    }
  }
 

  
  const sendUrl = async (value)=>{
    let   url        = '';
    let reset_filter = {
      type:         'reset_filter',
      filter:       0,
      make_search:  0,
    }
    dispatch(selectFilter(reset_filter));
    url = GenrateSearchURL(value,query)
    await router.push('/'+url);
  }


  useEffect(()=>{
    const {query}  = router;
    if(details)
      {
      let mainSearchText     = details.replaceAll('-'," ");
      if(page_type!=='under_projects' && page_type!=='listing'){
          setMykeyword(mainSearchText)
        }
      }
  },[])

  

 


    return (
        <>
            
            <Stack   sx={{ width: '100%',padding:'0px 10px' }}  >

              <Autocomplete
                options={query}
                freeSolo={true}
                inputValue={(mykeyword)?mykeyword:''}
                onChange={findcat}
                getOptionLabel={(option) => option.option_title}
                classes={{ paper: classes.paper }}
                renderOption={(props, option) => ( <div className='option-list'  {...props} > {option.title} </div> )}
                renderInput={(params) => (
                  <>
                  <TextField
                    {...params}  
                    id="main-search-box-input"
                    variant="standard"  
                    className="form-control mobile-search_input b-0 main-search-box-input"
                    placeholder='Search  Project, locality or builder'
                    name="project_slug"
                    onChange={(e)=>{
                      myvalue(e.target.value)}}
                    />
                  </>
                )}
                
              />
              </Stack>

        </>
    )
}
export default SearchProjectBox;