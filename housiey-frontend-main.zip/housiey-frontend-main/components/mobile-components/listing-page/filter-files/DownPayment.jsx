import React from 'react';
import Slider   from '@mui/material/Slider';

import {useDispatch,useSelector} from 'react-redux';
import { selectFilter } from "../../../../redux/slices/filterSlice";
import { numFormatter } from '../../../../utils/BasicFn';


const DownPayment = ({setDownPayment})=>{

    const dispatch                = useDispatch();
    const downPaymentValue        = useSelector((state)=>state.filter.allFilters.downPayment) 
    const reset_filter            = useSelector((state)=>state.filter.allFilters.reset_filter)
    const make_search             = useSelector((state)=>state.filter.make_search)

    const [anchorEl, setAnchorEl] = React.useState(null);
    const [open,setOpen]          = React.useState(Boolean(anchorEl));
    const [value, setValue]       = React.useState(downPaymentValue);


    let vArr = [200000,5000000];


         
const sty = {
    background: '#fff',
    color: '#234e70',
    fontSize:' 14px',
    color: '#234e70',
    fontWeight:'400',
    borderRadius:' 25px',
    height:' 40px',
} 

  const updateBudgetFilter = (e,newValue) => {
    // let obj = {
    //   type:   'downpayment',
    //   filter: newValue
    // }
    // console.log(obj);
    // dispatch(selectFilter(obj))
    setDownPayment(newValue)
  }

    const handleChange = (event, newValue) => {
      setValue(newValue);
    };



    React.useEffect(()=>{
      // if(reset_filter){
        setValue(0)
      // }
    },[reset_filter,make_search]);



    return (
        <>
            <Slider value={value}  min={vArr[0]} max={vArr[1]} aria-label="Default" valueLabelDisplay="on"   valueLabelFormat={numFormatter} onChange={handleChange}  onChangeCommitted={updateBudgetFilter} />

            <p style={{ fontSize: '13px',lineHeight:'1' }}>
                <span>
                Min
                <b> {numFormatter(vArr[0],1)} </b>
                </span>
                <span> to </span>
                <span>Max
                <b> {numFormatter(vArr[1],2)} </b>
                </span>
            </p>
        </>
    )
}
export default DownPayment;