import { useDispatch, useSelector } from "react-redux";
import React, { useState, useEffect } from "react"

import { set_Filter_modal } from '../../../redux/slices/MobileSignUpModalSlice';
import { set_mobile_filters } from '../../../redux/slices/filterSlice';



// import Box from '@mui/material/Box';
// import FormControl from '@mui/material/FormControl';
// import FormLabel from '@mui/material/FormLabel';
// import Button from '@mui/material/Button';
// import Grid from '@mui/material/Grid';




import Checkbox                 from '@mui/material/Checkbox';
import TextField                from '@mui/material/TextField';
import Autocomplete             from '@mui/material/Autocomplete';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon             from '@mui/icons-material/CheckBox';
import BudgetSlider             from "./filter-files/BudgetSlider";
import DownPayment              from "./filter-files/DownPayment";
import SizeSlider               from "./filter-files/SizeSlider";


const icon          = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon   = <CheckBoxIcon fontSize="small" />;

const AllFilters = () => {


    const [flatTypeFIlter,SetFlatTypeFIlter]     = useState([]);
    const [budgeFilterData,setBudgeFilterData]   = useState([]);
    const [posessionData,setPosessionData]       = useState([]);
    const [schemeFilterData,setSchemeFilterData] = useState([]);
    const [sizesFiltrData,setSizesFiltrData]     = useState([]);
  

    
    const [selectSize,setSelectSize]                    = React.useState([]);
    const [selectSchemeFilter,setSelectSchemeFilter]    = React.useState();
    const [selectPosession,setSelectPosession]          = React.useState();
    const [selectFlatType,setSelectFlatType]            = React.useState([]);
    const [selectDownPayment,setSelectDownPayment]      = React.useState([]);
    const [selectBudget,setSelectBudget]                = React.useState([]);
    const [isOffer,setIsOffer]                          = React.useState(0);




    const dispatch = useDispatch();
    const openFilterModal = useSelector((state) => state.MobileSignUpModal.openFilterModal)

    const CloseModal = () => {
        dispatch(set_Filter_modal(false));
    }

    const handleChangeFlatType  = (event,value)=>{
        console.log('here we ',value)
    }

    const fetchFilter = async()=>{
        let defaultCities = localStorage.getItem('houseiy_location');
        if(defaultCities){
          defaultCities   = JSON.parse(defaultCities);
        }else{
          let fetchCity    =  await fetch(process.env.BASE_URL+'get-default-city');
          if(fetchCity.ok){
            let cityresult =  await fetchCity.json(); 
            defaultCities  =  cityresult.data[0];
          }
        }
        let response       = await fetch(process.env.BASE_URL+'get-filters?city_id='+defaultCities.city_id);
        if(response.ok){
            let filterResult = await response.json();
            if(filterResult.res===true){
              let max_min_range_data = filterResult.min_max_details[0];

                // console.log(filterResult)
              SetFlatTypeFIlter(filterResult.configs);
              setBudgeFilterData([max_min_range_data.min_price,max_min_range_data.max_price]);
              setPosessionData(filterResult.possession_types);
              setSchemeFilterData(filterResult.schemes);

/*               if(filterResult.schemes){
                let schemeArr = [];
                filterResult.schemes.forEach(element => {
                  let obj = {id:  element.id,scheme: element.scheme,checked:0}
                  schemeArr.push(obj)
                }); 
                setSchemeFilterData(schemeArr);
              } */
              setSizesFiltrData([max_min_range_data.min_area,max_min_range_data.max_area]);
            }
          }
        
    }


    useEffect(()=>{
        fetchFilter();
    },[])

    const applyFilter = ()=>{
        try{


            
            let flatId='';
            if(selectFlatType){
                selectFlatType.map(({id})=>{
                    flatId += id+',';
                })
                flatId = flatId.slice(0, -1);
            }


        let posessionId='';
        if(selectPosession){
            selectPosession.map(({sno})=>{
                posessionId += sno+',';
            })
            posessionId = posessionId.slice(0, -1);
        }

        let schemsID='';
        if(selectSchemeFilter){
            selectSchemeFilter.map((item)=>{
                    schemsID += item.id+',';
            })
            schemsID = schemsID.slice(0, -1);
        }
        

        // console.log({
            //     selectSize,
        //     selectSchemeFilter,
        //     selectPosession,
        //     flatId,
        //     posessionId,
        //     schemsID,
        //     selectFlatType,
        //     selectDownPayment,
        //     selectBudget,
        //     isOffer
        // })

        const cityData  = JSON.parse(localStorage.getItem('houseiy_location'));
        let filterObj = {
            start              : 1,
            city_id            : cityData.city_id,
            downPayment        : selectDownPayment,
            budgetRange        : (selectBudget.length)?selectBudget[0]+','+selectBudget[1]:'',
            selectedSizeRange  : (selectSize.length)?selectSize[0]+','+selectSize[1]:'',
            posession          : posessionId,
            flatName           : flatId,
            schames            : schemsID,
            offers             : isOffer,
        }
        dispatch(set_mobile_filters(filterObj));
        CloseModal();
        
    }catch(err){
        console.log('have error in erro: ',err)
    }



    }



    const resetFilters =  ()=>{
        let reset_filter = {
            start             : 1,
            city_id           :'',
            posession         :'',
            downPayment       :'',
            budgetRange       :'',
            flatName          :'',
            selectedSizeRange :'',
            schames           :'',
            offers            :'',
        }
        dispatch(set_mobile_filters(reset_filter));
        CloseModal();
    }   
    const [isShowBtnns,setIsShowBtnns] = React.useState(true);
    const onFocusInput = ()=>{
        console.log('check here')

    }
    

    return (
        <>

            <div className={` ${openFilterModal?'open-modal':''} `} style={{ height:   "100%",    overflowX: 'auto' }}>

                <span className="mod-close" onClick={CloseModal} aria-hidden="true" >
                    <i className="ti-close" />
                </span>
                <h5 className="filter-title">Filters</h5>


                <div className="pl-4 pr-4 filert-modal-cotent " >

                        <div className="flat-type" >
                            <Autocomplete
                                multiple
                                freeSolo
                                id="checkboxes-tags-demo-flat-type"
                                options={flatTypeFIlter}
                                limitTags={1}
                                onChange={(e,value)=>setSelectFlatType(value)}
                                getOptionLabel={(option) => option.name}
                                renderOption={(props, option, { selected }) => (
                                    <li {...props}>
                                        <Checkbox
                                            icon={icon}
                                            checkedIcon={checkedIcon}
                                            style={{ marginRight: 8 }}
                                            checked={selected}
                                        />
                                        {option.name}
                                    </li>
                                )}
                                renderInput={(params) => (
                                    <TextField {...params} label="BHK" placeholder="Select BHK" />
                                    )}
                                />
                        </div>
                        <hr/>
                        <label htmlFor="" className="m-0" style={{paddingBottom: '20px'}} >Budget</label>
                        <div className="bidget-slider">
                            
                          <BudgetSlider budgetRange={budgeFilterData} setBudget={setSelectBudget}/>
                        </div>
                        <hr/>
                        <label htmlFor="" className="m-0" style={{paddingBottom: '35px'}}>Down Payment</label>
                        <div className="down-payment">
                            
                            <DownPayment setDownPayment={setSelectDownPayment} />
                        </div>
                        <hr/>
                        <div className="posession-filter">

                        <Autocomplete
                            multiple
                            freeSolo
                            id="checkboxes-tags-demo-posession"
                            options={posessionData}
                            onChange={(e,val)=>setSelectPosession(val)}
                            limitTags={1}
                            getOptionLabel={(option) => option.name}
                            renderOption={(props, option, { selected }) => (
                                <li {...props}>
                                    <Checkbox
                                        icon={icon}
                                        checkedIcon={checkedIcon}
                                        style={{ marginRight: 8 }}
                                        checked={selected}
                                    />
                                    {option.name}
                                </li>
                            )}
                            renderInput={(params) => (
                                <TextField {...params} label="Posession" placeholder="Select Posession" />
                            )}
                            />

                        </div>
                        <hr/>
                        <label htmlFor="" className="m-0" style={{paddingBottom: '20px'}}>Carpet Area</label>
                        <div className="size-filter">
                            
                            <SizeSlider selectSize={selectSize}  setSelectSize={setSelectSize}  sizeData={sizesFiltrData} />
                        </div>
                        <hr/>
                        <div className="schems-filters">

                        <Autocomplete
                            multiple
                            freeSolo
                            id="checkboxes-tags-demo-schems"
                            options={schemeFilterData}
                            
                            onChange={(e,val)=>setSelectSchemeFilter(val)}
                            limitTags={1}
                            getOptionLabel={(option) => option.scheme}
                            renderOption={(props, option, { selected }) => (
                                <li {...props}>
                                    <Checkbox
                                        icon={icon}
                                        checkedIcon={checkedIcon}
                                        style={{ marginRight: 8 }}
                                        checked={selected}
                                    />
                                    {option.scheme}
                                </li>
                            )}
                            renderInput={(params) => (
                                <TextField {...params} label="Scheme" placeholder="Scheme"
                                
                                onFocus={()=> setIsShowBtnns(false)}
                                onBlur={()=> setIsShowBtnns(true)}
                            
                                />
                            )}
                            />
                        </div>

                        {isShowBtnns ? <>
                            <div className="footer-btns mt-4" >
                                <button className="btn  btn-secondary w-50 reset-filters" onClick={resetFilters}  >
                                    Reset Filters
                                </button>
                                <button className="btn w-50 apply-filters" style={{ background:'#234e70',border:'none' }}  onClick={applyFilter} >
                                    Apply Filters    
                                </button>
                            </div>
                        </>  : <></>}
                </div>
            </div>

           
        </>
        
    )
    
}


export default AllFilters

