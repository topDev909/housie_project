import  React,{useState,useEffect}  from 'react';
import { useDispatch, useSelector } from "react-redux";
import { set_sign_up_modal, set_ola_modal_tab, set_sign_up_next_step, set_mobile_number, set_step1_modal } from '../../../redux/slices/MobileSignUpModalSlice';
import { set_sent_otp } from '../../../redux/slices/signUpModalSlice';
// import { selectFilter,applyFilters,set_filters } from "../../redux/slices/filterSlice";
import { select_project } from "../../../redux/slices/projectsSlice";
import { selectFilter,increase_paginate } from "../../../redux/slices/filterSlice";

import { set_active_tab } from "../../../redux/slices/signUpModalSlice";
import ConfigList              from '../../Listing/filterBtns/ConfigList'; 
import WhatsAppBtn             from '../../Listing/filterBtns/WhatsAppBtn';
import { parseJwt, numFormatter, slugGenrator } from '../../../utils/BasicFn';
import BuilderName             from '../../Listing/filterBtns/BuilderName';
import Link                    from 'next/link';
import { useRouter }           from 'next/router';
import SitevisitMobile         from '../home-page/Sitevisit_mobile';
import Signupperks_mobile      from '../home-page/Signupperks_listing_mobile'
import Online_presentation_mobile from '../home-page/Online_presentation_mobile';
import BreadCums from './BreadCums';
import { Scrollbar } from "react-scrollbars-custom";




import Skeleton,{SkeletonTheme} from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'

const Listing_card = ({search_query,page_type,details})=>{
    const router                          = useRouter();
    const dispatch                        = useDispatch();
  const [filterdData,setFilterdData]      = useState([]);
  // const sessionData                    = getUserSession();
  const [sessionData,setSessionData]      = useState(false);
  const allFilters                        = useSelector((state)=>state.filter.allFilters)
  let startVal                            = useSelector((state)=>state.filter.allFilters.start);
  const is_search_active                  = useSelector((state)=>state.filter.make_search);
  
  const [showResults,setShowResult]       = useState(0);
  const [isProjectLoad,setIsProjectLoad]  = useState(true);
  const [locationName,setLocationName]    = useState('');
  const [locationDesc,setLocationDesc]    = useState('');
  const [totalNum,setTotalNum]            = useState(0);
  const [builderInfo,setBuilderInfo]      = useState('');
  const [cityData, setCityData]           = useState("");

  const [currentPage,setCurrentPage]        = useState(1);
  const [projectPerPage,setProjectPerPage]  = useState(10);
  const [allProjects,setAllProjects]        = useState([]);
  

    const FetchAllProjects = async (keywords)=>{

      setIsProjectLoad(true);
      
      let defaultCities   = localStorage.getItem('houseiy_location');
      if(defaultCities){
        defaultCities =  JSON.parse(defaultCities)
      }else{
        let fetcheCity       = await fetch(process.env.BASE_URL+'get-default-city');
        if(fetcheCity.ok){
          let cityFetchData  = await fetcheCity.json();
          defaultCities      = cityFetchData.data[0];
          localStorage.setItem('houseiy_location',JSON.stringify(cityFetchData.data[0]))
        }
      }

      setCityData(defaultCities);
      let configs          = (keywords.flatName)          ? keywords.flatName:'';
      let city_id          = (keywords.city_id)           ? keywords.city_id:defaultCities.city_id;     
      let locality_id      = (keywords.locality_id)       ? keywords.locality_id:'';     
      let builder_id       = (keywords.builder_id)        ? keywords.builder_id:'';     
      let scheme_id        = (keywords.schames)           ? keywords.schames:'';     
      let budget           = (keywords.budgetRange)       ? keywords.budgetRange:'';     
      let downPayment      = (keywords.downPayment)       ? keywords.downPayment:'';    
      let possession_type  = (keywords.posession)         ? keywords.posession:'';
      let offers           = (keywords.offers)            ? keywords.offers:'';
      let sizeRange        = (keywords.selectedSizeRange) ? keywords.selectedSizeRange:'';
      let order_by_price   = (keywords.order_by_price)    ? keywords.order_by_price:'';
      let start            = keywords.start;
      

      
      if(!city_id){ return;}
      if(page_type==='locality'){
          if(!locality_id){
            return;
          }
      }else{
        locality_id = '';
      }

      if(page_type==='builder'){
          if(!builder_id){
            return;
          }
      }else{
        builder_id = '';
      }
      
      let query = `?config=${configs}&city_id=${city_id}&locality_id=${locality_id}&builder_id=${builder_id}&scheme_id=${scheme_id}&budget=${budget}&downPayment=${downPayment}&possession_type=${possession_type}&offer=${offers}&size=${sizeRange}&start=${start}&order_by_price=${order_by_price}`;
  
      const res                 = await fetch(`${process.env.BASE_URL}listing`+query);
      if(res.ok){
        const filter_result     = await res.json();
        let result_projects     = filter_result.projects;

        const indexOFLastPost   =  currentPage * projectPerPage;
        const indexOFFirstPost  =  indexOFLastPost - projectPerPage;
        const currentProjects   =  result_projects.slice(indexOFFirstPost,indexOFLastPost)

        setFilterdData(currentProjects)
        setAllProjects(result_projects)
        setShowResult(filter_result.projects.length)

        let locationInfoArr      = filter_result.location_details;
        let builderDetails       = filter_result.builder_details;
        
        setBuilderInfo(builderDetails);
        setTotalNum(filter_result.ToalProjects);

        if(page_type==='builder' && builderDetails.length>0){
          setLocationName(builderDetails[0].builder_name)
          setLocationDesc(builderDetails[0].description)
        }
        if(locationInfoArr.length > 0 && page_type!=='builder'){
          setLocationName(locationInfoArr[0].name)
          setLocationDesc(locationInfoArr[0].description)
        }

      }else{

      }
        setIsProjectLoad(false);
    }

    useEffect(()=>{

      // FetchAllProjects(allFilters);

      let again_start = 1;
      if(is_search_active){
        setFilterdData([]);
        dispatch(increase_paginate(again_start))
        FetchAllProjects(allFilters);
      }


    // eslint-disable-next-line react-hooks/exhaustive-deps
    },[allFilters])



  const openmodal = async (value) => {




    let arr = [];
      let obj = {
        project_name: value.project_name,
        slug: value.slug,
        id: value.id
      }
      arr.push(obj);
      
      dispatch(select_project(arr));
      dispatch(set_ola_modal_tab(true));
      dispatch(set_active_tab('1'))
      dispatch(set_step1_modal(true))


    // if (localStorage.getItem('housey_token')) {
    //   // console.log('gead')

    //   dispatch(set_ola_modal_tab(true))
    //   dispatch(set_step1_modal(true))


    // } else {
    //   localStorage.setItem('modal_type', 'ola_modal')

    //   dispatch(set_sign_up_modal(true));
    //   dispatch(set_sent_otp(false));
    // }
  }

  const loadMoreFn = ()=>{
    setIsProjectLoad(true);
    startVal                =  parseInt(startVal) + 1;
    const indexOFLastPost   =  startVal * projectPerPage;
    const indexOFFirstPost  =  indexOFLastPost - projectPerPage;
    const currentProjects   =  allProjects.slice(indexOFFirstPost,indexOFLastPost);
    setFilterdData((state) => [...state, ...currentProjects])
    dispatch(increase_paginate(startVal));
    setTimeout(() => {
      setIsProjectLoad(false);
    }, 1000);
}
  
 

  const PropertyListing = () => {
    let count_steps = 0;
    return (
      <>
        {isProjectLoad === false && filterdData.length !== 0 && filterdData && filterdData.map((item, index) => {

          let city_name = slugGenrator(cityData.name);
          let locality  = slugGenrator(item.location);
          let singleProjectSlug = `/in/${city_name}/${locality}/${item.slug}`;
          let banner;

          if (filterdData.length <= 4 && (index + 1) === filterdData.length) {
            banner = <><div className="row p-0 m-0" > <div className='col-12 p-0'><SitevisitMobile /></div>   <div className='col-12 p-0'><Online_presentation_mobile /></div><div className='col-12 p-0'><Signupperks_mobile /></div></div></>;
          }

          else if ((index + 1) % 2 === 0 && count_steps === 0 ){
            banner      = <Signupperks_mobile />
            count_steps = 1;
          }

          else if ((index + 1) % 2 === 0 && count_steps === 1) {
            banner      = <SitevisitMobile />
            count_steps = 2;
          }

          else if ((index + 1) % 2 === 0 && count_steps === 2) {
            banner = <Online_presentation_mobile />
            count_steps = 0;
          }
          
          let locationName = slugGenrator(item.location);
          let localistyUrl = `/in/${cityData.name}/${locationName}/projects`;
          return (
            <>


                    <BreadCums data={details} />
                         <section className="gray pt-2" style={{paddingBottom: '0px'}}>
                             <div className="container">		
                             <div className="row">
                                 <div className="col-lg-8 col-md-12 col-sm-12">
                                 <div className="row justify-content-center" id="single-listing-card">                                    
                                    <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section">
                                         <div className="property-listing list_view">										
                                             <div className="listing-img-wrapper">
                                             <div className="_exlio_125"><i className="fas fa-street-view" /></div>
                                             <div className="_exlio_126"><i className="far fa-play-circle" /></div>
                                             <div className="_exlio_128" data-toggle="tooltip" data-placement="top" data-original-title="Save property">
                                               <a href="#"><i className="far fa-heart" /></a>
                                             </div>
                                             {item.saving_amt ? <><div className="_exlio_129">Save {numFormatter(item.saving_amt,2)}</div></>:""}
                                             <div className="list-img-slide">
                                                 <div className="click">
                                                 <div>
                                                   <Link href={singleProjectSlug} >
                                                    <a >
                                                      {(item.images!==null)?
                                                        <img src={process.env.BASE_URL+item.images} className="mx-auto"    alt={item.project_name} />
                                                      :
                                                        <img src={'/assets/img/default-img.png'}    className="mx-auto"    alt={item.project_name} />
                                                      }
                                                    </a>
                                                    </Link>
                                                  </div>
                                                 </div>
                                             </div>
                                             </div>
                                             <div className="list_view_flex">
                                             <div className="listing-detail-wrapper mt-1">
                                                 <div className="listing-short-detail-wrap">
                                                 <div className="_card_list_flex mb-2">
                                                     <div className="_card_flex_01">
                                                     <Link href={singleProjectSlug} >
                                                      <h4 className="listing-name verified">
                                                        
                                                        <a href="javascript:void(0)" className="prt-link-detail">{item.project_name}</a>
                                                        
                                                        </h4>
                                                       </Link>
                                                     <p className="builder-name">By <BuilderName builder={item.builder} /> </p>
                                                     <p className="builder-name">
                                                         <span>
                                                             {cityData && 
                                                            <Link href={localistyUrl}>
                                                            <a><i className="fas fa-map-marker-alt" /> {item.location}</a>
                                                            </Link>
                                                            }
                                                        </span>
                                                    </p>
                                                    
                                                    </div>
                                                    <div className="_card_flex_last" style={{textAlign: 'right'}}>
                                                    <h6 className="listing-card-info-price mb-0"><i className="fas fa-rupee-sign" />{item.overall_price_range} <small  className='all-inc'>All In</small> </h6>
                                                    <p className="builder-name"><i className="fas fa-vector-square" /> {item.area_range_min+"-"+item.area_range_max} sqft</p>
                                                    <p className="builder-name" style={{float: 'right'}}><span><i className="far fa-calendar-alt" /> {item.target_possession}</span></p>
                                                    </div>
                                                </div>
                                                
                                                </div>
                                            </div>
                                            {item.configs && <> 
                                            <div className="price-features-wrapper">
                                              <Scrollbar style={{ height: 100 }}>
                                                <ConfigList configList={item.configs} /> 
                                              </Scrollbar> 
                                            </div>
                                            </>}
                                            {item.offer !== '' ? <div className="special-offer">
                                                <span style={{padding: '5px', fontSize: '12px', fontWeight: 600}}><b style={{background: 'rgba(244,197,5,.25)', padding: '2px'}}>OFFER</b> {item.offer}</span>
                                                
                                            </div>
                                             : ""}
                                            <div className="listing-detail-footer">
                                                <a href="javascript:void(0)" className="schedule" onClick={()=>openmodal(item)}>
                                                    <i className="fa fa-desktop" /> | <i className="fa fa-car" /> Tour
                                                </a>
                                                <WhatsAppBtn sellerInfo={item.sellers_info}  projectName={item.project_name} />
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                </div>
                            </div>
                            </div>	
                        </section>


              {banner && <>
                <div>
                  <div>
                    {banner}
                  </div>
                </div>
              </>}
            </>
          )
        })}
      </>
    )
  }

  return (
    <>

      
            {isProjectLoad ? <>
            <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section" >
            <SkeletonTheme baseColor="#c9c9c9" highlightColor="#f3f5f8">
              <Skeleton count={12} height={'300px'} style={{ margin:'1rem 0rem'}} />
            </SkeletonTheme>
            </div>
          </> : <>
          {filterdData.length===0?
          <>
          <div  className="alert alert-warning col-xl-12 col-lg-12 col-md-12 col-sm-12 listing-card-section no-result-found" >
            Sorry No Results Found
          </div>
          </>:""}
          </>} 

          <div id="listing-page">
            <PropertyListing/>
          </div>

          {(isProjectLoad===false && filterdData.length!==0 && filterdData && filterdData.length < totalNum ) && <>
              <div className="load-more-section text-center mt-5" >
                  <button className='load-more-btn' onClick={loadMoreFn} > Load More...</button>
              </div>
          </>}
    </>
  )
}



export default Listing_card;