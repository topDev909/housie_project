import React from 'react';
const BreadCums = ({data})=>{
    return (
        <>

        
        </>
    )
}
export default BreadCums;