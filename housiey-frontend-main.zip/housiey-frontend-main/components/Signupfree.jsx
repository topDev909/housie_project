import React from 'react'
import { useState,useEffect } from 'react'
import Signup from './component/Auth/Signup'
import 'react-phone-number-input/style.css'
import PhoneInput from 'react-phone-number-input'
import { useDispatch, useSelector } from "react-redux";
import { set_modal_state, set_signup_title, set_mobile_number,set_sent_otp} from '../redux/slices/signUpModalSlice';


const Signupfree = () => {
  const dispatch = useDispatch();
  let r_mobile = useSelector((state) => state.signUpModal.mobileNumber)
  const [error,setError]           = useState('');
  
  const validate =()=>{
    if (r_mobile && r_mobile.length >1){
     let title = 'Sign-Up';
     dispatch(set_signup_title(title))
     dispatch(set_sent_otp(true))
     $('#login').modal('show');
     setError('')
    }
  else{
     let error =<><span className='text-danger'>Mobile Number is required for Sign Up</span></>
      setError(error)
      return false;
   }
   
  }

  const getNumberOnchange = (e)=>{
    dispatch(set_mobile_number(e))
  }



  
 
    return (
      <div>
        <section className="call_action_wrap-wrap" id="free-sign-up-section">
          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <div className="call_action_wrap">
                  <div className="call_action_wrap-head">
                    <h3>Sign Up For Free</h3>
                    <div className="row">
                      <div className="col-lg-9 col-md-6 col-sm-12 d-lg-block">
                        <div className="form-group" id="this-is-my-input">
                                <PhoneInput
                                  placeholder="Enter phone number"
                                  countryCallingCodeEditable={false}
                                  defaultCountry="IN"
                                  international
                                  style={{ border: "1px solid #e7eaf1" }}
                                  className="form-control search_input "
                                  value={r_mobile}
                                  onChange={getNumberOnchange}
                                />
                        </div>
                      </div>
                      <div className="col-lg-3 col-md-3 col-md-2 col-sm-12">
                        <div className="form-group none">
                          <button className="btn otp-btn" type='button' onClick={validate}>
                            Sign Up
                          </button>
                        </div>
                        </div> 
                          <b style={{marginLeft:"22px"}}>{error}</b>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    )
}

export default Signupfree
