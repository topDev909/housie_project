/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @next/next/link-passhref */
import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import { useDispatch } from "react-redux";
import { select_project } from "../redux/slices/projectsSlice";
import { set_modal_state, set_ola_modal_tab, set_thank_u_modal, set_active_tab } from '../redux/slices/signUpModalSlice';
import SingleProjectList from './inc/SingleProjectList';


// import { set_active_tab } from "../../../redux/slices/signUpModalSlice";
const New_launch = ({ SendLocationLink, SendBuilderLink }) => {

  const dispatch = useDispatch();
  const [myproject, setMyProjects] = useState([]);
  const [cityData, setCityData] = useState('');

  useEffect(() => {
    const FetchFn = async () => {
      try{

      
      let cityData = JSON.parse(localStorage.getItem('houseiy_location'));
      let cityID = '';
      if (cityData) {
        cityID = cityData.city_id;
        setCityData(cityData);
      } else {
        let fetcheCity = await fetch(process.env.BASE_URL + 'get-default-city');
        if (fetcheCity.ok) {
          let cityFetchData = await fetcheCity.json();
          cityID = cityFetchData.data[0].city_id;
          setCityData(cityFetchData.data[0]);
        }
      }

      if (cityID) {
        const response = await fetch(process.env.BASE_URL + 'top-launches-projects/' + cityID)
        if (response.ok) {
          // console.log
          let result = await response.json();
          if (result.projects) {
            setMyProjects(result.projects)
          }
        }
      }
    }catch(e){
        console.log('Have Error : ',e)
    }
    }

  
    FetchFn();
  }, [])

  // const data = myproject.projects;

  const myModal = (value) => {

    const arr = [];
    let obj = {
      id: value.p_id,
      project_name: value.project_name,
      slug: value.slug
    }
    arr.push(obj);
    dispatch(select_project(arr));
    dispatch(set_ola_modal_tab(true));
    dispatch(set_active_tab('1'))
    $('#olamodal').modal('show');


    /*  if (localStorage.getItem('housey_token')) {
       $('#olamodal').modal('show')
       dispatch(set_thank_u_modal(false))
     }
     else {
       dispatch(set_modal_state(false))
       localStorage.setItem('modal_type', 'ola_modal');
       $('#login').modal('show'); 
     }
     */
  }

  return (
    <div>
      <section className="min light-bg">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-7 col-md-8">
              <div className="sec-heading center">
                <h2>Top New Launches in {cityData && cityData.name}</h2>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-12 col-md-12 col-sm-12">
              <div className="">
                {/* Single Item */}
                <div className="single_items">
                  <div className="row">

                    {/* Single Property */}

                    {myproject && myproject.map((item) =>
                      <>
                        <SingleProjectList item={item} myModal={myModal} SendLocationLink={SendLocationLink} SendBuilderLink={SendBuilderLink} cityName={cityData.name} />
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* <Top_lauches_modal mygetdata={selectProject} /> */}
    </div>
  )
}







export default New_launch
