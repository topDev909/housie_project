
import React,{useEffect} from 'react';
import {useRouter}       from 'next/router';
import {set_page_type}   from '../redux/slices/signUpModalSlice';
import { useDispatch }   from 'react-redux';

const Layout = ({children}) => {
  

  const router   = useRouter();
  const dispatch = useDispatch();


// {"city_id":14,"name":"Pune","default_city":1}

const FetchDefaultCity =  async ()=>{
  let location = localStorage.getItem('houseiy_location');
  if(!location){
    let fetcheCity       = await fetch(process.env.BASE_URL+'get-default-city');
    if(fetcheCity.ok){
      let cityFetchData  = await fetcheCity.json();
      let cityJson = {"city_id":cityFetchData.data[0].city_id,"name":cityFetchData.data[0].name,"default_city":1};
      localStorage.setItem('houseiy_location',JSON.stringify(cityJson))
    }
  }
}
  useEffect(()=>{
    let pathName  = router.pathname;
    let query     = router.query;
    let isBuilder = pathName.indexOf("builders") 
    let isListing = pathName.indexOf("in");

    let srchLenght =  query?.search?.length;
    // console.log((isBuilder,isListing))

      if(srchLenght===3 && query.search[srchLenght-1]!=='projetcs'){

      }else if(isBuilder !== -1 || isListing !== -1){
        let obj = {
          page_type: 'listing',
          project_id: 0
        }
        dispatch(set_page_type(obj))
      }else{
        let obj = {
          page_type: 'home',
          project_id: 0
        }
        dispatch(set_page_type(obj))
      }

      FetchDefaultCity();
  },[router])


  return( <>

      <main className='content-wrrapper'>
          {children}
      </main>
       </>
  )
};

export default Layout;
