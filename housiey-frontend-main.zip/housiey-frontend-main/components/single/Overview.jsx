/* eslint-disable react/jsx-no-target-blank */
/* eslint-disable react/no-unescaped-entities */


import React,{ useState,useEffect } from 'react'; 
import { useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { Markup } from 'interweave';
import {set_download_file,set_signup_title,set_first_time_login} from '../../redux/slices/signUpModalSlice';

import LongDescription from '../component/common/LongDescription';

// import { saveAs } from "file-saver";
    const Overview = ({ setproject, setbrocher,rera_details})=>{
    const dispatch                          = useDispatch();
    const router                            = useRouter();
    // const [project, setProject]             = useState(setproject)
    const project                           = setproject;
    const [userSession, setUserSession]     = useState('');
 
  
    const Brochuredata = async (link)=>{
        $('#login').modal('show')
        let obj = {
            file: link,
            status: true,
            name: 'brochure'
        }
        let title = 'Brochure';
        dispatch(set_signup_title(title));
        dispatch(set_download_file(obj));
        dispatch(set_first_time_login(true));
    }

    const downloadBrocher = async (link)=>{
        const token  = localStorage.getItem('housey_token');
        if(token){
            let url = `/api/download?link=`+link+`&name=brochure`;
            await router.push(url);
            let sendEnq = process.env.BASE_URL+`/download-doc/${project[0].id}`;
            let req     = await fetch(sendEnq,{
                headers: {
                    auth: token,
                    source: "brochure"
                }
            });


            let title = 'Brochure';
            dispatch(set_signup_title(title));
            $('#DownloadThankYou').modal('show');
        }else{
            $('#download-content-modal').modal('show')
            let obj = {
                file: link,
                status: true,
                name: 'brochure'
            }
            let title = 'Brochure';
            dispatch(set_signup_title(title));
            dispatch(set_download_file(obj));
            dispatch(set_first_time_login(true));
        }
    }

    useEffect(() => {
        let jwt_get_data = localStorage.getItem('housey_token')
        setUserSession(jwt_get_data);
    }, [])

    // const DownloadBroucher = async ()=>{
    //     let res = await fetch(`/api/downloadBrocher?link=${setbrocher}`);
    //     if(res.ok){
    //         let data = await res.json();
    //         console.log(data)
    //     }
    // }
  
    return(
        <>    
            

            <div className="_prtis_list mb-4">
                <div className="_prtis_list_header min" style={{padding: "0.5rem 1.5rem 1.2em", background: "#234e70"}}>
                    <h4 className="m-0" style={{color: "#fff"}}>
                        Overview &amp; <span className="">Description</span>
                        <button
                            onClick={()=>downloadBrocher(setbrocher)}
                            className="btn download-btn"    
                        >
                            <i className="fa fa-download fa-bounce" style={{ fontSize: 12, marginRight: 2 }} />
                            Brochure
                        </button> 
                    </h4>

                </div>

                <div className="_prtis_list_header">
                    {project && project.map((data) => {
                            return (
                                <>
                                    <ul>
                                        <li className='content-text'>
                                            <div className="content ">
                                                <span className='dark '>{data.land_parcel}</span>
                                                <span className="title" style={{color: "#234e70"}}>Land Parcel</span>
                                            </div>
                                        </li>

                                        <li className='content-text'>
                                            <div className="content">
                                                <span className="dark">{data.no_of_towers}</span>
                                                <span className="title" style={{color: "#234e70"}}>Towers</span>
                                            </div>
                                        </li>
                                        <li className='content-text'>
                                            {data.no_of_floors ? <>
                                                <div className="content">
                                                    <span className="dark">{data.no_of_floors}</span>
                                                    <span className="title" style={{color: "#234e70"}}>Floors</span>
                                                </div>
                                            </> : ''}
                                        </li>
                                        <li className='content-text'>
                                            {data.config ? <>
                                                <div className="content ">
                                                    <span className="dark">{data.config}</span>
                                                    <span className="title" style={{color: "#234e70"}}>Config</span>

                                                </div>
                                            </> : ''}
                                        </li>
                                    </ul>
                                    <ul style={{ paddingTop: 15 }}>
                                        <li className='content-text'>
                                            {data.area_range_max ? <>
                                                <div className="content">
                                                    <span className="dark">{data.area_range_min}-{data.area_range_max}Sq.ft</span>
                                                    <span className="title" style={{color: "#234e70"}}>Carpet Area</span>
                                                </div>
                                            </> : ''}
                                        </li>
                                        <li className='content-text'>
                                            <div className="content">
                                                {rera_details && rera_details.map((single_rera)=>(
                                                    <>
                                                    <span className="dark">
                                                        <a href={single_rera.rera_link} target={"_blank"} style={{color:"blue"}}>{single_rera.rera_no}</a>
                                                    </span>
                                                    </>
                                                ))}
                                                
                                                <span className="title" style={{color: "#234e70"}}>RERA No.</span>
                                            </div>
                                        </li>
                                        <li className='content-text'>
                                            {data.target_possession ? <>
                                                <div className="content">
                                                    <span className="dark">{data.target_possession}</span>
                                                    <span className="title" style={{color: "#234e70"}}>Target Possession</span>
                                                </div>
                                            </> : ''}
                                        </li>
                                        <li id ='content-text'>
                                            {data.rera_possession ? <>
                                                <div className="content">
                                                    <span className="dark">{data.rera_possession}</span>
                                                    <span className="title" style={{color: "#234e70"}}>RERA Possession</span>
                                                </div>
                                            </> : ''}
                                        </li>
                                    </ul>

                                </>
                            )
                        })
                    }

                </div>
                {project.map((name) =>
                    <>
                        <div className="_prtis_list_body" style={{color: "#000"}}>
                            <h5>About {name.project_name} </h5>
                            {/* <Markup  content={name.about} */}
                            <LongDescription content= {name.about}  wordlength={250} style={{paddingLeft: "10px"}}/>
                        </div>
                    </>
                )}
            </div>
      

        </>
    )
}
export default Overview;