/* eslint-disable @next/next/no-css-tags */
import React, { useEffect } from 'react'
import { useState } from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
import { Carousel } from 'react-responsive-carousel';
import ImageGallery from 'react-image-gallery';
import { set_download_file, set_signup_title, set_first_time_login } from '../../redux/slices/signUpModalSlice';
import { useDispatch,useSelector } from 'react-redux';
import { useRouter } from 'next/router';


import Lightbox from 'react-image-lightbox';
import "react-image-lightbox/style.css";





const Masterplan = ({ setfloor_plan, setmaster_plan, plan_kit }) => {

    // const [floor, setFloor]                         = useState(setfloor_plan);
    // const [master, setMaster]                       = useState(setmaster_plan);



    const page_type          = useSelector((state)=>state.signUpModal.page_type)
    const enq_project_id     = useSelector((state)=>state.signUpModal.enq_project_id)


    const floor                         = setfloor_plan;
    const master                        = setmaster_plan;

    

    
    const [masterPlaneSlider,setMasterPlaneSlider]  = useState([]);
    const [flourPlanSlider,setFlourPlanSlider]      = useState([]);

    const [isOpen,setIsOpen]                        = useState(false)
    const [PhoneIndex,setPhotoIndex]                = useState(0);

    const [lightBoxImage,setLightBoxImage]          = useState();

    const dispatch                                  = useDispatch();
    const router = useRouter();

    useEffect(()=>{
        const arr1 = [];
        setfloor_plan.map((singleFlImg)=>{
            let obj = {
                original: process.env.BASE_URL + singleFlImg.img
            }
            arr1.push(obj)
        })
        setFlourPlanSlider(arr1)

        const arr2 = [];
        setmaster_plan.map((singleFlImg)=>{
            let obj = {
                original: process.env.BASE_URL + singleFlImg.img
            }
            arr2.push(obj)
        })
        setMasterPlaneSlider(arr2)

    },[setfloor_plan,setmaster_plan])


    const [sliderImage, setSliderImage] = useState([]);


    const masterfloor = (image) => {

        let img = [];
        let lightBoxArr = [];
        image.forEach(element => {
            let obj = {
                original: process.env.BASE_URL + element.img
            }
            img.push(obj)
            lightBoxArr.push(process.env.BASE_URL+element.img)
        });
        setLightBoxImage(lightBoxArr)
        setIsOpen(true)
        setSliderImage(img);
    }



    const donwloadFile = async () => {
        let link = `/api/download?link=${plan_kit}&name=plan_kit`;
        let title = 'Plan Kit';
        dispatch(set_signup_title(title));
        let token = localStorage.getItem('housey_token');
        if (localStorage.getItem('housey_token')) {
            await router.push(link);
            let sendEnq = process.env.BASE_URL+`download-doc/${enq_project_id}`;
            let req     = await fetch(sendEnq,{
                headers: {
                    auth: token,
                    source: "plan kit"
                }
            });
            $('#DownloadThankYou').modal('show');
        } else {
            $('#download-content-modal').modal('show')
            let obj = {
                file: plan_kit,
                status: true,
                name: 'plan_kit'
            }

            dispatch(set_download_file(obj));
        }
    }
    return (
        <>
           

            <section className="_prtis_list mb-4" id="master-flour-plan" >
                <div className="_prtis_list_header min"  style={{padding: '0.5rem 1.5rem 1.4em'}}>
                    <h4 className="m-0">Master &amp; Floor Plan

                        <button onClick={donwloadFile} className="btn download-btn" >
                            <i className="fa fa-download fa-bounce" style={{ fontSize: 12, marginRight: 2 }} />Plan Kit
                        </button>
                    </h4>
                </div>
                <div className="_prtis_list_body">

                    <ul className="nav nav-tabs floor_plans" id="myTab" role="tablist">

                        <li className="nav-item">
                            <a className="nav-link active" id="1bed-tab" data-toggle="tab" href="#1bed" role="tab" aria-controls="1bed" aria-selected="false">Master Plan</a>
                        </li>

                        <li className="nav-item">
                            <a className="nav-link" id="2bed-tab" data-toggle="tab" href="#2bed" role="tab" aria-controls="2bed" aria-selected="false">Floor Plan</a>
                        </li>
                    </ul>

                    <div className="tab-content" id="myTabContent">
                     
                        <div className="tab-pane fade show active" id="1bed" role="tabpanel" aria-labelledby="1bed-tab">
                            <div className="_prtis_list_body" id="master-plan" style={{padding:0}}>
                                <div className=""   >

                                <div className="property_video">
                                    <div className="thumb"  >

                                        <div onClick={() => masterfloor(master)} className='slider-overlay'
                                           ></div>


                                        <ImageGallery items={masterPlaneSlider} showPlayButton={false}  />


                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                        <div className="tab-pane fade" id="2bed" role="tabpanel" aria-labelledby="2bed-tab">
                            <div className="_prtis_list_body" id="flour-plane" style={{padding:0}}>
                                
                                <div className=""   >
                                <div className="property_video">
                                    <div className="thumb" >
                                            <div onClick={() => masterfloor(floor)} className='slider-overlay'
                                           ></div>

                                        <ImageGallery items={flourPlanSlider} showPlayButton={false}  />


                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>



            {/* Modal */}
            <div>
                <div className="modal fade" id="master-flour-plane-slider" tabIndex={-1} role="dialog" aria-labelledby="master-flour-plane-sliderLabel" aria-hidden="true">
                    <div className="modal-dialog modal-xl" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="master-flour-plane-sliderLabel"></h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body p-0">
                                <ImageGallery items={sliderImage} showPlayButton={false}/>
                                {/* <ImageGallery items={images} /> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            {isOpen && (
          <Lightbox
            mainSrc={lightBoxImage[PhoneIndex]}
            nextSrc={lightBoxImage[(PhoneIndex + 1) % lightBoxImage.length]}
            prevSrc={lightBoxImage[(PhoneIndex + lightBoxImage.length - 1) % lightBoxImage.length]}
            onCloseRequest={() => setIsOpen(false)}
            onMovePrevRequest={() =>
                setPhotoIndex((PhoneIndex + lightBoxImage.length - 1) % lightBoxImage.length)
            }
            onMoveNextRequest={() =>
                setPhotoIndex((PhoneIndex + 1) % lightBoxImage.length)
            }
          />
        )}

        </>
    )
}

export default Masterplan