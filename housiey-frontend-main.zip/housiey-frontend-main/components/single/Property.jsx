/* eslint-disable react/no-unknown-property */
import GoogleMap  from 'google-map-react';
import {round_num} from '../../utils/BasicFn';
import * as React from 'react';
import {useState} from 'react';
import ReactPlayer from 'react-player'
import Overview from './Overview'
import Location from './Location'
import Proscons from './Proscons'
import Masterplan from './Masterplan';
import Video from './Video';

const AnyReactComponent = ({ text }) => <div className='google-map-marker'></div>;



function createMapOptions(maps) {
  // next props are exposed at maps
  // "Animation", "ControlPosition", "MapTypeControlStyle", "MapTypeId",
  // "NavigationControlStyle", "ScaleControlStyle", "StrokePosition", "SymbolPath", "ZoomControlStyle",
  // "DirectionsStatus", "DirectionsTravelMode", "DirectionsUnitSystem", "DistanceMatrixStatus",
  // "DistanceMatrixElementStatus", "ElevationStatus", "GeocoderLocationType", "GeocoderStatus", "KmlLayerStatus",
  // "MaxZoomStatus", "StreetViewStatus", "TransitMode", "TransitRoutePreference", "TravelMode", "UnitSystem"
  return {
    zoomControlOptions: {
      position: maps.ControlPosition.RIGHT_CENTER,
      style: maps.ZoomControlStyle.SMALL
    },
    mapTypeControlOptions: {
      position: maps.ControlPosition.TOP_RIGHT
    },
    mapTypeControl: true
  };
}

const Property = ({ setbrocher,setproject_videos,setcons,setpros,setfloor_plan,setlocation,setdetalis, setamenities, setproject,setexamenities,  setmaster_plan,plan_kit,rera_details}) =>{
  
 
  const defaultProps = {
    center: {
      lat: (setlocation.length) ? setlocation[0].lat:'',
      lng: (setlocation.length) ? setlocation[0].lng:''
    },
    zoom: 11
  };

  const [isVideoPlay, setVideoPlay] = useState(false);
  const [videoSrc,setVideoSrc] = useState('');
  const closeMapModal  = ()=>{
    $('#google-map-modal').modal('hide')

  }
 
    return (
        <> 

         <section className="pt-4" id="overview" >
          <div className="container">
          <div className="row">
            {/* property main detail */}
            <div className="col-lg-12 col-md-12 col-sm-12"  >
                          {/* Overview & Description Start */}
                          <Overview setproject={setproject} setbrocher={setbrocher} rera_details={rera_details}/>
                          {/* Overview & Description End */}


                        <div className="row">
                            <div className="col-lg-6 col-md-6 col-sm-12">
                              {/* Location Start */}
                              <Location setlocation={setlocation} setVideoSrc={setVideoSrc} 
                              setIsPlaying={setVideoPlay} />
                              {/* Location End  */}
                              {/* & Pros And Cons Start */}
                              <Proscons setpros={setpros} setcons={setcons}/>
                            </div>
                            {/* Pros And Cons End */}

                            {/* Video Section Start */}
                            
                            <Video setproject_videos={setproject_videos} setVideoSrc={setVideoSrc} 
                              setIsPlaying={setVideoPlay}  />

                            {/* Video Section End */}
                        </div>
                    

                      {/* Amenities Start */}
                      <div className="_prtis_list mb-4" id="internal-amenities" >
                        <div className="_prtis_list_header min">
                          <h4 className="m-0">
                            Amenities
                          </h4>
                        </div>
                        <div className="_prtis_list_body">
                          <h5>Internal Amenities</h5>
                          <div className="row _prtis_list_body" >
                            {setamenities.map((items)=>
                              <>
                                {items.name ? <div className="col-2 text-center">
                                  <img src={process.env.BASE_URL + items.img} alt="" style={{ width: "2rem", height: "2rem" }}/>
                                  <h6 style={{ fontSize: '12px', fontWeight: '400', color: "#000" }}>{items.name}</h6>
                                </div> 
                                  : ''}
                              </>
                            )}
                          </div>
                        </div>
                        <div className="_prtis_list_body">
                          <h5>External Amenities</h5>
                          <div className="row _prtis_list_body">
                        {setexamenities.map((item)=>
                          <>
                          {item.name && 
                          <div className="col-2 text-center">
                              <img src={process.env.BASE_URL + item.img} alt="" style={{ width: "2rem", height: "2rem" }}/>  
                              <h6 style={{ fontSize: '12px', fontWeight: '400', color: "#000" }}>{item.name}</h6>
                          </div>}</>
                            )}
                          </div>
                        </div>
                        
                      </div>
                  {/* Amenities End */}
                  {/* Master & Floor Plan Start */}

                  <Masterplan setmaster_plan={setmaster_plan} setfloor_plan={setfloor_plan} plan_kit={plan_kit}  />



                    

                  <div className="modal fade" id="popup-video" tabIndex={-1} role="dialog" aria-labelledby="popup-video" aria-hidden="true"
                  data-backdrop="static"
                  data-keyboard="false"> 
                  <div className="modal-dialog modal-dialog-centered " role="document">
                      <span className=" video-close" data-dismiss="modal" aria-hidden="true" onClick={() => setVideoPlay(false)}>
                        <i className="ti-close" />
                      </span>
                      <ReactPlayer url={videoSrc} playing={isVideoPlay} controls={true}/>
                    </div>
              </div>

            </div>
            {/* Master & Floor Plan End */}
            {/* ============================ Our Counter Start ================================== */}
            {/* ============================ Our Counter End ================================== */}
            </div>
          </div>
         </section>

        {/* Modal Location Start */}

        

        <div className="modal fade" id="google-map-modal" tabIndex={-1} role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
          data-backdrop="static"
          data-keyboard="false"
        >
          <div className="modal-dialog modal-lg" role="document">
            {/*Content*/} 
          
            <div className="modal-content">
             
              <div className="modal-body mb-0 p-0">

                <span className="mod-close" onClick={closeMapModal}  >
                  <i className="ti-close" />
                </span>

                <div id="map-container-google-2" className="z-depth-1-half map-container" style={{ height: 500 }}>
                  <div style={{ height: '500px', width: '100%' }}>
                  <GoogleMap 
                    bootstrapURLKeys={{ key: process.env.MAP_KEY2 }}
                      center={{
                        lat: round_num(defaultProps.center.lat),
                        lng: round_num(defaultProps.center.lng)    
                      }}
                      zoom={11}
                      options={createMapOptions}
                    >
                      <AnyReactComponent
                       lat={defaultProps.center.lat}
                       lng={defaultProps.center.lng}
                       text="My Marker"
                      />
                    </GoogleMap>
                  </div>
                </div>
              </div>
            </div>
            {/*/.Content*/}
          </div>
        </div>
        
        </>
    )
}
 
export default Property
