import React from 'react'

const Bookfree = () => {
    return (
        <>
         <div
  className="image-cover hero_banner"
  id="free-visit"
  style={{
    background: "url(assets/img/graphics9.jpg) no-repeat",
    paddingTop: 0
  }}
  data-overlay={0}
>
  <div className="container">
   
    <div className="row justify-content-center">
      <div className="col-xl-10 col-lg-12 col-md-12">
        <h1 className="big-header-capt mb-2" style={{ fontSize: "1.7rem" }}>
          Book Free Site Visit
          <i
            data-toggle="tooltip"
            data-placement="top"
            data-original-title="Save property"
            className="fas fa-info-circle"
            style={{ fontSize: "1rem", color: "#ccc" }}
          />
        </h1>
        <div
          className="full_search_box nexio_search"
          style={{ background: "transparent", padding: "0 0 0" }}
        >
          <div className="search_hero_wrapping">
            <div className="row">
              <div className="col-lg-12">
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control search-field"
                    placeholder="Search multiple projects for site visit"
                  />
                  <div className="input-group-append">
                    <button
                      type="button"
                      className="input-group-text theme-bg b-0 text-light"
                      style={{ width: 175 }}
                    >
                      Book Your
                      <img
                        src="/assets/img/ola-logo1.png"
                        width="60%"
                        style={{ marginLeft: 5 }}
                        alt=''
                      />
                    </button>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
   
        </>
    )
}

export default Bookfree
