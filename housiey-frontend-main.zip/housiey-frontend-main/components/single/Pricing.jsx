/* eslint-disable @next/next/no-css-tags */
import Head from "next/head"
import { useState } from 'react'
import { numFormatter } from '../../utils/BasicFn';
import ImageGallery from 'react-image-gallery';
import Marquee from "react-fast-marquee";
import Lightbox from 'react-image-lightbox';
import "react-image-lightbox/style.css";


import { set_download_file, set_signup_title, set_first_time_login } from '../../redux/slices/signUpModalSlice';
import { useDispatch,useSelector } from 'react-redux';
import { useRouter } from 'next/router';



const Pricing = ({ setdetalis, setschemes, setconigs, setbank, tour_video, price_sheet, plan_kit, payment_schedule }) => {
  const dispatch = useDispatch();
  const router = useRouter();

  const page_type          = useSelector((state)=>state.signUpModal.page_type)
    const enq_project_id     = useSelector((state)=>state.signUpModal.enq_project_id)



  const [checklog, setChecklog] = useState(false)


  const [value, setValue] = useState('1');
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  // console.log(setdetalis)
  // const [detalis, setDetalis] = useState(setdetalis)
  // const [bhk, setbhk] = useState(setconigs)
  // const [scheme, setschem] = useState(setschemes)
  // const [banks, setbanks] = useState(setbank);

  
  const detalis     = setdetalis;
  const bhk         = setconigs;
  const scheme      = setschemes;
  const banks       = setbank;;

  const [zoomImgSrc, setZoomImgSrc] = useState('');
  // const [checkLogin,setCheckLogin] = useState(false);

  const PricingUnit = () => {
    if (localStorage.getItem('housey_token')) {
      $('#modalGM').modal('show')
    }
    else {
      $('#login').modal('show')
    }
  }

  const viewproject = () => {
    setChecklog(true)
    // if (localStorage.getItem('housey_token')) {
    // }
    // else {
    //   $('#login').modal('show')
    // }
  }

  const priceimg = (img) => {
    $('#priceModal').modal('show')
    let imgSrc = process.env.BASE_URL + img;
    setZoomImgSrc(imgSrc);
    // if (localStorage.getItem('housey_token')) {
    // }
    // else {
    //   $('#login').modal('show')
    // }
  }


  const donwloadFile = async (file, fileName, name) => {
    let link  = `/api/download?link=${file}&name=${fileName}`;
    let title = name;
    dispatch(set_signup_title(title));
    let token = localStorage.getItem('housey_token');
    if (localStorage.getItem('housey_token')) {
      await router.push(link);

      let sendEnq = process.env.BASE_URL+`download-doc/${enq_project_id}`;
      let req     = await fetch(sendEnq,{
          headers: {
              auth: token,
              source: name
          }
      });
      
      $('#DownloadThankYou').modal('show');
    } else {
      $('#download-content-modal').modal('show')
      let obj = {
        file: file,
        status: true,
        name: fileName
      }
      dispatch(set_download_file(obj));
      dispatch(set_first_time_login(true));
    }
  }


  const closeLightbox = () => {
    setZoomImgSrc('');
  }





  return (
    <>
      <section className="pt-4" id="priceing-section" >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 col-md-12 col-sm-12">


              <div className="_prtis_list">
                <div className="_prtis_list_header min" style={{padding: '0.5rem 1.5rem 1.4em'}}>
                  <h4 className="m-0">
                    Pricing &amp; Unit Plans
                    <button
                      onClick={() => donwloadFile(price_sheet, 'price_sheet', 'Price Sheet')}
                      className="btn download-btn"
                    >
                      <i className="fa fa-download fa-bounce" style={{ fontSize: 12, marginRight: 2 }} />
                      Price Sheet
                    </button>
                  </h4>
                </div>

                <div className="_prtis_list_body">
                  <ul className="nav nav-tabs floor_plans" id="myTab" role="tablist">

                    {bhk.map((tb_items, index) =>
                      <>

                        <li className="nav-item">
                          <a
                            className={(index === 0) ? "nav-link active" : "nav-link"}
                            id={"1bed-tab-" + index}
                            data-toggle="tab"
                            href={"#1bed-" + index}
                            role="tab"
                            aria-controls={"1bed" + index}
                            aria-selected="false"
                          >
                            {tb_items.config_name}

                          </a>
                        </li>
                      </>
                    )
                    }
                  </ul>
                  <div className="tab-content" id="myTabContent">

                    {detalis.map((detali, tb_index) =>
                      <>

                        <div
                          className={`tab-pane fade ${tb_index === 0 ? 'show active' : ''}`}
                          id={"1bed-" + tb_index}
                          role="tabpanel"
                          aria-labelledby={"1bed-tab-" + tb_index}
                        >
                          <div className="table-responsive">
                            <table className="table">

                              <thead>
                                <tr style={{ color: "#000" }}>
                                  <th>Carpet Area</th>
                                  <th>All Inc</th>
                                  <th>Down Payment</th>
                                  <th>Parking</th>
                                  <th>Unit Plan</th>
                                </tr>
                              </thead>
                              <tbody style={{ color: "#000" }}>
                                {detalis[tb_index].map((subDetails, subIndex) => (
                                  <tr key={subIndex} >
                                    <td>{subDetails.carpet_area} sqft</td>
                                    {/* <td>{subDetails.builtup_area}sqft</td> */}
                                    <td>{numFormatter(subDetails.price)} <small  className='all-inc'>All In</small> </td>
                                    <td>{numFormatter(subDetails.down_payment)} <small  className='all-inc'>All In</small> </td>
                                    <td>{subDetails.parking_type} </td>
                                    <td className=" overlay-img" onClick={() => priceimg(subDetails.unit_plan_img)}>
                                      <i className="fa fa-search-plus" aria-hidden="true"></i>
                                      <a href="#" className="theme-cl">
                                        <img src={process.env.BASE_URL + subDetails.unit_plan_img} className="pricing-img" alt='unit-img' />
                                      </a>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </>
                    )}


                    {/* <p style={{color: "#000"}}>
                      <b>NOTE:</b> Lorem ipsum dolor sit amet, consectetur adipisicing
                      elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                      aliqua Ut enim ad minim veniam Ut enim ad minim.
                    </p> */}
                  </div>
                </div>

              </div>

              {/* Payment scheme start */}


            </div>
          </div>
        </div>
      </section>

      <section className="" id="payment-scheme" >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 col-md-12 col-sm-12">


              <div className="_prtis_list"  >
                <div className="_prtis_list_header min" style={{padding: '0.5rem 1.5rem 1.4em'}}>
                  <h4 className="m-0">
                    Payment Scheme


                    <button
                      onClick={() => donwloadFile(payment_schedule, 'payment_schedule', 'Payment Schedule')}
                      className="btn download-btn"
                    >
                      <i className="fa fa-download fa-bounce" style={{ fontSize: 12, marginRight: 2 }} />
                      Payment Schedule
                    </button>
                  </h4>
                </div>
                <div className="_prtis_list_body" style={{ padding: '1rem' }}>

                  <div className="accordion" id="floor-option">
                    {
                      scheme.map((item, index) =>
                        <>

                          {item.scheme_name ? <>
                            <div className="card">
                              <div className="card-header" id={"groundFloor-" + index} >
                                <h2 className="mb-0">
                                  <button
                                    type="button"
                                    className="btn btn-link"
                                    data-toggle="collapse"
                                    data-target={"#groundfloor-" + index}
                                  >
                                    {item.scheme_name}
                                  </button>
                                </h2>

                              </div>

                              <div
                                id={"groundfloor-" + index}
                                className={(index === 0) ? "collapse show" : "collapse"}
                                aria-labelledby={"groundFloor-" + index}
                                data-parent="#floor-option"
                              >
                                <div className="card-body">
                                  <p style={{ marginTop: "-23px", color: "#000" }}>{item.description}</p>
                                </div>
                              </div>
                            </div>
                          </> : ""}  </>)}
                  </div>
                </div>
              </div>

              {tour_video && <>
                <div className="_prtis_list" style={{marginTop: '30px'}}>
                  <div className="_prtis_list_header min">
                    <h4 className="m-0">
                      360 Tour
                    </h4>
                  </div>
                  {/* <div  className="overlay"> */}
                  <div className="_prtis_list_body" onClick={viewproject}>
                    <div className={(checklog === true) ? "thumb " : "overlay"}>
                      <iframe src={tour_video} height={'600'} title="Iframe Example" style={{ width: "100%" }}></iframe>
                      {checklog ? '' : <>
                      </>}
                    </div>
                  </div>
                  </div>
                {/* </div> */}
              </>}


            </div>
          </div>
        </div>
      </section>


      <section className="" id="bank" >
        <div className="container">

          <div className="row">
            <div className="col-lg-12 col-md-12 col-sm-12">

              <div className="_prtis_list mb-4" >
                <div className="_prtis_list_header min">
                  <h4 className="m-0">
                    Project approved by
                  </h4>
                </div>

                {/* Project Approved By Start */}
                <div className="_prtis_list_body" id="logo-slider">
                  <div className="slider1" style={{ overflow: "hidden" }} id="">
                    <div className="slide-track">
                      <Marquee >
                        {banks.map((shows, index) =>
                          <div className="bank-img" key={index}>
                            <img src={process.env.BASE_URL + shows.logo} alt='bank-logo' />
                          </div>
                        )}
                      </Marquee>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>






      {/* Modal */}



      {/* Modal */}
      {zoomImgSrc && <Lightbox mainSrc={zoomImgSrc}
        onCloseRequest={closeLightbox}

      />}


      {/* <div>
          <div className="modal fade" id="priceModal" tabIndex={-1} role="dialog" aria-labelledby="priceModalLabel" aria-hidden="true">
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                  </button>
                </div>
                <div className="modal-body">

                  
                </div>
              </div>
            </div>
          </div>
        </div> */}


    </>
  )
}

export default Pricing
