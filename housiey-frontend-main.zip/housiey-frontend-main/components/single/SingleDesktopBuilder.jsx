import LongDescription from '../component/common/LongDescription';
import React, { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { set_sign_up_modal, set_sign_up_next_step } from '../../redux/slices/MobileSignUpModalSlice';
const SingleDesktopBuilder = ({ setbrocher, setproject }) => {

    const dispatch  = useDispatch();
    const router    = useRouter();

    const viewproject = async (link) => {
        dispatch(set_sign_up_modal(true))
    }





    const [mydata, setMydata] = useState([])
    useEffect(async () => {
        const response  = await fetch(process.env.BASE_URL + `builder-info/24/`);
        let data        = await response.json();
        if (data.res === true) {
            setMydata(data.builder_info)
        }
    }, [])



    return (
        <>
            <div className="_prtis_list mb-2" id="top-builders">
                <div className="_prtis_list_header min" style={{ padding: '0.3rem 0.5rem 0.3rem' }}>
                    <h4 className="m-0"><span className="theme-cl">{setproject && setproject.project_name}</span>
                    </h4>
                </div>
                {
                    mydata.map((items,index) => {
                        return (
                            <div className="_prtis_list_body builder-details" key={index}>
                                <div className="builder-overview">
                                    <div className="col-5 builder-img">
                                        <img src="/assets/img/bl-1.webp" />
                                    </div>
                                    <div className="col-7 builder-states">



                                        <ul className="text-center">
                                            <li>
                                                <span>{items.experience}yrs</span>
                                                <p>Experience</p>
                                            </li>
                                            <li>
                                                <span>{items.projects_comp}</span>
                                                <p>Total Projects</p>
                                            </li>
                                            <li>
                                                <span>2000</span>
                                                <p>Established in</p>
                                            </li>
                                        </ul>

                                    </div>
                                </div>
                                <div className="builder-description">
                                    <h4 className="builder-name">{items.builder_name}</h4>
                                    <p className="builder-city">Mumbai/Pune/Banglore</p>
                                    <div className="_rate_stio">
                                        <i className="fa fa-star" />
                                        <i className="fa fa-star" />
                                        <i className="fa fa-star" />
                                        <i className="fa fa-star" />
                                        <i className="fa fa-star" />
                                    </div>
                                    {/* <p className="about-builder">{setproject && setproject.about}</p> */}
                                    <LongDescription content={items.description} wordlength={250} />
                                    {/* <p>
                    <a href="#" className="btn">View Projects <i className="fas fa-arrow-right" style={{ fontSize: 12, marginLeft: 2 }} /></a>
                  </p> */}
                                    <div className="button-block" style={{ float: "right" }}>
                                        <i className="fas fa-download button-image" />
                                        <button className="block-button-1" style={{ width: 100,background:"red" }} onClick={() => viewproject(setbrocher)}>View Project</button>
                                    </div>

                                </div>

                            </div>
                        )
                    })
                }

            </div>

        </>
    )
}

export default SingleDesktopBuilder