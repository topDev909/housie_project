import React,{useState,useEffect} from 'react';
import Link from 'next/link';
import {slugGenrator} from '../../utils/BasicFn';
import LongDescription from '../component/common/LongDescription';


const BuilderSection = ({setproject})=>{

    
  const [mydata, setMydata] = useState([])

  const fetchUseEfect = async ()=>{
    const response  = await fetch(process.env.BASE_URL + `builder-info/`+setproject.builder_id);
      let data      = await response.json();
      if (data.res === true) {  
        setMydata(data.builder_info)
      }
  }

  useEffect(()=>{
    fetchUseEfect()
  },[setproject.builder_id])


    return (<>

            
    <div className="container">
      <div className="_prtis_list mb-2" id="top-builders">
      { mydata.map((items,index) => {
        return (
        <div className="_prtis_list_header min" key={index} >
          <h4 className="m-0" ><span className="theme-cl">About {items.builder_name}</span>
          </h4>
        </div>
        )})}

        {mydata.map((items,index) => {
            return (
              <div className="_prtis_list_body builder-details" key={index} style={{ padding: "1rem 1rem 3rem 1rem" }}>
                <div className="builder-overview">
                  <div className="col-12 builder-img d-flex align-item-center ">
                    <img src={process.env.BASE_URL+items.logo} className="border p-2" />
                    <h4 className="builder-name ml-3">
                        {items.builder_name}
                        <p style={{ lineHeight:1,fontSize: '12px',fontWeight: '400' }}>{items.cities}</p>
                        <div className="_rate_stio">
                            <i className="fa fa-star" />
                            <i className="fa fa-star" />
                            <i className="fa fa-star" />
                            <i className="fa fa-star" />
                            <i className="fa fa-star" />
                        </div>

                        
                    <ul className="text-center">
                      <li className='ml-0'>
                        Experience
                        <span className='text-red'> : {items.experience}yrs</span>
                      </li>
                      <li>
                        Total Projects
                        <span className='text-red'> : {items.projects_comp}<sup>+</sup></span>
                      </li>
                      <li>
                        Happy Families
                        <span className='text-red'> : {items.happy_families}<sup>+</sup></span>
                      </li>
                    </ul>




                    </h4>

                  </div>


                </div>
                <div className="builder-description">
                  
                  
                  <div>
                  <LongDescription content={items.description} wordlength={250} />
                  </div>
                  <div className="button-block" style={{ float: "right" }}>
                    <Link href={"/builders/"+slugGenrator(items.builder_name)} >
                      <button className="block-button-1" style={{ width: 119, textAlign: 'center' }} >View Project</button>
                    </Link>
                  </div>
                </div>
              </div>
            )})}
      </div>
    </div>

        </>)
}
export default BuilderSection;