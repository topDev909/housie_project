/* eslint-disable jsx-a11y/alt-text */
import React from 'react'
import { Carousel } from 'react-responsive-carousel';
import Online_sidebar from '../Online_sidebar';
import { useState, useEffect } from 'react';
import {slugGenrator} from '../../utils/BasicFn';
import FormComponent from '../component/FormComponent';

import Link from 'next/link'
import Lightbox from 'react-image-lightbox';
import "react-image-lightbox/style.css";


const HeroBanner = ({ project, address, images, location }) => {


    // console.log("locationlocation",location)
    // console.log(address)

    const myproject                                 = project[0];
    const mylocation                                = location[0];

    const [maxSliderImg,setMaxSliderImg]            = useState([]);
    const [isOpen,setIsOpen]                        = useState(false)
    const [PhoneIndex,setPhotoIndex]                = useState(0);



    function numDifferentiation(value) {
        var val = Math.abs(value)
        if (val >= 10000000) {
            val = (val / 10000000).toFixed(2) + ' Cr';
        } else if (val >= 100000) {
            val = (val / 100000).toFixed(2) + ' Lac';
        }
        return val;
    }

    const openModal = ()=>{
        let lightBox = []
        images.map((singleImg)=>{
            lightBox.push(process.env.BASE_URL+singleImg.img)
        })
        setMaxSliderImg(lightBox)
        setIsOpen(true)
        setPhotoIndex(0)
    }
    return (
        <>

         <head>
                <link rel="stylesheet" href="/assets/css/singlestyles.css" />
                <link rel="stylesheet" href="/assets/css/imagegallery.css" /> 
         </head>
            <section id="detail" >
                <div className="container">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="row">
                                <div className="col-lg-12 col-md-12">
                                    <div className="property_lexible-1">
                                        <div className="pr-price-into flex-1">
                                            <div className="_card_list_flex">
                                                <div className="_card_flex_01">
                                                    <h4
                                                        className="listing-name verified"
                                                        style={{ fontSize: 12 }}
                                                    >
                                                        <a
                                                            href="single-property-1.html"
                                                            className="prt-link-detail"
                                                        />
                                                        <Link href="/">Home</Link>
                                                        &gt;
                                                        <Link href={"/in/"+mylocation.city+"/projects"}>{mylocation ? mylocation.city : ""}</Link>
                                                        &gt;
                                                        <Link href={"/in/"+mylocation.city+"/"+mylocation.locality+"/projects"}>{mylocation ? mylocation.locality : ""}</Link>
                                                    </h4>
                                                </div>
                                            </div>
                                            {/* {JSON.stringify(project)} */}
                                            <h2>{(myproject) ? myproject.project_name : ""}</h2>
                                            <p style={{paddingLeft: "0"}}>
                                                <span>
                                                    
                                                    By <Link href={"/builders/"+slugGenrator(myproject.builder_name)}>{(myproject) ? myproject.builder_name : ""}</Link>
                                                </span>
                                                &nbsp;|&nbsp;
                                                <span>{(address) ? address : ""}</span>
                                            </p>
                                        </div>
                                        <div className="price_into_last">
                                            <h2>
                                                <i className="fas fa-rupee-sign" />{(myproject) ? myproject.overall_price_range : ""}
                                                <span style={{ fontSize: 15 }}> All Inc.</span>{" "}
                                            </h2>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-8">
                                    <div className="product-images demo-gallery">
                                        {myproject.saving_amt ? <>
                                            <div className="_exlio_129">Save {numDifferentiation((myproject) ? myproject.saving_amt : "")}</div>
                                        </>: ""}
                                        <div className='slider-overlay hero' onClick={openModal}  ></div>
                                        <Carousel autoPlay={false}
                                            showArrows={true}
                                            showThumbs={true}
                                            showStatus={false}
                                            showIndicators={false}
                                        >
                                            {images.map((item, index) =>
                                                <img src={process.env.BASE_URL + item.img} key={index} alt={'slider-img'} />
                                            )}
                                        </Carousel>
                                    </div>
                                </div>


                                <div className="page-sidebar p-0 col-4">
                                    <div className="block-body">
                                        <FormComponent />
                                    </div>
                                </div>

                            </div>
                            {myproject.offer && <> <div className='_prtis_list mb-4 row'>
                                <div className="col-12 special-offer">
                                    <div className="special-offer-text">
                                        <span>SPECIAL OFFER</span>
                                    </div>
                                    <div className="special-offer-info">
                                        <span>{myproject.offer}</span>
                                    </div>
                                </div>
                            </div></>}
                        </div>
                    </div>
                </div>
            </section>

            {/* Sticky Header Start */}



            <section className="sticky-nav-tabs" style={{ position: 'sticky', top: '-14px', zIndex: '100', paddingTop:0 }} >

                <div className="sticky-nav-tabs-container" style={{ position: 'sticky', zIndex: '100' }}>
                    <nav className='navbar navbar-light' id="sub-menu-bar" >
                        <ul className="nav nav-pills ">
                            <li className="nav-item">
                                <a className="nav-link" href="#overview" >Overview</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#location">Location</a>
                            </li>

                            <li className="nav-item">
                                <a className="nav-link" href="#internal-amenities">Amenities</a>
                            </li>

                            <li className="nav-item">
                                <a className="nav-link" href="#master-flour-plan">Master &amp; Floor Plan</a>
                            </li>


                            <li className="nav-item">
                                <a className="nav-link" href="#priceing-section">Pricing &amp; Unit Plans</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#payment-scheme">Payment Scheme</a>
                            </li>

                            <li className="nav-item">
                                <a className="nav-link" href="#bank">Bank</a>
                            </li>

                        </ul>

                    </nav>

                    <span className="sticky-nav-tab-slider" />
                </div>
            </section>


            {/* Sticky Header End */}

            {isOpen && (
          <Lightbox
            mainSrc={maxSliderImg[PhoneIndex]}
            nextSrc={maxSliderImg[(PhoneIndex + 1) % maxSliderImg.length]}
            prevSrc={maxSliderImg[(PhoneIndex + maxSliderImg.length - 1) % maxSliderImg.length]}

            mainSrcThumbnail={maxSliderImg[PhoneIndex]}

            onCloseRequest={() => setIsOpen(false)}
            onMovePrevRequest={() =>
                setPhotoIndex((PhoneIndex + maxSliderImg.length - 1) % maxSliderImg.length)
            }
            onMoveNextRequest={() =>
                setPhotoIndex((PhoneIndex + 1) % maxSliderImg.length)
            }
          />
        )}


        </>
    )
}

export default HeroBanner