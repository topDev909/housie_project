import React from 'react'
import { useState } from 'react';
import ReactPlayer from 'react-player'
import { Markup } from 'interweave';
import KeyPoints from './KeyPoints';
import { useDispatch } from 'react-redux';
import {  set_signup_title } from '../../redux/slices/signUpModalSlice';

const Location = ({ setlocation, setVideoSrc, setIsPlaying }) => {

    // const [location, setLocation] = useState(setlocation)
    const location = setlocation;
    const dispatch = useDispatch();


    // console.log(location)
    const OpenMapModal = () => {
        $('#google-map-modal').modal('show')
    }

    const openvideo = (link) => {

        if (localStorage.getItem('housey_token')) {
            setVideoSrc(link)
            setIsPlaying(true)
            $('#popup-video').modal('show')
        }
        else {

            setVideoSrc(link)
            setIsPlaying(true)
            $('#popup-video').modal('show')
            startVideoForSec()
        }
    }


    const startVideoForSec = ()=>{
        setTimeout(() => {
            setIsPlaying(false);
            let title = 'video';
            dispatch(set_signup_title(title));
            $('#download-content-modal').modal('show')
            $('#popup-video').modal('hide')
        }, 15000);
    }


    return (
        <>
            <section className="_prtis_list mb-4" id="location">

                <div className="_prtis_list_header min">
                    <h4 className="m-0">
                        Location
                        <a
                            href="#"
                            className="btn my-map"
                            data-toggle="modal"
                            onClick={OpenMapModal}
                        >
                            <i className="fa fa-map fa-bounce" style={{ fontSize: 12, marginRight: 2 }} />
                            View on Map
                        </a>
                    </h4>
                </div>

                {location && location.map((detalis) => {
                    return (
                        <>

                            <div className="property_info_detail_wrap mb-4 _prtis_list_body" style={{ padding: "1rem 2rem" }} >
                                <div className="property_info_detail_wrap_first">
                                    <div className="pr-price-into">
                                        <span style={{ color: "#000" }}>
                                            <i className="lni-map-marker" /> {detalis.street}
                                        </span>
                                        <ul style={{ paddingLeft: 0 }}>
                                            <KeyPoints data={detalis.highlights} />
                                        </ul>
                                    </div>
                                </div>

                                {detalis.link && <>
                                    <div className="property_detail_section">
                                        <div className="prt-sect-pric">
                                            <div className="property_video" onClick={() => openvideo(detalis.link)}>

                                                <div className="thumb">
                                                    <ReactPlayer url={detalis.link} controls={true} width={150} height={100}   />

                                                    <div className="overlay_icon" style={{display: 'none'}}>
                                                        <div
                                                            className="bb-video-box"
                                                            style={{ width: 70, height: 70 }}
                                                        >
                                                            <div
                                                                className="bb-video-box-inner"
                                                                style={{ height: 60, width: 60 }}
                                                            >
                                                                <div
                                                                    className="bb-video-box-innerup"
                                                                    style={{ width: 40, height: 40 }}
                                                                >
                                                                    <button className="theme-cl link-btn" >
                                                                        <i
                                                                            className="ti-control-play "
                                                                            style={{ fontSize: 20 }}
                                                                        />
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </>}
                            </div>
                        </>
                    )
                })}

            </section>
        </>
    )
}

export default Location