import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBars } from '@fortawesome/free-solid-svg-icons'
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import Signup from '../component/Auth/Signup';
const Single_header = ({ get_user_data }) => {


    const logoutsession = () => {
        localStorage.removeItem('housey_token')
        localStorage.clear();
    }
    const [userSession, setUserSession] = useState('');
    useEffect(() => {
        let jwt_get_data = localStorage.getItem('housey_token')
        let get_data = parseJwt(jwt_get_data);
        // console.log(get_data);
        setUserSession(get_data);
    }, [])

    function parseJwt(token) {
        if (!token) { return; }
        const base64Url = token.split('.')[1];
        const base64    = base64Url.replace('-', '+').replace('_', '/');
        return JSON.parse(window.atob(base64));
    }
    // Pwd: AnT750@TC

    return (
        <>
           
            <div className="header header-light">
                <div className="container">
                    <nav id="navigation" className="navigation navigation-landscape">
                        <div className="nav-header">
                            <a className="nav-brand fixed-logo" href="#"><img src="assets/img/logo.png" className="logo" alt='' /></a>
                            <div className="nav-toggle" />
                            <div className="mobile_nav">
                                <ul>
                                    <li><a href="#" data-toggle="modal" data-target="#login"><i className="fas fa-user-circle fa-lg" /></a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="nav-menus-wrapper" style={{ transitionProperty: 'none' }}>
                            <ul className="nav-menu nav-menu-social align-to-right">

                                {(userSession) ?
                                    <>
                                        <li>
                                            <div className="btn-group account-drop">
                                                <button
                                                    type="button"
                                                    className="btn btn-order-by-filt"
                                                    data-toggle="dropdown"
                                                    aria-haspopup="true"
                                                    aria-expanded="false">
                                                 
                                                    <Stack direction="row" spacing={2}>
                                                        <Avatar
                                                            alt={userSession.name}
                                                            src="/static/images/avatar/1.jpg"
                                                            sx={{ width: 70, height: 70 }}/>
                                                    </Stack>
                                                   

                                                </button>
                                                <div className="dropdown-menu pull-right animated flipInX">
                                                    <ul>
                                                        <li>
                                                            <a href="#">About Us</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Buy Property in Mumbai</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Buy Property in Pune</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Buy Property in Bangalore</a>
                                                        </li>
                                                        <li onClick={logoutsession}>
                                                            <a href="">Logout</a>
                                                        </li>

                                                    </ul>
                                                </div>

                                            </div>
                                        </li>
                                    </>
                                    : <>
                                        {/* <li>
                                            <a
                                                href="#"
                                                className="alio_green"
                                                data-toggle="modal"
                                                data-target="#login"
                                            >
                                                <span className="dn-lg">Refer &amp; Earn</span>
                                            </a>

                                        </li> */}

                                        <li>
                                            <a
                                                href="#"
                                                className="alio_green"
                                                data-toggle="modal"
                                                data-target="#login"
                                            >
                                                <span className="dn-lg">Sign Up</span>
                                            </a>

                                        </li>

                                        <li>
                                            <a
                                                href="#"
                                                className="alio_green"
                                                data-toggle="modal"
                                                data-target="#login"
                                            >
                                                <span className="dn-lg">Login</span>

                                            </a>
                                        </li>


                                        <li>
                                            <div className="btn-group account-drop">
                                                <button
                                                    type="button"
                                                    className="btn btn-order-by-filt"
                                                    data-toggle="dropdown"
                                                    aria-haspopup="true"
                                                    aria-expanded="false"
                                                >
                                                    {/* <i className="fas fa-bars" > */}
                                                    <FontAwesomeIcon icon={faBars} style={{color:'black'}}/>
                                                    {/* </i> */}
                                                </button>
                                                <div className="dropdown-menu pull-right animated flipInX">
                                                    <ul>
                                                        <li>
                                                            <a href="#">About Us</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Buy Property in Mumbai</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Buy Property in Pune</a>
                                                        </li>

                                                    </ul>
                                                </div>

                                            </div>
                                        </li>
                                    </>}
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            <div className="clearfix"></div>
<Signup/>
        </>
    )
}

export default Single_header;