
import React,{useState,useEffect} from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import Ourmission       from './Ourmission';
import Pricing          from './Pricing';
import Property         from './Property';
import Online_project   from './Online_project';
import ListingHeader    from '../Listing/ListingHeader';
import Propertiesnew    from './Propertiesnew';
import Sitevisit        from '../Sitevisit'
import HeroBanner       from './HeroBanner';
import BuilderSection       from './BuilderSection';
import DownloadThankYou from '../inc/DownloadThankYou';
import DownloadContentModal from '../inc/DownloadContentModal';
import { useDispatch } from 'react-redux';
import { select_project } from '../../redux/slices/projectsSlice';
import Head from 'next/head';

const DesktopSinglePage = ({data})=>{
    const dispatch = useDispatch();
    
    const {brocher,faqs,conigs,cons,pros,schemes,floor_plan,location,ext_amenities,int_amenities,conigs_deatils,project_videos,tour_video,project,address,banks,images,master_plan,price_sheet,plan_kit,payment_schedule,rera_details,sellerInfo} = data;


    useEffect(()=>{
    let arr = [];
    let obj = {
        id:             project[0].id,  
        slug:           project[0].slug,
        project_name:   project[0].project_name,
    }
    arr.push(obj);
    dispatch(select_project(arr));
    },[data])
 
    return (
        <>

        <Head>
            <title> {project[0].project_title} : : {process.env.TITLE} </title>
        <meta name="viewport" content="initial-scale=1.0" />
        <meta name="description" content={project[0].project_desc} />
        <meta property="og:title" content={project[0].project_title} />
        <meta property="og:description" content={project[0].project_desc} />
        </Head>




            <ListingHeader header_type={'single'} />    

            <HeroBanner project={project} images={images} address={address}  location={location}/>
                    <Property   setpros={pros} 
                                setcons={cons}  
                                setdetalis={conigs_deatils}
                                setamenities={int_amenities} setexamenities={ext_amenities} 
                                setproject={project} setmaster_plan={master_plan} 
                                setlocation={location} setfloor_plan={floor_plan}
                                setproject_videos={project_videos}  setbrocher={brocher}
                                plan_kit={plan_kit}
                                rera_details={rera_details}
                        />
                    <Online_project/>
                    <Pricing setdetalis={conigs_deatils} setschemes={schemes} setconigs={conigs} setbank={banks} tour_video={tour_video} price_sheet={price_sheet} plan_kit={plan_kit} payment_schedule={payment_schedule} />
                    <Sitevisit/>

                    <div className='builder-section' >
                        <BuilderSection setproject={project[0]} />
                    </div>
                    <Ourmission                 setfaqs={faqs}  />
                    <Propertiesnew              project={project} location={location}/>
                    <DownloadThankYou           sellerInfo={sellerInfo} project={project[0]} />
                    <DownloadContentModal       project={project[0]}/>
        </>
    )
}
export default  DesktopSinglePage;