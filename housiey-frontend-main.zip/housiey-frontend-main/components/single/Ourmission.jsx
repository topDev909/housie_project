import {useState} from 'react'
const Ourmission = ({ setfaqs}) => {
// const [que,setQue]         = useState(setfaqs)
  const que  = setfaqs;
    return (
        <>
         <section>
  <div className="container">
    <div className="row justify-content-center">
      <div className="col-lg-7 col-md-8">
        <div className="sec-heading center">
          <h2>FAQs</h2>
        </div>
      </div>
    </div>
    <div className="row">
      <div className="col-lg-12 col-md-12 col-sm-12">
        {/* Single Basics List */}
        <div className="faq_wrap">
          <div className="faq_wrap_body mb-5">
            <div className="accordion" id="generalac">

           {
             que.map((question,index)=>
             
             <>
            {question.qus ?<>
              <div className="card">
                <div className="card-header " id={"headingThree-"+index}>
                  <h2 className="mb-0">
                    <button className={(index === 0) ? "btn btn-link " : "btn btn-link collapsed"}
                      type="button"
                      data-toggle="collapse"
                      data-target={"#collapseThree-" + index}
                      aria-expanded="false"
                      aria-controls="collapseThree"
                    >
                      {question.qus}
                    </button>
                  </h2>
                </div>
                     <div
                       id={"collapseThree-" + index}
                       className={(index === 0) ? "collapse show" : "collapse"}
                       aria-labelledby="headingThree"
                       data-parent={"#generalac-" + index}
                     >
                       <div className="card-body" >
                         <p className="ac-para" style={{color: "#000"}}>

                           {question.ans}
                         </p>
                       </div>
                     </div>
              </div>
                 </> : ""}
               </>
             )
             }
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
   
        </>
    )
}

export default Ourmission
