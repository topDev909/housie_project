/* eslint-disable react/jsx-key */
import React from 'react'
import ReactPlayer from 'react-player'
import { useState } from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import SwipeableViews from 'react-swipeable-views';
import AppBar from '@mui/material/AppBar';
import Typography from '@mui/material/Typography';  
import PropTypes from 'prop-types';

import { useDispatch } from 'react-redux';
import {  set_signup_title } from '../../redux/slices/signUpModalSlice';



const  TabPanel = (props)=>{
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`full-width-tabpanel-${index}`}
            aria-labelledby={`full-width-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};


const Video = ({ setproject_videos,setVideoSrc,setIsPlaying }) => {
    // const [video, setVideo]                 = useState(setproject_videos)
    const video                             = setproject_videos;
    const [isVideoPlay, setVideoPlay]       = useState(false)
    const [playingVideo,setPlayingVideo]    = useState('');
    const [value, setValue]                 = React.useState(0);
    const dispatch                          = useDispatch();

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const openvideo = (vLink) => {
        if (localStorage.getItem('housey_token')) {
            $('#popup-video').modal('show')
            setPlayingVideo(vLink);
            setVideoSrc(vLink);
            setIsPlaying(true);
            setVideoPlay(true);
        }
        else {
            setPlayingVideo(vLink);
            setVideoSrc(vLink);
            setIsPlaying(true);
            setVideoPlay(true);
            $('#popup-video').modal('show')
            startVideoForSec();
        }
    }



    const startVideoForSec = ()=>{
        setTimeout(() => {
            setVideoPlay(false);
            setIsPlaying(false);
            
            let title = 'video';
            dispatch(set_signup_title(title));
            $('#download-content-modal').modal('show')
            $('#popup-video').modal('hide')

   
        }, 15000);
    }

  return (
    <>

          <div className="col-lg-6 col-md-6 col-sm-12">
              <div className="_prtis_list mb-4">
                  <div className="_prtis_list_header min">
                      <h4 className="m-0">
                          Video 
                      </h4>
                  </div>

                  <div className="_prtis_list_body">
                      <Box sx={{ maxWidth: 550, bgcolor: 'background.paper' }}>
                          <AppBar position="static">
                                  
                          <Tabs
                              value={value}
                              onChange={handleChange}
                              variant="scrollable"
                              scrollButtons="auto"
                              aria-label="scrollable auto tabs example"
                          >

                              {
                                  video.map((content, index) => {

                                      return (
                                           <> 
                                              <Tab label={content.type} onClick={(e) => setValue(index)} className='tab-style' /> 
                                            </>
                                          )
                              })
                          }
                          </Tabs>
                          </AppBar>



                          <SwipeableViews
                            //   axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
                              index={value}
                            //   onChangeIndex={handleChangeIndex}
                          >
                              {video.map((content, index) => (
                                      <TabPanel value={value} index={index} >
                                      <div className="property_video" onClick={() => openvideo(content.video)}>
                                          <div className="thumb" >
                                              <ReactPlayer url={content.video} controls={true}  width={507}/>
                                              <div className="overlay_icon" style={{display: 'none'}}>
                                                  <div className="bb-video-box">
                                                      <div className="bb-video-box-inner">
                                                          <div className="bb-video-box-innerup">
                                                              <button 
                                                                  className="link-btn theme-cl "
                                                              >
                                                                  <i className="ti-control-play" />
                                                              </button>
                                                          </div>
                                                      </div>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                      </TabPanel>
                                  )
                                )}

                          </SwipeableViews>    
                      </Box>
                  </div>
              </div>
          </div>


          {/* <div className="modal fade" id="popup-video" tabIndex={-1} role="dialog" aria-labelledby="popup-video" aria-hidden="true"
                  data-backdrop="static"
                  data-keyboard="false"> 
            <div className="modal-dialog modal-dialog-centered" role="document">
                <span className=" video-close" data-dismiss="modal" aria-hidden="true" onClick={() => setVideoPlay(!isVideoPlay)}>
                  <i className="ti-close" />
                </span>
                <ReactPlayer url={playingVideo} playing={isVideoPlay} controls={true}/>
              </div>
        </div> */}

    </>
  )
}

export default Video