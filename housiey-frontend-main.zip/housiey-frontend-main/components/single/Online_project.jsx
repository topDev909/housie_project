import * as React from 'react';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import { useState, useEffect } from "react";
import Olamodel from '../Olamodel';
import { useDispatch, useSelector } from "react-redux";
import { searchProjects, select_project } from "../../redux/slices/projectsSlice";
import { set_modal_state, set_signup_title, set_thank_u_modal, set_ola_modal_tab, set_active_tab } from '../../redux/slices/signUpModalSlice';

const Online_project = () => {

  const [processUrl, setProsessUrl] = useState('no_redirect');
  const [thankTitle, setThankTitle] = useState('Sign-Up');
  const [searchKeywords, setSearchKeywrods] = useState('');
  const dispatch = useDispatch();
  const selectedProject = useSelector((state) => state.projects.selectedProject)
  const [mylist, setMylist] = useState([])


  const mykey = async (keyword) => {
    setSearchKeywrods(keyword)
    if (keyword !== '') {
      let cityDataLocal = JSON.parse(localStorage.getItem('houseiy_location'));
      let obj = {
        keywords: keyword,
        city_id: cityDataLocal.city_id
      }
      let search_projects = await dispatch(searchProjects(obj)); // this is for redux
      if (search_projects.payload) {
        setMylist(search_projects.payload.projects)
      }
    } else {
      setMylist([])
    }
  }
  // const mykey = async (keyword) => {
  //   let search_projects = await dispatch(searchProjects(keyword)); // this is for redux
  //   if (search_projects.payload) {
  //     setMylist(search_projects.payload.projects)
  //   }
  // }

  const [olaFormErr, setOlaFormErr] = useState('');
  const openmodel = () => {
    setOlaFormErr('');

    if (selectedProject.length === 0) {
      let msg = <><span className="text-danger ml-4" >Please Select Any Project</span> </>
      setOlaFormErr(msg)
      return;
    }
    // localStorage.setItem('modal_type', 'ola_modal');
    setProsessUrl('ola_modal');
    dispatch(set_signup_title('Onlien Presentation'));
    dispatch(set_ola_modal_tab(false));
    dispatch(set_active_tab('2'))
    $('#olamodal').modal('show');

    // if (localStorage.getItem('housey_token')) {
    //   dispatch(set_thank_u_modal(false));
    // }
    // else {
    //   dispatch(set_modal_state(false))
    //   $('#login').modal('show')
    // }
  }



  return (

    <div>
      {/* ============================ Hero Banner  Start================================== */}
      <div className="image-cover hero_banner" id="free-visit" style={{ background: 'url(/assets/img/online-presentation1.png) no-repeat', paddingTop: 0, minHeight: 320 }} data-overlay={0}>
        <div className="container">
          {/* <h1 class="big-header-capt mb-2" style="font-size:2rem;text-transform: uppercase;">Book Free Site Visit</h1> */}
          {/* <p class="text-center mb-4">Find new & featured property located in your local city.</p> */}
          {/* Type */}
          <div className="row">
            <div className="col-xl-10 col-lg-12 col-md-12">

              <h1 className="big-header-capt" style={{ fontSize: '1.7rem', textAlign: 'left', color: '#234e70', marginBottom: 0 }}>Online project Presentation</h1>
              <p className="font-weight-normal text-dark" style={{paddingLeft: 0}}>Directly by Builder Team | Latest Offers | Live Flat Tour</p>
              <div className="full_search_box nexio_search" style={{ background: 'transparent', padding: '0 0 0' }}>
                <div className="search_hero_wrapping">
                  <div className="row">
                    <div className="col-lg-12">
                      <div className="input-group">
                        {/* <input type="text" className="form-control search-fiel" placeholder="Search projects for online presentation" /> */}
                        <Stack>
                          <Autocomplete
                            multiple
                            options={mylist}
                            freeSolo={true}
                            value={selectedProject}
                            getOptionLabel={(option) => option.project_name}

                            onChange={(event, value) => dispatch(select_project(value))}
                            renderInput={(params) => (
                              <TextField
                                {...params}
                                variant="standard"
                                placeholder="Search multiple projects for Online Presentation"
                                className="form-control search-field"
                                onChange={(e) => { mykey(e.target.value) }}
                              />
                            )}
                          />
                        </Stack>
                        <div className="input-group-append">
                          <button type="button" onClick={openmodel} className="input-group-text theme-bg b-0 text-light" style={{ width: 175, cursor: "-webkit - grab; cursor: grab" }}> Schedule Presentation</button>
                        </div>
                        <b>{olaFormErr}</b>
                      </div>

                    </div>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>

      {/* ============================ Hero Banner End ================================== */}
    </div>


  )
}

export default Online_project;
