import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import * as React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import Head from "next/head"
import Online_sidebar from '../Online_sidebar';
const Section_header = () => {
    return (
        <>

   <section id="detail" style={{ background: "#f4f8fa" }}>
  <div className="container">
    <div className="row">
      <div className="col-lg-12">
        <div className="row">
          <div className="col-lg-12 col-md-12">
            <div className="property_lexible-1">
              <div className="pr-price-into flex-1">
                <div className="_card_list_flex">
                  <div className="_card_flex_01">
                    <h4
                      className="listing-name verified"
                      style={{ fontSize: 12 }}
                    >
                      <a
                        href="single-property-1.html"
                        className="prt-link-detail"
                      />
                      <a href="#">Home</a> &gt; <a href="#">Mumbai</a> &gt;
                      Thane
                    </h4>
                  </div>
                </div>
                <h2>Lodha Codename Premier</h2>
                <p>
                  <span>
                    By <a href="#">Builder Name</a>
                  </span>{" "}
                  |{" "}
                  <span>
                    <a href="#"> Dombivali, Mumbai</a>
                  </span>
                </p>
              </div>
              <div className="price_into_last">
                <h2>
                  <i className="fas fa-rupee-sign" /> 35 - 50{" "}
                  <span style={{ fontSize: 15 }}> Lac All Inc.</span>{" "}
                  {/* <span>USD/mo</span> */}
                </h2>
              </div>
            </div>
          </div>

          <div className="col-md-8">
            <div className="product-images demo-gallery">
              <div className="_exlio_129">Save 4 Lac</div>
              <div className="main-img-slider">
                            
                <Carousel autoPlay={true} showArrows={false} dynamicHeight={true}>
                <div>          
                    <img src="assets/img/p-1.png" />
                </div>
                <div>          
                    <img src="assets/img/p-1.png" />
                </div>
                <div>          
                    <img src="assets/img/p-1.png" />
                </div>
                <div>          
                    <img src="assets/img/p-1.png" />
                </div>
                <div>          
                    <img src="assets/img/p-1.png" />
                </div>
                <div>          
                    <img src="assets/img/p-1.png" />
                </div>
                </Carousel>
              </div>
            </div>
            {/* End Product Images & Alternates */}
          </div>
          <Online_sidebar/>
        </div>
      </div>
    </div>
  </div>
</section>

        </>
    )
}

export default Section_header
