import Head from 'next/head';
import React,{useState,useEffect} from 'react';
import { Markup } from 'interweave';
import striptags from 'striptags';
import { useRef } from 'react';



const LocationModal = ()=>{

  
  const [locationSegg,setLocationSegg] = useState([]);
  const [selectedLocationID,setSelectedLocationID]= useState();
  const [LocationLabel, setLocationLabel] = useState();
  const [get_location, set_location] = useState();

  const HERE_API_KEY = 'EBtkpbQla3PsF4wn40e8R5G-Ld5dNupdTRKtItmFY54';

  const GetSuggestions = async (e)=>{
    let check = e.target.value;
    setLocationLabel(e.target.value);
    let url   = `https://autocomplete.geocoder.ls.hereapi.com/6.2/suggest.json?apiKey=${HERE_API_KEY}&query=${check}&beginHighlight=%3Cb%3E&endHighlight=%3C/b%3E&matchLevel=`

    // current_location
    const response = await fetch(url);
    const data     = await response.json();
    if(data.suggestions){
      setLocationSegg(data.suggestions)
    }
}

const SetLocationfn = async (location_id,location_label)=>{
  
  const url                    = `https://geocoder.ls.hereapi.com/6.2/geocode.json?locationid=${location_id}&jsonattributes=1&gen=9&apiKey=${HERE_API_KEY}`;
  const response               = await fetch(url);
  const location_info_data     = await response.json();

    
  location_label = striptags(location_label)
  setSelectedLocationID(location_id);
  setLocationLabel(location_label);

  if(location_info_data.response.view[0].result[0].location.address){
    let full_address  = location_info_data.response.view[0].result[0].location.address;
    let lat_long_data = location_info_data.response.view[0].result[0].location.displayPosition;
    let set_location_obj = {
      label:      full_address.label      ?full_address.label:'',
      city:       full_address.county     ?full_address.county:'',
      country:    full_address.country    ?full_address.country:'',
      state:      full_address.state      ?full_address.state:'',
      postalcode: full_address.postalCode ?full_address.postalCode:'',
      longitude:  lat_long_data.longitude ?lat_long_data.longitude:'',
      latitude:   lat_long_data.latitude  ?lat_long_data.latitude:'' 
    }
    // console.log(set_location_obj)
    // set_location(location_info_data.response.view[0].result[0].location)
    set_location(set_location_obj)
    setLocationSegg([]);
  } 
}


const GetCurrentLocation =  async ()=>{
  if ("geolocation" in navigator) {

      navigator.geolocation.getCurrentPosition(async function(position) {
        let long  = position.coords.longitude;
        let lat   = position.coords.latitude;

        let url = `https://revgeocode.search.hereapi.com/v1/revgeocode?at=${long}%2C${lat}&lang=en-US`;
        let get_data = await fetch(url, {
          method: 'GET',
          headers: {
            Authorization: "Bearer s"+HERE_API_KEY
          }
        });

        let json_res = await get_data.json();
        console.log(json_res);
        
      });
    } else {
      console.log("Not Available");
    }
}
const location_input_ref = useRef();



  return(
    <>

        <Head>
          <link rel="stylesheet" href="/assests/css/search.css"/> 
        </Head> 
        {/* start */}

        
        <div id="mybottam_nav" className="container-fluid bottam_nav" style={{height:"75%"}}>
        
  
        <div className="row p_top_10">
          <hr></hr>

          <div className="col-12 button_filter_clic p_top_20">
            <div className="filter_box-da">Select Location</div>     
            <i className="fa fa-times" onClick={()=>closeModal(false)}></i>
          </div>             
        </div>
  <div className="row pl-2 pr-2"> 
    <div className="col-12">
      <div className="reletive">
      </div>    
    </div>
    <div className="col-12 location-text">
      <i className="fa fa-map-marker-alt" />
      <input type="text" ref={location_input_ref} className="address-input"  placeholder="Enter Location"  onChange={GetSuggestions} autoComplete={'off'} value={LocationLabel}    />
      <ul className="location-suggestions" onClick={()=>closeModal(false)}>
                        {locationSegg.length > 0 ?  locationSegg.map((SingleLocation)=>{
                          return (
                            <>
                                <li className="suggested-list  " onClick={()=>{SetLocationfn(SingleLocation.locationId,SingleLocation.label)}} style={{ cursor:"pointer" }} key={SingleLocation.locationId}  >
                                    <Markup content={SingleLocation.label} />  
                                </li>
                            </>
                          )
                        })
                        :
                        <>
                     
                        </>
                        }
                        </ul>
    </div>
    <div className="col-12 p_top_20 text-center">
      OR
    </div>
    <div className="col-12 p_top_20 text-center">
      <button type="button" className="choose-location" onClick={GetCurrentLocation}>Choose Your Current Location <i className="fa fa-location" /></button>
    </div>
  </div>
</div>

  {/* End */}

    </>
  )
}
export default LocationModal;