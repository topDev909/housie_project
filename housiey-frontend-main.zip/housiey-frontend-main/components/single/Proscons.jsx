import React from 'react'
import { Markup } from 'interweave';
import { useState } from 'react';
const Proscons = ({ setpros, setcons}) => {

    // const [pros, setPros] = useState(setpros)
    // const [cons, setCons] = useState(setcons)


    const pros = setpros;
    const cons = setcons;
    

  return (
    <>
          <div className="_prtis_list" id="procandcons" style={{marginBottom: '1rem'}}>
              <div className="_prtis_list_header min">
                  <h4 className="m-0">
                      Pros &amp; <span className="theme-cl">Cons</span>
                  </h4>
              </div>
              <div className="row">
                  <div className="col-lg-12">
                      <div className="faq_wrap">
                          <div className="faq_wrap_body ">
                              <div className="accordion" id="generalac">
                                  <div className="card">
                                      <div className="card-header" id="headingOne" 
                                      style={{background: "#0080002b", borderRadius: 0}}>
                                          <h2 className="mb-0">
                                              <button
                                                  className="btn btn-link"
                                                  type="button"
                                                  data-toggle="collapse"
                                                  data-target="#collapseOne"
                                                  aria-expanded="true"
                                                  aria-controls="collapseOne"
                                              >
                                                  <i className="fas fa-thumbs-up"></i>  Pros
                                              </button>
                                          </h2>
                                      </div>
                                      <div
                                          id="collapseOne"
                                          className="collapse show"
                                          aria-labelledby="headingOne"
                                          data-parent="#generalac"
                                      >
                                          <div className="card-body">
                                              <ul style={{ paddingLeft: "10px", color:"#000" }}>
                                                  {
                                                      pros.map((items) => {
                                                          return (<>
                                                              {items.tag ? <>
                                                                  <li><Markup content={items.tag} /></li>
                                                              </> : <><li><Markup /></li></>}
                                                          </>)
                                                      })
                                                  }

                                              </ul>
                                          </div>
                                      </div>
                                  </div>
                                  <div className="card">
                                      <div className="card-header" id="headingTwo"
                                      style={{background: "#ff000030", borderRadius: 0}}>
                                          <h2 className="mb-0">
                                              <button
                                                  className="btn btn-link collapsed"
                                                  type="button"
                                                  data-toggle="collapse"
                                                  data-target="#collapseTwo"
                                                  aria-expanded="false"
                                                  aria-controls="collapseTwo"
                                              >
                                                  <i className="fas fa-thumbs-down"></i>   Cons
                                              </button>
                                          </h2>
                                      </div>
                                      <div
                                          id="collapseTwo"
                                          className="collapse"
                                          aria-labelledby="headingTwo"
                                          data-parent="#generalac"
                                      >
                                          <div className="card-body">
                                              <ul style={{ paddingLeft: "10px", color:"#000" }}>
                                                  {/* <li><Markup content={item.tag} /></li> */}
                                                  {
                                                      cons.map((item) => {
                                                          return (<>
                                                              {item.tag ? <>
                                                                  <li><Markup content={item.tag} /></li>
                                                              </> : <>   <li><Markup /></li> </>}
                                                          </>)
                                                      })
                                                  }
                                              </ul>
                                          </div>
                                      </div>
                                  </div>

                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
    </>
  )
}

export default Proscons