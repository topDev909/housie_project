
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import { useEffect, useState } from 'react'
import Tooltip from '@mui/material/Tooltip';
import Link from 'next/link'
import { slugGenrator } from '../../utils/BasicFn';
const Propertiesnew = ({ project,location }) => {


  const [detalis, setDetalis] = useState([])
  // const [mylocation, setMylocation] = useState(location[0])
  const mylocation = location[0];
 
  useEffect(() => {
    if (project.length) {
      fetch(`${process.env.BASE_URL}get-similer-projects/${project[0].id}`)
        .then((result) => {
          result.json().then((response) => {
            setDetalis(response.projects)
          })
        })
    }
  }, []);

  // console.log("detalisdetalis", detalis)

  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 3
    },

    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 3
    },

    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2
    },

  };


  return (

    <>

      <section className="pt-30 min bg-light" id="similar-projects">
        <div className="container">

          <div className="row justify-content-center">
            <div className="col-lg-7 col-md-8">
              <div className="sec-heading center">
                <h2>Similar Projects</h2>
              </div>

            </div>
          </div>

          {/* <div className="row justify-content-center"> */}
          {/* Single Property */}

          <Carousel responsive={responsive} autoPlay={false} removeArrowOnDeviceType={["tablet", "mobile"]} infinite={true} shouldResetAutoplay={true}>
            {detalis && detalis.map((items, index) =>

              <div key={index}>
                <div className="property-listing property-2">
                  <div className="listing-img-wrapper">
                    <div className="list-img-slide">
                      <div className="click">
                        <div>
                          {/* <a  target={"_blank"} href="#"> */}
                          <Link href={"/in/" + mylocation.city + "/" + items.location + "/" + items.slug}>
                            <img
                              src={process.env.BASE_URL + items.images}
                              className="mx-auto"
                              alt='img'
                            />
                          {/* </a> */}
                          </Link>
                        </div>

                      </div>
                    </div>
                  </div>
                  <div className="listing-detail-wrapper">
                    <div className="listing-short-detail-wrap">
                      <div className="_card_list_flex">
                        <div className="_card_flex_01">
                          <h4 className="listing-name verified">
                            <a  target={"_blank"} href={"/in/" + mylocation.city + "/" + items.location + "/" + items.slug} className="prt-link-detail" rel="noopener noreferrer" >
                              {items.project_name}
                            </a>
                          </h4>
                          <div style={smilardesign}>
                          <p className="mb-0">
                              By <Link href={"/in/" + mylocation.city + "/" + slugGenrator(items.builder)} style={design}>{items.builder}</Link>
                          </p>
                            <a  target={"_blank"} href={"/in/" + mylocation.city + "/" + slugGenrator(items.location)} rel="noopener noreferrer" >
                                <p className="mb-0"> 
                                  <i className="fas fa-map-marker-alt"></i> {items.location}
                                </p>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="price-features-wrapper">
                  
                    <div className="list-fx-features mb-1">
                      {items.config.length > 9 ? <>
                        <Tooltip title={items.config}>
                          <div className="listing-card-info-icon">
                            <div className="inc-fleat-icon">
                              <i className="fas fa-bed" />
                            </div>
                            {items.config}
                          </div>
                        </Tooltip>
                      </> : <>
                      
                        <div className="listing-card-info-icon">
                          <div className="inc-fleat-icon">
                            <i className="fas fa-bed" />
                          </div>
                          {items.config}
                        </div>
                      </>}
                      
                      <div className="listing-card-info-icon">
                        <div className="inc-fleat-icon">
                          <i className="fas fa-vector-square" />
                        </div>
                        {items.area_range_min + '-' + items.area_range_max}sqft
                      </div>
                    
                      
                    </div>
                    {/* </div> */}
                   
                    <div className="listing-card-info-icon">
                      <div className="inc-fleat-icon">
                        <i className="far fa-file-alt" />
                      </div>
                      {items.target_possession}
                    </div>
                  </div>
                  <div className="listing-detail-wrapper">
                    <div className="listing-short-detail-wrap">
                      <div className="_card_list_flex mb-2">
                        <div className="_card_flex_01">
                          <h6 className="listing-card-info-price mb-0">
                            <i className="fas fa-rupee-sign" /> {items.overall_price_range}
                          </h6>
                        </div>
                        <div className="_card_flex_last">
                          <span className="_list_blickes types">
                          <a  target={"_blank"} href={"/in/" + mylocation.city + "/" + items.location + "/" + items.slug} className="prt-link-detail" rel="noopener noreferrer" >
                            View Details
                          </a>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            )
            }
          </Carousel>

          {/* End Single Property */}

          {/* </div> */}

        </div>
      </section>

    </>
  )
}
// Css
const smilardesign =
{
  display:"flex",
  justifyContent:"space-between"
}

const design=
{
  textDecoration:"underline"
}

export default Propertiesnew
