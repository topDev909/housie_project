const KeyPoints = ({ data }) => {
    let det = data.split(',');
    // console.log('thi s ies fakl fadjks',data)
    return (
        <>
            {det.map((item, inex) => (
                <li key={inex} style={{ color: "#000" }}>
                    - {item}
                </li>
            ))}

        </>
    )
}

export default KeyPoints;