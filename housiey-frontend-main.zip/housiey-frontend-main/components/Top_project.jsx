/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @next/next/link-passhref */
/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */
import React, { useEffect, useState }                                         from 'react';
import Link                                                                   from 'next/link';
import Olamodel                                                               from './Olamodel'
import Project_modal                                                          from './Project_modal'
import { useDispatch,useSelector }                                            from "react-redux";
import { set_modal_state,set_ola_modal_tab,set_thank_u_modal,set_active_tab } from '../redux/slices/signUpModalSlice';
import { GenrateSearchURL,slugGenrator } from '../utils/BasicFn';


import { select_project } from "../redux/slices/projectsSlice";

import SingleProjectList from './inc/SingleProjectList';


const Top_project = ({SendLocationLink,SendBuilderLink}) => {
  const dispatch = useDispatch();
  const [cityname, setCityname]         = useState([])
  const [city_id,setCityId]             = useState();
  const [cityproduct, setCityproduct]   = useState([])
  const [projectname,setProjectname]    = useState([])
  const [getRangeID,setRangeId]         = useState('');
 const [cityInfo,setCityInfo]           = useState('');
 const [AllProjectURL,SetAllProjectURL] = useState('');

  useEffect(async () => {
    let cityData = JSON.parse(localStorage.getItem('houseiy_location'));
    let cityID   = '';
      if(cityData){
        cityID   = cityData.city_id;
        setCityId(cityID);
        setCityInfo(cityData);
      }else{
        let fetcheCity       = await fetch(process.env.BASE_URL+'get-default-city');
        if(fetcheCity.ok){
          let cityFetchData  = await fetcheCity.json();
          cityID = cityFetchData.data[0].city_id;
          setCityId(cityID);
          setCityInfo(cityFetchData.data[0]);
          cityData = cityFetchData.data[0];
        }
      }
      const response = await fetch(process.env.BASE_URL+"top-range-tabs/"+cityID);
      let result     = await response.json();
      if(result.tabs.length > 0){
        setCityname(result.tabs) 
        if (result.tabs[0].range_id){
          let range_id    = result.tabs[0].range_id;
          let range_title = result.tabs[0].price_raneg.toLowerCase().replace("under", ""); 
          
          // let matches = result.tabs[0].price_raneg.match(/\d+/g);
          // console.log(matches);

          let slug        = slugGenrator(range_title);
          let cityName    = cityData.name.toLowerCase();
          let url         = '/in/'+cityName+"/under/"+slug+"/projects"; 
          SetAllProjectURL(url)
          setRangeId(range_id)
        }
      }

    // }
  }, [])


  useEffect(()=>{
    if(getRangeID){
      rangedataid()
    }
  },[getRangeID])

  // range by city
    const rangedataid = async(rId='')=>{
      let rngId = (rId)?rId:getRangeID;
      const response = await fetch(process.env.BASE_URL+`top-range-projects/${city_id}/${rngId}/`);
      let result     = await response.json();
      setCityproduct(result.projects)
    }

  // fetch data
  const rangedata =(data)=>{
    let cityData    = JSON.parse(localStorage.getItem('houseiy_location'));

    let range_id    = data.range_id;
    let range_title = data.price_raneg.toLowerCase().replace("under", "");; 
    let slug        = slugGenrator(range_title,range_id);
    let cityName    = cityData.name.toLowerCase();
    let url         = '/in/'+cityName+"/under/"+slug+"/projects"; 
    
    SetAllProjectURL(url)
    rangedataid(range_id)
  }

  // Open MOdal function
  const openmodal = (value)=>{

    let arr = [];
    let obj = {
      id: value.p_id,
      project_name: value.project_name,
      slug: value.slug
    }
    arr.push(obj);
    dispatch(select_project(arr));
    dispatch(set_ola_modal_tab(true));
    dispatch(set_active_tab('1'));
    $('#olamodal').modal('show');
    
  
  }


 
    return (
        <div>
            <section className="min" id="top-projects">
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-lg-7 col-md-8">
          <div className="sec-heading center">
            <h2>Top Projects In {cityInfo && cityInfo.name} </h2>
            </div>
        </div>
      </div>
      <div className="property_block_wraps">
        <div className="property_block_wrap_header">
          <ul
            className="nav nav-pills tabs_system"
            id="pills-tab"
            role="tablist"
          >
            {cityname.map((city,i)=>
             <>
             
            <li className="nav-item" key={i} >
              
              <a
                className={(i === 0) ? 'nav-link   active' : 'nav-link  '}
                id="pills-property-tab "
                data-toggle="pill"
                href="#pills-property"
                role="tab"
                aria-controls="pills-property"
                aria-selected="true"
                onClick={()=>{rangedata(city)}}
                 >
                  {city.price_raneg} 
              </a>
            </li>
                 
                </>
              )}

              {AllProjectURL && <>
                <li  className='ml-auto ' >
                  <Link href={AllProjectURL} >
                      <button className="link-btn"  >
                        View All Projects <i style={{fontSize:"10px"}} className="fas fa-arrow-right"></i>
                      </button>
                    </Link>
                </li>
              </>}
          </ul>
        </div>
        <div className="block-bodys">
          <div className="sidetab-content">
            <div className="tab-content" id="pills-tabContent">
              {/* Book Now Tab */}
              <div
                className="tab-pane fade show active"
                id="pills-property"
                role="tabpanel"
                aria-labelledby="pills-property-tab"
              >
                <div className="row justify-content-center">
                    {cityproduct && cityproduct.map((product,i)=>
                      <SingleProjectList item={product} myModal={openmodal} SendLocationLink={SendLocationLink} SendBuilderLink={SendBuilderLink} key={i} cityName={cityInfo.name} />
                    )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
        <Project_modal select_projectname ={projectname}/>
        </div>
    )
}



export default Top_project
