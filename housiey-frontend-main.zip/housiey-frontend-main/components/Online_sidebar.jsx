import * as React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';

const Online_sidebar = () => {
    return (
        <>
            
        <div className="page-sidebar p-0">
          <div className="block-body">
            <ul className="nav nav-tabs floor_plans" id="myTab" role="tablist">
              <li className="nav-item">
                <a
                  className="nav-link active"
                  id="buy-tab"
                  data-toggle="tab"
                  href="#buy"
                  role="tab"
                  aria-controls="all"
                  aria-selected="true"
                >
                  Online Presentation
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link"
                  id="1bed-tab"
                  data-toggle="tab"
                  href="#1bed"
                  role="tab"
                  aria-controls="1bed"
                  aria-selected="false"
                >
                  Book Free Site Visit
                </a>
              </li>
            </ul>
            <div className="tab-content" id="myTabContent">
              {/* All Tabs */}
              <div
                className="tab-pane fade show active"
                id="buy"
                role="tabpanel"
                aria-labelledby="buy-tab"
              >
                {/* Single List */}
                <div className="row justify-content-center">
                  <div className="login-form"  >
                    <form>
                      <div className="form-group">
                        {/* <label>Search Project for Online Presentation</label> */}
                        <div className="input-with-icon">
                          <input
                            type="text"
                            className="form-control"
                            placeholder="Search Project for Online Presentation"
                          />
                          <i className="ti-search" />
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-6">
                          <div className="form-group">
                            {/* <label>Date</label> */}
                            <div className="input-with-icon">
                              <input
                                type="date"
                                className="form-control"
                                style={{ paddingLeft: "4px!important" }}
                              />
                              {/* <i class="ti-search"></i> */}
                            </div>
                          </div>
                        </div>
                        <div className="col-6">
                          <div className="form-group">
                            {/* <label>Time</label> */}
                            <div className="input-with-icon">
                              <input type="time" className="form-control" style={{ paddingLeft: "0px!important" }} />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="form-group">
                        <label>Preffered Source</label>
                        <br />
                        
                        <div style={{ display: "flex" }}>
                          <RadioGroup
                              aria-labelledby="demo-radio-buttons-group-label"
                              defaultValue="OLA"
                              name="radio-buttons-group"
                            >
                            <span>
                                  <FormControlLabel value="OLA"   control={<Radio  />} label={<img src="/assets/img/zoom.jpeg" width="60" />} id="ola_lebel"/>
                            </span>
                            
                            <span>
                                <FormControlLabel value="gmeet"   control={<Radio  />} label={<img src="/assets/img/gmeet.jpeg" width="60" />} id="gmeet_label"/>
                            </span>

                            <span>
                                <FormControlLabel value="teams"   control={<Radio  />} label={<img src="/assets/img/teams.jpeg" width="60" />} id="m_teams" />
                            </span>
                          </RadioGroup>
                        </div>
                      
                      </div>
                      
                      <ul style={{ paddingLeft: 0 }}>
                        <li>
                          <i className="fas fa-check" /> Directly form Builder
                          Salesperson
                        </li>
                        <li>
                          <i className="fas fa-check" /> Latest Offer &amp;
                          Payment Schemes
                        </li>
                        <li>
                          <i className="fas fa-check" /> Live Sample Flat Tour
                        </li>
                      </ul>
                      <div className="form-group">
                        <button
                          type="submit"
                          className="btn btn-md full-width pop-login"
                        >
                          Schedule Online Presentation
                        </button>
                      </div>
                      {/* <div class="form-group text-center">
															
																		By Continuing, you agree to our<a href="#"> Terms & Conditions</a>
																
														</div> */}
                    </form>
                  </div>
                </div>
              </div>
              <div
            className="tab-pane fade"
            id="1bed"
            role="tabpanel"
            aria-labelledby="1bed-tab"
          >
  <div className="row justify-content-center">
    <div className="login-form" style={{ width: "80%" }}>
      <form>
        <div className="form-group">
     
          <div className="input-with-icon">
            <input
              type="text"
              className="form-control"
              placeholder="Search Project for Online Presentation"
            />
            <i className="ti-search" />
          </div>
        </div>
        <div className="row">
          <div className="col-6">
            <div className="form-group">
              <label>Date</label>
              <div className="input-with-icon">
                <input
                  type="date"
                  className="form-control"
                  style={{ paddingLeft: "4px!important" }}
                />
                {/* <i class="ti-search"></i> */}
              </div>
            </div>
          </div>
          <div className="col-6">
            <div className="form-group">
              <label>Time</label>
              <div className="input-with-icon">
                <input
                  type="time"
                  className="form-control"
                  style={{ paddingLeft: "4px!important" }}
                />
                {/* <i class="ti-search"></i> */}
              </div>
            </div>
          </div>
        </div>
        <div className="form-group">
          <label>Pick Up &amp; Drop</label>
          <br />
          <div style={{ display: "flex" }}>
            <span>

              <RadioGroup
                defaultValue="OLA"
                name="radio-buttons-group">
                <FormControlLabel value="OLA" control={<Radio />} label="OLA"/>
                <FormControlLabel value="Not" control={<Radio />} label="Not Required"/>
                  </RadioGroup>

                  
              {/* <label htmlFor="a-p" className="checkbox-custom-label">
                OLA
              </label>
            </span>
            <span>
              <input
                id="a-p"
                className="checkbox-custom"
                name="a-p"
                type="radio"
              />
              <label htmlFor="a-p" className="checkbox-custom-label">
                Not Required
              </label> */}
            </span>
          </div>
        </div>
        <ul style={{ paddingLeft: 0 }}>
          <li>
            <i className="fas fa-check" /> Free Pick Up &amp; Drop - Book
            Personal OLA
          </li>
          <li>
            <i className="fas fa-check" /> Visit your selected 3 projects in one
            tour
          </li>
          <li>
            <i className="fas fa-check" /> Just visit &amp; Decide later
          </li>
        </ul>
        <div className="form-group">
          <button type="submit" className="btn btn-md full-width pop-login">
            Schedule Free Site Visit
          </button>
        </div>
        {/* <div class="form-group text-center">
															
																		By Continuing, you agree to our<a href="#"> Terms & Conditions</a>
																
														</div> */}
      </form>
    </div>
  </div>
</div>

            </div>
          </div>
        </div>
       
        </>
    )
}

export default Online_sidebar
