import React,{useState,useEffect} from 'react';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import SignUpParks from '../component/Auth/SignUpParks';
import DownloadModalContent from './DownloadModalContent';
import Confetti from 'react-confetti'
const DownloadThankYou = ({sellerInfo,project})=>{
    const title                 =  useSelector((state)=>state.signUpModal.signup_title)
    const is_first_time_login   =  useSelector((state)=>state.signUpModal.is_first_time_login)
    const show_sign_up_perks    =  useSelector((state)=>state.signUpModal.show_sign_up_perks)
    const router                =  useRouter();

    const closeModal = ()=>{
        if(is_first_time_login){
            router.reload(window.location.reload)
        }else{
            $('#DownloadThankYou').modal('hide');
        }
    }

    /* SignUpParks */
    return (
        <>
        <div
            className="modal fade"
            id="DownloadThankYou"
            tabIndex={-1}
            role="dialog"
            aria-labelledby="DownloadThankYouLabel"
            aria-hidden="true"
        >

                <div className="modal-dialog" role="document">
                    <div className="modal-content"  style={{ borderTop: "5px solid #0e8744",overflow:'hidden' }} >

                        <Confetti width={'500px'} />

                    <span className="mod-close" onClick={closeModal}><i className="ti-close" /></span>
                    <div className="modal-body">
                        <div className={` ${show_sign_up_perks? "":"" }   `} >
                            <DownloadModalContent sellerInfo={sellerInfo} project={project} />
                        </div>
                        {show_sign_up_perks && <>
                            <div className='' >
                                <SignUpParks/>
                            </div>
                        </>}
                    </div>
                    </div>
                </div>
                </div>

        </>
    )
}
export default DownloadThankYou;