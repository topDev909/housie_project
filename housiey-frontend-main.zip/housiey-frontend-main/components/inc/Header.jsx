/* eslint-disable @next/next/no-sync-scripts */
import React,{useState,useEffect} from 'react';
import Avatar from '@mui/material/Avatar';

import Stack  from '@mui/material/Stack';
import Link   from 'next/link';

import Router, { useRouter } from 'next/router';

import { useDispatch, useSelector } from "react-redux";
import {set_modal_state,set_signup_title,set_page_type} from '../../redux/slices/signUpModalSlice';

const Header = ({get_user_data})=>{
  
  const dispatch = useDispatch();
  const router   = useRouter();


  const logoutsession = ()=>{
    localStorage.removeItem('housey_token')
    router.reload(window.location.reload)
  }
  
  const [userSession, setUserSession] = useState('');
  useEffect(() => {
    let jwt_get_data = localStorage.getItem('housey_token')
    let get_data     = parseJwt(jwt_get_data);
    setUserSession(get_data);
  }, [])

  function parseJwt(token) {
    if (!token) { return; }
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace('-', '+').replace('_', '/');
    return JSON.parse(window.atob(base64));
  }

  const openSignModal = ()=>{
    dispatch(set_modal_state(false))
    let msg = 'Sign-Up';    
    dispatch(set_signup_title(msg))
  }

    return(
        <>
        <div id="main-wrapper">
          <div className="header header-transparent change-logo">
            <div className="container">
              <nav id="navigation" className="navigation navigation-landscape">
                <div className="nav-header">
                  <a className="nav-brand static-logo" href="#">
                    <img
                      src="/assets/img/logo3.png"
                      className="logo"
                      alt="housiey-logo"
                      style={{ borderRadius: 10}}
                    />
                  </a>
                  <a className="nav-brand fixed-logo" href="#">
                    <img src="/assets/img/logo.png" className="logo" alt='housiey-logo' />
                  </a>
                  <div className="nav-toggle"/>
                  <div className="mobile_nav">
                    <ul>
                      <li>
                        <a href="#" data-toggle="modal" data-target="#login">
                          <i className="fas fa-user-circle fa-lg" />
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>

                <div
                  className="nav-menus-wrapper"
                  style={{ transitionProperty: "none"}}
                >
                  <ul className="nav-menu" id="main-menu">
                    <li>
                      <a href={"/in/pune/projects"}>Buy Property in Pune</a>
                    </li>
                  </ul>

                  <ul className="nav-menu nav-menu-social align-to-right">

                            {(userSession)?
                            <>
                            
                                {/* User Option Start */}
                                <li>
                                  <div className="btn-group account-drop">
                                    <button
                                      type="button"
                                      className="btn btn-order-by-filt login"
                                      data-toggle="dropdown"
                                      aria-haspopup="true"
                                      aria-expanded="false"
                                    >
                                      <Stack direction="row" spacing={2}>
                                        <Avatar
                                          src="/static/images/avatar/1.jpg"
                                          sx={{ width: 32, height: 32 }}
                                        />
                                        <span className="user-name" style={{textTransform: "capitalize"}}>{userSession.name} </span>
                                      </Stack>

                                    </button>
                                    <div className="dropdown-menu pull-right animated flipInX">
                                      <ul>
                                        <li onClick={logoutsession}>
                                          <a href="#" >Logout</a>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </li>



                            </>  
                          :<>
                              <li>
                                <a
                                  href="#"
                                  className="alio_green"
                                  data-toggle="modal"
                                  data-target="#login"
                                  onClick={openSignModal}
                                >
                                  <span className="dn-lg">Sign Up</span>
                                </a>
                              </li>
                          </>}
                          <li>
                                  <div className="btn-group account-drop">
                                    <button
                                      type="button"
                                      className="btn btn-order-by-filt "
                                      data-toggle="dropdown"
                                      aria-haspopup="true"
                                      aria-expanded="false" >
                                      <i className="fas fa-bars" />
                                    </button>
                                    <div className="dropdown-menu pull-right animated flipInX">
                                      <ul>
                                        <li>
                                          <Link href={"/about-us"} >
                                            <a> About Us </a>
                                          </Link>
                                        </li>
                                        <li>
                                        <Link href={"/in/pune/projects"} >
                                            <a>Buy Property in Pune </a>
                                        </Link>
                                        </li>
                                        <li>
                                          <Link href={"/privacy-policy"}>
                                          <a>Privacy policy</a>
                                          </Link>
                                        </li>
                                        <li>
                                          <Link href={"/disclaimer"}>
                                          <a>Disclaimer</a>
                                          </Link>
                                        </li>
                                        <li>
                                          <Link href={"/contact-us"} >
                                            <a>Contact Us</a>
                                          </Link>
                                        </li>
                                      </ul>

                                      <ul className="text-center" style={{padding: "15px", color: "#fff"}}>
                                        <li>
                                          <a target='_blank' rel="noreferrer" href="https://api.whatsapp.com/send?phone=918097452839&text=Hello Housiey, Need assistance   with home buying" style={{background: '#0e8744', padding: '10px', borderRadius: '5px', color: '#fff', justifyContent: 'center'}}>
                                            Support - <i className='fab fa-whatsapp' style={{top: 0, marginLeft:'4px'}}></i> 8097452839
                                            </a>
                                        </li>
                                        <li>
                                          <span className="text-center" style={{display: "flex"}}>
                                            <a href="https://www.facebook.com/housiey" target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-facebook" style={{color: "#234e70" }}></i></a>
                                            <a href="https://www.linkedin.com/company/housiey" target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-linkedin" style={{color: "#234e70"}}></i></a>
                                            <a href="https://www.youtube.com/c/Housiey" target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-youtube" style={{color: "#234e70"}}></i></a>
                                            <a href="https://www.instagram.com/housiey/" target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-instagram" style={{color: "#234e70"}}></i></a>
                                          </span>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </li>

                  </ul>
                </div>
              </nav>
            </div>
          </div>
          <div className="clearfix" />
          </div>
  </>
    )
}
export default Header;  