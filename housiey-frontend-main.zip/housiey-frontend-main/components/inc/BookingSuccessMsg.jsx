import React from 'react';
import { useSelector } from 'react-redux';
import Link from 'next/link';
import moment from 'moment';

const BookingSuccessMsg = ()=>{


    const activeTab               = parseInt(useSelector((state)=>state.signUpModal.activeTab));
    const enqueryDetails          = useSelector((state)=>state.signUpModal.modal_details)
    const show_sign_up_perks      = useSelector((state)=>state.signUpModal.show_sign_up_perks)

    return (

        <>
        
        <div id="successfull-popup" style={{marginBottom: '15px'}}>
            <div className="px-3 to-front">
              <div className="row align-items-center">
                <div className="col text-right">
                  <a
                    href="#"
                    className="close-btn"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">
                      <span className="icon-close2" />
                    </span>
                  </a>
                </div>
              </div>
            </div>
            <div className="to-front">
              <div className="text-center">
                <div className="logo">
                  <img src="/assets/img/right1.png" alt="Image" className="img-fluid" />
                </div>
                <h3>{activeTab===1?"Free Site Visit":"Online Presentation"} booked Successfully</h3>
                <p className="mb-4">You will recieve a confirmation mail shortly</p>
                <hr />
                {enqueryDetails && <>
                <div className="project-details">
                  {(enqueryDetails.source==='ola' || enqueryDetails.source==='Not-Required') ? <span>Site Visit Booked for</span> :  <span>Online Presentation</span> }
                  

                  <div className="project-name text-center">

                    {enqueryDetails.projectDetails.map((sinel_project,index)=>(
                      <>
                        <Link href={'/in/'+sinel_project.url}>
                          <a  className="btn btn-project">
                            {sinel_project.name} 
                          </a>
                        </Link>
                        </>
                      ))}  
                  </div>
                  
                  <div className="other-details text-left">
                    <div className='row'>
                    <div className='col-md-6'>
                      <span>Date &amp; Time</span><br></br>
                      <span>
                        <img className="calendar" src="/assets/img/calendar.png" /> 
                        {/* {enqueryDetails.enquiry_datetime.split(" ")[0]} {enqueryDetails.enquiry_datetime.split(" ")[1]} */}
                        {moment(enqueryDetails.enquiry_datetime).format('h:mm a ddd, DD MMMM YYYY ')}
                      </span>
                    </div>
                    {/* <h1>{enqueryDetails.source}</h1> */}

                    {enqueryDetails.source==='zoom' && <> 
                      <div className='col-md-6'>
                      <span>Source</span><br></br>
                      <span>
                        <img className="calendar" src="/assets/img/zoom.jpeg" />Zoom
                      </span>
                      </div>
                    </>}

                    {enqueryDetails.source==='gmeet' && <> 
                      <div className='col-md-6'>
                      <span>Source</span><br></br>
                      <span>
                        <img className="calendar" src="/assets/img/gmeet.jpeg" />Gmeet
                      </span>
                      </div>
                    </>}

                    {enqueryDetails.source==='teams' && <> 
                      <div className='col-md-6'>
                      <span>Source</span><br></br>
                      <span>
                        <img className="calendar" src="/assets/img/teams.jpeg" />Teams
                      </span>
                      </div>
                    </>}
                    </div>
                    <br></br>
                    {enqueryDetails.source==='ola' && <>
                      <span>
                        <img className="ola" src="/assets/img/ola.png" /> Cab details will be
                        shared 1 hr before the scheduled time
                      </span>
                    </>}
                    {(enqueryDetails.source!=='ola' && enqueryDetails.source!=='Not-Required') && <>
                    <br></br>
                    <span>
                      <img className="ola" src="/assets/img/bell.png" /> Meeting details will be shared 1 hr 
                      before the scheduled time
                    </span>
                    </> }



                    
                    
                    <br></br>
                    
                    <span>
                      For any queries, kindly contact your Housiey Relationship Manager
                    </span>
                    <br />
                    <span  >
                      <img src="/assets/img/user.png" /> 
                      <span  >
                       {enqueryDetails.sellerInfo.name} - {enqueryDetails.sellerInfo.phone} 
                      </span>

                      <span style={{ float:'right' }}>

                      <a href={`https://api.whatsapp.com/send?phone=91${enqueryDetails.sellerInfo.phone}&text=Hello,  *${enqueryDetails.sellerInfo.name}*  Need More Details about the  *${enqueryDetails.projects[0].project_name}*  `} className="btn btn-chat" target="_blank" rel="noopener noreferrer" >
                        <i className="fab fa-whatsapp" /> Live Chat with RM
                      </a>
                      </span>
                    </span>
                  </div>
                </div>
                </>}
              </div>
              
            </div>
          </div>
        </>
    )
}
export default BookingSuccessMsg;