import React from 'react';
import FormComponent from "./component/FormComponent";

import { useDispatch, useSelector } from "react-redux";
import { searchProjects, select_project } from "../redux/slices/projectsSlice";
import { useRouter } from 'next/router';


const NewOlaModal = ({ mygetdata}) => {
    
    const router   = useRouter();
    const dispatch = useDispatch();

    const crossBtn = ()=>{
        dispatch(select_project([]))   
        let modal_type = localStorage.getItem('modal_type')
        localStorage.removeItem('modal_type')
        $('#olamodal').modal('hide');
        if(modal_type && modal_type==='ola_modal'){
            router.reload(window.location.reload)
        }
    }
    
  return (
      <>
          <div
              className="modal fade"
              id="olamodal"
              tabIndex={-1}
              role="dialog"
              aria-labelledby="free_site_visit_modal"
              aria-hidden="true"
                data-backdrop="static"
                data-keyboard="false"
          >
              <div className="modal-dialog login-pop-form" role="document">
                  {/* modal-content overli  /it is class/ */}

                  
                  <div className=" " id="free_site_visit_modal">
                      <div className="modal-body p-0">
                          <div className="resp_log_wrap">
                              <div className="resp_log_caption col">
                                  <span className="mod-close"  onClick={crossBtn}>
                                      <i className="ti-close" />
                                  </span>
                                  <div className='' >
                                    <FormComponent seldata={mygetdata}/>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </>
  )
};

export default NewOlaModal;
