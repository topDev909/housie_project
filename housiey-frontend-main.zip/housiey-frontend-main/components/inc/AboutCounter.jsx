import React from 'react';
import CountUp from 'react-countup';

const AboutCounter = ()=>{
    return (
        <>
<section className="image-cover about-counter-section" style={{ background: "#234e70 url(/assets/img/pattern.png) no-repeat" }} >
    <div className="container">
        <div className="row justify-content-center">
        <div className="col-xl-7 col-lg-10 col-md-12 col-sm-12">
            <div className="text-center mb-5">
            <span className="text-light">Our Achievements</span>
                <h2 className="font-weight-normal text-light">Housiey has presence in Mumbai, Pune &amp; Bangalore &amp; so far we have facilitated </h2>
            </div>
        </div>
        </div>
        <div className="row justify-content-center">
        <div className="col-lg-2 col-md-6 col-4">
            <div className="_morder_counter">
            <div className="_morder_counter_thumb">
                <i className="ti-calendar" />
            </div>
            <div className="_morder_counter_caption">
                <h5 className="text-light">
                <span>
                    <CountUp delay={2} end={6} />+
                </span>
                </h5>
                <span className="text-light">Years</span>
            </div>
            </div>
        </div>
        <div className="col-lg-3 col-md-6 col-4">
            <div className="_morder_counter">
            <div className="_morder_counter_thumb">
                <i className="ti-car" />
            </div>
            <div className="_morder_counter_caption">
                <h5 className="text-light">
                <span><CountUp delay={2} end={12000} />+</span>
                </h5>
                <span className="text-light">Site Visits</span>
            </div>
            </div>
        </div>
        <div className="col-lg-2 col-md-6 col-4">
            <div className="_morder_counter">
            <div className="_morder_counter_thumb">
                <i className="ti-desktop" />
            </div>
            <div className="_morder_counter_caption">
                <h5 className="text-light">
                <span><CountUp delay={2} end={2300} />+</span>
                </h5>
                <span className="text-light">Presentations</span>
            </div>
            </div>
        </div>
        <div className="col-lg-3 col-md-6 col-6">
            <div className="_morder_counter">
            <div className="_morder_counter_thumb">
                <i className="ti-face-smile" />
            </div>
            <div className="_morder_counter_caption">
                <h5 className="text-light">
                <span><CountUp delay={2} end={3500} />+</span>
                </h5>
                <span className="text-light">Happy Customers</span>
            </div>
            </div>
        </div>
        <div className="col-lg-2 col-md-6 col-6">
            <div className="_morder_counter">
            <div className="_morder_counter_thumb">
                <i className="ti-heart" />
            </div>
            <div className="_morder_counter_caption">
                <h5 className="text-light">
                <span><CountUp delay={2} end={3} /></span>
                </h5>
                <span className="text-light">Cities</span>
            </div>
            </div>
        </div>
        </div>
    </div>
</section>
        </>
    )
}
export default AboutCounter;