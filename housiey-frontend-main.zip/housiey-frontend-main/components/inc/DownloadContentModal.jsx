import React,{useState,useEffect} from 'react';
import DownloadSignUpForm from '../component/Auth/DownloadSignUpForm';
import {useDispatch,useSelector} from 'react-redux';


const DownloadContentModal = ({project})=>{
    const dispatch   = useDispatch();
    const title      = useSelector((state)=>state.signUpModal.signup_title)

    let showTitle    =  (title!=='video') ? "Get " + project.project_name +" "+ title :  project.project_name + " Watch Full Video";
    const closeModal = ()=>{
        $('#download-content-modal').modal('hide')
    }
    return (
        <>  
            <div
                className="modal fade"
                id="download-content-modal"
                data-bs-backdrop="static"
                data-bs-keyboard="false"
                tabIndex={-1}
                aria-labelledby="download-content-modal-Label"
                aria-hidden="true"
            >
                <div className="modal-dialog resp_log_caption p-0">
                <div className="modal-content" style={{width: '400px', margin: '0 auto'}}>
                    <div className="modal-header">
                    <h5 className="modal-title" id="download-content-modal-Label">
                        {showTitle}
                    </h5>
                    <button
                        type="button"
                        className="btn-close"
                        onClick={closeModal}
                    >
                        <i className='fa fa-times'></i>
                    </button>
                    </div>
                    <div className="modal-body p-0" id="download-content-modal-body" >
                        <DownloadSignUpForm/>
                    </div>
                </div>
                </div>
            </div>
        </>
    )
}
export default DownloadContentModal;