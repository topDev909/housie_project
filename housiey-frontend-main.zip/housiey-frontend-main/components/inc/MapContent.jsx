import React,{useEffect,useState} from 'react';
import GoogleMap               from 'google-map-react';
import {round_num} from '../../utils/BasicFn';

const AnyReactComponent = ({ text }) => <div className='google-map-marker'></div>;




function createMapOptions(maps) {
  // next props are exposed at maps
  // "Animation", "ControlPosition", "MapTypeControlStyle", "MapTypeId",
  // "NavigationControlStyle", "ScaleControlStyle", "StrokePosition", "SymbolPath", "ZoomControlStyle",
  // "DirectionsStatus", "DirectionsTravelMode", "DirectionsUnitSystem", "DistanceMatrixStatus",
  // "DistanceMatrixElementStatus", "ElevationStatus", "GeocoderLocationType", "GeocoderStatus", "KmlLayerStatus",
  // "MaxZoomStatus", "StreetViewStatus", "TransitMode", "TransitRoutePreference", "TravelMode", "UnitSystem"
  return {
    zoomControlOptions: {
      position: maps.ControlPosition.RIGHT_CENTER,
      style: maps.ZoomControlStyle.SMALL
    },
    mapTypeControlOptions: {
      position: maps.ControlPosition.TOP_RIGHT
    },
    mapTypeControl: true
  };
}



const MapContent = ({lat,lng})=>{
    const defaultProps = {
        center: {
          lat: round_num(lat),
          lng: round_num(lng)
        },
        zoom: 11
      };
    return(
        <>

<div style={{ height: '50vh', width: '100%' }}>
      
        <GoogleMap 
            bootstrapURLKeys={{ key: process.env.MAP_KEY2 }}
            center={{
              lat: round_num(defaultProps.center.lat),
              lng: round_num(defaultProps.center.lng)    
            }}
            zoom={11}
            options={createMapOptions}
          >
            <AnyReactComponent
              lat={defaultProps.center.lat}
              lng={defaultProps.center.lng}
              text="My Marker"
            />
        </GoogleMap>
                    
      </div>
        </>
    )
}
export default MapContent;