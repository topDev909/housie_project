import React,{useEffect,useState} from 'react';
import { useSelector } from 'react-redux';
import SignUpParks from '../component/Auth/SignUpParks';
import BookingSuccessMsg from './BookingSuccessMsg';
import Link from 'next/link';


const ThanksModalContent = ()=>{
    const activeTab               = parseInt(useSelector((state)=>state.signUpModal.activeTab));
    const enqueryDetails          = useSelector((state)=>state.signUpModal.modal_details)
    const show_sign_up_perks      = useSelector((state)=>state.signUpModal.show_sign_up_perks)



   
    return (
        <>  
          {show_sign_up_perks ? <>
          <div className='row' id="modal-with-sign-up-parks"  >
            <div className='col-md-6 border-right' >
               <BookingSuccessMsg   />
            </div>
            <div className='col-md-6' >
                <SignUpParks/>
            </div>
          </div>
          </> :  <> <BookingSuccessMsg  /> </> }
        </>
    )
}
export default ThanksModalContent