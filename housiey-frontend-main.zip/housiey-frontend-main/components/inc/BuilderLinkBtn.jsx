import React from 'react';
import Link from 'next/link';
import {slugGenrator} from '../../utils/BasicFn';
const BuilderLinkBtn = ({name,id,text})=>{
    let slug = slugGenrator(name,id)
    return (
        <>
        <Link href={'/builders/'+slug} >
           <a className='link' >{text}</a>
        </Link>
        </>
    )
}
export default BuilderLinkBtn;