import React from 'react';
import { slugGenrator } from '../../utils/BasicFn';
import Link from 'next/link';
const SingleProjectList = ({ item, myModal, SendBuilderLink, SendLocationLink, cityName }) => {


  let locality = slugGenrator(item.location);
  let singleProjectSlug = `/in/${cityName}/${locality}/${item.slug}`;

  return (
    <>

      <div className="col-xl-6 col-lg-12 col-md-12 col-sm-12">
        <div className="property-listing list_view">
          <div className="listing-img-wrapper ">
            <div className="_exlio_125">
              <i className="fas fa-street-view " />
            </div>
            <div className="_exlio_126">
              <i className="far fa-play-circle" />
            </div>
            <div
              className="_exlio_128"
              data-toggle="tooltip"
              data-placement="top"
              data-original-title="Save property">
              <a href="#">
                <i className="far fa-heart" />
              </a>
            </div>
            <div className="list-img-slide">
              <Link href={singleProjectSlug}>
                <a
                  target="_blank"
                >
                  <img
                    src={process.env.BASE_URL + item.image}
                    className="img-fluid mx-auto"
                    alt='new-lauches data'

                  />
                </a>
              </Link>
            </div>
          </div>
          <div className="list_view_flex">
            <div className="listing-detail-wrapper mt-1">
              <div className="listing-short-detail-wrap">
                <div className="_card_list_flex">
                  <div className="_card_flex_01">
                    <h4 className="listing-name verified">
                      <Link href={singleProjectSlug}>
                        <a className="prt-link-detail" target="_blank">
                          {item.project_name}
                        </a>
                      </Link>
                    </h4>
                    <p className="builder-name">
                      By <button className='link-btn'
                        onClick={() => SendBuilderLink(item.builder, item.builder_id)} >
                        {item.builder}
                      </button>

                      <button className='link-btn' style={{ float: 'right' }} onClick={() => SendLocationLink(item.location, item.locality_id)} >
                        <i className="fas fa-map-marker-alt" /> &nbsp; {item.location}
                      </button>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="price-features-wrapper">
              <div className="list-fx-features">
                <div className="listing-card-info-icon">
                  <div className="inc-fleat-icon">
                    <i className="fas fa-bed" />
                  </div>
                  {item.config}
                </div>

                <div className="listing-card-info-icon  text-right">
                  <div className="inc-fleat-icon">
                    <i className="fas fa-vector-square" />
                  </div>
                  {item.area_range_max} sqft
                </div>
              </div>
              <div className="list-fx-features">

                <div className="listing-card-info-icon">
                  <div className="inc-fleat-icon">
                    <i className="far fa-file-alt" />
                  </div>
                  {/* Possession */}
                  {item.possession}
                </div>
              </div>
            </div>
            <div className="_card_list_flex mb-2">

              <div className="_card_flex_last">
                <h6 className="listing-card-info-price mb-0">
                  <i className="fas fa-rupee-sign" /> {item.overall_price_range} <sub  className='all-inc'>(All inc)</sub>
                </h6>
              </div>
            </div>

            <div className="listing-detail-footer">
              <div className="footer-first">
                <span className="schedule-view"
                  onClick={() => myModal(item)}
                >
                  <i className="fa fa-desktop"></i>  &nbsp; | &nbsp; <i className="fa fa-car"></i> &nbsp; Tour
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

    </>
  )
}
export default SingleProjectList;