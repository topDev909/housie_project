import React from 'react';
import { useRouter } from 'next/router';
import { useSelector } from 'react-redux';
import { useEffect,useState } from 'react';
import {useDispatch} from 'react-redux';
import {select_project} from '../../redux/slices/projectsSlice';
import ThanksModalContent from './ThanksModalContent';
import Confetti from 'react-confetti'
const LoginThankModal  = ()=>{
   const dispatch = useDispatch();
   const router   = useRouter();
    const is_refreash       = useSelector((state)=>state.signUpModal.is_first_time_login);
    const activeTab         = parseInt(useSelector((state)=>state.signUpModal.activeTab));
    const enqueryDetails    = useSelector((state)=>state.signUpModal.modal_details)
    const show_sign_up_perks      = useSelector((state)=>state.signUpModal.show_sign_up_perks)


    // const [SellerInfo,setSellerInfo] = useState('');
    // useEffect(()=>{
    //   // get-seller-project
    //   let p_id = enqueryDetails.projects[0].id;
    //   const CallFn = async ()=>{
    //     let query = await fetch(process.env.BASE_URL+'get-seller-project/'+p_id);
    //     if(query.ok){
    //       let result = query.json();
    //       if(result.res===true){
    //         let data  = result.data[0];
    //         setSellerInfo(data)
    //       }
    //     }
    //   }
    //   CallFn();
    // },[])
    
    const CloseModal = ()=>{
      dispatch(select_project([])) 
      $('#login-thank-you-modal').modal('hide');
      if(is_refreash){
        router.reload(window.location.reload)
      }
    }

    const width = show_sign_up_perks ? "1000px": "500px"

    return (
        <>
            <div
              className="modal fade"
              id="login-thank-you-modal"
              tabIndex={-1}
              role="dialog"
              aria-labelledby="authomessage"
              aria-hidden="true"
                data-backdrop="static"
                data-keyboard="false"
            >
              <div
                className={`modal-dialog modal-dialog-centered login-pop-form  ${show_sign_up_perks?'modal-xl':''}  `}
                role="document"
                style={{ maxWidth:  (show_sign_up_perks) ?'1120px':'500px' }} >
                <div
                  className="modal-content"
                  id="authomessage"
                  style={{ borderTop: "5px solid #0e8744",overflow:'hidden' }}
                >

                  <Confetti width={width} />
                  <span className="mod-close" onClick={CloseModal}>
                    <i className="ti-close" />
                  </span>
                  <div className="modal-body">
                      <ThanksModalContent/>
                  </div>
                </div>
              </div>
            </div>
        </>
    )
}
export default LoginThankModal;