import React,{useState,useEffect} from 'react';
import {useSelector} from 'react-redux';
import { useRouter } from 'next/router';
const DownloadModalContent = ({sellerInfo,project})=>{
    const title                 =  useSelector((state)=>state.signUpModal.signup_title)
    
    return (
        <>
            
            <div className="to-front" id="successfull-popup" >
                        <div>
                            <div className="logo" style={{textAlign: 'center'}}>
                            <img src="/assets/img/right1.png" alt="Image" className="" />
                            </div>
                            <h3 style={{textAlign: 'center'}}>{title} Downloaded Successfully</h3>
                            <span style={{textAlign: 'center'}}> For any queries, kindly contact your Housiey Relationship Manager </span>
                            <br />
                            <br />
                            <div>
                            <span><img src="/assets/img/user.png"  alt="Image" width={'6%'} /> </span>
                            
                            <span>
                                {sellerInfo[0].name} - {sellerInfo[0].phone} 
                            </span>

                            <span style={{ float:'right' }}>
                                <a href={`https://api.whatsapp.com/send?phone=91${sellerInfo[0].phone}&text=Hello,  *${sellerInfo[0].name}*  Need More Details about the  *${project.project_name}*  `} className="btn-chat-whatsapp" target="_blank" rel="noopener noreferrer" >
                                    <i className="fab fa-whatsapp" /> Live Chat with RM
                                </a>
                            </span>
                            </div>
                                
                            <hr />
                        </div>
                </div>
        </>
    )
}
export default DownloadModalContent;