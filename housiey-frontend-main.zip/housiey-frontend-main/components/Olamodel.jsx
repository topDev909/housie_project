import React,{useState} from 'react';
import FormComponent from "./component/FormComponent";

import { useDispatch, useSelector } from "react-redux";
import { searchProjects, select_project } from "../redux/slices/projectsSlice";
import { set_form_step,set_ola_modal_tab } from "../redux/slices/signUpModalSlice";
import { useRouter } from 'next/router';


const Olamodel = ({ mygetdata}) => {
    const router = useRouter();
    const dispatch = useDispatch();
    const [session,setSession] = useState('');
    const steps = useSelector((state)=>state.signUpModal.form_step)
    const [getStep,setStep] = useState(0);
    React.useEffect(()=>{
        let token = localStorage.getItem('housey_token');
        setSession(token);
        setStep(steps);
    },[])

    const crossBtn = ()=>{
        dispatch(select_project([]))   
        localStorage.removeItem('modal_type')
        $('#olamodal').modal('hide');
        dispatch(set_form_step(0));
        dispatch(set_ola_modal_tab(true));
    }
    
  return (
      <>
          <div
              className="modal fade"
              id="olamodal"
              tabIndex={-1}
              role="dialog"
              aria-labelledby="free_site_visit_modal"
              aria-hidden="true"
                data-backdrop="static"
                data-keyboard="false"
          >
              <div className="modal-dialog login-pop-form" role="document">                  
                  <div className=" " id="free_site_visit_modal">
                      <div className="modal-body p-0">
                          <div className="resp_log_wrap">
                              <div className="resp_log_caption col">
                                  <span className="mod-close"  onClick={crossBtn}>
                                      <i className="ti-close" />
                                  </span>
                                  <div className='' >
                                    <FormComponent seldata={mygetdata} session={session} stepsCount={getStep}/>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </>
  )
};

export default Olamodel;
