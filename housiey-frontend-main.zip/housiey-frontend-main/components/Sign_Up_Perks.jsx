/* eslint-disable react/no-unescaped-entities */
/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */
import React from 'react';
import ReactTooltip from 'react-tooltip';

const Sign_Up_Perks = () => {
    return (
        <div>
            <section className="p-0 mb-4" id="home-policy">
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-xl-11 col-lg-11 col-md-12 policy">
          <div className="_awards_group">
            <ul className="_awards_lists">
              {/* single list */}
              <li>
                <div className="_awards_list_wrap">
                  <div className="_awards_list_thumb">
                    <img
                      src="assets/img/no-brokerage.svg"
                      className="img-fluid"
                            alt=''
                      width="70%"
                    />
                  </div>
                  <div className="_awards_list_caption">
                    <h5 className="theme-cl">No Brokerage</h5>
                    {/* <span>Annual Awards</span> */}
                  </div>
                </div>
              </li>
              {/* single list */}
              <li>
                <div className="_awards_list_wrap">
                  <div className="_awards_list_thumb">
                    <img
                      src="assets/img/bottom-rate.svg"
                      className="img-fluid"
                            alt=''
                      width="60%"
                    />
                  </div>
                  <div className="_awards_list_caption">
                    <h5 className="theme-cl-2">
                      Bottom Rate Policy{" "}
                      <p style={{display: 'inline-flex'}}>
                      <i 
                      data-tip="Housiey guarantees its clients Bottom Rate, 
                      else will refund double the price difference."                       
                        className="fas fa-info-circle"
                        style={{ fontSize: "1rem" }}
                      />
                      <ReactTooltip  />
                      </p>
                    </h5>
                    {/* <span>Filka Vivo Award</span> */}
                  </div>
                </div>
              </li>
              {/* single list */}
       
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* ============================ Our Awards End ================================== */}
  {/* ============================ Sign Up Perks Start ================================== */}
  <section className="min">
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-lg-7 col-md-8">
          <div className="sec-heading center">
            <h2>Sign Up Perks</h2>
          </div>
        </div>
      </div>
      <div className="row justify-content-center">
        <div className="col-lg-3 col-md-6 col-sm-12">
          <div className="wpk_process"> 
            <div className="wpk_thumb">
              <div className="wpk_thumb_figure">
                <img src="assets/img/bonus.svg" className="img-fluid" alt='' />
              </div>
            </div>
            <div className="wpk_caption">
              <h4>Referral Bonus Refer Housiey &#38; get bonus upto Rs 2lac</h4>
              <p>Get Flat Bonus Amount directly credited to your account</p>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-6 col-sm-12">
          <div className="wpk_process active">
            <div className="wpk_thumb">
              <div className="wpk_thumb_figure">
                <img src="assets/img/free-cab.svg" className="img-fluid" alt='' />
              </div>
            </div>
            <div className="wpk_caption">
              <h4>Free Site Visit</h4>
              <p>
                Get Free Pickup &amp; Drop for unlimited project's in the entire
                city.
              </p>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-6 col-sm-12">
          <div className="wpk_process">
            <div className="wpk_thumb">
              <div className="wpk_thumb_figure">
                <img
                  src="assets/img/bottom-rate.svg"
                  className="img-fluid"
                        alt=''
                />
              </div>
            </div>
            <div className="wpk_caption">
              <h4>Bottom Rate Guarantee</h4>
              <p>
                Rock Bottom Prices Guaranteed in return otherwise, get double
                the discount form us.
              </p>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-6 col-sm-12">
          <div className="wpk_process">
            <div className="wpk_thumb">
              <div className="wpk_thumb_figure">
                      <img src="assets/img/manager.svg" className="img-fluid" alt='' />
              </div>
            </div>
            <div className="wpk_caption">
              <h4>Relationship Manager</h4>
              <p>
                Get personalized RM managing everything from site visit to
                booking.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <div className="clearfix" />
        </div>
    )
}

export default Sign_Up_Perks
