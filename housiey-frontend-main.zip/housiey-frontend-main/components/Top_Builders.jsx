/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @next/next/link-passhref */
/* eslint-disable @next/next/no-img-element */
/* eslint-disable jsx-a11y/alt-text */

import React, { useEffect, useState, Component } from 'react'
import Slider from "react-slick";


let blank_img = "admin/uploads/builders/1643368034019-img.webp";
const Top_Builders = ({SendLocationLink,SendBuilderLink}) => {

  const settings = {
    className: "center",
    centerMode: true,
    infinite: true,
    centerPadding: "10px",
    slidesToShow: 3,
    speed: 500,
    rows: 3,
    slidesPerRow: 1,
    
  };


const[logo,setLogo]=useState([])
const [builderid, setBuilderid] = useState([])

const [cityInfo,setCityInfo] = useState()

  // builder logo api
  useEffect(async()=>{

    // let cityData = JSON.parse(localStorage.getItem('houseiy_location'));
    let cityData = '';
    if(cityData){

    }else{
      let fetcheCity  = await fetch(process.env.BASE_URL+'get-default-city');
        if(fetcheCity.ok){
          let cityFetchData  = await fetcheCity.json();
          cityData = cityFetchData.data[0];
        }
    }
    


    if(cityData)
    {
      setCityInfo(cityData)
      let cityName   = cityData.name;
      const getlogo  = await fetch(process.env.BASE_URL +"get-builders-logos?city="+cityName);
      let data       = await getlogo.json();
      

      
      let arr = [];
      data.logos.forEach(element => {
        arr.push(element)
      });
      
      
      let li = 3-data.logos.length%3
      for (let index = 0; index < li; index++) {
        const element = data.logos[index];
        arr.push(element)
      }
      setLogo(arr)
      if(data.logos[0].id){
        let id =  data.logos[0].id;
        builder(id)
      }
      else{
        return false;
      }
      
  }
  },[])


  //  builder detalis api
  const builder = async(id) => {
    
    const response = await fetch(process.env.BASE_URL +`builder-info/${id}/`);
    let data = await response.json();
    if (data.res===true){
      setBuilderid(data.builder_info)
    }
  }

  const myid=(e)=>{
   
   builder(e)

  }

    return (
        <div>
           <section className="gray-simple pt-4 pb-4" id="top-builders">
  <div className="container">
    <div className="row justify-content-center">
      <div className="col-lg-7 col-md-8">
        <div className="sec-heading center">
          <h2>Top Builders in {cityInfo && cityInfo.name}</h2>
        </div>
      </div>
    </div>
    {/* row Start */}
    <div className="row">
      <div className="col-lg-4 col-md-6 col-sm-12 builder-details">
                 {
                    builderid.map((detalis) =>
                    <>                 
                      <div className="story-wrap explore-content text-center">
                        <div className="builder-name">
                        <h4 className="builder-name">{detalis.builder_name}</h4>
                          <div className="_rate_stio">
                                
                            <i className="fa fa-star" />
                            <i className="fa fa-star" />
                            <i className="fa fa-star" />
                            <i className="fa fa-star" />
                            <i className="fa fa-star" />
                          </div>
                        </div>
                        <div className="experience">
                          <div className="row">
                            <div className="col-lg-6 exp">
                            <span>Experience { detalis.experience}</span>
                            </div>
                            <div className="col-lg-6 pro">
                            <span>Total Projects {detalis.projects_comp}</span>
                            </div>
                          </div>
                        </div>
                        <div className="about">
                          <p>
                            {detalis.description.substring(0, 200) + "..."}
                            <button type="button" className='link-btn' 
                            onClick={()=>SendBuilderLink(detalis.builder_name,detalis.id)} >Read More</button>  
                          </p>
                          <button onClick={()=>SendBuilderLink(detalis.builder_name,detalis.id)}  className="link-btn" >
                            View all Projects <i className="fas fa-arrow-right" />
                          </button>
                        </div>
                      </div>
                    </>

                  )
                }
      </div>
      <div className="col-lg-8 col-md-6 col-sm-12">
               
                  <Slider {...settings}>
                  
                  {logo.map((items,index) =>
                      
                      <div className="" key={index}>
                        <a href="javascript:void(0)">
                          <div className=" mb-4">
                            <div className="">
                              <div className="">
                                <div className="">
                                    
                                   <img src={process.env.BASE_URL+items.logo} 
                                    className="img-fluid builder-single-logo"
                                    alt='builder-logo'
                                    onClick={()=>{myid(items.id)}}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </a>
                      </div>
                      
                    )
                  }
                  </Slider>
                  
      </div>
    </div>
    {/* /row */}
  </div>
</section>

        </div>
    )
}

export default Top_Builders
