import React from 'react';
import styles from './UnderConstruction.module.css';
const UnderConstruction = ()=>{
    return (
        <>
        <header className={styles.header}>
          <p>Site is Construction </p>
        </header>
        {/* <div className={styles.body}>
          <div className={styles.overlay} />
          <div className={styles.stars}   aria-hidden="true" />
          <div className={styles.starts2} aria-hidden="true" />
          <div className={styles.stars3}  aria-hidden="true" />
          <main className={styles.main} >
            <section className={styles.contact}>
              <h1 className={styles.title}>
                <img src="/assets/img/logo1.png" width={'400px'} />
              </h1>
              <h2 className={styles.subTitle}>Site Under Construction</h2>
              <h3 className={styles.details}>
                For Queries Please Contact : Ronak Pandya <a href="tel:917021912976" className={styles.underline} > 91-7021912976 </a> or <a href="tel:917769072111" className={styles.underline}> 91-7769072111 </a>  
              </h3>
            </section>
          </main>
        </div> */}
        </>
    )
}

export default UnderConstruction;