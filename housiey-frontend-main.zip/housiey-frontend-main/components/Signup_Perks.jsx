import React from 'react'

import PhoneInput from 'react-phone-number-input';
import { useState,useEffect } from 'react';
import 'react-phone-number-input/style.css';
import { useDispatch, useSelector } from "react-redux";
import { set_modal_state, set_signup_title, set_mobile_number,set_sent_otp} from '../redux/slices/signUpModalSlice';

const Signup_Perks = () => {

  const dispatch = useDispatch();
  let r_mobile = useSelector((state) => state.signUpModal.mobileNumber)
  const [number, setNumber] = useState(r_mobile);
  const [dataMobile,setDataMobile] = useState('');
  const [phone, setPhone]          = useState('');
  const [error,setError]           = useState('');
  
  const validate =()=>{
    if (r_mobile && r_mobile.length >1){
     setDataMobile(number);
     let title = 'Free Sign-Up';
     dispatch(set_signup_title(title))
     dispatch(set_sent_otp(true))
     $('#login').modal('show');
     setError('')
    }
  else{
     let error =<><span className='text-danger'>Mobile Number is required for Sign Up</span></>
      setError(error)
      return false;
   }
   
  }

  const getNumberOnchange = (e)=>{
    setNumber(e)
    dispatch(set_mobile_number(e))
  }

    return (
        <>
         <div className="card">
          <div className="card-header">
            <h6>Sign Up Perks</h6>
          </div>
          <div className="ground-list ground-list-hove">
            <div className="ground ground-single-list">
              <a href="#">
                <div
                  className="btn-circle-40 theme-cl theme-bg-light"
                  style={{ border: "none" }}
                >
                  <img src="/assets/img/bonus.svg" className="img-fluid" alt='img' />
                </div>
              </a>
              <div className="ground-content">
                <h6>
                  <b>Referral Bonus
Refer Housiey &#38; get bonus upto Rs 2lac</b>
                </h6>
                <span className="small">
                  Get Flat Bonus Amount directly credited to your account
                </span>
              </div>
            </div>
            <div className="ground ground-single-list">
              <a href="#">
                <div
                  className="btn-circle-40 theme-cl theme-bg-light"
                  style={{ border: "none" }}
                >
                  <img
                    src="/assets/img/free-cab.svg"
                    className="img-fluid"
                    alt='img'
                  />
                </div>
              </a>
              <div className="ground-content">
                <h6>
                  <b>Free Site Visit</b>
                </h6>
                <span className="small">
                  Get Free Pickup &amp; Drop for unlimited projects in the
                  entire city.
                </span>
              </div>
            </div>
            <div className="ground ground-single-list">
              <a href="#">
                <div
                  className="btn-circle-40 theme-cl theme-bg-light"
                  style={{ border: "none" }}
                >
                  <img
                    src="/assets/img/bottom-rate.svg"
                    className="img-fluid"
                    alt='img'
                  />
                </div>
              </a>
              <div className="ground-content">
                <h6>
                  <b>Bottom Rate Guarantee</b>
                </h6>
                <span className="small">
                  Rock Bottom Prices Guaranteed in return otherwise, get double
                  the discount form us.
                </span>
              </div>
            </div>
            <div className="ground ground-single-list">
              <a href="#">
                <div
                  className="btn-circle-40 theme-cl theme-bg-light"
                  style={{ border: "none" }}
                >
                  <img src="/assets/img/manager.svg" className="img-fluid" alt='img' />
                </div>
              </a>
              <div className="ground-content">
                <h6>
                  <b>Relationship Manager</b>
                </h6>
                <span className="small">
                  Get personalized RM managing everything from site visit to
                  booking.
                </span>
              </div>
            </div>
            
            <div className=" ground-single-list row" id="side-View-sign-up" >

              

                      <div className="col-8 p-0">
                        <div className="form-group">
                        <PhoneInput
                            placeholder="Enter phone number"
                            countryCallingCodeEditable={false}
                            defaultCountry="IN"
                            international
                            style={{ border: "1px solid #e7eaf1" }}
                            className="form-control search_input "
                            value={r_mobile}
                            onChange={getNumberOnchange}
                          />
                        </div>
                      </div>
                  <div className="col-4 p-0 ">
                
                  <div className="form-group none">
                    <button href="#" className="btn otp-btn pl-2 pr-2" type='button' onClick={validate} >
                      Send OTP
                    </button>
                  </div>
              


              </div>
            </div>
          </div>
        </div>   
        </>
    )
}

export default Signup_Perks
