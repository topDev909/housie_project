import React,{useState,useEffect} from 'react';

import { useDispatch, useSelector } from "react-redux";
import { getFilters,set_min_max_budget,selectFilter,getCities,applyFilters } from "../../redux/slices/filterSlice";
import FlatType from "./filterBtns/FlatType";
import DownPaymentBtn from './filterBtns/DownPaymentBtn';
import PosessionBtn from './filterBtns/PosessionBtn';
import DropDown from './filterBtns/DropDown';
import MoreFilters from './filterBtns/MoreFilters';


import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';

import { useRouter } from 'next/router';
import { makeStyles } from "@material-ui/core/styles";

import {slugGenrator,GenrateSearchURL} from '../../utils/BasicFn';




const useStyles = makeStyles({
    paper: {
      border: "0px solid black",
      borderRadius: "0px !important",
      marginTop: "11px"
    }
  });
  

const HeaderSearchBox = ()=>{

    
  const dispatch          = useDispatch();
  const router            = useRouter();
  const ResetFilter                         = useSelector((state)=>state.filter.allFilters.reset_filter)

  const classes           = useStyles();
  
  const [query, setQuery]                  = useState([]);
  const [mykeyword, setMykeyword]          = useState('');
  const [cityData,setCityData]             = useState([]);
  const [selectedMainCity,setSelectedCity] = useState([]);
  

  const findcat = (e,value)=>{

    if(value===null){
    }
    else{
      let obj={
        id:value.id,
        type:value.type,
        title:value.title
      }
      setMykeyword(value.option_title)
      sendUrl(value)
    }
  }

  
 const searchCity = async ()=>{
    let   city_data   = JSON.parse(localStorage.getItem('houseiy_location'));
    let   city_name   = city_data.name.toLowerCase();
    await router.push('/in/'+city_name+"/projects");
   }
  
    const sendUrl = async (value)=>{
      let   url        = '';
      let reset_filter = {
        type: 'reset_filter',
        filter: 0,
        make_search: 0,
      }
      dispatch(selectFilter(reset_filter));
      url = GenrateSearchURL(value,query)
      await router.push('/'+url);
    }
  

    
  useEffect(()=>{
    const fnCall = async ()=>{
      let defaultCities  = localStorage.getItem('houseiy_location');
        if(defaultCities){
          defaultCities = JSON.parse(defaultCities);
        }
        let fetchCity = await fetch(process.env.BASE_URL+'getCities');

        if(fetchCity.ok){
          let city_result = await fetchCity.json();
          setCityData(city_result.cities);
          for (let city_i = 0; city_i < city_result.cities.length; city_i++) {
            if(defaultCities){
              if(defaultCities.city_id===city_result.cities[city_i].city_id){
                setSelectedCity(city_result.cities[city_i].city_id)
                localStorage.setItem('houseiy_location',JSON.stringify(city_result.cities[city_i]))
                break;
              }
            }else if(city_result.cities[city_i].default_city){
                setSelectedCity(city_result.cities[city_i].city_id)
                let obj = {
                  type: 'city_id',
                  filter: city_result.cities[city_i].city_id
                }
                localStorage.setItem('houseiy_location',JSON.stringify(city_result.cities[city_i]))
                break;
              }
            }
        }


      // let mainSearchText = details.substring(0, details.lastIndexOf("-"))
    //   let mainSearchText     = details.replaceAll('-'," ");
    //   if(page_type!=='under_projects' && page_type!=='listing'){
    //     setMykeyword(mainSearchText)
    //   }
        // fetchAllFilters()
      }


      fnCall();
  },[])

  
  const myvalue = (e)=>{
    setMykeyword(e)
    let cityLocalData  =  JSON.parse(localStorage.getItem('houseiy_location'));
    let selectedCity   =  cityLocalData.city_id;
    let key = e;
    if (key){
      fetch(process.env.BASE_URL + `search/${selectedCity}/${key}`).then(result => {
        result.json().then((response) => {
          let opt_arr = [];
          if (response.builders.length > 0) {
            for (let b_i = 0; b_i < response.builders.length; b_i++) {
              let title  = <>{response.builders[b_i].builder_name} <span className="side-title" > Builder</span></>
              let b_slug = slugGenrator(response.builders[b_i].builder_name)
              let b_obj  = {
                title:         title,
                option_title:  response.builders[b_i].builder_name,
                id:            b_slug,
                type:          "builders"
              }
              opt_arr.push(b_obj)
            }
          }
          if (response.locality.length > 0) {
            for (let l_i = 0; l_i < response.locality.length; l_i++) {
              let title  = <>{response.locality[l_i].name} <span className="side-title" > Locality</span></>
              let b_slug = slugGenrator(response.locality[l_i].name)
              let l_obj = {
                title: title,
                option_title: response.locality[l_i].name,
                id: b_slug,
                type: "locality"
              }
              opt_arr.push(l_obj)
            }

          }
          if (response.projects.length > 0) {
            for (let p_i = 0; p_i < response.projects.length; p_i++) {
              let title         = <>{response.projects[p_i].project_name} <span className="side-title" > Project</span></>
              let locality_clug = slugGenrator(response.projects[p_i].locality);
              let project_id    = locality_clug+'/'+response.projects[p_i].slug;
              let p_obj = {
                title: title,
                option_title: response.projects[p_i].project_name,
                id: project_id,
                type: "projects"
              }
              opt_arr.push(p_obj)
            }
          }
          else {
            
          }
          setQuery(opt_arr)
        })
      })
   }else{
      setQuery([])
   }
    

}


    return (
        <>

        
<Stack className="listing-main-search col-8 p-0 pl-2"   >



<Autocomplete
  options={query}
  freeSolo={true}
  inputValue={(mykeyword)?mykeyword:''}
  onChange={findcat}
  getOptionLabel={(option) => option.option_title}
  classes={{ paper: classes.paper }}
  renderOption={(props, option) => (
<>
      <div className='option-list'  {...props} >
        {option.title}
      </div>
</>
)}
  renderInput={(params) => (
    <>
    <TextField
      {...params}  
      id="main-search-box-input"
      variant="standard"  
      className="form-control search_input b-0 main-search-box-input"
      placeholder='Search  Project, locality or builder'
      name="project_slug"
      onChange={(e)=>{
        myvalue(e.target.value)}}
      />
    </>
  )}
  
/>
</Stack>

        </>
    )
}
export default HeaderSearchBox;