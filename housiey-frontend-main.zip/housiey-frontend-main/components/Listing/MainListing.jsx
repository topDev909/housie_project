import React,{useState,useEffect} from 'react';
import {useDispatch} from 'react-redux';
import ListingHeader from './ListingHeader';
import Headerfillter from './Headerfillter';
import All_properties from './All_properties';
import { selectFilter } from '../../redux/slices/filterSlice';
import {useRouter} from 'next/router';
 

const MainListing = ({search_query,page_type,details})=>{

    const dispatch              = useDispatch(); 
    const [citName,setCityName] = useState('');
    const router = useRouter();


    useEffect( async()=>{
        let cityData = JSON.parse(localStorage.getItem('houseiy_location'));
        if(cityData){
            setCityName(cityData.name)
        }else{
            
            let fetcheCity       = await fetch(process.env.BASE_URL+'get-default-city');
            if(fetcheCity.ok){
                let cityFetchData  = await fetcheCity.json();
                cityData = {"city_id":cityFetchData.data[0].city_id,"name":cityFetchData.data[0].name,"default_city":1};
                localStorage.setItem('houseiy_location',JSON.stringify(cityData))
            }
        }

        let obbj = {
            type: 'reset_filter',
            filter: ''
        }
        dispatch(selectFilter(obbj))

        if(page_type==='locality'){
            let localityid = details.substring(details.lastIndexOf("-") + 1, details.length);
            let obbj = {
                type: 'locality_id',
                filter: localityid
            }
            dispatch(selectFilter(obbj))
        }

        if(page_type==='listing'){
            let obbj = {
                type: 'city_id',
                filter: cityData.city_id
            }
            dispatch(selectFilter(obbj))
        }


        if(page_type==='under_projects'){
            let words       = details.replace(/[0-9]/g, '');
            let matches     = details.match(/\d+/g);
            words           = words.replace(/-/g, '');

            let {locality}  = router.query();

            let minPrice    = matches[0] * 100000; 
            let maxPrice    = (matches.length > 2) ? matches[1] * 100000 : matches[0] * 100000;

            if(locality){

                let obj = {
                    filter: minPrice+','+maxPrice,
                    type: 'budget'
                }
                dispatch(selectFilter(obj)) 

            }


            if(matches.length > 2){
                let obj = {
                    filter: minPrice+','+maxPrice,
                    type: 'budget'
                }
                dispatch(selectFilter(obj))   
            }else{                
                let obj = {
                    filter: minPrice,
                    type: 'budget'
                }
                dispatch(selectFilter(obj))   
            }
        }





    },[search_query,page_type,details])
   

    return (
        <>

         <ListingHeader  search_query={search_query} page_type={page_type} details={details} />
         <Headerfillter  search_query={search_query} page_type={page_type} details={details} /> 
         <All_properties search_query={search_query} page_type={page_type} details={details} />


        </>
    )
}
export default MainListing;