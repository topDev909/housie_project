import React from 'react';
import Link from 'next/link';
const BreadCums = ()=>{
    return (
        <>
          <ul className="breacums-ul">
            <li>
                <Link to={'/'} >
                    <a  >Home</a>
                </Link> 
            </li>

          </ul>

        </>
    )
}
export default BreadCums;