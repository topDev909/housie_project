import  React,{useState,useEffect}  from 'react';
import Signup_Perks                 from '../Signup_Perks';
import { useDispatch, useSelector } from "react-redux";
import { selectFilter,applyFilters,set_filters } from "../../redux/slices/filterSlice";
import { select_project } from "../../redux/slices/projectsSlice";
import { set_modal_state,set_ola_modal_tab,set_thank_u_modal } from "../../redux/slices/signUpModalSlice";
import ConfigList              from './filterBtns/ConfigList';
import ProjectTitle            from './filterBtns/ProjectTitlte';
import WhatsAppBtn             from './filterBtns/WhatsAppBtn';
import FormComponent           from '../component/FormComponent';
import {parseJwt,numFormatter} from '../../utils/BasicFn';
import BuilderName             from './filterBtns/BuilderName';
import Link                    from 'next/link';
import Sitevisit               from '../Sitevisit';
import Online_project          from '../single/Online_project';



const All_properties = ({search_query,page_type,details}) => {

  const dispatch                      = useDispatch();
  const [filterdData,setFilterdData]  = useState([]);
  // const sessionData                   = getUserSession();
  const [sessionData,setSessionData] = useState(false);
  const allFilters                   = useSelector((state)=>state.filter.allFilters)
  let startVal                       = useSelector((state)=>state.filter.allFilters.start);
  const [showResults,setShowResult]  = useState(0);



  const [isProjectLoad,setIsProjectLoad]  = useState(true);
  const [locationName,setLocationName] = useState('');
  const [locationDesc,setLocationDesc] = useState('');

  /* useEffect(()=>{
    const fnCall = async ()=>{
      // let dispatch_cities = await dispatch(getCities());
      //   if(dispatch_cities.payload){
      //     // setCityData(dispatch_cities.payload.cities)
      //   }

      let dispatch_filter = await dispatch(applyFilters());
        if(dispatch_filter.payload){

          // console.log(dispatch_filter.payload.projects)
          setFilterdData(dispatch_filter.payload.projects)

        }
      }
      fnCall();
    },[]) 
    */

    const [totalNum,setTotalNum]       = useState(0);
    const [builderInfo,setBuilderInfo] = useState('');

    const handleScroll = (e)=>{
      
      let windowHeight  = window.innerHeight;
      let topHeight     = e.target.documentElement.scrollTop;
      let scrollHeight  = e.target.documentElement.scrollHeight;

      if(windowHeight+topHeight+1 >= scrollHeight){
        console.log('hit bottom')
        console.log('Handle Scroll Called ',window.innerHeight);
        console.log('height of the scrool ',e.target.documentElement.scrollTop);
        console.log('height of the scrool ',e.target.documentElement.scrollHeight);
      }

    }
useEffect(()=>{
  dispatch(set_ola_modal_tab(true));

  window.addEventListener('scroll',handleScroll)
},[])


/*     useEffect(()=>{
      const FnCall = async ()=>{
        setIsProjectLoad(true);


        // let getCity        = await dispatch(getCities());
        let defaultCities   = localStorage.getItem('houseiy_location');
        let token           = localStorage.getItem('housey_token');
        let userData        = parseJwt(token);
        setSessionData(userData);
        

        // allFilters.start     = 10;
        let dispatch_filter  = await dispatch(applyFilters(allFilters));
        if(dispatch_filter.payload){
          setIsProjectLoad(false);
          if(dispatch_filter.payload.projects){
            let allFilterdProjects = dispatch_filter.payload.projects;  
            let locationInfoArr    = dispatch_filter.payload.location_details;
            let builderDetails = dispatch_filter.payload.builder_details;
            setBuilderInfo(builderDetails)
            setTotalNum(dispatch_filter.payload.ToalProjects)
            let price_arr          = [];
            // setLocationInfo(locationInfoArr);
            // console.log(builderDetails,page_type)
            if(page_type==='builder' && builderDetails.length>0){
              setLocationName(builderDetails[0].builder_name)
              setLocationDesc(builderDetails[0].description)
            }

            if(locationInfoArr.length > 0 && page_type!=='builder'){
              setLocationName(locationInfoArr[0].name)
              setLocationDesc(locationInfoArr[0].description)
            }

            setFilterdData(allFilterdProjects)
            // project loop
            for (let pro_index = 0; pro_index < allFilterdProjects.length; pro_index++) {
                if(allFilterdProjects[pro_index].configs){
                  let allConfigs = JSON.parse(allFilterdProjects[pro_index].configs);
                  for (let con_i = 0; con_i < allConfigs.length; con_i++) {
                    price_arr.push(allConfigs[con_i].price);
                  }
                }
            }

            price_arr    = price_arr.sort(function(a, b){return b-a});
            let minVal   = price_arr[price_arr.length-1];
            let maxVal   = price_arr[0];
            let fil_obj = {
              type: 'budgetRange',
              minVal:minVal,
              maxVal:maxVal 
            }
            dispatch(set_filters(fil_obj))
          }
        }
      }
      FnCall();
    },[allFilters])

 */

    const [cityData,setCityData] = useState("");
    
    const FetchAllProjects = async (keywords)=>{
      
      setIsProjectLoad(true);
      setFilterdData([]);
      setShowResult(0);
      
      let defaultCities   = JSON.parse(localStorage.getItem('houseiy_location'));
      setCityData(defaultCities);
      let configs          = (keywords.flatName)          ? keywords.flatName:'';
      let city_id          = (keywords.city_id)           ? keywords.city_id:defaultCities.city_id;     
      let locality_id      = (keywords.locality_id)       ? keywords.locality_id:'';     
      let builder_id       = (keywords.builder_id)        ? keywords.builder_id:'';     
      let scheme_id        = (keywords.schames)           ? keywords.schames:'';     
      let budget           = (keywords.budgetRange)       ? keywords.budgetRange:'';     
      let downPayment      = (keywords.downPayment)       ? keywords.downPayment:'';    
      let possession_type  = (keywords.posession)         ? keywords.posession:'';
      let offers           = (keywords.offers)            ? keywords.offers:'';
      let sizeRange        = (keywords.selectedSizeRange) ? keywords.selectedSizeRange:'';
      let order_by_price   = (keywords.order_by_price)    ? keywords.order_by_price:'';
      let start            = keywords.start;
      if(!city_id){ return;}
      
      let query = `?config=${configs}&city_id=${city_id}&locality_id=${locality_id}&builder_id=${builder_id}&scheme_id=${scheme_id}&budget=${budget}&downPayment=${downPayment}&possession_type=${possession_type}&offer=${offers}&size=${sizeRange}&start=${start}&order_by_price=${order_by_price}`;
  
      const res                  = await fetch(`${process.env.BASE_URL}listing`+query);
      if(res.ok){
        const filter_result      = await res.json();
        // let allFilterdProjects   = (filter_result.projects.length)  ? filter_result.projects : [];  
        if(start){
          // let oldDataArr = filter_result.projects;
          console.log(filter_result.projects);
          // setFilterdData(oldArray => [...oldArray, filter_result.projects]);
          setFilterdData((state) => [...state, ...filter_result.projects])
        }else{
          setFilterdData(filter_result.projects)

        }
        setShowResult(filter_result.projects.length);
        // showResults,setShowResult
        let locationInfoArr      = filter_result.location_details;
        let builderDetails       = filter_result.builder_details;
        
        setBuilderInfo(builderDetails);
        setTotalNum(filter_result.ToalProjects);


        if(page_type==='builder' && builderDetails.length>0){
          setLocationName(builderDetails[0].builder_name)
          setLocationDesc(builderDetails[0].description)
        }
        if(locationInfoArr.length > 0 && page_type!=='builder'){
          setLocationName(locationInfoArr[0].name)
          setLocationDesc(locationInfoArr[0].description)
        }

      }else{

      }
        setIsProjectLoad(false);
    }

    useEffect(()=>{
      FetchAllProjects(allFilters);
    },[allFilters])


    const openmodal = (value)=>{

      let arr = [];
      let obj = {
        project_name: value.project_name,
        slug: value.slug
      }
      arr.push(obj);
      
      dispatch(select_project(arr));
      dispatch(set_ola_modal_tab(true));
  
      if (localStorage.getItem('housey_token')) {
        $('#olamodal').modal('show');
        dispatch(set_thank_u_modal(false));
      }
      else {
        localStorage.setItem('modal_type', 'ola_modal')
        dispatch(set_modal_state(false))
        $('#login').modal('show')
      }
    }

    


    // useEffect(()=>{


    //   console.log(budgetRangeFilter)
    //   // if (!Array.isArray(budgetRangeFilter)) {
    //   //      return;
    //   // }

    //   if(budgetRangeFilter && budgetRangeFilter.length > 0){
    //     let budgetRange = budgetRangeFilter.split('-');
    //     let newwFilterdProjects = []; 
    //     for (let rangeP_i = 0; rangeP_i < filterdDataRedux.length; rangeP_i++) {
    //       let configs    = JSON.parse(filterdDataRedux[rangeP_i].configs);
    //       if(configs){
    //           for (let con_i = 0; con_i < configs.length; con_i++) {
    //             if(budgetRange[0] <= configs[con_i].price && budgetRange[1] >= configs[con_i].price){
    //               newwFilterdProjects.push(filterdDataRedux[rangeP_i])
    //               break;
    //             }
    //           }
    //         }
    //     }
    //     setFilterdData(newwFilterdProjects)
    //   }
    // },[budgetRangeFilter])

    
 const loadMoreFn = ()=>{
    
    startVal     = parseInt(startVal) + 10;
    let fil_obj = {
      type:   'paginate',
      filter: startVal
    }
    
    dispatch(selectFilter(fil_obj))
 }
    



    return (
        <>
         
<div className="yellow-skin " id="listing-page">
         <section className="gray pt-4" >
  <div className="container">
    <div className="row">
      <div className="col-lg-8 col-md-12 col-sm-12">
        <div className="row justify-content-center">
          

          {/* {JSON.stringify(locationInfo)} */}

          <ProjectTitle type="city"  locationName={locationName} locationDesc={locationDesc}  search_query={search_query} page_type={page_type}  slug={details}  total_project={totalNum} showing_results={showResults}  />

          {/* Location Details End */}
          {isProjectLoad ? <>
            <div className="alert alert-success col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section" >
              Loading
            </div>
          </> : <>
            {filterdData.length===0?
          <>
          <div className="alert alert-warning col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section" >
            Sorry No Results Found
          </div>
          </>:""}
          </>} 

          
            

          {isProjectLoad===false && filterdData.length!==0 && filterdData && filterdData.map((item,index)=>{
              return (
                <>
                  <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section" >
                    <div className="property-listing list_view">
                      <div className="listing-img-wrapper">
                        
                        {(item.video_three_sixty !==0)?
                          <div className="_exlio_125">
                            <i className="fas fa-street-view" />
                          </div>
                        :""}
                        {(item.video !==0)?  
                        <div className="_exlio_126">
                          <i className="far fa-play-circle" />
                        </div>
                        :""}
                        
                        <div
                          className="_exlio_128"
                          data-toggle="tooltip"
                          data-placement="top"
                          data-original-title="Save property"
                        >
                          <a href="#">
                            <i className="far fa-heart" />
                          </a>
                        </div>
                          {item.saving_amt ? <><div className="_exlio_129">Save {numFormatter(item.saving_amt,2)}</div></>:""}
                        <div className="list-img-slide">
                          <div className="click">

                            <div>
                              <a href="#">
                                {(item.images!==null)?
                                <img src={process.env.BASE_URL+item.images} className="img-fluid mx-auto"    alt={item.project_name} />
                                :
                                <img src={'/assets/img/default-img.png'}    className="img-fluid mx-auto"    alt={item.project_name} />
                                }
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="list_view_flex">
                        <div className="listing-detail-wrapper mt-1">
                          <div className="listing-short-detail-wrap">
                            <div className="_card_list_flex mb-2">
                              <div className="_card_flex_01">
                                <h4 className="listing-name verified">
                                  <a href="#" className="prt-link-detail">
                                    {item.project_name}
                                  </a>
                                </h4>
                                <p className="builder-name">
                                  By <BuilderName builder={item.builder} /> 
                                </p>
                                <p className="builder-name">
                                  <span >
                                    {cityData && 
                                    <Link href={`/in/${cityData.name}/${item.location}-${item.locality_id}/projects`}>
                                      <a><i className="fas fa-map-marker-alt" /> {item.location}</a>
                                    </Link>
                                    }
                                  </span>
                                </p>
                              </div>
                              <div
                                className="_card_flex_last"
                                style={{ textAlign: "right" }}
                              >
                                <h6 className="listing-card-info-price mb-0">
                                  <i className="fas fa-rupee-sign" /> 
                                  {item.overall_price_range}
                                </h6>
                                <p className="builder-name">
                                  <i className="fas fa-vector-square" /> {item.area_range_min+"-"+item.area_range_max} sqft
                                </p>
                                <p className="builder-name">
                                  <span>
                                    <i className="far fa-calendar-alt" /> {item.target_possession}
                                  </span>
                                </p>
                              </div>
                            </div>
                          
                          </div>
                        </div>
                        {item.configs && <> 
                        <div className="price-features-wrapper">
                         <ConfigList configList={item.configs} />  
                        </div>
                        </>}
                        <div className="listing-detail-footer">
                          
                          <div className="footer-flex">
                            <i
                              data-toggle="tooltip"
                              data-placement="top"
                              data-original-title="Save property"
                              className="fas fa-info-circle"
                            />
                            
                            <button type="button" className="schedule" onClick={()=>openmodal(item)} >  
                            <i className="fa fa-desktop"></i>  &nbsp; | &nbsp; <i className="fa fa-car"></i> &nbsp; Tour
                            </button>


                            <WhatsAppBtn sellerInfo={item.sellers_info} />
                            
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    { item.offer && <>
                        <div className="col-12 special-offer">
                          <div className="special-offer-text">
                            <span>SPECIAL OFFER</span>
                          </div>
                          <div className="special-offer-info">
                            <span>{item.offer}</span>
                          </div>
                        </div>
                    </> }
                    
                  </div>   

                  
                    {(index===4 || (filterdData.length-1) < 4) && <>
                      <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section" >
                        <div className="property-listing list_view">
                          <Sitevisit/>
                        </div>
                      </div>
                    </>}
{/* || index===(filterdData.length-1) */}
                    {(index===8)  && <>
                      <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section" >
                        <div className="property-listing list_view">
                          <Online_project/>
                        </div>
                      </div>
                    </>}



                </>
              )
          })}

          <div className="load-more-section" >
              <button className='load-more-btn' onClick={loadMoreFn} > Load More...</button>
          </div>

         
        </div>
      </div>
      {/* property Sidebar */}

      <div className="col-lg-4 col-md-12 col-sm-12">
        {/* <Online_sidebar/> */}
        <FormComponent />
        {sessionData ? <></>: <Signup_Perks/>}
        
      </div>
    </div>
  </div>
</section>
</div>

        </>
    )
}

export default All_properties
