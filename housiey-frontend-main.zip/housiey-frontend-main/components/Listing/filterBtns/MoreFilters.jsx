import React                        from 'react';
import SizesFilterSlider            from './SizesFilterSlider';
import { useSelector,useDispatch }  from 'react-redux';
import {  selectFilter }            from '../../../redux/slices/filterSlice';

import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import CheckBoxes from './CheckBoxes';



const MoreFilters = ({sizeData,schemeData,selectScheme})=>{

    const schemes                                       = schemeData;
    const dispatch                                      = useDispatch();
    const [selectSchemeFilter,setSelectSchemeFilter]    = React.useState(schemeData);
    const [selectSize,setSelectSize]                    = React.useState([]);
    const [isOffer,setIsOffer]                          = React.useState(0);

    
    
    /* const getAllSchemes = (selecedtData=[])=>{

        // let selecedtData = selectSchemeFilter;
        let newArr       = []; 
        for (let main_i = 0; main_i < schemes.length; main_i++) {
            let obj;
            let checked = 0;
            for (let selected_i = 0; selected_i < selecedtData.length; selected_i++) {
                if(schemes[main_i].id===parseInt(selecedtData[selected_i])){
                    checked = 1;
                    break;
                }else{
                    checked = 0;
                }
            }

            obj = {
                id:      schemes[main_i].id,
                scheme:  schemes[main_i].scheme,
                checked: checked
            } 
            console.log(obj)
            newArr.push(obj);
        }
        // console.log(newArr,selecedtData)
        setMainSchemsData(newArr)

    }    */

    const setOffer = (event)=>{
        let isChecked   = event.target.checked;
        let value       = event.target.value;
        let filter      = 0;
        if(isChecked){
            setIsOffer(value)
            
            filter =  1
        }else{
            setIsOffer(0)
            filter =  0
        }

        let obj = {
            type:   'set_offer',
            filter: filter
        }
        dispatch(selectFilter(obj))

    }

    



    const ApplyMoreFilters = ()=>{
        let schemAtr   = selectSchemeFilter.toString();
        let sizeRange  = selectSize.toString();
        let obj = {
            type:       'more_filter',
            sizeRange:  sizeRange, 
            schames:    schemAtr,
            offers:     isOffer
        }
        dispatch(selectFilter(obj));
        handleClose(null);
    }

    // const updateBudgetFilter = (e,newValue) => {
    //     let obj = {
    //       type:   'size_range',
    //       filter: newValue
    //     }
    //     dispatch(selectFilter(obj))
    //   }
    
    
    


    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        // getAllSchemes();
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
      setAnchorEl(null);
    };

const CheckFun = (id)=>{
    for (let check_i = 0; check_i < selectSchemeFilter.length; check_i++) {
        // const element = selectSchemeFilter[check_i].id;
        if(selectSchemeFilter[check_i].id===id){
            return 1;
        }

        
    }
    return 0;
    // selectSchemeFilter.some(element => {
    //     if (element.id === item.id) {
    //       return 1;
    //     }
    //   })
}
    

const makeSelect = (event)=>{
        
    let isChecked   = event.target.checked; 
    let value       = event.target.value;
    let arr         = selectSchemeFilter;
    // console.log('is checked  : ',isChecked)
    if(isChecked){
        arr.push(value);
        let uniqueChars = [...new Set(arr)];
        setSelectSchemeFilter(uniqueChars);
        // getAllSchemes(uniqueChars);
    }else{
        
        let newArr = [];
        for (let ri = 0; ri < arr.length; ri++) {
            if(arr[ri]!==value){
                newArr.push(arr[ri]);
            }
        }   
        let uniqueChars = [...new Set(newArr)];
        setSelectSchemeFilter(uniqueChars);
    }
    // console.log(selectSchemeFilter)
    

    // let uniqueChars = [...new Set(arr)];
    
    // console.log(arr)
    
    // if(isChecked){
    //     arr.push(value);
    //     setSelectSchemeFilter(arr);
    //     // reff.current=1;
    //     // setIsChecked(1);
    // }else{
    //     // remove from array logic here
    //     // reff.current=0;
    //     // setIsChecked(0);

    //     let newArr = [];
    //     for (let ri = 0; ri < arr.length; ri++) {
    //         if(arr[ri]!==value){
    //             newArr.push(arr[ri]);
    //         }
    //     }   
    //     setSelectSchemeFilter(newArr);
    // }
}



// useEffect(()=>{
//     getAllSchemes();

// },[])


    return (
        <>
       
<Button
        id="more-filter-btn"
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
      >
        More Filters  <i className="fa fa-caret-down" ></i>
      </Button>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button',
        }}
      >

<div className='row' >
            {/* <nav
                id="navbar-example3"
                className="navbar navbar-light bg-light flex-column align-items-stretch p-3 col-4"
            >
                <nav className="nav nav-pills flex-column">
                    <Scrollspy items={ ['item-1', 'item-2', 'item-3'] } currentClassName="is-current">
                    <a className="nav-link" href="#item-1">
                        Schemes
                    </a>
                    <a className="nav-link" href="#item-2">
                        Offer
                    </a>
                    <a className="nav-link" href="#item-3">
                        Sizes
                    </a>
                    </Scrollspy>


                    <button className="btn btn-success mt-auto  more-filter-applied" type="button"  onClick={ApplyMoreFilters} >
                        Apply Button
                    </button>
                </nav>
            </nav> */}

            <div
                data-bs-spy="scroll"
                data-bs-target="#navbar-example3"
                data-bs-offset={0}
                tabIndex={0}
                className={'col-12 side-scroll-spy-section pt-3 ml-2 text-left'}
                >
                <div className='' id="item-1" >
                    <h4 className="filter-title" >Schemes</h4>
                    <ul className="ks-cboxtags">
                        <CheckBoxes SchemsData={schemes} setSelect={selectScheme}  />
                    </ul>
                </div>
                <div className='' id="item-2" >
                    <h4 className="filter-title" >Sizes</h4>
                    
                    <div className="" >
                        <SizesFilterSlider selectSize={selectSize} setSelectSize={setSelectSize} sizeData={sizeData} />
                    </div>

                </div>
                <div className='' id="item-3" >
                    <h4 className="filter-title" >Offers</h4>
                    <ul className="ks-cboxtags">
                        <li>
                            <input type="checkbox" name="offer" id="offer-yes" value="1" onClick={setOffer} checked={isOffer} />
                            <label htmlFor="offer-yes">Yes</label>
                        </li>
                    </ul>
                </div>

            </div>
        </div>

      </Menu>



        </>
    )
}
export default MoreFilters;