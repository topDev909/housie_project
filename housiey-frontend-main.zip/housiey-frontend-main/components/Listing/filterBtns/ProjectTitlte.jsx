import React,{useState,useEffect} from 'react';
import Link from 'next/link';
import LongDescription from '../../component/common/LongDescription';
import {selectFilter} from '../../../redux/slices/filterSlice';
import {useDispatch,useSelector} from 'react-redux';
const ProjectTitle = ({locationName,locationDesc,search_query,total_project,page_type,showing_results})=>{

  const dispatch       = useDispatch();
  const order_by_price = useSelector((state)=>state.filter.allFilters.order_by_price)

  const changeOderBy = (e)=>{
    let val = e.target.value;
    let obj = {
      type: "oder_by",
      filter: val
    }
    dispatch(selectFilter(obj))    
  }



    return (
        <>
          <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4" >
            <div
              className="property-listing list_view"
              style={{
                borderBottomLeftRadius: "0.5rem",
                borderBottomRightRadius: "0.5rem"
              }}
            >
              <div className="list_view_flex" id="listing-top">
                <div className="listing-detail-wrapper mt-1">
                  <div className="listing-short-detail-wrap">
                    <div
                      className="_card_list_flex mb-2"
                      style={{ alignItems: "flex-start" }}
                    >
                    <div className="_card_flex_01">
                        <h4 className="listing-name verified" style={{ fontSize: '12px' }}  >
                            <Link href={'/'} >
                              <a>Home</a>
                            </Link>
                            <>
                              { (page_type==='builder') ? 
                              <>
                                <i className='ti-angle-right ti-small' ></i>
                                Builders 
                                <i className='ti-angle-right ti-small' ></i>
                                <Link href={'/in/'+search_query} >
                                  <a  >{locationName}</a>
                                </Link>
                              </>
                              : 
                              <>
                              {(page_type==='listing')         &&  <>
                              <i className='ti-angle-right ti-small' ></i>
                                <Link href={'/in/'+search_query} >
                                  <a  >{locationName}</a>
                                </Link>
                              </>}

                              {(page_type==='locality')        &&  <> 
                                <i className='ti-angle-right ti-small' ></i>
                                <Link href={'/in/'+search_query} >
                                  <a  >{search_query[0]}</a>
                                </Link>     

                                <i className='ti-angle-right ti-small' ></i>
                                <Link href={'/in/'+search_query} >
                                  <a  >{locationName}</a>
                                </Link>
                                </>
                              }
                              
                              {(page_type==='under_projects')  &&  <> <i className='ti-angle-right ti-small' ></i>
                                <Link href={'/in/'+search_query[0]} >
                                  <a  >{search_query[0]}</a>
                                </Link>


                                <i className='ti-angle-right ti-small' ></i>
                                <Link href={'/in/'+search_query[2]} >
                                  <a  >{search_query[1]}-{search_query[2]}</a>
                                </Link>
                                 </>} 
                              </>
                              }
                            </>
                            
                            
                        </h4>

                        <h4>New Projects  {(page_type==='builder')?<i>By</i>:<i>In</i>}  {locationName}</h4>
                        <p className="builder-name">
                          <LongDescription  content={locationDesc} wordlength={180} />
                        </p>
                      </div>
                      <div className="_card_flex_last">
                        <h6 style={{ fontSize: 12 }} className={'text-right mr-2'} >
                          Showing {showing_results} of {total_project} projects
                        </h6>
                        <div className="form-group">
                          <div className="simple-input">
                            <select
                              className="form-control"
                              style={{ height: 40 }}
                              onChange={changeOderBy}
                            >
                              <option value=""        selected={order_by_price===""?1:0} >Top Projects</option>
                              <option value={"ASC"}   selected={order_by_price==="ASC"?1:0} >Low-to-High</option>
                              <option value={"DESC"}  selected={order_by_price==="DESC"?1:0} >High-to-Low</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </>
    )
}
export default ProjectTitle;