import React from 'react';
import Link from 'next/link';
import { slugGenrator } from '../../../utils/BasicFn';

const BuilderName = ({builder})=>{

    const item = (builder)? JSON.parse(builder):'';
    const slug = (item) ? slugGenrator(item[0].builder_name) :"";

    return (
        <>
        {builder && <>
        <Link href={'/builders/'+slug} >
            <a> {item[0].builder_name} </a>
        </Link>
        </>}
        </>
    )
}
export default BuilderName;