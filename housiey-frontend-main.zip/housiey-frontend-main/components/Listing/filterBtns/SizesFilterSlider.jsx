import React from 'react';
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';


import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';


import ButtonGroup from '@mui/material/ButtonGroup';
import { useDispatch, useSelector } from "react-redux";
import { selectFilter,applyFilters } from "../../../redux/slices/filterSlice";
// import { numFormatter } from '../../../utils/BasicFn';


const SizesFilterSlider = ({selectSize,setSelectSize,sizeData})=>{
  const dispatch        = useDispatch();
  // const sizeRange    = useSelector((state)=>state.filter.sizeRange);
  const sizeRange       = sizeData;

  const numFormatter = (num)=>{
    return num + ' SQFT';
  }
  
  // console.log('here i have Size Filter : '+sizeRange);
  // const selectdRange  = useSelector((state)=>state.filter.allFilters.sizeRange);
  
/*   if(selectdRange){
    let rangeSplit = selectdRange.split(',');
    let selStr     = numFormatter(rangeSplit[0])+'-'+numFormatter(rangeSplit[1]);
  } */

  // console.log(selectdRange)
//   console.log(sizeRange);
//   const FnCall = async ()=>{
//     let dispatch_filter  = await dispatch(applyFilters(allFilters));
//     if(dispatch_filter.payload){
//       setFilterdData(dispatch_filter.payload.projects)
//     }
//   }
//   useEffect()

  
// useEffect(()=>{
//   FnCall();
// },[allFilters])



  let minVal = parseInt(sizeRange[0]);
  let maxVal = parseInt(sizeRange[1]);

//   let minVal = 1000000;
//   let maxVal = 15000000;

  
  

  // console.log(minVal,maxVal)




  let steps       = 100;
  let setDefaultMaxVal = parseInt(maxVal/2);

    const [value, setValue]       = React.useState(selectSize);
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [open,setOpen]          = React.useState(Boolean(anchorEl));

    const handleClick = (event) => {
      setAnchorEl(event.currentTarget);
      setOpen(true);
    };
    const handleClose = () => {  setAnchorEl(null); setOpen(false); } 

    const handleChange = (event, newValue) => {
      setValue(newValue);
      setSelectSize(newValue);
    };

    let [selectedStr,setSelectStr] = React.useState('');
    

    React.useEffect(()=>{
        if(sizeRange && sizeRange.length && selectSize.length===0){
          let arr = sizeRange;
          setValue(arr)
        }
    },[sizeRange])



    const sty = {
      background: '#fff',
      color: '#234e70',
      fontSize:' 14px',
      color: '#234e70',
      fontWeight:'400',
      borderRadius:' 25px',
      height:' 40px',
    } 
    



 /*  const updateSizeFilter = ()=>{
    let priceRangeMin = value[0];
    let priceRangeMax = value[1];
    let obj = {
      filter: priceRangeMin+','+priceRangeMax,
      type: 'size'
    }

    let selStr     = numFormatter(priceRangeMin)+'-'+numFormatter(priceRangeMax);
    setSelectStr(selStr)
    dispatch(selectFilter(obj))
    handleClose();
  } */

  const updateBudgetFilter = (e,newValue) => {
    let obj = {
      type:   'size_range',
      filter: newValue
    }
    dispatch(selectFilter(obj))
  }




    return (
        <>
         <Box sx={{ width: '100%',padding:'0px 40px',marginTop:'15px',textAlign:'center' }} className="drop-down-box" >
        <Slider
            getAriaLabel={() => 'Temperature range'}
            value={value}
            onChange={handleChange}
            valueLabelDisplay="on"
            style={{marginTop:'15px'}}
            step={steps}
            min={minVal}
            max={maxVal}
            valueLabelFormat={numFormatter}
            onChangeCommitted={updateBudgetFilter}
          />

          <p style={{ fontSize: '13px',lineHeight:'1' }}>
            <span>
              Min
              <b> {numFormatter(minVal)} </b>
            </span>
            <span> to </span>
            <span>Max
              <b> {numFormatter(maxVal)} </b>
            </span>
          </p>
        </Box>
        </>
    )
}

export default SizesFilterSlider;