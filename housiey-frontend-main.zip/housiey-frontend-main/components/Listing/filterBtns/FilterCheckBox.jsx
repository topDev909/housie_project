import React,{useState} from 'react';
const FilterCheckBox = ({title,id,setSelect,selectedSchems,key,letSCheck})=>{
    
    const reff = React.useRef();
    const [isCheckedCheck,setIsChecked] = useState(letSCheck);

    // console.log(selectedSchems);
    const makeSelect = (event)=>{
        
        let isChecked   = event.target.checked; 
        let value       = event.target.value;
        let arr      = selectedSchems;

        
        if(isChecked){
            arr.push(value);
            setSelect(arr);
            reff.current=1;
            setIsChecked(1);
        }else{
            // remove from array logic here
            reff.current=0;
            setIsChecked(0);

            let newArr = [];
            for (let ri = 0; ri < arr.length; ri++) {
                if(arr[ri]!==value){
                    newArr.push(arr[ri]);
                }
            }   
            setSelect(newArr);
        }
    }

    
const isFound = selectedSchems.some(element => {
    if (element.id === id) {
        setIsChecked(1);
      return true;
    }
  });


    return (
        <>  
        {selectedSchems}
            <li key={key}>
                <input type="checkbox" id={"checkboxOne-"+id} value={id} onChange={makeSelect} checked={isCheckedCheck}    />
                <label htmlFor={"checkboxOne-"+id}>{title}</label>
            </li>
        </>
    )
}
export default FilterCheckBox;