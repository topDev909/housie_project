import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import ButtonGroup from '@mui/material/ButtonGroup';
import Button from '@mui/material/Button';

import { makeStyles } from '@material-ui/core/styles';



import { selectFilter,applyFilters } from "../../../redux/slices/filterSlice";
import { useDispatch, useSelector }  from "react-redux";
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};


const useStyles = makeStyles(theme => ({
  dialogPaper: {     
      height : '400px'
  },
}));



function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}


export default function DropDown({cls_name,dropDownValues,title,type,selectedValue}) {
           
const sty = {
  background: '#fff',
  color: '#234e70',
  fontSize:' 14px',
  color: '#234e70',
  fontWeight:'400',
  borderRadius:' 25px',
  height:' 40px',
} 

  const dispatch                    = useDispatch();
  const reset_filter                = useSelector((state)=>state.filter.allFilters.reset_filter)
  const make_search                 = useSelector((state)=>state.filter.make_search)
  const selectedValuesArr           = (selectedValue)?selectedValue.split(','):[];
  const names                       = dropDownValues || [];
  const theme                       = useTheme();

  const [personName, setPersonName] = React.useState(selectedValuesArr);
  const [btn_title,setBtn_title]    = React.useState(title);
  const [open,setOpen]              = React.useState(false);
  const ref = React.useRef();



  const handleChange = async (event) => {
    const {target: { value }, } = event;

    let main_title             = '';
    let num_count              = 0;
    let appliy = [];
    let filterIds = [];
    for(let cat_i=0;cat_i < value.length ; cat_i++){
      if(cat_i===0){
        main_title = value[cat_i]
      }
      // filterIds.push(value[cat_i].id)
      appliy.push(value[cat_i]);
      num_count++; 
    }
    let aplied_st = appliy.toString();
    let filterObj = {type: type, filter: aplied_st}
    dispatch(selectFilter(filterObj))
    // dispatch(applyFilters())
    main_title = main_title +"-"+num_count;
    setPersonName(typeof value === 'string' ? value.split(',') : value)   
  };

  
  // const handleChange = (event) => {
      
  //   const {
  //     target: { value },
  //   } = event;
  //   let newValue = [];
  //   let applied = 0;
  //   let appliy = [];


  //   for (let v_i = 0; v_i < value.length; v_i++) {
  //       if(value[v_i]!=='apply'){
  //         // ResetFilter()
  //           newValue.push(value[v_i]);
  //       }else{
  //           applied += 1;
  //       }
  //   }
  //   // console.log(applied);

  //   setPersonName( typeof newValue === 'string' ? newValue.split(',') : newValue,);
  //   if(applied > 0){
  //       setOpen(false)
  //       applyBtnFilter();
  //   }
  // };


  const GetSelectedVal = (selected)=>{
    let   main_title     = '';
      if(selected.length > 0){
        main_title = btn_title + ' ('+ selected.length +')' ; 
        return (<>{main_title}</>)
      }else{
        return selected.join(',');
      }
    } 

    const applyBtnFilter = ()=>{
        let aplied_st = personName.toString();
        let filterObj = {type: type,filter: aplied_st}
        dispatch(selectFilter(filterObj))
        dispatch(applyFilters())
    }

    React.useEffect(()=>{
      // if(reset_filter){
        setPersonName([])
      // }
    },[reset_filter,make_search]);


  return (
    <div>

<FormControl  className={cls_name}>
        <Select
         labelId={"demo-multiple-checkbox-label-"+cls_name}
         id={"demo-multiple-checkbox-"+cls_name}
          multiple
          displayEmpty
          open={open}
          value={personName}
          onChange={(handleChange)}
          onOpen={()=>setOpen(!open)}
          onClose={()=>setOpen(false)}
          input={<OutlinedInput />}
          renderValue={(selected) => {
            if (selected.length === 0) {
              return <span>{btn_title}</span>;
            }
            return GetSelectedVal(selected)
          }}
          className={"ods-filter " + cls_name }  
          style={sty}

          
        >
        
          {names && names.map(({id,name}) => (
            <MenuItem
              key={id}
              value={id}
              style={getStyles(name, personName, theme)}
            >
              {name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

    </div>
  );
}
