import React from 'react';
import {useDispatch} from 'react-redux';
import { selectFilter } from '../../../redux/slices/filterSlice';

const CheckBoxes = ({SchemsData,setSelect})=>{
    const dispatch = useDispatch();

    const handleCheckboxClick = (event,clickedItem) => {
        const updatedArray = SchemsData.map((item) => {
            item.checked = item.id === clickedItem.id ? !item.checked : item.checked;
            return item;
        });
        setSelect(updatedArray)
        let isChecked = event.target.checked;

        let idArr = [];
        for (let up_i = 0; up_i < updatedArray.length; up_i++) {
            if(updatedArray[up_i].checked){
                idArr.push(updatedArray[up_i].id)
            }
        }



        let idStr = idArr.toString();
        let obj = {
            type: 'scheme',
            filter: idStr
        }
        dispatch(selectFilter(obj))


    };

    return (
        <>
         {SchemsData.map((item,index)=>(
            <>
            <li key={index}>
                <input type="checkbox" id={"checkboxOne-"+item.id} value={item.id} onChange={(e)=>handleCheckboxClick(e,item)} checked={item.checked}  />
                <label htmlFor={"checkboxOne-"+item.id}>{item.scheme}</label>
            </li>
            </>
        ))}

        </>
    )
}
export default CheckBoxes;