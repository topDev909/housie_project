import React from 'react';
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';

import { useRouter } from 'next/router'

import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';


import ButtonGroup from '@mui/material/ButtonGroup';
import { useDispatch, useSelector } from "react-redux";
import { selectFilter,applyFilters } from "../../../redux/slices/filterSlice";
import { numFormatter } from '../../../utils/BasicFn';


const BudgetFilter = ({budgetRange})=>{
  
  const dispatch      = useDispatch();
  const router        = useRouter();
  const reset_filter  = useSelector((state)=>state.filter.allFilters.reset_filter)
  const make_search   = useSelector((state)=>state.filter.make_search)
  const appliedBudget = useSelector((state)=>state.filter.budgetRange)



  


  // const selectdRange  = useSelector((state)=>state.filter.allFilters.budgetRange);

  
/*   if(selectdRange){
    let rangeSplit = selectdRange.split(',');
    let selStr     = numFormatter(rangeSplit[0])+'-'+numFormatter(rangeSplit[1]);
  } */

  // console.log(selectdRange)
//   console.log(budgetRange);
//   const FnCall = async ()=>{
//     let dispatch_filter  = await dispatch(applyFilters(allFilters));
//     if(dispatch_filter.payload){
//       setFilterdData(dispatch_filter.payload.projects)
//     }
//   }
//   useEffect()

  
// useEffect(()=>{
//   FnCall();
// },[allFilters])

  // console.log('here we have Budget Filter : ',budgetRange)
  let minVal = (budgetRange.length) ? (budgetRange[0]) : 1000000;
  let maxVal = (budgetRange.length) ? (budgetRange[1]) : 15000000;

  // let minVal = 1000000;
  // let maxVal = 15000000;

  
  

  // console.log(minVal,maxVal)




    let steps            = 100000;
    let minDistance      = 10000;
    let setDefaultMaxVal = parseInt(maxVal/2);

    const [value, setValue]       = React.useState([1000000, 400000]);
    const [anchorEl, setAnchorEl] = React.useState(null); 
    const [open,setOpen]          = React.useState(Boolean(anchorEl));

    const handleClick = (event) => {
      setAnchorEl(event.currentTarget);
      setOpen(true);
    };
    const handleClose = () => {  setAnchorEl(null); setOpen(false); } 

    const handleChange = (event, newValue) => {
      setValue(newValue);
    };

    let [selectedStr,setSelectStr] = React.useState('');
    

    React.useEffect(()=>{
        if(budgetRange && selectedStr===''){
          let arr = [minVal, maxVal]
          setValue(arr)
        }
    },[budgetRange])


    React.useEffect(()=>{
      if(reset_filter){
        let arr = [minVal, maxVal]
        // console.log('Budget Filter Here ',arr);
        setValue(arr)
        setSelectStr('')
      }
    },[reset_filter,make_search]);





    const sty = {
      background: '#fff',
      color: '#234e70',
      fontSize:' 14px',
      color: '#234e70',
      fontWeight:'400',
      borderRadius:' 25px',
      height:' 40px',
    } 
    



  const updateBudgetFilter = ()=>{
    let priceRangeMin = value[0];
    let priceRangeMax = value[1];
    let obj = {
      filter: priceRangeMin+','+priceRangeMax,
      type: 'budget'
    }

    dispatch(selectFilter(obj))
    let selStr     = numFormatter(priceRangeMin,1)+'-'+numFormatter(priceRangeMax,1);
    setSelectStr(selStr)
    // handleClose();
  }


  React.useEffect(()=>{
    //  
    // const {query} = router;
    // if(query.search[1]==='under'){
      // let matches     = query.search[2].match(/\d+/g);
      // let minPrice    = matches[0] * 100000; 
      // let maxPrice    = (matches.length===2) ? matches[1] * 100009 : matches[0] * 100000;

      // let obj = {
        // filter: minPrice+','+maxPrice,
        // type: 'budget'
      // }

      // let selStr     = numFormatter(minPrice,1)+'-'+numFormatter(maxPrice,1);
      // setSelectStr(selStr);
      // dispatch(selectFilter(obj));
      // console.log('Here we are For Filters Inside : ',appliedBudget,query)
    // }
  },[])


    return (
        <>
         <div>
      <Button
        id="basic-button"
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
        style={sty}
      >
        {selectedStr?selectedStr:'Budget'}
        <i className="fa fa-caret-down" ></i>
      </Button>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button',
        }} 
      >
    <Box sx={{ width: 270,padding:'0px 40px',marginTop:'15px',borderBottom:'1px solid #ccc' }} className="drop-down-box" >
        <Slider
            getAriaLabel={() => 'Temperature range'}
            value={value}
            onChange={handleChange}
            valueLabelDisplay="on"
            style={{marginTop:'15px'}}
            step={steps}
            min={minVal}
            max={maxVal}
            valueLabelFormat={(num)=>numFormatter(num,1)}
            onChangeCommitted={updateBudgetFilter}
          />

          <p style={{ fontSize: '13px',lineHeight:'1' }}>
            <span>
              Min
              <b> {numFormatter(minVal,1)} </b>
            </span>
            <span> to </span>
            <span>Max
              <b> {numFormatter(maxVal,2)} </b>
            </span>
          </p>
        </Box>
          
          {/* <ButtonGroup  variant="contained" value="apply" key={'apply'}   >
              <Button color="success" sx={{ width:'100%' }} className="apply-btn" onClick={updateBudgetFilter}   >Apply</Button>
          </ButtonGroup> */}
      </Menu>
    </div>
        </>
    )
}

export default BudgetFilter;