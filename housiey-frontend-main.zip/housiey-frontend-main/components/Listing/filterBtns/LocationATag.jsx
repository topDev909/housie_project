import React from 'react';
import Link from 'next/link';
import { slugGenrator } from '../../../utils/BasicFn';


const LocationATag = ({location})=>{
    const item = JSON.parse(location)
    console.log(item)
    // const slug = slugGenrator(item[0].location_name,item[0].id)


    return (
        <>
        {item}
        </>
    )
}
export default LocationATag;