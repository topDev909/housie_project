import React from 'react';
import Link from 'next/link';

const WhatsAppBtn = ({sellerInfo,projectName})=>{
    let details = [];
    if(sellerInfo){
        details = JSON.parse(sellerInfo)
    }

    let sellerName = sellerInfo ? details[0].name:'';
    sellerName = sellerName.split(" ");

    let msg = ` Hello *${sellerName.length ? sellerName[0]:sellerName}*,    Need More Details about the  *${projectName}* `;
    
    return (
        <>
        <Link href={`https://api.whatsapp.com/send?phone=91${(sellerInfo) && details[0].phone}&text=${msg}`}>
            <a  className="reply" target={'_blank'}>
                <i className="fab fa-whatsapp" /> Live Chat
            </a>
        </Link>
        </>
    )
}
export default WhatsAppBtn;