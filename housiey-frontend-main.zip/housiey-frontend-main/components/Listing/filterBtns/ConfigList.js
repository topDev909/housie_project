import React from 'react';
function changeNumberFormat(number, decimals, recursiveCall) {
    const decimalPoints = decimals || 2;
    const noOfLakhs = number / 100000;
    let displayStr;
    let isPlural;
  
    // Rounds off digits to decimalPoints decimal places
    function roundOf(integer) {
        return +integer.toLocaleString(undefined, {
            minimumFractionDigits: decimalPoints,
            maximumFractionDigits: decimalPoints,
        });
    }
  
    if (noOfLakhs >= 1 && noOfLakhs <= 99) {
        const lakhs = roundOf(noOfLakhs);
        isPlural = lakhs > 1 && !recursiveCall;
        displayStr = `${lakhs} Lac${isPlural ? 's' : ''}`;
    } else if (noOfLakhs >= 100) {
        const crores = roundOf(noOfLakhs / 100);
        const crorePrefix = crores >= 100000 ? changeNumberFormat(crores, decimals, true) : crores;
        isPlural = crores > 1 && !recursiveCall;
        displayStr = `${crorePrefix} Crore${isPlural ? 's' : ''}`;
    } else {
        displayStr = roundOf(+number);
    }
  
    return displayStr;
  }
  
const ConfigList = ({configList})=>{
    // const [] = useState();
    let list = JSON.parse(configList);
    return (
        <>
        {list.map((config_item,ci)=>(
            <div className="list-fx-features" key={ci}>
                <div className="listing-card-info-icon">{config_item.config}</div>
                <div className="listing-card-info-icon">{config_item.area} sqft</div>
                <div className="listing-card-info-icon">{changeNumberFormat(config_item.price)} <small  className='all-inc'>All In</small> </div>
            </div>
        ))}
        </>
    )
}

export default ConfigList;