import React,{useState} from 'react';

import { useTheme }  from '@mui/material/styles';
import OutlinedInput from '@mui/material/OutlinedInput';
import MenuItem      from '@mui/material/MenuItem';
import FormControl   from '@mui/material/FormControl';
import Select        from '@mui/material/Select';

import { selectFilter,applyFilters } from "../../../redux/slices/filterSlice";
import { useDispatch, useSelector }  from "react-redux";

import ButtonGroup from '@mui/material/ButtonGroup';
import Button from '@mui/material/Button';
import DropDown from './DropDown';





const FlatType = ({option_val,type})=>{

  const dispatch      = useDispatch();
  const selectedValue = useSelector((state)=>state.filter.allFilters.flatName)
    let btnVal     = [];
    for (let name_i = 0; name_i < option_val.length; name_i++) {
        btnVal[name_i] = option_val[name_i].name;
    }

  



    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
      PaperProps: {
        style: {
          maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
          width: 50,
        },
      },
    };
    // First Button
    const names = option_val;
  
     
      function getStyles(name, personName, theme) {
        return {
          fontWeight:
            personName.indexOf(name) === -1
              ? theme.typography.fontWeightRegular
              : theme.typography.fontWeightMedium,
        };
      }
  
      const theme                        = useTheme();
      const [personName, setPersonName]  = useState([]);
  
      const handleChange = async (event) => {
        const {target: { value }, } = event;

        let main_title             = '';
        let num_count              = 0;
        let appliy = [];
        let filterIds = [];
        for(let cat_i=0;cat_i < value.length ; cat_i++){
          if(cat_i===0){
            main_title = value[cat_i]
          }
          // filterIds.push(value[cat_i].id)
          appliy.push(value[cat_i]);
          num_count++; 
        }
        let aplied_st = appliy.toString();
        let filterObj = {type: 'flatName',filter: aplied_st}

        dispatch(selectFilter(filterObj))
        dispatch(applyFilters())

        main_title = main_title +"-"+num_count;
        setPersonName(typeof value === 'string' ? value.split(',') : value)   
      };

      
      let cls_name = 'flat-cls';
      const GetSelectedVal = (selected)=>{
      let   main_title     = '';
        if(selected.length > 0){
          main_title = btn_title + ' ('+ selected.length +')' ; 
          return (<>{main_title}</>)
        }else{
          return selected.join(',');
        }
      } 
      let btn_title = 'BHK';


    return(
        <>

{/* <h1>{appliedFlat}</h1> */}
{/*            
<FormControl  className={cls_name}>
        <Select
         labelId={"demo-multiple-checkbox-label-"+cls_name}
         id={"demo-multiple-checkbox-"+cls_name}
          multiple
          displayEmpty
          value={personName}
          onChange={handleChange}
          input={<OutlinedInput />}
          renderValue={(selected) => {
            if (selected.length === 0) {
              return <span>{btn_title}</span>;
            }
            return GetSelectedVal(selected)
          }}
          className={"ods-filter " + cls_name }  
          
        >
        
          {names && names.map(({id,name}) => (
            <MenuItem
              key={id}
              value={id}
              style={getStyles(name, personName, theme)}
            >
              {name}
            </MenuItem>
          ))}

        
        </Select>
      </FormControl> */}



{/* <MenuItem onClick={()=>console.log('Handle Event')} >
            <ButtonGroup  variant="contained">
                <Button color="success" >Apply</Button>
            </ButtonGroup>
        </MenuItem> */}




                  {/* <FilterBtn btnVal={names} btn_title={'BHK'} class_name={'flat-cls'} /> */}

        <DropDown  cls_name={'flat-cls'} dropDownValues={names} title={'BHK'} type={'flatName'} selectedValue={selectedValue}  />

        </>
    )
}
export default FlatType;