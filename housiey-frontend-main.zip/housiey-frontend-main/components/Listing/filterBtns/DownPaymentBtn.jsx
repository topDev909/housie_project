import React,{useEffect,useState} from 'react';
import Box      from '@mui/material/Box';
import Slider   from '@mui/material/Slider';
import Menu     from '@mui/material/Menu';
import Button   from '@mui/material/Button';

import {useDispatch,useSelector} from 'react-redux';
import { selectFilter } from "../../../redux/slices/filterSlice";
import { numFormatter } from '../../../utils/BasicFn';


import ButtonGroup from '@mui/material/ButtonGroup';

const DownPaymentBtn = ()=>{
    const dispatch                = useDispatch();
    const downPaymentValue        = useSelector((state)=>state.filter.allFilters.downPayment) 
    const reset_filter            = useSelector((state)=>state.filter.allFilters.reset_filter)
    const make_search             = useSelector((state)=>state.filter.make_search)

    const [anchorEl, setAnchorEl] = React.useState(null);
    const [open,setOpen]          = React.useState(Boolean(anchorEl));
    const [value, setValue]       = React.useState(downPaymentValue);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
        setOpen(true);
      };
    let vArr = [200000,5000000];


         
const sty = {
    background: '#fff',
    color: '#234e70',
    fontSize:' 14px',
    color: '#234e70',
    fontWeight:'400',
    borderRadius:' 25px',
    height:' 40px',
} 

  const updateBudgetFilter = (e,newValue) => {
    let obj = {
      type:   'downpayment',
      filter: newValue
    }
    // console.log(obj);
    dispatch(selectFilter(obj))
  }

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };


  const applyFilter = () => {
    let obj = {
      type:   'downpayment',
      filter: value
    } 
    dispatch(selectFilter(obj))
    setOpen(false);
   }

    const handleClose = () => { 
      setAnchorEl(null); 
      setOpen(false); 
    }; 

    React.useEffect(()=>{
      // if(reset_filter){
        setValue(0)
      // }
    },[reset_filter,make_search]);


    return (
        <>

        <Button
        id="down-payment-btn"
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
        style={sty}
      >
        {downPaymentValue? numFormatter(downPaymentValue) : 'Down-Payment'}  
        <i className="fa fa-caret-down" ></i>
      </Button>
      <Menu
            id="down-payment"
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            MenuListProps={{
            'aria-labelledby': 'down-payment-btn',
            }} 
        >
            <Box sx={{ width: 270,padding:'0px 40px',marginTop:'15px',borderBottom:'1px solid #ccc' }} className="drop-down-box" >
              <Slider value={value}  min={vArr[0]} max={vArr[1]} aria-label="Default" valueLabelDisplay="on"   valueLabelFormat={numFormatter} onChange={handleChange}  onChangeCommitted={updateBudgetFilter} />
            </Box>

            {/* <ButtonGroup  variant="contained" value="apply" key={'apply'} sx={{float:'right',margin:'5px 0px',fontSize:'11px',padding:'5px 17px' }}>
                <Button color="success" onClick={applyFilter} className="apply-btn" >Apply</Button>
            </ButtonGroup>
 */}


    </Menu>


        </>
    )
}
export default DownPaymentBtn;