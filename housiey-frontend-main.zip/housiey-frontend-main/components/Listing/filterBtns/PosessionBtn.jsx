import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Chip from '@mui/material/Chip';



import ButtonGroup from '@mui/material/ButtonGroup';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';


import { selectFilter,applyFilters } from "../../../redux/slices/filterSlice";
import { useDispatch, useSelector }  from "react-redux";
import DropDown from './DropDown';



const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

export default function PosessionBtn({PossessionValues}) {
  const theme = useTheme();
  const dispatch = useDispatch();
  const [personName, setPersonName] = React.useState([]);
  const btn_title                   = 'Posession';
  // let PossessionValues              = useSelector((state)=>state.filter.posessions);
  const selectedValue               = useSelector((state)=>state.filter.allFilters.posession);

  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  
const names = [];

  let btnVal     = [];
    for (let name_i = 0; name_i < PossessionValues.length; name_i++) {
        let obj = {
            id: PossessionValues[name_i].sno,
            name: PossessionValues[name_i].name,
        }
        names.push(obj)
    }

  
  function getStyles(name, personName, theme) {
    return {
      fontWeight:
        personName.indexOf(name) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  }

  

//   const handleChange = (event) => {
//     const {
//       target: { value },
//     } = event;
//     setPersonName(
//       // On autofill we get a stringified value.
//       typeof value === 'string' ? value.split(',') : value,
//     );
//   };

const handleChange = async (event) => {
    const {target: { value }, } = event;
    let main_title             = '';
    let num_count              = 0;
    let appliy                 = [];
    let filterIds              = [];
    for(let cat_i=0;cat_i < value.length ; cat_i++){
      if(cat_i===0){
        main_title = value[cat_i]
      }
      // filterIds.push(value[cat_i].id)
      appliy.push(value[cat_i]);
      num_count++; 
    }
    let aplied_st = appliy.toString();
    let filterObj = {type: 'posession',filter: aplied_st}

    // dispatch(selectFilter(filterObj))
    // dispatch(applyFilters())
    // setAppliedFlat(aplied_st)

    // main_title = main_title +"-"+num_count;
    main_title = btn_title +"-"+num_count;
    // setPersonName(main_title);
    // console.log(main_title);
    setPersonName(typeof value === 'string' ? value.split(',') : value)   
  };

  const GetSelectedVal = (selected)=>{
    let   main_title     = '';
      if(selected.length > 0){
        main_title = btn_title + ' ('+ selected.length +')' ; 
        return (<>{main_title}</>)
      }else{
        return selected.join(',');
      }
    } 

    let cls_name        = 'posession-cls';
    let dropDownValues  = names;

  return (
    <>
      <DropDown  cls_name={cls_name} dropDownValues={dropDownValues} title={'Posession'} type={'posession'} selectedValue={selectedValue} />
    </>
  );
}
