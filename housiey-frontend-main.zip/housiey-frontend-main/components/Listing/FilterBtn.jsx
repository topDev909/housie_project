import React,{useState,UseEffect}   from 'react';
import { useTheme }                 from '@mui/material/styles';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import ListItemText from '@mui/material/ListItemText';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import Checkbox from '@mui/material/Checkbox';
import TextField from '@material-ui/core/TextField';

const FilterBtn = ({btnVal,btn_title,class_name,class_mr})=>{

    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
      PaperProps: {
        style: {
          maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
          width: 50,
        },
      },
    };
    // First Button
    const names = btnVal;
  
     
      function getStyles(name, personName, theme) {
        return {
          fontWeight:
            personName.indexOf(name) === -1
              ? theme.typography.fontWeightRegular
              : theme.typography.fontWeightMedium,
        };
      }
  
      const theme = useTheme();
      const [personName, setPersonName] = React.useState([]);
      const [showRanderVal,setShowRanderVal] = React.useState('');
  
      const handleChange = (event) => {
        const {
          target: { value},
        } = event;
    
        let main_title = '';
        let num_count = 0;
        for(let cat_i=0;cat_i < value.length ; cat_i++){
          if(cat_i===0){
            main_title = value[cat_i]
          }
          num_count++; 
        }

        main_title = main_title +"-"+num_count;
        
        setPersonName(typeof value === 'string' ? value.split(',') : value)
    
        setShowRanderVal(main_title)
       
      };
      let cls_name = (class_name)?class_name:'';
      const GetSelectedVal = (selected)=>{
        let main_title = '';
        if(selected.length > 0){
        
          main_title = btn_title + ' ('+ selected.length +')' ; 
          return (<>{main_title}</>)
        }else{
          return selected.join(',');
        }
      } 

    return(
        <>
        
<FormControl  className={cls_name}>
        <Select
         labelId={"demo-multiple-checkbox-label-"+cls_name}
         id={"demo-multiple-checkbox-"+cls_name}
          multiple
          displayEmpty
          value={personName}
          onChange={handleChange}
          input={<OutlinedInput />}
          renderValue={(selected) => {
            if (selected.length === 0) {
              return <span>{btn_title}</span>;
            }

            return GetSelectedVal(selected)
          }}
          className={"ods-filter " + cls_name }  
        >
        
          {names && names.map((name) => (
            <MenuItem
              key={name}
              value={name}
              style={getStyles(name, personName, theme)}
            >
              {name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

        </>
    )
}
export default FilterBtn;

