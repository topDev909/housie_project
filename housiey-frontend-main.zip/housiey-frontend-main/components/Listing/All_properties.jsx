import  React,{useState,useEffect}  from 'react';
import Head          from 'next/head';
import Signup_Perks                 from '../Signup_Perks';
import { useDispatch, useSelector } from "react-redux";
import { selectFilter,increase_paginate } from "../../redux/slices/filterSlice";
import { select_project } from "../../redux/slices/projectsSlice";
import { set_modal_state,set_ola_modal_tab,set_thank_u_modal,set_first_time_login,set_active_tab } from "../../redux/slices/signUpModalSlice";
import ConfigList              from './filterBtns/ConfigList';
import ProjectTitle            from './filterBtns/ProjectTitlte';
import WhatsAppBtn             from './filterBtns/WhatsAppBtn';
import FormComponent           from '../component/FormComponent';
import {parseJwt,numFormatter,slugGenrator} from '../../utils/BasicFn';
import BuilderName             from './filterBtns/BuilderName';
import Link                    from 'next/link';
import Sitevisit               from '../Sitevisit';
import Online_project          from '../single/Online_project';

import Skeleton,{SkeletonTheme} from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'

// import {RecursivePagination}     from 'recursive-load-more-reactjs';


const All_properties = ({search_query,page_type,details}) => {

  const dispatch                            = useDispatch();
  const [filterdData,setFilterdData]        = useState([]);
  const [metaData, setmetaData]             = useState({});
  const allFilters                          = useSelector((state)=>state.filter.allFilters);
  const ResetFilter                         = useSelector((state)=>state.filter.allFilters.reset_filter)
  const is_search_active                    = useSelector((state)=>state.filter.make_search);
  let startVal                              = useSelector((state)=>state.filter.paginate_start);

    const [isProjectLoad,setIsProjectLoad]    = useState(true);
    const [locationName,setLocationName]      = useState('');
    const [locationDesc,setLocationDesc]      = useState('');
    const [totalNum,setTotalNum]              = useState(0);
    const [cityData,setCityData]              = useState("");
    const [currentPage,setCurrentPage]        = useState(1);
    const [projectPerPage,setProjectPerPage]  = useState(10);
    const [allProjects,setAllProjects]        = useState([]);
    

    const FetchAllProjects = async (keywords)=>{


      try {
        // setIsLoading(true);
        // const response = await axios.get(
        //   `https://randomuser.me/api/?page=${page}&results=10`
        // );
        // setUsers([...users, ...response.data.results]);
        // setErrorMsg('');

        setFilterdData([]);
        let defaultCities   = JSON.parse(localStorage.getItem('houseiy_location'));


        if(!defaultCities){
          let fetcheCity       = await fetch(process.env.BASE_URL+'get-default-city');
          if(fetcheCity.ok){
            let cityFetchData  = await fetcheCity.json();
            defaultCities = {"city_id":cityFetchData.data[0].city_id,"name":cityFetchData.data[0].name,"default_city":1};
            localStorage.setItem('houseiy_location',JSON.stringify(defaultCities))
          }
        }


      setIsProjectLoad(true);      
      setCityData(defaultCities);

      let configs          = (keywords.flatName)          ? keywords.flatName:'';
      let city_id          = (keywords.city_id)           ? keywords.city_id:defaultCities.city_id;     
      let locality_id      = (keywords.locality_id)       ? keywords.locality_id:'';     
      let builder_id       = (keywords.builder_id)        ? keywords.builder_id:'';     
      let scheme_id        = (keywords.schames)           ? keywords.schames:'';     
      let budget           = (keywords.budgetRange)       ? keywords.budgetRange:'';     
      let downPayment      = (keywords.downPayment)       ? keywords.downPayment:'';    
      let possession_type  = (keywords.posession)         ? keywords.posession:'';
      let offers           = (keywords.offers)            ? keywords.offers:'';
      let sizeRange        = (keywords.selectedSizeRange) ? keywords.selectedSizeRange:'';
      let order_by_price   = (keywords.order_by_price)    ? keywords.order_by_price:'';
      let start            = startVal;


      
      if(!city_id){ return;}
      if(page_type==='locality'){
          if(!locality_id){
            return;
          }
      }else{
        locality_id = '';
      }

      if(page_type==='builder'){
          if(!builder_id){
            return;
          }
      }else{
        builder_id = '';
      }

      // console.log('this testing from gautam',page_type,is_search_active)
      // return;




      
      let query = `?config=${configs}&city_id=${city_id}&locality_id=${locality_id}&builder_id=${builder_id}&scheme_id=${scheme_id}&budget=${budget}&downPayment=${downPayment}&possession_type=${possession_type}&offer=${offers}&size=${sizeRange}&start=${start}&order_by_price=${order_by_price}`;

      const res                  = await fetch(`${process.env.BASE_URL}listing`+query);
      if(res.ok){
        const filter_result     =  await res.json();
        let result_projects     =  filter_result.projects;
        let metaDetails           =  filter_result.metaData;
        const indexOFLastPost   =  currentPage * projectPerPage;
        const indexOFFirstPost  =  indexOFLastPost - projectPerPage;
        const currentProjects   =  result_projects.slice(indexOFFirstPost,indexOFLastPost)

        setmetaData(metaDetails);
        setFilterdData(currentProjects)
        setAllProjects(result_projects)

        let locationInfoArr      = filter_result.location_details;
        let builderDetails       = filter_result.builder_details;

        setTotalNum(filter_result.ToalProjects);

        if(page_type==='builder' && builderDetails.length>0){
          setLocationName(builderDetails[0].builder_name)
          setLocationDesc(builderDetails[0].description)
        }
        if(locationInfoArr.length > 0 && page_type!=='builder'){
          setLocationName(locationInfoArr[0].name)
          setLocationDesc(locationInfoArr[0].description)
        }
      }

      } catch (error) {

      } finally {
        setIsProjectLoad(false);
      }

      
    }

    useEffect(()=>{
      let again_start = 1;
      if(is_search_active){
        setFilterdData([]);
        dispatch(increase_paginate(again_start))
        FetchAllProjects(allFilters);
      }
    },[allFilters])


    const openmodal = (value)=>{
      let arr = [];
      let obj = {
        project_name: value.project_name,
        slug: value.slug,
        id: value.id
      }
      arr.push(obj);
      
      dispatch(select_project(arr));
      dispatch(set_ola_modal_tab(true));
      dispatch(set_active_tab('1'))
      $('#olamodal').modal('show');

      
     
    }

    


    
 const loadMoreFn = ()=>{
      setIsProjectLoad(true);
      startVal                =  parseInt(startVal) + 1;
      const indexOFLastPost   =  startVal * projectPerPage;
      const indexOFFirstPost  =  indexOFLastPost - projectPerPage;
      const currentProjects   =  allProjects.slice(indexOFFirstPost,indexOFLastPost);
      setFilterdData((state) => [...state, ...currentProjects])
      dispatch(increase_paginate(startVal));
      setTimeout(() => {
        setIsProjectLoad(false);
      }, 1000);
 }
    
  const PropertyListing = ()=>{
    let count_steps = 0;
    return (
      <>
        {isProjectLoad===false && filterdData.length!==0 && filterdData && filterdData.map((item,index)=>{
            let city_name         = slugGenrator(cityData.name);
            let locality          = slugGenrator(item.location);
            let singleProjectSlug = `/in/${city_name}/${locality}/${item.slug}`;
            let banner;
            if(filterdData.length <= 4 && (index + 1)===filterdData.length ){
                banner = <><div className="row p-0 m-0" > <div className='col-12 p-0'><Sitevisit/></div>   <div className='col-12 p-0'><Online_project/></div></div></>;
            }
            else if(filterdData.length < 8){
              if((index+1)===4){
                banner = <Sitevisit/>
              }else if((index+1)===filterdData.length){
                banner = <Online_project/>
              }
            }
            else{
              if(((index + 1) %4===0 && count_steps===0)){
                count_steps = 1;
                banner = <Sitevisit/>;
              } else if(( (index + 1)%4===0 && count_steps === 1 )){
                banner = <Online_project/>;
                count_steps = 0;
              }
            }
            let locationName  = slugGenrator(item.location);
            let localistyUrl  = `/in/${cityData.name}/${locationName}/projects`; 
              return (
                <>
                  <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section" >
                    <div className="property-listing list_view">
                      <div className="listing-img-wrapper">
                        
                        {(item.video_three_sixty !==0)?
                          <div className="_exlio_125">
                            <i className="fas fa-street-view" />
                          </div>
                        :""}
                        {(item.video !==0)?  
                        <div className="_exlio_126">
                          <i className="far fa-play-circle" />
                        </div>
                        :""}
                        
                        <div
                          className="_exlio_128"
                          data-toggle="tooltip"
                          data-placement="top"
                          data-original-title="Save property"
                        >
                          <a href="#">
                            <i className="far fa-heart" />
                          </a>
                        </div>
                          {item.saving_amt ? <><div className="_exlio_129">Save {numFormatter(item.saving_amt,2)}</div></>:""}
                        <div className="list-img-slide">
                          <div className="click">
                            <div>
                              <Link href={singleProjectSlug} >
                              <a >
                                {(item.images!==null)?
                                <img src={process.env.BASE_URL+item.images} className="img-fluid mx-auto"    alt={item.project_name} />
                                :
                                <img src={'/assets/img/default-img.png'}    className="img-fluid mx-auto"    alt={item.project_name} />
                              }
                              </a>
                              </Link>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="list_view_flex">
                        <div className="listing-detail-wrapper mt-1">
                          <div className="listing-short-detail-wrap">
                            <div className="_card_list_flex mb-2">
                              <div className="_card_flex_01">
                                <h4 className="listing-name verified">
                                <Link href={singleProjectSlug} >
                                  <a  className="prt-link-detail">
                                      {item.project_name}
                                  </a>
                                </Link>
                                </h4>
                                <p className="builder-name">
                                  By <BuilderName builder={item.builder} projectName={item.project_name} /> 
                                </p>
                                <p className="builder-name">
                                  <span >
                                    {cityData && 
                                    <Link href={localistyUrl}>
                                      <a><i className="fas fa-map-marker-alt" /> {item.location}</a>
                                    </Link>
                                    }
                                  </span>
                                </p>
                              </div>
                              <div
                                className="_card_flex_last"
                                style={{ textAlign: "right" }}
                              >
                                <h6 className="listing-card-info-price mb-0">
                                  <i className="fas fa-rupee-sign" /> 
                                  {item.overall_price_range} <small  className='all-inc'>All In</small> 
                                </h6>
                                <p className="builder-name">
                                  <i className="fas fa-vector-square" /> {item.area_range_min+"-"+item.area_range_max} sqft
                                </p>
                                <p className="builder-name">
                                  <span>
                                    <i className="far fa-calendar-alt" /> {item.target_possession}
                                  </span>
                                </p>
                              </div>
                            </div>
                          
                          </div>
                        </div>
                        {item.configs && <> 
                        <div className="price-features-wrapper">
                         <ConfigList configList={item.configs} />  
                        </div>
                        </>}
                        <div className="listing-detail-footer">
                          
                          <div className="footer-flex">
                            {/* <i
                              data-toggle="tooltip"
                              data-placement="top"
                              data-original-title="Save property"
                              className="fas fa-info-circle"
                            /> */}
                            <button type="button" className="schedule" onClick={()=>openmodal(item)} >  
                              <i className="fa fa-desktop"></i>  &nbsp; | &nbsp; <i className="fa fa-car"></i> &nbsp; Tour
                            </button>
                            <WhatsAppBtn sellerInfo={item.sellers_info} projectName={item.project_name} />
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    { item.offer && <>
                        <div className="col-12 special-offer">
                          <div className="special-offer-text">
                            <span>SPECIAL OFFER</span>
                          </div>
                          <div className="special-offer-info">
                            <span>{item.offer}</span>
                          </div>
                        </div>
                    </> }
                  </div>   


                    {banner &&  <>
                      <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section" >
                        <div className="property-listing list_view banner">
                          {banner}
                        </div>
                      </div>
                    </>}


                </>
              )
          })}
      </>
    )
  }







    return (
        <>
         
<div className="yellow-skin " id="listing-page">
         <section className="gray pt-4" >
  <div className="container">
    <div className="row">
      <div className="col-lg-8 col-md-12 col-sm-12">
        <div className="row justify-content-center">
          
          <ProjectTitle type="city"  locationName={locationName} locationDesc={locationDesc}  search_query={search_query} page_type={page_type}  slug={details}  total_project={totalNum} showing_results={filterdData.length}  />
          
          <PropertyListing/>

          {isProjectLoad ? <>
            <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section" >
            <SkeletonTheme baseColor="#c9c9c9" highlightColor="#f3f5f8">
              <Skeleton count={12} height={'250px'} style={{ margin:'1rem 0rem'}} />
            </SkeletonTheme>
            </div>
          </> : <>
          {filterdData.length===0?
          <>
          <div className="alert alert-warning col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4 listing-card-section" >
            Sorry No Results Found
          </div>
          </>:""}
          </>} 
          
          {(isProjectLoad===false && filterdData.length!==0 && filterdData && filterdData.length < totalNum ) && <>
              <div className="load-more-section text-center" >
                  <button className='load-more-btn' onClick={loadMoreFn} > Load More...</button>
              </div>
          </>}

        </div>
      </div>
      {/* property Sidebar */}

      <div className="col-lg-4 col-md-12 col-sm-12 ">
        <div className='stickey' style={{  position : 'sticky',top: '100px'}}  >
          <FormComponent />
        </div>
      </div>
    </div>
  </div>
</section>
</div>

        </>
    )
}

export default All_properties;

