/* eslint-disable @next/next/no-sync-scripts */
import React,{useEffect,useState} from 'react';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import {parseJwt} from '../../utils/BasicFn';
import Link from 'next/link';
import {useRouter} from 'next/router';
import {useDispatch} from 'react-redux';
import {set_modal_state,set_signup_title} from '../../redux/slices/signUpModalSlice';
import HeaderSearchBox from './HeaderSearchBox';


const ListingHeader = ({header_type,search_query,page_type,details}) => {
  const dispatch  = useDispatch();
  const router                  = useRouter();
  const [useSession,setSession] = useState('');

  const logoutsession = ()=>{
    localStorage.removeItem('housey_token')
    router.reload(window.location.reload)
  }

  useEffect(()=>{
    let user         = localStorage.getItem('housey_token');
    let get_data     = parseJwt(user);
    setSession(get_data);
  },[])


  const openSignModal = ()=>{
    dispatch(set_modal_state(false))
    let msg = 'Sign-Up';
    dispatch(set_signup_title(msg))
  }





    return (
        <>
        {/* header header-light */}
        <div className=" listing-header">
          <div className="container">
            <nav id="navigation" className="navigation navigation-landscape">
              <div className="nav-header">
                <Link href="/" >
                  <a className="nav-brand fixed-logo"  >
                    <img src="/assets/img/logo.png" className="logo" alt="logo" />
                  </a>
                </Link>
                <div className="nav-toggle" />
                <div className="mobile_nav">
                  <ul>
                    <li>
                      <a href="#" data-toggle="modal" data-target="#login">
                        <i className="fas fa-user-circle fa-lg" />
                      </a>
                    </li>
                  </ul>
                </div>
              </div>

              
              <div className="nav-menus-wrapper" style={{ transitionProperty: "none" }}>


                {header_type === 'single' ? <>
                <ul className='nav-menu' >
                <li className='w-50'  id="detail-search" >
                  <HeaderSearchBox search_query={search_query} page_type={page_type} details={details}  />
                </li>  
                </ul>
                </> : ''}


                
                <ul className="nav-menu nav-menu-social align-to-right">
                
                  
                  {useSession ? <>
                    <li>                      
                      <div className="btn-group account-drop" style={{padding: '13px 0px'}}>
                        <button
                          type="button"
                          className="btn btn-order-by-filt login"
                          data-toggle="dropdown"
                          aria-haspopup="true"
                          aria-expanded="false"
                        >

                          <Stack direction="row" spacing={2}>
                            <Avatar
                              src="/static/images/avatar/1.jpg"
                              sx={{ width: 32, height: 32 }}
                            />
                            <span className="user-name text-dark">
                              {useSession.name} 
                            </span>
                          </Stack>

                        </button>
                        <div className="dropdown-menu pull-right animated flipInX">
                          <ul>
                            <li onClick={logoutsession}>
                              <a href="#" >Logout</a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </li>
                  </>: <>
                  <li>
                    <a
                      href="#"
                      className="alio_green"
                      data-toggle="modal"
                      data-target="#login"
                      onClick={openSignModal}
                    >
                      <span className="dn-lg">Sign Up</span>
                    </a>
                  </li>
                  </>}
                  

                  <li>
                    <div className="btn-group account-drop" style={{ marginTop: 0 }}>
                      <button
                        type="button"
                        className="btn btn-order-by-filt"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        <i className="fas fa-bars text-dark mt-2" />
                      </button>
                      <div className="dropdown-menu pull-right animated flipInX">
                      <ul>

                                <li>
                                  <Link href={"/about-us"}>
                                  <a>About Us </a>
                                  </Link>
                                </li>
                                <li>
                                  <Link href={"/in/pune/projects"} >
                                    <a>Buy Property in Pune </a>
                                </Link>
                                </li>
                  
                                  <li>
                                    <Link href={"/privacy-policy"}>
                                      <a>Privacy Policy</a>
                                    </Link>
                                  </li>
                                  <li>
                                    <Link href={"/disclaimer"}>
                                    <a>Disclaimer</a>
                                    </Link>
                                  </li>
                                  <li>
                                  <Link href={"/contact-us"}>
                                    <a >Contact Us</a>
                                  </Link>
                                  </li>

                              </ul>

                              <ul className="text-center" style={{padding: "15px", color: "#fff"}}>
                                <li>
                                  <a target='_blank' rel="noreferrer" href="https://api.whatsapp.com/send?phone=918097452839&text=Hello Housiey, Need assistance   with home buying" style={{background: '#0e8744', padding: '10px', borderRadius: '5px', color: '#fff', justifyContent: 'center'}}>
                                    Support - <i className='fab fa-whatsapp' style={{top: 0, marginLeft:'4px'}}></i> 8097452839
                                    </a>
                                </li>
                                <li>
                                  <span className="text-center" style={{display: "flex"}}>
                                    <a href="https://www.facebook.com/housiey" target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-facebook" style={{color: "#234e70" }}></i></a>
                                    <a href="https://www.linkedin.com/company/housiey" target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-linkedin" style={{color: "#234e70"}}></i></a>
                                    <a href="https://www.youtube.com/c/Housiey" target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-youtube" style={{color: "#234e70"}}></i></a>
                                    <a href="https://www.instagram.com/housiey/" target='_blank' rel="noreferrer" style={{display: "block", borderBottom: "none"}}><i className="ti-instagram" style={{color: "#234e70"}}></i></a>
                                  </span>
                                </li>
                              </ul>
                      </div>
                    </div>
                  </li>

                </ul>
              </div>
            </nav>
          </div>
        </div>
        </>
    )
}

export default ListingHeader
