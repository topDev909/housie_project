import * as React from 'react';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import { useState, useEffect } from "react";
import Olamodel from './Olamodel';
import { useDispatch, useSelector } from "react-redux";
import { searchProjects,select_project } from "../redux/slices/projectsSlice";
import { makeStyles } from "@material-ui/core/styles";
import ReactTooltip from 'react-tooltip';



import { set_modal_state,set_signup_title,set_thank_u_modal,set_ola_modal_tab,set_active_tab } from '../redux/slices/signUpModalSlice';

const useStyles = makeStyles({
  paper: {
    border: "0px solid black",
    borderRadius: "0px !important",
    marginTop: "11px",
    marginLeft: "13px"
  }
});

const Sitevisit = () => {
  const dispatch              = useDispatch();
  const selectedProject       = useSelector((state)=>state.projects.selectedProject) 
  const [mylist, setMylist]   = useState([])
  const [data, setData]       = useState(selectedProject)
  const [searchKeywords,setSearchKeywrods]   = useState('');
  const classes = useStyles();
  
  const mykey = async (keyword)=>{
    setSearchKeywrods(keyword)
    if(keyword!==''){
      let cityDataLocal = JSON.parse(localStorage.getItem('houseiy_location'));
      let obj  = {
        keywords: keyword,
        city_id: cityDataLocal.city_id
      }
      let search_projects = await dispatch(searchProjects(obj)); // this is for redux
      if(search_projects.payload){
        setMylist(search_projects.payload.projects)
      }
    }else{
      setMylist([])
    }
  
  }

  const [olaFormErr,setOlaFormErr] = useState('');
  const openmodel =()=>{
    setOlaFormErr('');

    if(selectedProject.length === 0){
      let msg = <><span  >Please Select Any Project</span> </>
      setOlaFormErr(msg)
      hideMsg();
      return;
    }

    

    dispatch(set_signup_title('Free Site Booking'));
    dispatch(set_ola_modal_tab(false));
    dispatch(set_active_tab('1'));
    $('#olamodal').modal('show');

    
/*     
  if (localStorage.getItem('housey_token')){
        dispatch(set_thank_u_modal(false));
        $('#olamodal').modal('show');
    }
    else{
        localStorage.setItem('modal_type','ola_modal');
       dispatch(set_modal_state(false))
       $('#login').modal('show')
    }    
    */
  }


  const handleChange = (value)=>{
    if(value.length <= 3){
      dispatch(select_project(value))
    }else{
      let msg = <><span  >Upto 3 projects allowed in one Site Visit Tour</span> </>
      setOlaFormErr(msg)
    }
    hideMsg();
  }

  const hideMsg = ()=>{
      setTimeout(() => {
        setOlaFormErr('')
      }, 10000);
  }
  
  return (
    <div>

      <div
        className="image-cover hero_banner"
        id="free-visit"
        style={{
          background: "url(/assets/img/graphics9.jpg) no-repeat",
          paddingTop: 0
        }}
        data-overlay={0}
      >
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-xl-10 col-lg-12 col-md-12">
              <h1 className="big-header-capt mb-2" style={{ fontSize: "1.7rem"}}>  
                Book Free Site Visit
                <p style={{display: 'inline-flex'}}>
                <i   
                 data-tip="Do one or multiple projects site visit through our free Ola Cab Service, 
                 Just visit & decide later, No commitments on bookings."                
                  className="fas fa-info-circle"
                  style={{ fontSize: "1rem", color: "#ccc", marginLeft: "5px" }}
                />
                <ReactTooltip />
                </p>
              </h1>
              
              <div
                className="full_search_box nexio_search"
                style={{ background: "transparent", padding: "0 0 0" }}
              >
                <div className="search_hero_wrapping">
                  <div className="row">
                    <div className="col-lg-12">

                      <div className="input-group">
                        
                            <Stack>
                              <Autocomplete
                                multiple
                                options={mylist}
                                freeSolo={true}
                                value={selectedProject}
                                getOptionLabel={(option) => option.project_name}		
                                classes={{ paper: classes.paper }}						
                                onChange={(event, value) => handleChange(value) }
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    variant="standard"
                                    placeholder={(selectedProject.length) ? "":"Search multiple projects for site visit"}
                                    className="form-control search-field"
                                    onChange={(e)=>{mykey(e.target.value)}}
                                  /> 
                                )}
                              />
                            </Stack>
                        <div className="input-group-append">
                          <button
                            type="button"
                            className="input-group-text theme-bg b-0 text-light"
                            style={{ width: 175, cursor: "pointer"}}
                            onClick={() => openmodel()}
                            >
                            Book Your
                            <img
                              src="/assets/img/ola-logo1.png"
                              width="60%"
                              style={{ marginLeft: 5 }}
                              alt='ola-booking'
                            />
                          </button>
                        </div>
                        {olaFormErr && <>
                          <div className='alert alert-danger w-50 ml-3 mt-2' >
                            {olaFormErr}
                          </div>
                        </>}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Olamodel mygetdata={data}/>
    </div>


  )
}

export default Sitevisit
