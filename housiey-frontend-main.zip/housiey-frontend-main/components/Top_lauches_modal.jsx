import React from 'react';
import FormComponent from "./component/FormComponent";
import { useState, useEffect } from "react"
const Top_lauches_modal = ({ mygetdata}) => {
    
    const [data, setData]           = useState([])
    const [getProjects, products]   = useState([]);

    const getProjectList = async ()=>{
        const resposen = await fetch(process.env.BASE_URL +"/top-launches-projects/1");
        let result = await resposen.json();
        products(result.projects)
    }
    useEffect(()=>{
        
    },[])
    
  return (
      <>
          <div
              className="modal fade"
              id="Top_lauches_modal"
              tabIndex={-1}
              role="dialog"
              aria-labelledby="Top_lauches_modal"
              aria-hidden="true"
          >
              <h1>hello</h1>
              <div className="modal-dialog modal-xl login-pop-form" role="document">
                  <div className="modal-content overli" id="Top_lauches_modal" style={{ width: "60%", marginLeft: "10rem" }}>
                      <div className="modal-body p-0">
                          <div className="resp_log_wrap">
                              <div className="resp_log_caption col">
                                  <span className="mod-close" data-dismiss="modal" aria-hidden="true">
                                      <i className="ti-close" />
                                  </span>
                                  <div className="edlio_152">
                                      <ul
                                          className="nav nav-pills tabs_system center"
                                          id="pills-tab"
                                          role="tablist">
                                      </ul>
                                  </div>
                                  <div className="tab-content" id="pills-tabContent">
                                      <div
                                          className="tab-pane fade show active"
                                          id="pills-login"
                                          role="tabpanel"
                                          aria-labelledby="pills-login-tab">
                                          <div className="login-form">
                                           
                                              <FormComponent seldata={mygetdata}/>
                                          </div>
                                      </div>
                                      <div
                                          className="tab-pane fade"
                                          id="pills-signup"
                                          role="tabpanel"
                                          aria-labelledby="pills-signup-tab">
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </>
  )
};

export default Top_lauches_modal;
