export const parseJwt = (token) => {
  if (!token) {
    return;
  }
  const base64Url = token.split(".")[1];
  const base64 = base64Url.replace("-", "+").replace("_", "/");
  return JSON.parse(window.atob(base64));
};

export const numFormatter = (num, decimal = 0) => {
  if (num >= 100000 && num < 1000000) {
    return (num / 100000).toFixed(decimal) + " Lac";
  } else if (num < 10000000) {
    return (num / 100000).toFixed(decimal) + " Lacs";
  } else if (num >= 10000000) {
    return (num / 10000000).toFixed(decimal) + " Cr";
  }
};

export const formatArea = (num) => {
  if (num >= 100000 && num < 1000000) {
    return (num / 100000).toFixed(0) + " Lac";
  } else if (num < 10000000) {
    return (num / 100000).toFixed(0) + " Lacs";
  } else if (num >= 10000000) {
    return (num / 10000000).toFixed(2) + " Cr";
  }
};
export const setDefaultCity = async (e) => {
  // let cityData = useSelector)_
  let city_id = parseInt(e.target.value);
  let filteredArray = cityData.filter((item) => {
    if (item.city_id === city_id) {
      return item;
    }
  });
  // setSelectedCity(city_id)
  localStorage.setItem("houseiy_location", JSON.stringify(filteredArray[0]));
};

/* 
  age kuch bhi nhi dala toh (project static hai) 
  in/cityName/Projects
  
  agr usne locality select kiya toh 
  in/cityName/locality/Projects/
  
  single project
  in/cityName/locality/Project-Slug/

  Builder Listing
  in/cityName/builders/BuilderName/

*/
export const GenrateSearchURL = (value) => {
  let url = "";
  let url_id = value.id ? value.id : "";
  let cityData = JSON.parse(localStorage.getItem("houseiy_location"));
  let cityName = cityData.name.toLowerCase();

  if (value.type === "builders") {
    url = "/builders/" + url_id;
  } else if (value.type === "locality") {
    url = `/in/${cityName}/${url_id}/projects`;
  } else if (value.type === "projects") {
    url = `/in/${cityName}/${url_id}`;
  } else {
    url = `/in/${cityName}/`;
  }
  return url;
};

export const slugGenrator = (name, id = "") => {
  let slug = name
    .toString()
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^\w\-]+/g, "")
    .replace(/\-\-+/g, "-")
    .replace(/^-+/, "")
    .replace(/-+$/, "");
  if (id !== "") {
    slug = slug + "-" + id;
  }
  return slug;
};

export const DownloadBroucher = async (link) => {
  // console.log(link);
  let res = await fetch(`/api/downloadBrocher?link=${link}`);
  if (res.ok) {
    let data = await res.json();
    console.log(data);
  }
};

export const getMainSearch = async (key) => {
  let cityData = JSON.parse(localStorage.getItem("houseiy_location"));
  let cityName = cityData.name.toLowerCase();
  if (key !== "") {
    await fetch(
      process.env.BASE_URL + `search/${cityName.city_id}/${key}`
    ).then((result) => {
      result.json().then((response) => {
        let opt_arr = [];
        if (response.builders.length > 0) {
          for (let b_i = 0; b_i < response.builders.length; b_i++) {
            let title = (
              <>
                {response.builders[b_i].builder_name}{" "}
                <span className="side-title"> Builder</span>
              </>
            );
            let b_slug = slugGenrator(response.builders[b_i].builder_name);
            let b_obj = {
              title: title,
              option_title: response.builders[b_i].builder_name,
              id: b_slug,
              type: "builders",
            };
            opt_arr.push(b_obj);
          }
        }
        if (response.locality.length > 0) {
          // console.log(response.locality);
          for (let l_i = 0; l_i < response.locality.length; l_i++) {
            let title = (
              <>
                {response.locality[l_i].name}{" "}
                <span className="side-title"> Locality</span>
              </>
            );
            let b_slug = slugGenrator(response.locality[l_i].name);
            let l_obj = {
              title: title,
              option_title: response.locality[l_i].name,
              id: b_slug,
              type: "locality",
            };
            opt_arr.push(l_obj);
          }
        }
        if (response.projects.length > 0) {
          for (let p_i = 0; p_i < response.projects.length; p_i++) {
            let title = (
              <>
                {response.projects[p_i].project_name}{" "}
                <span className="side-title"> Project</span>
              </>
            );
            let locality_clug = slugGenrator(response.projects[p_i].locality);
            let project_id = locality_clug + "/" + response.projects[p_i].slug;
            let p_obj = {
              title: title,
              option_title: response.projects[p_i].project_name,
              id: project_id,
              type: "projects",
            };
            opt_arr.push(p_obj);
          }
        } else {
          return [];
        }
        //  console.log(opt_arr);
        return opt_arr;
      });
    });
  } else {
    return [];
  }
};

export const getUserSession = () => {
  let sessionData = localStorage.getItem("housey_token");
  if (!sessionData) {
    return false;
  }
  const base64Url = sessionData.split(".")[1];
  const base64 = base64Url.replace("-", "+").replace("_", "/");
  let data = JSON.parse(window.atob(base64));
  return data;
};

export const getCities = async () => {
  const res = await fetch(`${process.env.BASE_URL}getcities`);
  const filter_result = await res.json();
  return filter_result;
};

export const round_num = (num) => {
  var m = Number((Math.abs(num) * 100).toPrecision(15));
  return (Math.round(m) / 100) * Math.sign(num);
};

export const Fetchmeta = async (search_query) => {
  try {
    let query = `?city_id=${search_query[0]}&locality_id=${search_query[1]}`;
    const res = await fetch(`${process.env.BASE_URL}getMeta` + query);
    if (res.ok) {
      let filter_result = await res.json();
      let newmeta = filter_result.metaData;
      return { status: true, data: newmeta };
    }
  } catch (e) {
    return { status: false, data: newmeta };
  }
};
