import { createSlice,createAsyncThunk  } from "@reduxjs/toolkit";
const initialState = {
    projectList: [],
    selectedProject: [],
    status:null,
    video_modal_src: "",
}


function multiDimensionalUnique(arr) {
    var uniques = [];
    var itemsFound = {};
    for(var i = 0, l = arr.length; i < l; i++) {
        var stringified = JSON.stringify(arr[i]);
        if(itemsFound[stringified]) { continue; }
        uniques.push(arr[i]);
        itemsFound[stringified] = true;
    }
    return uniques;
  }

  


export const searchProjects = createAsyncThunk('category/searchProjects', async (obj) => {
    if(obj.keyword===''){
        return [];
    }

    let city_id = obj.city_id;
    let keyword = obj.keywords;
    const response = await fetch(`${process.env.BASE_URL}search/${city_id}/${keyword}`)
    const result   = await response.json(); 
    return result;
})



export const projectsSlice = createSlice({
    name:'projects',
    initialState,
    reducers:{
        select_project:(state,action)=>{
			// console.log(action.payload);
            // action.payload.slug
            // console.log(action.payload)
            // for (let count_i = 0; count_i < action.payload.length; count_i++) {
            //     const element = array[count_i];
            // }
			if(action.payload.length <= 3){
                let arr = multiDimensionalUnique(action.payload);
				state.selectedProject =   arr
			}
        },
        set_video: (state,action)=>{
            state.video_modal_src = action.payload
        }
    },
    extraReducers:{

        [searchProjects.pending]: (state,action)=>{
            state.status = 'Loading';
        },
        [searchProjects.fulfilled]: (state,{payload})=>{
            state.projectList = payload;
            state.status = 'success';
        },
        [searchProjects.rejected]:(state,action)=>{
            state.status = 'failed';
        }

    }
});

/* export const incrementAsync = keywork => dispatch => {
    // setTimeout(() => {
    //   dispatch(incrementByAmount(amount));
    // }, 1000);

    
};
 */
export const {select_project,set_video} = projectsSlice.actions;
export default projectsSlice.reducer;

  

