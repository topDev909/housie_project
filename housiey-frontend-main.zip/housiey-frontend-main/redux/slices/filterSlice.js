import { createSlice,createAsyncThunk  } from "@reduxjs/toolkit";
const initialState = {
    flatName:   [],
    selectFlatName:[],
    budgetRange: [],
    selectBudgetRange:'',
    posessions: [],
    selectPosessions:[],
    downPayment:["1000000-5000000"],
    selectDownPayment:[],
    moreFilter: [],
    schemes:[],
    selectSchems:[],
    status:null,
    filterResult:[],
    city_data:[],
    selectedCity: '',
    cityState:null,
    sizeRange:[],
    paginate_start: 1,
    make_search : 1,
    allFilters:{
            flatName: '',
            budgetRange: '',
            downPayment: '',
            posession:"",
            city_id: '',
            locality_id: '',
            builder_id:'',
            scheme_id:'',
            selectedSizeRange:'',
            schames: '',
            offers: 0,
            searchText:'',
            start: 0, 
            reset_filter: 0,
            order_by_price:'',
        }
    

}


export const getFilters = createAsyncThunk('filter/getFilters', async () => {
    let cityData            = localStorage.getItem('houseiy_location');
    let  query              = '';
    if(cityData){
        cityData             = JSON.parse(cityData);
        query                = '?city_id='+cityData.city_id;
    }
    const res           = await fetch(`${process.env.BASE_URL}get-filters${query}`);
    const  result_data  = await res.json();
    return result_data;
})


export const applyFilters = createAsyncThunk('filter/applyFilters',async (ketwords)=>{
    
    let query            = '';
    let configs          = (ketwords.flatName)?ketwords.flatName:'';
    let city_id          = (ketwords.city_id)?ketwords.city_id:'';     
    let locality_id      = (ketwords.locality_id)?ketwords.locality_id:'';     
    let builder_id       = (ketwords.builder_id)?ketwords.builder_id:'';     
    let scheme_id        = (ketwords.schames)?ketwords.schames:'';     
    let budget           = (ketwords.budgetRange)?ketwords.budgetRange:'';     
    let downPayment      = (ketwords.downPayment)?ketwords.downPayment:'';    
    let possession_type  = (ketwords.posession)?ketwords.posession:'';
    let offers           = (ketwords.offers)?ketwords.offers:'';
    let sizeRange        = (ketwords.selectedSizeRange)?ketwords.selectedSizeRange:'';
    let order_by_price   = (ketwords.order_by_price)?ketwords.order_by_price:'';
    let start            = ketwords.start;
    
    query = `?config=${configs}&city_id=${city_id}&locality_id=${locality_id}&builder_id=${builder_id}&scheme_id=${scheme_id}&budget=${budget}&downPayment=${downPayment}&possession_type=${possession_type}&offer=${offers}&size=${sizeRange}&start=${start}&order_by_price=${order_by_price}`;

    const res               = await fetch(`${process.env.BASE_URL}listing`+query);
    const filter_result     = await res.json();
    return filter_result;
})

export const getCities = createAsyncThunk('filter/getCities',async ()=>{

    const res               = await fetch(`${process.env.BASE_URL}getcities`);
    const filter_result     = await res.json();
    return filter_result;
})
/* export const numberConverter = createAsyncThunk('filter/numberConverter',async (number, decimals, recursiveCall)=>{
    
    const decimalPoints = decimals || 2;
    const noOfLakhs = number / 100000;
    let displayStr;
    let isPlural;

    // Rounds off digits to decimalPoints decimal places
    function roundOf(integer) {
        return +integer.toLocaleString(undefined, {
            minimumFractionDigits: decimalPoints,
            maximumFractionDigits: decimalPoints,
        });
    }

    if (noOfLakhs >= 1 && noOfLakhs <= 99) {
        const lakhs = roundOf(noOfLakhs);
        isPlural = lakhs > 1 && !recursiveCall;
        displayStr = `${lakhs} Lakh${isPlural ? 's' : ''}`;
    } else if (noOfLakhs >= 100) {
        const crores = roundOf(noOfLakhs / 100);
        const crorePrefix = crores >= 100000 ? changeNumberFormat(crores, decimals, true) : crores;
        isPlural = crores > 1 && !recursiveCall;
        displayStr = `${crorePrefix} Crore${isPlural ? 's' : ''}`;
    } else {
        displayStr = roundOf(+number);
    }

    return displayStr;

})
 */


const filterSlice = createSlice({
    name:"filter",
    initialState,
    reducers:{
        selectFilter:(state,action)=>{
            switch (action.payload.type) {
                case 'flatName':
                    state.allFilters.flatName    = action.payload.filter
                    break;
                case 'budget':
                    state.allFilters.budgetRange = action.payload.filter
                    break;
                case 'downpayment':
                    state.allFilters.downPayment = action.payload.filter
                    break;
                case 'posession':
                    state.allFilters.posession   = action.payload.filter
                    break;
                case 'city_id':
                    state.allFilters.city_id     = action.payload.filter
                    break;
                case 'searchText':
                    state.allFilters.searchText  = action.payload.filter
                    break;
                case 'locality_id':
                    state.allFilters.locality_id = action.payload.filter
                    break;
                case 'builder_id':
                    state.allFilters.builder_id  = action.payload.filter
                    break;
                case 'size_range':
                    state.allFilters.selectedSizeRange  = action.payload.filter
                    break;
                case 'set_offer':
                    state.allFilters.offers  = action.payload.filter
                    break;
                case 'scheme':
                    state.allFilters.schames  = action.payload.filter
                    break;
                case 'more_filter':
                    state.allFilters.selectedSizeRange  = action.payload.sizeRange
                    state.allFilters.schames            = action.payload.schames
                    state.allFilters.offers             = action.payload.offers
                    // selectedSizeRange:'',
                    // schames: '',
                    // offers: 0,
                    break;
                case 'paginate':
                    state.allFilters.start  = action.payload.filter
                    break;
                case 'oder_by':
                    state.allFilters.order_by_price  = action.payload.filter
                    break;
                case 'reset_filter':
                    state.allFilters.start              = 1;
                    state.allFilters.city_id            = '';
                    state.allFilters.posession          = '';
                    state.allFilters.downPayment        = '';
                    state.allFilters.budgetRange        = '';
                    state.allFilters.flatName           = '';
                    // state.allFilters.builder_id         = '';
                    // state.allFilters.locality_id        = '';
                    state.allFilters.selectedSizeRange  = '';
                    state.allFilters.schames            = '';
                    state.allFilters.offers             = '';
                    state.allFilters.reset_filter       = action.payload.filter;
                    state.make_search                   = (action.payload.make_search)?action.payload.make_search:1;
                    break;
                default:
                    break;
            }
        },
        set_mobile_filters: (state,action)=>{  
            state.allFilters.start              = action.payload.start;
            state.allFilters.city_id            = action.payload.city_id;
            state.allFilters.posession          = action.payload.posession;
            state.allFilters.downPayment        = action.payload.downPayment;
            state.allFilters.budgetRange        = action.payload.budgetRange;
            state.allFilters.flatName           = action.payload.flatName;
            state.allFilters.selectedSizeRange  = action.payload.selectedSizeRange;
            state.allFilters.schames            = action.payload.schames;
            state.allFilters.offers             = action.payload.offers;
        },
        set_filters: (state,action)=>{
            switch (action.payload.type){
                case 'budgetRange':
                    let arr = [action.payload.minVal,action.payload.maxVal];
                    state.budgetRange = arr;
                default:
                    break;
            }
        },
        set_min_max_budget:(state,action)=>{
            console.log(action.payload);
            // state.budgetRange = action.payload;
        },
        do_select_city:(state,action)=>{
            state.selectedCity = action.payload;// here we settled City-ID
        },
        
        increase_paginate: (state,action)=>{
            state.paginate_start = action.payload
        }

    },
    extraReducers:{
        [getFilters.pending]: (state)=>{
            state.status = 'Loading';
        },

        [getFilters.fulfilled]: (state,{payload})=>{
            if(payload.res===true){
                state.flatName      = payload.configs;
                state.schemes       = payload.schemes;
                state.posessions    = payload.possession_types;
                state.sizeRange     = [payload.min_max_details[0].min_area,payload.min_max_details[0].max_area];
                state.budgetRange   = [payload.min_max_details[0].min_price,payload.min_max_details[0].max_price];
            }
        },

        [getFilters.rejected]: (state)=>{
            state.status = 'Error';
        },


        [applyFilters.pending]: (state)=>{
            state.status = 'Loading';
        },

        [applyFilters.fulfilled]: (state,{payload})=>{
            if(payload.res===true){
                state.filterResult   = payload.projects;
            }
        },

        [applyFilters.rejected]: (state)=>{
            state.status = 'Error';
        },


        [getCities.pending]: (state)=>{
            state.cityState = 'Loading';
        },

        [getCities.fulfilled]: (state,{payload})=>{

        let defaultCities  = localStorage.getItem('houseiy_location');
         //   console.log(defaultCities);
            if(payload.cities){
                state.city_data   = payload;
                // let city_data     = payload.cities;
                // for (let city_i = 0; city_i < city_data.length; city_i++) {
                //     if(city_data[city_i].default_city > 0){
                //         state.allFilters.city_id = city_data[city_i].city_id;
                //         break;
                //     }
                // }
                // console.log('Get City Data',payload.cities)
                // state.allFilters.city_id =
                
                
                if(payload){
                    // setCityData(getCity.payload.cities || [])
                    if(defaultCities){
                      let city_json = JSON.parse(defaultCities);
                      state.allFilters.city_id = city_json.city_id;
                    //   setSelectedCity(city_json.city_id)
                    }else{
                      for (let city_i = 0; city_i < payload.cities.length; city_i++) {
                        if(payload.cities[city_i].default_city){
                            state.allFilters.city_id = getCity.payload.cities[city_i].city_id;
                        //   setSelectedCity(getCity.payload.cities[city_i].city_id)
                        //   dispatch(do_select_city(getCity.payload.cities[city_i]))
                        //   let obj = {
                        //     type: 'city_id',
                        //     filter: getCity.payload.cities[city_i].city_id
                        //   }
                        //   dispatch(set_filters(obj));
                          break;
                        }
                      }
                    }
                }
                
            }
        },

        [getCities.rejected]: (state)=>{
            state.cityState = 'Error';
        },




    }

});



export const {selectFilter,set_min_max_budget,set_filters,do_select_city,increase_paginate,set_mobile_filters} = filterSlice.actions;
export default filterSlice.reducer;
