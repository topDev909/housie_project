
import {createSlice} from '@reduxjs/toolkit';
const initialState = {
    signUpModalStep:    false, 
    show_thanku_modal:  true,
    start_sign_up:      true,
    signup_title:       'Sign-Up',
    ola_modal_type:     true,
    mobileNumber:       '',
    start_sent_otp:     false,
    activeTab:          '1',
    last_modal_type:    '1',
    modal_details:      '',
    is_first_time_login:     false,
    session_data:       '',
    enq_data:           [],
    form_step:          0,
    downloadFile: '',
    is_login_download: false,
    download_file_name: 'download',
    afterLoginModal: false,
    show_sign_up_perks: false,
    open_download_signup:false,
    page_type: '',
    enq_project_id: ''
    
}
export const signUpModalSlice = createSlice({
    name:"signUpModal",
    initialState,
    reducers:{
        set_modal_state: (state,action)=>{
            state.signUpModalStep = action.payload;
        },
        set_signup_state: (state,action)=>{
            state.start_sign_up = action.payload
        },
        set_signup_title: (state,action)=>{
            state.signup_title = action.payload
        },
        set_ola_modal_tab:(state,action)=>{
            state.ola_modal_type = action.payload
        },
        set_thank_u_modal: (state,action)=>{
            state.show_thanku_modal = action.payload
        },
        set_mobile_number: (state,action)=>{
            state.mobileNumber = action.payload;
        },
        set_sent_otp: (state,action)=>{
            state.start_sent_otp = action.payload;
        },
        set_active_tab: (state,action)=>{
            state.activeTab = action.payload;
        },
        set_last_modal:(state,action)=>{
            state.last_modal_type = action.payload;
        },
        set_modal_details: (state,action)=>{
            state.modal_details = action.payload
        },
        set_first_time_login:(state,action)=>{
            state.is_first_time_login = action.payload 
        },
        set_session:(state,action)=>{
            state.session_data = action.payload
        },
        set_enq_data:(state,action)=>{
            state.enq_data  = action.payload; 
        },
        set_form_step: (state,action)=>{
            state.form_step = action.payload;
        },
        set_download_file: (state,action)=>{
            state.downloadFile       = action.payload.file
            state.is_login_download  = action.payload.status
            state.download_file_name = action.payload.name
        },
        set_after_login_modal: (state,action)=>{
            state.afterLoginModal = action.payload;
        },
        set_show_sign_up_perks: (state,action)=>{
            state.show_sign_up_perks = action.payload
        },
        set_open_download_signup: (state,action)=>{
            state.open_download_signup = action.payload
        },
        set_page_type: (state,action)=>{
            state.page_type = action.payload.page_type;
            state.enq_project_id = action.payload.project_id
        }
    }   
});
export const { set_modal_state,set_signup_state,set_signup_title,set_thank_u_modal,set_ola_modal_tab,set_mobile_number,set_sent_otp,set_active_tab,set_modal_details,set_first_time_login,set_form_step,set_enq_data,set_download_file,set_after_login_modal,set_show_sign_up_perks,set_open_download_signup,set_page_type} = signUpModalSlice.actions;
export default signUpModalSlice.reducer;


