import {createSlice} from '@reduxjs/toolkit';
const initialState  = {
    openModal:false,
    signup_next:false,
    mobileNumber:'',
    openThankyouModal:false,
    activeTab: '1',
    ola_modal_type: true,
    openStep1Modal:false,
    openSortModal:false,
    openFilterModal:false,
    openDownloadModal:false,
    }
const MobileSignUpModalSlice = createSlice({
    name:"MobileSignUpModal",
    initialState,
    reducers:{
        set_sign_up_modal:(state,action)=>{
            state.signup_next   = false;
            state.openModal     = action.payload
        },
        set_sign_up_next_step: (state,action)=>{
            state.signup_next = action.payload
        },
        set_mobile_number: (state,action)=>{
            state.mobileNumber = action.payload;
        },
        set_thanks_modal: (state,action)=>{
            state.openThankyouModal = action.payload;
        }, 
        set_step1_modal: (state,action)=>{
            state.openStep1Modal = action.payload;
        }, 
        
        set_active_tab: (state,action)=>{
            state.activeTab = action.payload;
        },
        set_ola_modal_tab:(state,action)=>{
            state.ola_modal_type = action.payload
        },
        set_Sort_modal:(state,action)=>{
            state.openSortModal = action.payload
        },
         set_Filter_modal:(state,action)=>{
            state.openFilterModal = action.payload
        },
        set_download_modal: (state,action)=>{
            state.openDownloadModal = action.payload
        },
        // set_download_info : (state,action)
    }
});

export const { set_Filter_modal,set_Sort_modal,set_active_tab,set_ola_modal_tab,set_sign_up_modal,set_sign_up_next_step,set_mobile_number,set_thanks_modal,set_step1_modal,set_download_modal } = MobileSignUpModalSlice.actions;
export default MobileSignUpModalSlice.reducer;

