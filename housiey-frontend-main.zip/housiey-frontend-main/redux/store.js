import {configureStore} from '@reduxjs/toolkit';
import counterReducer   from './slices/counterSlice';
import categoryReducer  from './slices/categorySlice';
import projectsReducer  from './slices/projectsSlice';
import filterReducer  from './slices/filterSlice';
import signUpModalSlice from './slices/signUpModalSlice';
import MobileSignUpModalReducer from './slices/MobileSignUpModalSlice';

export const store = configureStore({
    reducer:{counter:counterReducer,category:categoryReducer,projects:projectsReducer,filter:filterReducer,signUpModal:signUpModalSlice,MobileSignUpModal:MobileSignUpModalReducer}
})