/* eslint-disable @next/next/no-sync-scripts */
import '../styles/globals.css'
import Head from 'next/head';
import '@fortawesome/fontawesome-svg-core/styles.css'

import { createTheme, ThemeProvider, styled } from '@mui/material/styles';


import Layout from '../components/Layout';
import React, {useEffect,useState} from 'react';
import App from "next/app"



import { store } from '../redux/store';
import { Provider } from 'react-redux';



import Router from 'next/router';
import NProgress from 'nprogress';


const THEME = createTheme({
  root: {
   "fontFamily": `'Source Sans Pro',sans-serif`,
   "fontSize": 14,
   "fontWeightLight": 300,
   "fontWeightRegular": 400,
   "fontWeightMedium": 500
  }
});






export default function MyApp({isMobileView, Component, pageProps }) {



const [screenLoader,setScreanLoader] = useState(false);


  Router.onRouteChangeStart = () => {
    console.log('onRouteChangeStart triggered');
    setScreanLoader(true)
    NProgress.start();
  };
  
  Router.onRouteChangeComplete = () => {
    console.log('onRouteChangeStart On Change Complete');
    setScreanLoader(false)
    NProgress.done();
  };
  
  Router.onRouteChangeError = () => {
    console.log('onRouteChangeStart On Change Error');
    setScreanLoader(false)
    NProgress.done();
  };
  
  

  


  
  return (
    <ThemeProvider theme={THEME}>
      <Provider store={store}>
          <>
                <Head>
                  <link href="/assets/css/styles.css" rel="stylesheet"/> 
                  <link href="/assets/css/home.css" rel="stylesheet"/>  

                  <link rel="stylesheet" type="text/css" media="screen and (max-device-width: 780px)" href="/assets/css/style-mobile.css" />
                  <link rel="stylesheet" type="text/css" media="screen and (max-device-width: 780px)" href="/assets/css/mobile-index.css" />
                  <link rel="stylesheet" type="text/css" media="screen and (max-device-width: 780px)" href="/assets/css/single_mobile.css" />
                  <link rel="stylesheet" type="text/css" media="screen and (max-device-width: 780px)" href="/assets/css/imagegallery.css" />


                  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-137729094-2" />

                  <script
                    dangerouslySetInnerHTML={{
                      __html: `
                      window.dataLayer = window.dataLayer || [];
                      function gtag(){dataLayer.push(arguments);}
                      gtag('js', new Date());
                      gtag('config', 'UA-137729094-2');            `,
                    }}
                  />



                </Head>
                <Layout>




                  {screenLoader ? <> 
                    <div className='loading-box'>
                      <img src="https://thumbs.gfycat.com/ElectricDesertedGannet-max-1mb.gif" className='main-page-loader' />
                    </div>

                  </> : ""}
                <Component {...pageProps}/>
                </Layout> 
                <script src="/assets/js/jquery.min.js"></script>
                <script src="/assets/js/popper.min.js"></script>
                <script src="/assets/js/bootstrap.min.js"></script>
                <script src="/assets/js/ion.rangeSlider.min.js"></script>
                <script src="/assets/js/select2.min.js"></script>
                <script src="/assets/js/jquery.magnific-popup.min.js"></script>
                <script src="/assets/js/slick.js"></script>
                <script src="/assets/js/slider-bg.js"></script>
                <script src="/assets/js/lightbox.js"></script> 
                <script src="/assets/js/imagesloaded.js"></script>
                <script src="/assets/js/daterangepicker.js"></script>
                <script src="/assets/js/custom.js"></script>
                <script src="/assets/js/single.js"></script>
                <script src="/assets/js/listing.js"></script>
                {/* Date Booking Script */}
                <script src="/assets/js/moment.min.js"></script>
                <script src="/assets/js/daterangepicker.js"></script>
                
                {/* <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAh2NR5_a2X3L3f7hyL3K0Oha8KY2uc0NM&libraries=places"></script> */}

          
          </>
      </Provider>
    </ThemeProvider>

  );
}


App.getInitialProps = async (ctx)=>{

    let isMobileView = (ctx.req ? ctx.req.headers['user-agent'] : navigator.userAgent).match( /Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i )



    console.log('here we are going to show ',isMobileView,ctx.req)
    
    // const res = await fetch(process.env.BASE_URL+"/top-launches-projects/10");
    // const project = await res.json();


    //Returning the isMobileView as a prop to the component for further use.
    return {
      isMobileView: Boolean(isMobileView),
      project: []
    }


}


// MyApp.getInitialProps = async (ctx)=>{
//   console.log(ctx.req)
//   let isMobileView = (ctx.req ? ctx.req.headers['user-agent'] : navigator.userAgent).match( /Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i )


    
//     // const res = await fetch(process.env.BASE_URL+"/top-launches-projects/10");
//     // const project = await res.json();


//     //Returning the isMobileView as a prop to the component for further use.
//     return {
//       isMobileView: Boolean(isMobileView),
//       project: []
//     }

//  }



// export default MyApp
