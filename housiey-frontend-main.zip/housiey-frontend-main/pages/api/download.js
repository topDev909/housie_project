
import stream from 'stream';
import { promisify } from 'util';
import fetch from 'node-fetch';

const pipeline = promisify(stream.pipeline);

const handler = async (req, res) => {
  let pdf_url    = process.env.BASE_URL+req.query.link;
  let file_name  = req.query.name;
  const response = await fetch(pdf_url); // replace this with your API call & options
  if (!response.ok) throw new Error(`unexpected response ${response.statusText}`);
  res.setHeader('Content-Type',         'application/pdf');
  res.setHeader('Content-Disposition',  `attachment; filename=${file_name}.pdf`);
  await pipeline(response.body, res);
};

export default handler;