// Next.js API route support: https://nextjs.org/docs/api-routes/introduction

export default async function handler(req, res) {
  
  
  let check = await fetch("http://194.233.70.101:9001/api/verify-otp",{
            method:'POST',
            headers:req.headers,
            body:req.body
        })
  let check_result = await check.json();

  res.status(200).json({ status:true,check_result: check_result })
}
