import React,{useState,useEffect}   from 'react';
import Head                         from 'next/head';
import { useDispatch }              from "react-redux";
import { getFilters,selectFilter }  from "../../redux/slices/filterSlice";
import  Signup                      from "../../components/component/Auth/Signup";
import Olamodel                     from '../../components/Olamodel';
import MainListing                  from '../../components/Listing/MainListing';
import DesktopSinglePage            from '../../components/single/DesktopSinglePage';
import MainSingleMobilePage         from '../../components/mobile-components/Single_mobile/MainSingleMobilePage';
import LoginThankModal              from '../../components/inc/LoginThankModal';
import Thankmodal                   from '../../components/component/Auth/Thankmodal';
import ListingPage                  from '../../components/mobile-components/listing-page/ListingPage';

import AfterLoginThanksModal        from '../../components/mobile-components/inc/AfterLoginThanksModal';
import Thankyou_modal               from '../../components/mobile-components/home-page/Thankyou_modal';
import Step1_modal                  from '../../components/mobile-components/home-page/Step1_modal';

import Footer_mobile                from '../../components/mobile-components/inc/Footer_mobile';
import Footer                       from '../../components/inc/Footer';
import {set_page_type}              from '../../redux/slices/signUpModalSlice';
import { Fetchmeta } from '../../utils/BasicFn';


const Search = ({search_query,page_type,details,single_page_data,isMobileView,mobileData,metaData})=>{
    const dispatch              = useDispatch(); 
    const [citName,setCityName] = useState('');
    
    useEffect( async()=>{

        let obbj = {
            type: 'reset_filter',
            filter: 0,
            make_search: 1,
        }
        dispatch(selectFilter(obbj))




        let cityData = JSON.parse(localStorage.getItem('houseiy_location'));
        if(cityData){
            setCityName(cityData.name)
            if(page_type==='listing'){
                let obbj = {
                    type: 'city_id',
                    filter: cityData.city_id
                }
                dispatch(selectFilter(obbj))
            }
        }else{
            let fetcheCity       = await fetch(process.env.BASE_URL+'get-default-city');
            if(fetcheCity.ok){
                let cityFetchData  = await fetcheCity.json();
                cityData = {"city_id":cityFetchData.data[0].city_id,"name":cityFetchData.data[0].name,"default_city":1};
                if(page_type==='listing'){
                    let obbj = {
                        type: 'city_id',
                        filter: cityFetchData.data[0].city_id
                    }
                    dispatch(selectFilter(obbj))
                }
                
                localStorage.setItem('houseiy_location',JSON.stringify(cityData))
            }
              
        }

        console.log('here we are now ',cityData,metaData)
        
        if(page_type==='locality'){
            let localityName = details.replaceAll("-"," ");
            let obbj = {
                type: 'locality_id',
                filter: localityName
            }
            dispatch(selectFilter(obbj))
        }


        if(page_type==='under_projects'){
            let matches     = details.match(/\d+/g);
            let minPrice    = matches[0] * 100000; 
            let maxPrice    = (matches.length===2) ? matches[1] * 100009 : matches[0] * 100000;
            let obj = {
                filter: minPrice+','+maxPrice,
                type: 'budget'
            }
            dispatch(selectFilter(obj))   
        }

        // console.log(mobileData.project)
        if(page_type==='single_project'){
            let obj = {
                page_type:"details",
                project_id: mobileData.project.id
            }
            dispatch(set_page_type(obj))
        }

   

    },[search_query,page_type,details])

  
   
    return (
        <>  
        <Head>
            <title>Property In {citName} : : {process.env.TITLE} </title>
            <meta name="keywords" content={metaData.data.meta_tags}></meta>
           
            <meta name="description" content={metaData.data.description}></meta>
            <meta property='og:description'  content={metaData.data.description}></meta>
            <meta name='twitter:description' content={metaData.data.description}></meta>

            <meta name="title" content={metaData.data.title}></meta>
            <meta property='og:title'  content={metaData.data.title}></meta>
            <meta name='twitter:title' content={metaData.data.title}></meta>

            <meta name="image" content={"http://64.227.164.7:4001/uploads/"+metaData.data.image}></meta>
            <meta property="og:image"  content={"http://64.227.164.7:4001/uploads/"+metaData.data.image}></meta>
            <meta name="twitter:image" content={"http://64.227.164.7:4001/uploads/"+metaData.data.image}></meta>

            <meta property="og:image:alt" content={metaData.data.alttag} />
            <meta name="twitter:image:alt" content={metaData.data.alttag}></meta>

        </Head>
        {isMobileView ? 
        <>
            {page_type==='single_project' ? <> <MainSingleMobilePage SingleProjectData={mobileData}  search_query={search_query} page_type={page_type} details={details}  /> </> : <><ListingPage  search_query={search_query} page_type={page_type} details={details} /></>}  
            <AfterLoginThanksModal />
            <Thankyou_modal/>
            <Step1_modal/>
            <Footer_mobile/>
        </> 
        : 
        <>
            {page_type!=='single_project' && <><MainListing  search_query={search_query} page_type={page_type} details={details}/></>}
            {page_type==='single_project' && <><DesktopSinglePage data={single_page_data}/></>}
            <Signup    />
            <Olamodel  />
            <Thankmodal/>
            <LoginThankModal  />
            <Footer/>
        </> }
        </>
    )
}



export async function getServerSideProps(ctx) {


    let isMobileView = (ctx.req
        ? ctx.req.headers['user-agent']
        : navigator.userAgent).match(
          /Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i
        )
    let query_params        = ctx.query.search;
    let page_type           = 'listing';
    let location_details    = ''; 
    let filterPrice = '';
    
    if(query_params.length <= 2){
            page_type = 'listing';
            location_details = query_params[0];
    }else if(query_params.length <= 3){
        if(query_params[2]==='projects'){
            page_type        = 'locality';
            location_details = query_params[1];
        }else{
            location_details = query_params[2];
            page_type        = 'single_project';
        }
    }else if(query_params.length <= 4){
        page_type           = 'under_projects';        
        location_details    = query_params[2];
    }
    else{
        page_type = 'not_found';
    }   

    let send_data  = {};
    let sendMobile = {};
    if(page_type ==='single_project'){
        let query  = await fetch(process.env.BASE_URL+`/project/${query_params[2]}`);
        let data   = [];
        if(query.ok){
            data = await query.json();
            send_data = {
                project:        data.project,
                address:        data.address,
                images:         data.images,
                banks:          data.banks,
                tour_video:     data.tour_video,
                project_videos: data.project_videos,
                conigs_deatils: data.conigs_deatils,
                int_amenities:  data.int_amenities,
                ext_amenities:  data.ext_amenities,
                master_plan:    data.master_plan,
                location:       data.location,
                floor_plan:     data.floor_plan,
                schemes:        data.schemes,
                pros:           data.pros,
                cons:           data.cons,
                conigs:         data.conigs,
                faqs:           data.faqs,
                brocher:        data.brocher,     
                plan_kit:        data.plan_kit,     
                payment_schedule:        data.payment_schedule,     
                price_sheet:             data.price_sheet,     
                rera_details:            data.rera_details,     
                sellerInfo:            data.sellerInfo,     
            }


            sendMobile  = {
                project:            data.project[0],
                address:            data.address,
                images:             data.images,
                banks:              data.banks,
                tour_video:         data.tour_video,
                project_videos:     data.project_videos,
                conigs_deatils:     data.conigs_deatils,
                conigs:             data.conigs,
                int_amenities:      data.int_amenities,
                ext_amenities:      data.ext_amenities,
                master_plan:        data.master_plan,
                location:           data.location,
                floor_plan:         data.floor_plan, 
                schemes:            data.schemes,
                pros:               data.pros,
                cons:               data.cons,
                brocher:            data.brocher,
                rera_details:       data.rera_details, 
                price_sheet:        data.price_sheet,
                plan_kit:           data.plan_kit,
                faqs:              data.faqs,
                sellerInfo:         data.sellerInfo,
                payment_schedule:        data.payment_schedule
            }
        }
    }

    let metaData = await Fetchmeta(query_params);
   
    return {
      props: {search_query:query_params,page_type:page_type,details:location_details,
        isMobileView: Boolean(isMobileView),
        single_page_data:send_data,
        mobileData: sendMobile,
        metaData: metaData
    }, 
      // will be passed to the page component as props
    }
  }


export default Search;