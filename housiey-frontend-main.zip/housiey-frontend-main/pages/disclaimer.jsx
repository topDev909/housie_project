import React         from 'react';
import Head          from 'next/head';
import Footer        from '../components/inc/Footer';
import ListingHeader from '../components/Listing/ListingHeader';
import HeaderMobile  from '../components/mobile-components/inc/Header_mobile';
import Footer_mobile  from '../components/mobile-components/inc/Footer_mobile';
import Signup_modal   from '../components/mobile-components/home-page/Signup_modal';
import Link           from 'next/link';


import AfterLoginThanksModal      from '../components/mobile-components/inc/AfterLoginThanksModal';
import Thankyou_modal             from '../components/mobile-components/home-page/Thankyou_modal';



import LoginThankModal            from '../components/inc/LoginThankModal';
import Thankmodal                 from '../components/component/Auth/Thankmodal';
import Signup                 from '../components/component/Auth/Signup';

import styles from '../styles/PrivacyPolicy.module.css';


const Disclaimer = ({isMobileView})=>{
    return (
                <>
                    <Head >
                        <title>About : : {process.env.TITLE}</title>
                    </Head>         
                    {/* ============================================================== */}
                    {/* Preloader - style you can find in spinners.css */}
                    {/* ============================================================== */}
                    
                    {/* ============================================================== */}
                    {/* Main wrapper - style you can find in pages.scss */}
                    {/* ============================================================== */}
                    <div id="main-wrapper">
                        {/* ============================================================== */}
                        {/* Top header  */}
                        {/* ============================================================== */}

                        {isMobileView ? <HeaderMobile/>   :  <ListingHeader /> }
                        <div className="clearfix" />
                        {/* ============================================================== */}
                        {/* Top header  */}
                        {/* ============================================================== */}
                        {/* ============================ Page Title Start================================== */}
                       
                        {/* ============================ Page Title End ================================== */}
                        {/* ============================ Our Story Start ================================== */}
                        



                        <>
                        <div className='container-fluid mt-5'>
                            <div className='row'>
                                <div className='col-lg-3 col-md-4 col-sm-12'>
                                    <aside className={styles.sidebar}>
                                        <nav className={styles.nav}>
                                            <ul>
                                            <li>
                                                <Link href="/privacy-policy">
                                                    <a>Privacy Policy</a>
                                                </Link>
                                            </li>
                                            <li className={styles.active}>
                                                <a href="#">Disclaimer</a>
                                            </li>
                                            
                                            </ul>
                                        </nav>
                                    </aside>
                                </div>
                                <div className='col-lg-9 col-md-8 col-sm-12'>
                                    <section className={styles.twitter}>
                                        <div className="container">
                                            <h2>Discalimer</h2>                                            
                                            <p>Housiey.com will take all possible measures to avoid any misrepresentation, fraud, illegal and unlawful action/inaction by any person using services of Housiey.com but does not guarantee for any accuracy, correctness and/or reliability of any such information/content or user of Housiey.com. As a user, you are expected and assumed to be alert and check the accuracy and correctness of any information submitted by any user on Housiey.com site. Anything provided on this site is only for your reference and should not be treated as an advice of Housiey.com and before using or 
                                                putting into any use of any such advice, or draft document you must consult a Legal practitioner.
                                            </p>
                                            <ul className={styles.list}>
                                                <li>Your use of the Housiey.com service is at your sole risk please note that this Agreement strictly limits our liability and Housiey.com does 
                                                    not provide any warranty for the service. The Agreement also limits your remedies
                                                </li>
                                                <li>Housiey.com shall not be liable or responsible to verify the authenticity of the content posted by the users/Users on the site such as, property price, plan, location, opinion/suggestions etc and shall in no way be responsible for any loss/damages caused to the User/Users. Housiey.com only provides a platform/medium for communication between the property seekers, property providers & property or related service(s) providers. Housiey.com is not responsible for any incorrect or inaccurate content posted on the site or in connection with the Housiey.com service, whether caused by User/Users or by any of the equipment or programming associated with or utilized neither in the service,
                                                     nor for the conduct of any User and/or Users of the Housiey.com service whether online or offline</li>
                                                <li>Housiey.com does not guarantee or confirm the financial capability of any User/Users of its services and does not acknowledge any ownership or guarantee for complying with the 
                                                    obligation between the property buyer and seller or licensor/lessor and licensee/lessee</li>
                                                <li>Housiey.com is not responsible for any incorrect or inaccurate content posted on the site or in connection with the Housieyl.com service, whether caused by User/Users or by any 
                                                    of the equipment or programming associated with or utilized neither in the service, nor for the </li>
                                                <li>Housiey.com assumes no responsibility for any error, omission, interruption, deletion, defect, delay in operation or transmission, communications line failure, 
                                                    theft or destruction or unauthorized access to, or alteration of, user and/or User communications
                                                    
                                                </li>
                                                <li>Under no circumstances will Housiey.com be responsible for any loss or damage resulting from anyone&#39;s use of the site or the service and/ or any 
                                                    content/data posted on the Housiey.com site or transmitted to </li>
                                                
                                            </ul>
                                            <span className={styles.query}>
                                                <h3>Any Queries?</h3>
                                                <p><i className="fa fa-phone-alt"></i> <a href='tel:+918097452839'>+91 8097452839 </a>
                                                &nbsp;&nbsp; OR &nbsp;&nbsp; <i className="fa fa-envelope"></i> <a href='mailto: info@housiey.com'>info@housiey.com</a> </p>
                                            </span>   
                                        </div>
                                    </section>
                                </div>
                            </div>
                        </div>
                           
                        </>


                      

                        <div className="clearfix" />

                    </div>
                    {/* ============================================================== */}
                    {/* End Wrapper */}
                    {/* ============================================================== */}
                    {/* ============================================================== */}
                    {/* All Jquery */}
                    {/* ============================================================== */}
                    {/* ============================================================== */}
                    {/* This page plugins */}
                    {/* ============================================================== */}
                    { (isMobileView) ? <Footer_mobile/> : <Footer/> }
                    

                    <AfterLoginThanksModal />
                    <Thankyou_modal/>


                    
        <LoginThankModal/>
        <Thankmodal/>


        {isMobileView?<Signup_modal/> : <Signup/> }


                </>
        )
}

Disclaimer.getInitialProps = async (ctx)=>{
    let isMobileView = (ctx.req
      ? ctx.req.headers['user-agent']
      : navigator.userAgent).match(
        /Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i
      )
        return {
        isMobileView: Boolean(isMobileView),
        project: []
      }
      
    }
export default Disclaimer;
