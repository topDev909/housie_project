import React         from 'react';
import Head          from 'next/head';
import Footer        from '../components/inc/Footer';
import ListingHeader from '../components/Listing/ListingHeader';
import HeaderMobile  from '../components/mobile-components/inc/Header_mobile';
import Footer_mobile  from '../components/mobile-components/inc/Footer_mobile';
import Signup_modal   from '../components/mobile-components/home-page/Signup_modal';
import Link            from 'next/link';


import AfterLoginThanksModal      from '../components/mobile-components/inc/AfterLoginThanksModal';
import Thankyou_modal             from '../components/mobile-components/home-page/Thankyou_modal';



import LoginThankModal            from '../components/inc/LoginThankModal';
import Thankmodal                 from '../components/component/Auth/Thankmodal';
import Signup                 from '../components/component/Auth/Signup';

import styles from '../styles/PrivacyPolicy.module.css';


const PrivacyPolicy = ({isMobileView})=>{
    return (
                <>
                    <Head >
                        <title>About : : {process.env.TITLE}</title>
                    </Head>         
                    {/* ============================================================== */}
                    {/* Preloader - style you can find in spinners.css */}
                    {/* ============================================================== */}
                    
                    {/* ============================================================== */}
                    {/* Main wrapper - style you can find in pages.scss */}
                    {/* ============================================================== */}
                    <div id="main-wrapper">
                        {/* ============================================================== */}
                        {/* Top header  */}
                        {/* ============================================================== */}

                        {isMobileView ? <HeaderMobile/>   :  <ListingHeader /> }
                        <div className="clearfix" />
                        {/* ============================================================== */}
                        {/* Top header  */}
                        {/* ============================================================== */}
                        {/* ============================ Page Title Start================================== */}
                       
                        {/* ============================ Page Title End ================================== */}
                        {/* ============================ Our Story Start ================================== */}
                        



                        <>
                        <div className='container-fluid mt-5'>
                            <div className='row'>
                                <div className='col-lg-3 col-md-4 col-sm-12'>
                                    <aside className={styles.sidebar}>
                                        <nav className={styles.nav}>
                                            <ul>
                                            <li className={styles.active}>
                                                <a>Privacy Policy</a>
                                            </li>
                                            <li>
                                                <Link href="/disclaimer">
                                                    <a>Disclaimer</a>
                                                </Link>
                                            </li>
                                            
                                            </ul>
                                        </nav>
                                    </aside>
                                </div>
                                <div className='col-lg-9 col-md-8 col-sm-12'>
                                    <section className={styles.twitter}>
                                        <div className="container">
                                            <h2>Privacy Policy</h2>
                                            <span><b>Housiey.com  the website is owned and operated by Housiey Property Solutions Pvt Ltd</b></span>
                                            <p>Housiey Property Solutions Pvt Ltd has created this privacy statement 
                                               in order to demonstrate our commitment to our user&#39;s privacy
                                            </p>
                                            <ul className={styles.list}>
                                                <li>We may use an IP address to help diagnose problems with our server and to administer our Web site. 
                                                    Your IP address may be also used to gather broad demographic information
                                                </li>
                                                <li>Neat layout without clutter and unnecessary advertisements</li>
                                                <li>Housieyl.com contains links to other Websites. Housiey Property Solutions Pvt Ltd. 
                                                    is not responsible for the privacy practices or the content of such Web sites.</li>
                                                <li>We may use a third-party ad company to display ads on Housiey.com (e.g. Google AdSense). These ads may contain cookies. 
                                                    While we may use cookies in other parts of our Web sites, cookies received with banner ads are collected by our ad company, 
                                                    and we do not have access to this information.</li>
                                                <li>Certifiable information is collected from users and/or registered members of Housiey.com which includes, but may not be limited to
                                                    <ul>
                                                        <li>Email address</li>
                                                        <li>Contact person name</li>
                                                        <li>User-created password</li>
                                                        <li>Mailing address</li>
                                                        <li>Pin code</li>
                                                        <li>Telephone number or another contact number</li>
                                                    </ul>
                                                </li>
                                                <li>Except where you are explicitly informed, Housiey Property Solutions 
                                                    Pvt Ltd does not sell or trade any of your personal information</li>
                                                <li>Housiey.com may tie-up with pre-verified and qualified partners 
                                                    to bring you related services. We will </li>
                                                <li>selectively share your personal information to ensure high-quality services. We encourage you to review the privacy policy of the partner for questions about their use, 
                                                    any personally identifiable information that you may separately submit to such partner</li>
                                                <li>If we change our privacy policy, we will prominently post a link to those changes on our website. If at any point we decide to use personally identifiable information in a manner materially different from that stated at the time it was collected, we will notify you by way of an email. We will give you a choice as to whether or 
                                                    not we can use information in this different manner and act accordingly.</li>
                                                
                                            </ul>
                                            <span className={styles.query}>
                                                <h3>Any Queries?</h3>
                                                <p><i className="fa fa-phone-alt"></i> <a href='tel:+918097452839'>+91 8097452839 </a>
                                                &nbsp;&nbsp; OR &nbsp;&nbsp; <i className="fa fa-envelope"></i> <a href='mailto: info@housiey.com'>info@housiey.com</a> </p>
                                            </span>   
                                        </div>
                                    </section>
                                </div>
                            </div>
                        </div>
                           
                        </>


                      

                        <div className="clearfix" />

                    </div>
                    {/* ============================================================== */}
                    {/* End Wrapper */}
                    {/* ============================================================== */}
                    {/* ============================================================== */}
                    {/* All Jquery */}
                    {/* ============================================================== */}
                    {/* ============================================================== */}
                    {/* This page plugins */}
                    {/* ============================================================== */}
                    { (isMobileView) ? <Footer_mobile/> : <Footer/> }
                    

                    <AfterLoginThanksModal />
                    <Thankyou_modal/>


                    
        <LoginThankModal/>
        <Thankmodal/>


        {isMobileView?<Signup_modal/> : <Signup/> }


                </>
        )
}

PrivacyPolicy.getInitialProps = async (ctx)=>{
    let isMobileView = (ctx.req
      ? ctx.req.headers['user-agent']
      : navigator.userAgent).match(
        /Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i
      )
        return {
        isMobileView: Boolean(isMobileView),
        project: []
      }
      
    }
export default PrivacyPolicy;
