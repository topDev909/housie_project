import React         from 'react';
import Head          from 'next/head';
import AboutCounter  from '../components/inc/AboutCounter';
import Footer        from '../components/inc/Footer';
import ListingHeader from '../components/Listing/ListingHeader';
import HeaderMobile  from '../components/mobile-components/inc/Header_mobile';
import Footer_mobile  from '../components/mobile-components/inc/Footer_mobile';
import Signup_modal   from '../components/mobile-components/home-page/Signup_modal';


import AfterLoginThanksModal      from '../components/mobile-components/inc/AfterLoginThanksModal';
import Thankyou_modal             from '../components/mobile-components/home-page/Thankyou_modal';



import LoginThankModal            from '../components/inc/LoginThankModal';
import Thankmodal                 from '../components/component/Auth/Thankmodal';
import Signup                 from '../components/component/Auth/Signup';


const AboutUs = ({isMobileView})=>{
    return (
                <>
                    <Head >
                        <title>About : : {process.env.TITLE}</title>
                    </Head>         
                    {/* ============================================================== */}
                    {/* Preloader - style you can find in spinners.css */}
                    {/* ============================================================== */}
                    
                    {/* ============================================================== */}
                    {/* Main wrapper - style you can find in pages.scss */}
                    {/* ============================================================== */}
                    <div id="main-wrapper">
                        {/* ============================================================== */}
                        {/* Top header  */}
                        {/* ============================================================== */}

                        {isMobileView ? <HeaderMobile/>   :  <ListingHeader /> }
                        <div className="clearfix" />
                        {/* ============================================================== */}
                        {/* Top header  */}
                        {/* ============================================================== */}
                        {/* ============================ Page Title Start================================== */}
                        <div
                        className="page-title"
                        style={{ background: "url(/assets/img/pattern.png) no-repeat rgb(35, 78, 112)" }}
                        data-overlay={5}
                        >
                        <div className="container">
                            <div className="row">
                            <div className="col-lg-12 col-md-12">
                                <div className="breadcrumbs-wrap text-center">
                                <ol className="breadcrumb">
                                    <li
                                    className="breadcrumb-item text-center active"
                                    style={{ float: "none", fontSize: 22, fontWeight: 600 }}
                                    aria-current="page"
                                    >
                                    Housiey makes Home Buying Simplified
                                    </li>
                                </ol>
                                <h2
                                    className="breadcrumb-title"
                                    style={{ fontSize: 32, fontWeight: 800, lineHeight:1 }}
                                >
                                    People &amp; Property - Two Things we are passionate about.
                                </h2>
                                <p style={{ fontSize: 16, fontWeight: 600 }}>
                                    At Housiey, we aspire to build a data driven digital ecosystem
                                    to help and enable home buyers to take unbiased and informed
                                    decisions while buying their homes.
                                </p>
                                </div>
                            </div>
                            </div>
                        </div>
                        </div>
                        {/* ============================ Page Title End ================================== */}
                        {/* ============================ Our Story Start ================================== */}
                        <section>
                        <div className="container">
                            {/* row Start */}
                            <div className="row align-items-center">
                            <div className="col-lg-6 col-md-6">
                                <div className="story-wrap explore-content">
                                <h2 style={{ fontSize: 24 }}>
                                    We have two strong pillars on which we stand firm -
                                </h2>
                                {/* Single Item */}
                                <div
                                    className="_walk_score_list"
                                    style={{
                                    padding: 20,
                                    background: "rgba(5, 175, 120,0.1)",
                                    borderRadius: 10
                                    }}
                                >
                                    <div className="_walk_score_flex">
                                    <img src="/assets/img/no-brokerage.svg" width={50} />
                                    <div className="_walk_score_caption">
                                        <h5>No Brokerage Policy</h5>
                                        <span>
                                        We don&apos;t charge single penny from our customers{" "}
                                        </span>
                                    </div>
                                    </div>
                                </div>
                                <div
                                    className="_walk_score_list"
                                    style={{
                                    padding: 20,
                                    background: "rgba(5, 175, 120,0.1)",
                                    borderRadius: 10
                                    }}
                                >
                                    <div className="_walk_score_flex">
                                    <img src="/assets/img/bottom-rate.svg" width={50} />
                                    <div className="_walk_score_caption">
                                        <h5>Bottom Rate Guarantee </h5>
                                        <span>
                                        We commit our esteemed clients that through Housiey, they
                                        will get the bottom rate on all the projects listed on our
                                        platform &amp; if that&apos;s not the case We will refund
                                        double the price difference.
                                        </span>
                                    </div>
                                    </div>
                                </div>
                                <p className="mt-4">
                                    Unlike other Real Estate portals &amp; brokerage companies, We
                                    don&apos;t do typical sales where we push clients for one particular
                                    project, instead we give them the unbiased views of every
                                    project along with the pros &amp; cons &amp; then let the client
                                    decide what he/she needs.
                                </p>
                                </div>
                            </div>
                            <div className="col-lg-6 col-md-6">
                                <img
                                    src="/assets/img/about-us-second.jpg"
                                    className="img-fluid rounded"
                                    alt=""
                                />
                            </div>
                            </div>
                            {/* /row */}
                        </div>
                        </section>
                        {/* ============================ Our Story End ================================== */}
                        {/* ============================ Our Counter Start ================================== */}
                        <section
                        className="image-cover"
                        style={{ background: "#234e70 url(/assets/img/pattern.png) no-repeat",    padding: "3rem 0px" }}
                        >
                        <div className="container-fluid">
                            <div className="row justify-content-center">
                            <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <div className="text-center mb-3">
                                {/* <span class="text-light" style="font-size: 20px">Housiey</span> */}
                                <h2
                                    className="font-weight-normal text-light"
                                    style={{ fontSize: 18,lineHeight: 1.2 }}
                                >
                                    With a team size of 85+ young professionals who know the latest
                                    trend and dedicate themselves in bringing out the best living
                                    &amp; investment opportunities for our clients and maintain the
                                    high standard in quality &amp; customer satisfaction. Our only
                                    goal is to provide every individual an outstanding real estate.
                                </h2>
                                </div>
                            </div>
                            </div>
                        </div>
                        </section>

                        
                        {/* ============================ Our Counter End ================================== */}
                        {/* ============================ Property Type Start ================================== */}
                        <section className="gray-simple min">
                        <div className="container">
                            <div className="row">
                            <div className="col-lg-12 col-md-12">
                                <div className="sec-heading center">
                                <h2>Housiey Unique Features are</h2>
                                </div>
                            </div>
                            </div>
                            <div className="row justify-content-center">
                            <div className="col-lg col-md-4">
                                <div className="property_cats_boxs">
                                <a href="grid-layout-with-sidebar.html" className="category-box">
                                    <div className="property_category_short">
                                    <div className="category-icon clip-5">
                                        <img src="/assets/img/unboxing.svg" width={30} />
                                    </div>
                                    <div className="property_category_expand property_category_short-text">
                                        <h4>Online Site<br></br> Visit through our project unboxing</h4>
                                    </div>
                                    </div>
                                </a>
                                </div>
                            </div>
                            <div className="col-lg col-md-4">
                                {/* Single Category */}
                                <div className="property_cats_boxs">
                                <a href="grid-layout-with-sidebar.html" className="category-box">
                                    <div className="property_category_short">
                                    <div className="category-icon clip-5">
                                        <img src="/assets/img/manager.svg" width={30} />
                                        {/* <i class="flaticon-apartments"></i> */}
                                    </div>
                                    <div className="property_category_expand property_category_short-text">
                                        <h4>Dedicated Relationship manager</h4>
                                    </div>
                                    </div>
                                </a>
                                </div>
                            </div>
                            <div className="col-lg col-md-4">
                                {/* Single Category */}
                                <div className="property_cats_boxs">
                                <a href="grid-layout-with-sidebar.html" className="category-box">
                                    <div className="property_category_short">
                                    <div className="category-icon clip-5">
                                        <img
                                        src="/assets/img/online-presentation-icon.png"
                                        width={32}
                                        />
                                        {/* <i class="flaticon-student-housing"></i> */}
                                    </div>
                                    <div className="property_category_expand property_category_short-text">
                                        <h4>Online Presentations</h4>
                                    </div>
                                    </div>
                                </a>
                                </div>
                            </div>
                            <div className="col-lg col-md-4">
                                {/* Single Category */}
                                <div className="property_cats_boxs">
                                <a href="grid-layout-with-sidebar.html" className="category-box">
                                    <div className="property_category_short">
                                    <div className="category-icon clip-5">
                                        <img src="/assets/img/free-cab.svg" width={30} />
                                        {/* <i class="flaticon-modern-house-4"></i> */}
                                    </div>
                                    <div className="property_category_expand property_category_short-text">
                                        <h4>Free Site Visit</h4>
                                    </div>
                                    </div>
                                </a>
                                </div>
                            </div>
                            <div className="col-lg col-md-4">
                                {/* Single Category */}
                                <div className="property_cats_boxs">
                                <a href="grid-layout-with-sidebar.html" className="category-box">
                                    <div className="property_category_short">
                                    <div className="category-icon clip-5">
                                        <img src="/assets/img/pros-cons.svg" width={30} />
                                        {/* <i class="flaticon-cabin"></i> */}
                                    </div>
                                    <div className="property_category_expand property_category_short-text">
                                        <h4>
                                        Unbiased view<br></br> through Pros &amp; Cons of each projects
                                        </h4>
                                    </div>
                                    </div>
                                </a>
                                </div>
                            </div>
                            </div>
                        </div>
                        </section>
                        {/* ============================ Property Type End ================================== */}
                        {/* ============================ Our Counter Start ================================== */}
                        <AboutCounter/> 
                        {/* ============================ Our Counter End ================================== */}
                        {/* ============================ How It Works Start ================================== */}
                        
                        <div className="clearfix" />

                    </div>
                    {/* ============================================================== */}
                    {/* End Wrapper */}
                    {/* ============================================================== */}
                    {/* ============================================================== */}
                    {/* All Jquery */}
                    {/* ============================================================== */}
                    {/* ============================================================== */}
                    {/* This page plugins */}
                    {/* ============================================================== */}
                    { (isMobileView) ? <Footer_mobile/> : <Footer/> }
                    

                    <AfterLoginThanksModal />
                    <Thankyou_modal/>


                    
        <LoginThankModal/>
        <Thankmodal/>


        {isMobileView?<Signup_modal/> : <Signup/> }


                </>
        )
}

AboutUs.getInitialProps = async (ctx)=>{
    let isMobileView = (ctx.req
      ? ctx.req.headers['user-agent']
      : navigator.userAgent).match(
        /Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i
      )
        return {
        isMobileView: Boolean(isMobileView),
        project: []
      }
      
    }
export default AboutUs;
