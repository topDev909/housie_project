import React            from 'react';
import Head             from 'next/head';
import ListingHeader    from '../components/Listing/ListingHeader';
import Footer           from '../components/inc/Footer';
import HeaderMobile     from '../components/mobile-components/inc/Header_mobile';
import Footer_mobile     from '../components/mobile-components/inc/Footer_mobile';
import Signup_modal      from '../components/mobile-components/home-page/Signup_modal';
import AfterLoginThanksModal      from '../components/mobile-components/inc/AfterLoginThanksModal';
import Thankyou_modal             from '../components/mobile-components/home-page/Thankyou_modal';

import LoginThankModal            from '../components/inc/LoginThankModal';
import Thankmodal                 from '../components/component/Auth/Thankmodal';
import LoginModal                 from '../components/component/Auth/LoginModal';
import Signup                     from '../components/component/Auth/Signup';




const ContactUs = ({isMobileView})=>{
    return (


<>
        <Head>
            <title>Contact-US : : {process.env.TITLE} </title>
        </Head>
    <div id="main-wrapper">

    {isMobileView ? <HeaderMobile/>   :  <ListingHeader /> }
        <div className="clearfix" />
        <div className="page-title" style={{ background: "#f4f4f4 url(/assets/img/slider-3.jpg)" }} data-overlay={5} >
        <div className="ht-80" />
        <div className="container">
            <div className="row">
            <div className="col-lg-12 col-md-12">
                <div className="_page_tetio">
                <div className="pledtio_wrap">
                    <span>Get In Touch</span>
                </div>
                <h2 className="text-light mb-0">
                    Get Helps &amp; Friendly Support
                </h2>
                <p>
                    Looking for help or any support? We&apos;s available 24 hour a day.
                </p>
                </div>
            </div>
            </div>
        </div>
        <div className="ht-120" />
        </div>
        {/* ============================ Page Title End ================================== */}
        {/* ============================ Agency List Start ================================== */}
        <section className="pt-0">
        <div className="container">
            <div className="row align-items-center pretio_top">
            <div className="col-lg-4 col-md-4 col-sm-12">
                <div className="contact-box">
                <i className="ti-location-pin" />
                <h4>Mumbai</h4>
                <p><b>Corporate Office</b> - Vasudev chamber, B-2,2nd floor, Near Andheri Subway, Telli Galli Cross Road, Andheri East,Mumbai, Maharashtra 400053</p>
                {/* <span>+01 215 245 6258</span> */}
                </div>
            </div>
            <div className="col-lg-4 col-md-4 col-sm-12">
                <div className="contact-box">
                <i className="ti-location-pin" />
                <h4>Pune</h4>
                <p>Plot No. 34 /B, Lane No. 2, Tejaswini Society, Next to Medipoint Hospital, Aundh, Pune, Maharashtra 411007</p>
                {/* <span>+01 215 245 6258</span> */}
                </div>
            </div>
            <div className="col-lg-4 col-md-4 col-sm-12">
                <div className="contact-box">
                <i className="ti-location-pin" />
                <h4>Banglore</h4>
                <p>802, 4th Floor, 8th Main-East Rd, HRBR Layout 1st Block, Kalyan Nagar, Bengaluru, Karnataka 560043</p>
                </div>
            </div>
            </div>
        </div>
        </section>
        {/* ============================ Agency List End ================================== */}
        

        { (isMobileView) ? <Footer_mobile/> : <Footer/> }



        
        <AfterLoginThanksModal />
        <Thankyou_modal/>

        <LoginThankModal/>
        <Thankmodal/>
        {isMobileView?<Signup_modal/> : <Signup/> }


  </div>
</>
    )
}


ContactUs.getInitialProps = async (ctx)=>{
    let isMobileView = (ctx.req
      ? ctx.req.headers['user-agent']
      : navigator.userAgent).match(
        /Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i
      )
        return {
        isMobileView: Boolean(isMobileView),
        project: []
      }
      
    }
export default ContactUs;