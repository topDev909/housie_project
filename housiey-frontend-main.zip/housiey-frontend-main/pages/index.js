import Head          from 'next/head';
import { useRouter } from 'next/router';

import Header        from '../components/inc/Header'
import Search        from '../components/Search'
import Sign_Up_Perks from '../components/Sign_Up_Perks'
import Signupfree    from '../components/Signupfree'
import Sitevisit     from '../components/Sitevisit'
import New_launch    from '../components/New_launch'
import Unique_Features from '../components/Unique_Features' 
import Top_project    from '../components/Top_project'
import Top_Builders   from '../components/Top_Builders';
import Online_project from '../components/single/Online_project';

import React,{useState,useEffect} from 'react';
import Signup                     from '../components/component/Auth/Signup';
import LoginModal                 from '../components/component/Auth/LoginModal';
import Step1_modal                from '../components/mobile-components/home-page/Step1_modal';

import HeaderMobile               from '../components/mobile-components/inc/Header_mobile';
import Footer_Mobile              from '../components/mobile-components/inc/Footer_mobile';
import AfterLoginThanksModal      from '../components/mobile-components/inc/AfterLoginThanksModal';
import Thankyou_modal             from '../components/mobile-components/home-page/Thankyou_modal';


import SearchMobile               from '../components/mobile-components/home-page/Search_mobile';
import Signupperks_mobile         from '../components/mobile-components/home-page/Signupperks_mobile';
import SitevisitMobile            from '../components/mobile-components/home-page/Sitevisit_mobile';
import Online_presentation_mobile from '../components/mobile-components/home-page/Online_presentation_mobile';
import New_Launch_Mobile          from '../components/mobile-components/home-page/New_launch_mobile';
import Unique_Features_Mobile     from '../components/mobile-components/home-page/Unique_features_mobile'; 
import Top_Project_Mobile         from '../components/mobile-components/home-page/Top_project_mobile';
import Top_Builders_Mobile        from '../components/mobile-components/home-page/Top_builders_mobile';

import LoginThankModal            from '../components/inc/LoginThankModal';
import Thankmodal                 from '../components/component/Auth/Thankmodal';
import { useDispatch }            from 'react-redux';

import {selectFilter}                           from '../redux/slices/filterSlice';

import {slugGenrator, GenrateSearchURL}         from '../utils/BasicFn';

import AboutCounter from '../components/inc/AboutCounter';
import Footer from '../components/inc/Footer';
import UnderConstruction from '../components/UnderConstruction';




 
export default function Home({isMobileView}) {
  const router                      = useRouter();
  const dispatch                    = useDispatch();
  const [processUrl,setProsessUrl]  = useState('no_redirect');
  const [thankTitle,setThankTitle]  = useState('Sign-Up');
  const[checkfree,setCheckfree]     = useState(<Signupfree/>);
  
     

  useEffect(()=>{
    let item = localStorage.getItem('housey_token')
     if(item){
      setCheckfree('')
     }
  },[])


  // SendBuilderLink,SendLocationLink
  const SendBuilderLink = async (bulderName,id)=>{
    let reset_filter = {
      type: 'reset_filter',
      filter: 0,
      make_search: 0,
    }    
    dispatch(selectFilter(reset_filter));
    let url = slugGenrator(bulderName)
    await router.push('/builders/'+url)
  }

  const SendLocationLink = async  (LocationName,id)=>{
    let url = slugGenrator(LocationName)
    let urlObj   = {
      id: url,
      type:'locality',
    }
    let reset_filter = {
      type: 'reset_filter',
      filter: 0,
      make_search: 0,
    }    
    dispatch(selectFilter(reset_filter));
    let main_url = GenrateSearchURL(urlObj);
    await router.push(main_url)
  }

  const is_under_construction = 0;


  return (
    <>
    <Head>
      <title>Home : : {process.env.TITLE}</title>
    </Head>



    {isMobileView? 
    <>
     <HeaderMobile/>
     <SearchMobile/>
     <Signupperks_mobile/>
     <SitevisitMobile/>
     <New_Launch_Mobile   SendLocationLink={SendLocationLink}  SendBuilderLink={SendBuilderLink} />
     <div className="mobile-counter-section" >
     <AboutCounter/>
     </div>
     <Unique_Features_Mobile/>
     <Top_Project_Mobile  SendLocationLink={SendLocationLink}  SendBuilderLink={SendBuilderLink} />
     <Online_presentation_mobile />
     <Top_Builders_Mobile SendLocationLink={SendLocationLink}  SendBuilderLink={SendBuilderLink}/>
     <Footer_Mobile/>
     <Step1_modal/>
     <AfterLoginThanksModal />
     <Thankyou_modal/>
    </>:
    <>
     <Header />
     <Search  />
     <Sign_Up_Perks/>
     {checkfree}
     <Sitevisit />
     <New_launch         SendLocationLink={SendLocationLink}  SendBuilderLink={SendBuilderLink}  />
     <AboutCounter/>
     <Unique_Features/>
     <Top_project        SendLocationLink={SendLocationLink}  SendBuilderLink={SendBuilderLink} />
     <Online_project/>
     <Top_Builders       SendLocationLink={SendLocationLink}  SendBuilderLink={SendBuilderLink} />
     <Footer />
     <Signup             thankTitle={thankTitle}              processUrl={processUrl}  />
     <LoginModal/>
     <LoginThankModal/>
     <Thankmodal/>


     

     </>
    }
    </>
  )
}

Home.getInitialProps = async (ctx)=>{
  let isMobileView = (ctx.req
    ? ctx.req.headers['user-agent']
    : navigator.userAgent).match(
      /Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i
    )


    
    // const res = await fetch(process.env.BASE_URL+"/top-launches-projects/10");
    // const project = await res.json();


    //Returning the isMobileView as a prop to the component for further use.
    return {
      isMobileView: Boolean(isMobileView),
      project: []
    }

 }









