import React,{useState,useEffect}           from 'react';
import { useDispatch}                       from "react-redux";
import Head                                 from 'next/head';

import ListingHeader                        from '../../components/Listing/ListingHeader';
import Headerfillter                        from '../../components/Listing/Headerfillter';
import All_properties                       from '../../components/Listing/All_properties';
import LoginThankModal                      from '../../components/inc/LoginThankModal';
import ListingPage                          from '../../components/mobile-components/listing-page/ListingPage';
import { selectFilter }                     from "../../redux/slices/filterSlice";
import  Signup                              from "../../components/component/Auth/Signup";
import Thankmodal                           from '../../components/component/Auth/Thankmodal';
import Footer_mobile                        from '../../components/mobile-components/inc/Footer_mobile';
import AfterLoginThanksModal                from '../../components/mobile-components/inc/AfterLoginThanksModal';
import Thankyou_modal                       from '../../components/mobile-components/home-page/Thankyou_modal';
import Step1_modal                          from '../../components/mobile-components/home-page/Step1_modal';


import Footer from '../../components/inc/Footer';



const Builders = ({search_query,page_type,details,isMobileView})=>{

    const dispatch              = useDispatch();
    const [citName,setCityName] = useState('');


    useEffect(()=>{
        
        let obbj = {
            type: 'reset_filter',
            filter: 0,
            make_search: 1,
        }
        dispatch(selectFilter(obbj));

        let cityData = JSON.parse(localStorage.getItem('houseiy_location'));
        if(cityData){
            setCityName(cityData.name)
        }

        let builderName = details.replaceAll("-"," ");
            obbj = {
            type: 'builder_id',
            filter: builderName
        }
        dispatch(selectFilter(obbj))

    },[search_query,page_type,details])

    return (
        <>
         
        <Head>
            <title>Property By {details}  : : {process.env.TITLE} </title>
        </Head>

        {isMobileView ? 
        <>
            <ListingPage search_query={search_query} page_type={page_type} details={details} />

            <AfterLoginThanksModal />
            <Thankyou_modal/>
            <Step1_modal/>

            <Footer_mobile />
        </> : 
        <>
         <ListingHeader/>
         <Headerfillter search_query={search_query} page_type={page_type} details={details} /> 
         <All_properties search_query={search_query} page_type={page_type} details={details} />
         <Footer />
         <Signup />
         <LoginThankModal />
         <Thankmodal/>
        </>}

        </>
    )
}


export async function getServerSideProps(ctx) {

    let query_params        = ctx.query.builder;
    let page_type           = 'builder';
    let location_details    = query_params; 
    let isMobileView = (ctx.req
        ? ctx.req.headers['user-agent']
        : navigator.userAgent).match(
          /Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i
        )
    return {
      props: {search_query:query_params,page_type:page_type,details:location_details,isMobileView:isMobileView}, // will be passed to the page component as props
    }
  }

export default Builders;