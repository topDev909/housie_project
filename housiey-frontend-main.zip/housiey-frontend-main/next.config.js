module.exports = {
  reactStrictMode: true,
  env:{
    BASE_URL:      "https://hst.com/api/",
    IMAGE_URL:     "https://hst.com/",
    Category_URL:  "https://hst.com/api/search-cat?s=",
    MAP_KEY:       "AIzaSyBqWeOjdXPZ_7SbM0UEZi9Gh_TAV6aKHMM",
    MAP_KEY2:      "AIzaSyBqWeOjdXPZ_7SbM0UEZi9Gh_TAV6aKHMM",
  
    TITLE:         'Housiey - Home Buying Simplified' 
  }
}
