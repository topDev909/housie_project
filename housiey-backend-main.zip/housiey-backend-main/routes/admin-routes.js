var express = require("express");
const app = express.Router();
// const envr = 'PRODUCTION'
const envr = 'DEVELOPMENT'

const multer = require("multer");
// start multer
const storage = multer.memoryStorage();
const upload = multer({ storage });

app.use(express.static("./uploads"));
// end multer

// start multer for files
const multerStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, "./views/admin/uploads/temp/");
    },
    filename: (req, file, cb) => {
      const ext = file.originalname.split(".")[1];
      cb(null, `${file.fieldname}_${Date.now()}.${ext}`);
    },
  });
const uploadFile = multer({
    storage: multerStorage
  });
// end multer for files

const sess = function(req, res, next) {
    if (envr == "PRODUCTION") {
        if (typeof req.session.DATA == 'undefined') {

            res.redirect(base_url+'login');
            res.end();
        } else {
            next()
        }
    } else {
        req.session.DATA = [{
                id: 1,
                username: 'admin',
                password: '$2b$14$sJx7vduH8knGwmPCec9c9uxYpW.KUorVa/otuP7/g5D0QPqPBafVK',
                status: 1
            }
        ]
        req.session.usertype = 1
        next()
    }
}
const {login,login_post,logout,dashboard,get_location,add_states,add_city,add_locality,add_city_by_state,
    add_builder,add_builderPost,edit_builderPost,removeBuilder,manage_builders,manage_sellers,add_seller,add_amenities,add_scheme,add_config,
    add_project,add_projectPost,manage_bank,add_bank,add_configerations,add_configerationsPost,manage_configs,manage_payment_schemes,manage_unit_type,
    add_unit_type,manage_possession_type,add_possession_type,poss_switch_btn,unit_switch_btn,scheme_switch_btn,config_switch_btn,bank_switch_btn,manage_video_type,
    add_video_type,video_switch_btn,builder_switch_btn,manage_amenities,states_switch_btn,city_switch_btn,locality_switch_btn,internal_switch_btn,
    external_switch_btn,seller_switch_btn,save_project_basis,save_project_overview,save_project_location,save_images,getAltbyId,
    saveAltbyId,deleteProjectImg,deleteProjectImgById,getCities,get_sellers_bycity,
    getcities,getlocalities,docs,save_docs,save_videos,save_proscons,save_payment_schemes,save_faqs,drafts,published,projects,
    edit_configuration,edit_configurationPost,delete_configuration,publish_project,project_status,edit_project,manage_parking_type
    ,add_parking_type,manage_project_type,add_project_type,getallcities,getstates,getschemes,getvideotype,change_status,
    add_filter,add_range,getranges,save_filter,getfilterprojects,manage_tabs,removeTab,getrangeTabs,update_order,manage_topnew_launches,
    add_topnew_launches,save_topnew_launches,getcityprojects,getTopnew,update_order_top_launches,removeTopnew,get_builder_info,
    edit_seller,removeSeller,get_seller_info,edit_amenity,removeAmenity,get_amenity_info,edit_config,removeConfig,get_config_info,
    edit_scheme,removeScheme,get_scheme_info,edit_bank,removeBank,get_bank_info,edit_unit_type,removeUnit,get_unit_info,edit_possession_type
    ,removePossession,get_possession_info,edit_video_type,removeVideo_type,get_video_type_info,edit_parking_type,removeParking_type,parking_type_status,
    get_parking_type_info,edit_project_type,removeProject_type,project_type_status,get_project_type_info,edit_state,get_state,
    edit_city,get_city,edit_locality,get_locality,add_city_head,save_city_head,city_head_status,getusertype,deleteProject} = require("../admin-api");
// app.get('/',login)
app.get('/login',login)
app.post('/login',login_post)
app.get('/logout',logout)
app.get('/dashboard',sess,dashboard)
app.get('/location', get_location)
app.post('/add-states',add_states)
app.post('/add-city',add_city)
app.post('/add-locality',add_locality)
app.get('/select-city/:id',add_city_by_state)
app.get('/add-builder',sess,add_builder)
app.post('/add-builder',sess, upload.single('logo'),add_builderPost)
app.post('/edit-builder',sess, upload.single('logo'),edit_builderPost)
app.get('/remove-builder/:id',sess,removeBuilder)
app.get('/manage-builders',sess,manage_builders)
app.get('/manage-sellers',sess,manage_sellers)
app.post('/add-seller',sess,add_seller)
app.post('/add-amenities',sess, upload.single('img'), add_amenities)
app.post('/add-scheme',sess,add_scheme)
app.post('/add-config',sess,add_config)
app.get('/add-project',sess,add_project)
app.post('/add-project',sess,add_projectPost)
app.get('/manage-bank',sess,manage_bank)
app.post('/add-bank',sess,upload.single('img'),add_bank)
app.get('/add-configerations',sess,add_configerations)
app.post('/add-configerations',sess,upload.array('img',10),add_configerationsPost)
app.get('/manage-unit-type',sess, manage_unit_type)
app.post('/add-unit-type',sess, add_unit_type)
app.get('/manage-possession-type',sess, manage_possession_type)
app.post('/add-possession-type',sess, add_possession_type)
app.get('/possession-status/:poss_id',sess,poss_switch_btn)
app.get('/unit-status/:unit_id',sess,unit_switch_btn)
app.get('/scheme-status/:scheme_id',sess,scheme_switch_btn)
app.get('/config-status/:config_id',sess,config_switch_btn)
app.get('/bank-status/:bank_id',sess,bank_switch_btn)
app.get('/manage-video-type',sess, manage_video_type)
app.post('/add-video-type',sess, add_video_type)
app.get('/video-status/:vid_id',sess, video_switch_btn)
app.get('/builder-status/:builder_id',sess, builder_switch_btn)

app.get('/manage-amenities',sess, manage_amenities)
app.get('/manage-configs',sess, manage_configs)
app.get('/manage-payment-schemes',sess, manage_payment_schemes)
app.get('/states-status/:state_id',sess,states_switch_btn)
app.get('/city-status/:city_id',sess,city_switch_btn)
app.get('/locality-status/:locality_id',sess,locality_switch_btn)
app.get('/int-amenity-status/:int_id',sess,internal_switch_btn)
app.get('/ext-amenity-status/:ext_id',sess,external_switch_btn)
app.get('/seller-status/:slr_id',sess,seller_switch_btn)
app.post('/save_project_basis',sess,save_project_basis)
app.post('/save_project_overview',sess,save_project_overview)
app.post('/save_project_location',sess,save_project_location)
app.post('/save_images',sess,upload.single('file'),save_images)

app.get("/getalt/:id", sess, getAltbyId);
app.get("/saveAlt/:id/:altmsg", sess, saveAltbyId);

app.get('/deleteProjectImg',sess,deleteProjectImg)
app.get('/deleteProjectImgById/:id',sess,deleteProjectImgById)
app.get('/getcities/:id',sess,getcities)
app.get("/getCities",sess, getCities);
app.get('/getlocalities/:state_id/:city_id',sess,getlocalities)
app.post('/save_docs',sess,uploadFile.fields(docs),save_docs)
app.post('/save_videos',sess,save_videos)
app.post('/save_proscons',sess,save_proscons) 
app.post('/save_payment_schemes',sess,save_payment_schemes)
app.post('/save_faqs',sess,save_faqs)
app.get('/drafts',sess, drafts)
app.get('/published',sess, published)
app.get('/projects',sess, projects)
app.get('/edit-configuration/:id',sess, edit_configuration)
app.post('/edit-configuration/:id',sess,upload.array('img',10) ,edit_configurationPost)
app.get('/delete-configuration/:id',sess, delete_configuration)
app.get('/publish-project/:id',sess, publish_project)
app.get('/project-status/:pro_id',sess, project_status)
app.get('/edit-project/:id',sess, edit_project)
app.get('/manage-parking-type',sess, manage_parking_type)
app.post('/add-parking-type',sess, add_parking_type)
app.get('/manage-project-type',sess, manage_project_type)
app.post('/add-project-type',sess, add_project_type)
app.get("/getallcities",sess,getallcities)
app.get("/getstates",sess,getstates)
app.get("/getschemes",sess,getschemes)
app.get("/getvideotype",sess,getvideotype)
app.get('/change_status/:id',sess, change_status)
app.get('/add-tabs',sess, add_filter)
app.post('/add-range',sess, add_range)
app.get('/getranges/:id',sess, getranges)
app.post('/save-filter',sess, save_filter)
app.get('/getfilterprojects/:city_id/:range_id',sess, getfilterprojects)
app.get('/manage-tabs',sess,manage_tabs)
app.get('/removeTab/:id',sess,removeTab)
app.get('/getrangeTabs/:city_id',sess,getrangeTabs)
app.post('/update-order',sess,update_order)
app.get('/manage-topnew-launches',sess,manage_topnew_launches)
app.get('/add-topnew-launches',sess,add_topnew_launches)
app.get('/getcityprojects/:city_id',sess,getcityprojects)
app.post('/save-topnew-launches',sess,save_topnew_launches)
app.get('/getTopnew/:city_id',sess,getTopnew)
app.post('/update-order-top-launches',sess,update_order_top_launches)
app.get('/removeTopnew/:id',sess,removeTopnew)
app.get('/get-builder-info/:id',sess,get_builder_info)
app.post('/edit-seller',sess,edit_seller)
app.get('/remove-seller/:id',sess,removeSeller)
app.get('/get-seller-info/:id',sess,get_seller_info)
app.post('/edit-amenity',sess, upload.single('img'),edit_amenity)
app.get('/remove-amenity/:id',sess,removeAmenity)
app.get('/get-amenity-info/:id',sess,get_amenity_info)
app.post('/edit-config',sess, edit_config)
app.get('/remove-config/:id',sess,removeConfig)
app.get('/get-config-info/:id',sess,get_config_info)
app.post('/edit-scheme',sess, edit_scheme)
app.get('/remove-scheme/:id',sess,removeScheme)
app.get('/get-scheme-info/:id',sess,get_scheme_info)
app.post('/edit-bank',sess,upload.single('img'),edit_bank)
app.get('/remove-bank/:id',sess,removeBank)
app.get('/get-bank-info/:id',sess,get_bank_info)
app.post('/edit-unit',sess, edit_unit_type)
app.get('/remove-unit/:id',sess,removeUnit)
app.get('/get-unit-info/:id',sess,get_unit_info)
app.post('/edit-possession-type',sess, edit_possession_type)
app.get('/remove-possession/:id',sess,removePossession)
app.get('/get-possession-info/:id',sess,get_possession_info)
app.post('/edit-video-type',sess, edit_video_type)
app.get('/remove-video-type/:id',sess,removeVideo_type)
app.get('/get-video-type-info/:id',sess,get_video_type_info)
app.post('/edit-parking-type',sess, edit_parking_type)
app.get('/remove-parking/:id',sess,removeParking_type)
app.get('/parking-type-status/:id',sess,parking_type_status)
app.get('/get-parking-info/:id',sess,get_parking_type_info)
app.post('/edit-project-type',sess, edit_project_type)
app.get('/remove-project-type/:id',sess,removeProject_type)
app.get('/project-type-status/:id',sess,project_type_status)
app.get('/get-project-type-info/:id',sess,get_project_type_info)
app.post('/edit-state',sess,edit_state)
app.get('/get-state/:id',sess,get_state)
app.post('/edit-city',sess,edit_city)
app.get('/get-city/:id',sess,get_city)
app.post('/edit-locality',sess,edit_locality)
app.get('/get-locality/:id',sess,get_locality)
app.get('/add-city-head',sess,add_city_head)
app.post('/add-city-head',sess,save_city_head)
app.get('/city-head-status/:id',sess,city_head_status)
app.get('/getusertype',sess,getusertype)
app.get('/deleteProject/:id',sess,deleteProject)

app.get("/get_sellers_bycity", get_sellers_bycity);

module.exports = app;
