var express = require("express");
var csrf = require('csurf')
const app = express.Router();
const { body, validationResult } = require('express-validator');
// const envr = 'PRODUCTION'
const envr = 'DEVELOPMENT'
// setup route middlewares
var csrfProtection = csrf({ cookie: true })

const {signup,login,verify_otp,top_range_tabs,top_range_projects,top_launches_projects,getcities,getbuilderslogo,getbuilder
        ,getbuilderById,search,getproject,listing,save_enquiry,get_schemes,get_possession_type,get_configs,get_filters,get_default_city,getMeta,
        get_similer_projects,getSellerDetailsByProjectID,download_doc,testing,get_config_by_id,deleteNumber,listingNew,getProjectDetails,TestAPi} = require("../api");

//public APIs
app.post('/signup', 
body('mobile').isMobilePhone().isLength({min: 10,max: 10})
,signup)
app.post('/signin', 
body('mobile').isMobilePhone().isLength({min: 10,max: 10})
,login)
app.post('/verify-otp', 
body('otp').isMobilePhone().isLength({min: 6,max: 6}),
body('mobile').isMobilePhone().isLength({min: 10,max: 10}),
body('name').trim().contains(),
body('email').isEmail().normalizeEmail()
,verify_otp)
app.get('/top-range-tabs/:city_id',top_range_tabs)
app.get('/top-range-projects/:city_id/:range_id',top_range_projects)
app.get('/top-launches-projects/:city_id',top_launches_projects)
app.get('/getCities',getcities);
app.get('/getcities',getcities);
app.get('/get-builders-logos',getbuilderslogo)
app.get('/builder-info/:id',getbuilder)
app.get('/get-builder-for-mobile/:city_id',getbuilderById)
app.get('/search/:city_id/:keyword',search)
app.get('/project/:slug',getproject)
app.get('/listing',listing)
app.get('/listing-new',listingNew)
app.post('/save-enquiry',save_enquiry)
app.get('/get-schemes',get_schemes)
app.get('/get-possession-type',get_possession_type)
app.get('/get-configs',get_configs)
app.get('/get-filters',get_filters)
app.get('/get-default-city',get_default_city)
app.get('/get-similer-projects/:pid',get_similer_projects)
app.get('/get-seller-project/:id',getSellerDetailsByProjectID)
app.get('/download-doc/:project_id',download_doc)
app.get('/testing',testing)
app.get('/get-config-by-id/:pid/:cid',get_config_by_id)
app.get('/test-api',TestAPi)

app.get('/singleproject/:slug',getProjectDetails);

app.get('/delete-number/:mobile',deleteNumber);



app.get('/getMeta',getMeta);

module.exports = app;
