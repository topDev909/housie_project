const gateway = require('fast-gateway')
const {setupLogging} = require("../logs/logging");
const port= 9001;

const Auth= (req, res, next)=>{
    next();
    // if(req.headers.auth == null){
    //     next();
    // }else{
    //     res.setHeader('Content-type','application/json' );
    //     res.statuscode =401;
    //     res.end(JSON.stringify({status:401, Warning: 'UnAuthorized Access!'}))
    // }
}




const server = gateway({
  middlewares:[Auth],
  routes: [
        {
            prefix: '/',
            target: 'http://localhost:3003/',
            hooks:{

            }
        },
        {
            prefix: '/admin',
            target: 'http://localhost:3003/',
            hooks:{

            }
        },
        {
            prefix: '/api',
            target: 'http://localhost:3003/',
            hooks:{

            }
        }
    ]
})

setupLogging(server);

server.start(port).then(server=>{
    console.log('gateway service is up on port 9001')
})
