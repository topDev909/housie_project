var date = require("date-and-time");
var fs = require("fs");
const sharp = require("sharp"); // npm install sharp --build-from-source
var moment = require("moment");
const pngToJpeg = require('png-to-jpeg');
module.exports = {
    login: async (req,res)=>{
      let failed = req.flash('failed')
      let success = req.flash('success')
      res.render('../views/admin/login',{"success":success,"failed":failed})
    },
    login_post: async (req,res)=>{
      try {
        let data = await db.query("select * from admin where username=:username",{"username":req.body.username},true)
          if(data.length > 0){
              let plain_pwd = req.body.password
              let hash_pwd = data[0].password
              fun.comparePassword(plain_pwd,hash_pwd,function(err,isMathch){
                  if(isMathch == true){
                      req.session.DATA = data
                      req.session.usertype = 1
                      res.redirect(base_url+'published')
                  }else{
                      req.flash('failed', 'incorrect username or password!');
                      res.redirect(base_url+'login')
                  }   
              })
          }else{
              req.flash('failed', 'incorrect username or password!');
              res.redirect(base_url+'login')
          }
         
       } catch (error) {
           console.log(error);
       }
    },
    logout: async (req,res)=>{
      try {
        if (req.session) {
          // delete session object
          req.session.destroy(function (err) {
            if (err) {
              return next(err);
            } else {
              return res.redirect(base_url+'login');
            }
          });
        }
      } catch (error) {
        console.log(error);
      }
    },
    dashboard: async (req,res)=>{
     
      res.render('../views/admin/dashboard',{})
    },
    get_location: async (req,res)=>{
      let states = await db.query("SELECT * FROM state order by state_id desc", false, true);
      let city = await db.query("SELECT *,(select name from state where state_id=city.state_id) as state_name FROM city order by city_id desc", false, true);
      let locality = await db.query("SELECT *,(select name from state where state_id=locality.state_id) as state_name,(select name from city where city_id=locality.city_id) as city_name FROM locality order by locality_id desc", false, true);
        console.log(states);
        console.log(city);
        console.log(locality);
      res.render('../views/admin/location',{"states":states,"city":city,"locality":locality});
    },

    add_city_by_state : async (req,res)=>{  
      let city = await db.query("SELECT * FROM city WHERE state_id=:state_id", {"state_id":req.params.id}, true);  
      res.send({"res":true,"city":city});
    },

    add_states: async(req, res)=>{
      let states = await db.query("SELECT name FROM state WHERE name=:name ", {"name":req.body.state}, true);
      if(states.length>0){
        res.send({"res":false,"msg":"State already exist."})
      }else{
        let add_state = await db.insert("state",{
          "name" : req.body.state  
        }, true)
        res.send({"res":true,"msg":"State saved successfully.","name":req.body.state,"id":add_state.insertId})
      }
    },
    add_city : async(req, res)=>{
      let city = await db.query("SELECT name FROM city WHERE name=:name AND state_id=:state_id", {"name":req.body.name,"state_id":req.body.state_id}, true);
      if(city.length>0){
        res.send({"res":false, "msg":"City already exist."})
      }else{
        let add_city = await db.insert("city",{
          "state_id" : req.body.state_id,
          "name" : req.body.name,
          "description" : req.body.description  
        }, true)
        res.send({"res":true, "msg":"City saved successfully.","name":req.body.name,"id":add_city.insertId})
      }   
   
    },
    add_locality : async(req, res)=>{
      let locality = await db.query("SELECT name FROM locality WHERE name=:name AND state_id=:state_id AND city_id=:city_id", {
        "name":req.body.name,
        "state_id" : req.body.state_id,
        "city_id" : req.body.city_id,
      }, true);
      if(locality.length>0){
        res.send({"res":false, "msg" :"Locality already exist."})
      }else{
        let add_locality = await db.insert("locality",{
          "state_id" : req.body.state_id,
          "city_id" : req.body.city_id,
          "name" : req.body.name,
          "description" : req.body.description  
        }, true)
        res.send({"res":true,"msg":"Locality saved successfully.","name":req.body.name,"id":add_locality.insertId})
      }
    },
    add_builder: async (req,res)=>{
      let cities = await db.query("SELECT name FROM cities", false, true);
      
      res.render('../views/admin/add_builder',{"cities":cities})
    },
    add_builderPost: async (req,res)=>{
      try {
        let chk = await db.query("select id from builders where builder_name=:builder_name",{"builder_name":req.body.builder_name});
        if(chk.length>0){
          res.send({"res":false,"msg":"Already Exist Builder Name."})
        }else{
          let logo = await compress('./views/admin/uploads/builders/',req.file)
          let cities = ''
          if(req.body.cities!=undefined){
            cities = req.body.cities
          }
          let newBulder = await db.query("insert into builders set builder_name=:builder_name,established_year=:established_year, "+
          " experience=:experience,projects_comp=:projects_comp,cities='"+cities+"',happy_families=:happy_families,description=:description,logo=:logo,status=:status,datetime=:datetime",{
            "builder_name"      : req.body.builder_name,
            "established_year"  : req.body.established_year,
            "experience"        : req.body.experience,
            "projects_comp"     : req.body.projects_comp,
            "happy_families"    : req.body.happy_families,
            "description"       : req.body.description,
            "logo"              : logo,
            "status"            : 1,
            "datetime"          : moment().format('YYYY-MM-DD H:m:s')
          },true)
          res.send({"res":true,"msg": "Builder Saved Successfully.","name":req.body.builder_name,"id":newBulder.insertId})
        }
      } catch (error) {
        console.log(error)
      }
    },
    edit_builderPost: async (req,res)=>{
      try {
        let chk = await db.query("select id from builders where builder_name=:builder_name AND id!=:id",{"builder_name":req.body.builder_name,"id":req.body.id});
        if(chk.length>0){
          res.send({"res":false,"msg":"Already Exist Builder Name."})
        }else{
          if(req.file!=null){
            let logo = await compress('./views/admin/uploads/builders/',req.file)
            let cities = ''
            if(req.body.cities!=undefined){
              cities = req.body.cities
            }
            let newBulder = await db.query("update builders set builder_name=:builder_name,established_year=:established_year, "+
            " experience=:experience,projects_comp=:projects_comp,cities='"+cities+"',happy_families=:happy_families,description=:description,logo=:logo,datetime=:datetime where id=:id",{
              "id" : req.body.id,
              "builder_name"      : req.body.builder_name,
              "established_year"  : req.body.established_year,
              "experience"        : req.body.experience,
              "projects_comp"     : req.body.projects_comp,
              "happy_families"    : req.body.happy_families,
              "description"       : req.body.description,
              "logo"              : logo,
              "datetime"          : moment().format('YYYY-MM-DD H:m:s')
            },true)
            res.send({"res":true,"msg": "Builder Updated Successfully."})
          }else{
            let cities = ''
            if(req.body.cities!=undefined){
              cities = req.body.cities
            }
            let newBulder = await db.query("update builders set builder_name=:builder_name,established_year=:established_year, "+
            " experience=:experience,projects_comp=:projects_comp,cities='"+cities+"',happy_families=:happy_families,description=:description,datetime=:datetime where id=:id",{
              "id" : req.body.id,
              "builder_name"      : req.body.builder_name,
              "established_year"  : req.body.established_year,
              "experience"        : req.body.experience,
              "projects_comp"     : req.body.projects_comp,
              "happy_families"    : req.body.happy_families,
              "description"       : req.body.description,
              "datetime"          : moment().format('YYYY-MM-DD H:m:s')
            },true)
            res.send({"res":true,"msg": "Builder Updated Successfully."})
          }
        }
      } catch (error) {
        console.log(error)
      }
    },
    removeBuilder: async (req,res)=>{
      await db.query("DELETE FROM `builders` WHERE id=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    get_builder_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `builders` WHERE id = :id",{"id":req.params.id});
      let cities = await db.query("SELECT name FROM cities ", false, true);
      res.send({
        "res":true,
        "data":data,
        "cities":cities
      })
    },
    manage_builders: async (req,res)=>{
      let builders = await db.query("select * from builders order by id desc",false);
      let cities = await db.query("SELECT name FROM cities", false, true);
      res.render('../views/admin/manage_builders',{"builders":builders,"cities":cities})
    },
    manage_sellers: async (req,res)=>{
      let sellers = await db.query("select * from sellers order by seller_id desc",false);
      res.render('../views/admin/manage_sellers',{"sellers":sellers})
    },
    add_seller: async (req,res)=>{
      try {
        let chk = await db.query("select seller_id from sellers where email=:email OR phone=:phone",{"email":req.body.email,"phone":req.body.mobile});
        if(chk.length>0){
          res.send({"res":false,"msg":"Already Exist Seller From This Email or Mobile."})
        }else{
          let save = await db.query("insert into sellers set name=:name,email=:email,phone=:phone,datetime=:datetime",{
            "name"      : req.body.name,
            "email"     : req.body.email,
            "phone"     : req.body.mobile,
            "datetime"  : moment().format('YYYY-MM-DD H:m:s')
          },true)
          res.send({"res":true,"msg": "Seller Saved Successfully.","name":req.body.name,"id":save.insertId})
        }
      } catch (error) {
        console.log(error)
      }
    },
    add_amenities: async (req,res)=>{
      try {
        let chk = await db.query("select id from amenities where name=:name and type=:type",{"name":req.body.name, "type":req.body.type});
        if(chk.length>0){
          res.send({"res":false,"msg":"Already Exist Amenities Name."})
        }else{
          let img = await compress('./views/admin/uploads/amenities/',req.file)
          let save = await db.query("insert into amenities set name=:name,type=:type,img=:img",{
            "name"    : req.body.name,
            "type"    : req.body.type,
            "img"     : img
          },true)
          if(req.body.type==1){
            res.send({"res":true,"msg": "Internal Amenitie Saved Successfully.","name":req.body.name,"id":save.insertId})
          }else{
            res.send({"res":true,"msg": "External Amenitie Saved Successfully.","name":req.body.name,"id":save.insertId})
          }
        }
      } catch (error) {
        console.log(error)
      }
    },
    add_scheme: async (req,res)=>{
      try {
        let chk = await db.query("select id from payment_schemes where scheme	=:scheme",{"scheme":req.body.name});
        if(chk.length>0){
          res.send({"res":false,"msg":"Already Exist Scheme Name."})
        }else{
          let save = await db.query("insert into payment_schemes set scheme=:scheme",{
            "scheme"    : req.body.name
          },true)
          res.send({"res":true,"msg": "Scheme Saved Successfully.","name":req.body.name,"id":save.insertId})
        }
      } catch (error) {
        console.log(error)
      }
    },
    add_config: async (req,res)=>{
      try {
        let chk = await db.query("select id from configs where name	=:name",{"name	":req.body.name});
        if(chk.length>0){
          res.send({"res":false,"msg":"Already Exist Config Name."})
        }else{
          let save = await db.query("insert into configs set name=:name",{
            "name"    : req.body.name
          },true)
          res.send({"res":true,"msg": "Config Saved Successfully.","name":req.body.name,"id":save.insertId})
        }
      } catch (error) {
        console.log(error)
      }
    },
    add_project: async (req, res) => {
      let builders = await db.query(
        "select id,builder_name from builders where status=1 order by id desc",
        false
      );
      let sellers = await db.query(
        "SELECT seller_id,name FROM `sellers` WHERE status=1 order by seller_id desc",
        false
      );
      let configs = await db.query(
        "SELECT * FROM `configs` order by id desc",
        false
      );
      let internal_amenities = await db.query(
        "SELECT * FROM `amenities` WHERE type=1 AND status=1 order by id desc;",
        false
      );
      let external_amenities = await db.query(
        "SELECT * FROM `amenities` WHERE type=2 AND status=1 order by id desc;",
        false
      );
      let states = await db.query(
        "SELECT * FROM `state` WHERE status=1 order by state_id desc;",
        false
      );
      let video_type = await db.query(
        " SELECT * FROM `video_type` WHERE status = 1 order by sno desc;",
        false
      );
      let banks = await db.query(
        " SELECT * FROM `banks` WHERE status=1  order by id desc;",
        false
      );
      let payment_schemes = await db.query(
        " SELECT * FROM `payment_schemes` WHERE status = 1  order by id desc;",
        false
      );
      let cities = await db.query(
        "SELECT id,name FROM cities  order by id desc",
        false,
        true
      );
      let parking_type = await db.query(
        "SELECT sno,name FROM parking_type where status = 1  order by sno desc",
        false,
        true
      );
      let project_type = await db.query(
        "SELECT sno,name FROM project_type  where status = 1  order by sno desc",
        false,
        true
      );
      let possession_type = await db.query(
        "SELECT sno,name FROM possession_type  where status = 1  order by sno desc",
        false,
        true
      );
      let unit_type = await db.query(
        "SELECT sno,name FROM unit_type  where status = 1  order by sno desc",
        false,
        true
      );
  
      res.render("../views/admin/add_project", {
        builders: builders,
        sellers: sellers,
        internal_amenities: internal_amenities,
        external_amenities: external_amenities,
        configs: configs,
        states: states,
        video_type: video_type,
        banks: banks,
        cities: cities,
        payment_schemes: payment_schemes,
        parking_type: parking_type,
        project_type: project_type,
        possession_type: possession_type,
        unit_type: unit_type,
        flag: 0,
        project_details: [],
        project_int_amenities: [],
        project_ext_amenities: [],
        project_videos_360: [],
        project_videos: [],
        pros: [],
        cons: [],
        faqs: [],
        brochure: [],
        plan_kit: [],
        price_sheet: [],
        payment_schedule: [],
        project_images_ext: [],
        project_images_int: [],
        project_images_mas: [],
        project_images_flo: [],
        project_banks: [],
        project_locations: [],
        project_rera: [],
        project_schemes: [],
        project_schemes1: [],
        project_videos_normal: [],
        project_videos_custom: [],
      });
    },
    add_projectPost: async (req,res)=>{
      try {
        let chk = await db.query("select id from configs where name	=:name",{"name	":req.body.name});
        if(chk.length>0){
          res.send({"res":false,"msg":"Already Exist Config Name."})
        }else{
          await db.query("insert into configs set name=:name",{
            "name"    : req.body.name
          },true)
          res.send({"res":true,"msg": "Config Saved Successfully."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    manage_bank: async (req,res)=>{
      try {
        let banks = await db.query("select * from banks order by id desc ",{"name":req.body.name});
        console.log(banks);
        res.render('../views/admin/manage_bank',{"banks":banks})
      } catch (error) {
        console.log(error)
      }
    },
    add_bank: async (req,res)=>{
      try {
        let chk = await db.query("select id from banks where name=:name",{"name":req.body.name});
        if(chk.length>0){
          res.send({"res":false,"msg":"Banks Name Alredy Exist."})
        }else{
          let logo = await compress('./views/admin/uploads/banks/',req.file)
          let save = await db.query("insert into banks set name=:name,logo=:logo",{
            "name"    : req.body.name,
            "logo"    : logo
          },true)
          res.send({"res":true,"msg": "Bank Saved Successfully.","name":req.body.name,"id":save.insertId})
        }
      } catch (error) {
        console.log(error)
      }
    },
    add_configerations: async (req,res)=>{
      try {
        let projects = await db.query("SELECT project_name,id FROM `projects` where publish_status=0 AND draft_status=0;",false);
        let configs = await db.query("SELECT * FROM `configs` order by id desc;",false);
        res.render('../views/admin/add_configerations',{"projects":projects,"configs":configs})
      } catch (error) {
        console.log(error)
      }
    },
    add_configerationsPost: async (req,res)=>{
      try {
        if(req.body.status==2){
          let getproject = await  db.query("select publish_status,seller_id,project_type,unit_type,land_parcel,no_of_towers,no_of_floors,config,parking,possession_type,target_possession,rera_possession,area_range_min,area_range_max from projects where id=:id",{"id":req.body.project_id},false);   
          if(getproject[0].seller_id==null || getproject[0].seller_id=='' || getproject[0].seller_id==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].project_type==null || getproject[0].project_type=='' || getproject[0].project_type==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].unit_type==null || getproject[0].unit_type=='' || getproject[0].unit_type==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].land_parcel==null || getproject[0].land_parcel=='' || getproject[0].land_parcel==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].no_of_towers==null || getproject[0].no_of_towers=='' || getproject[0].no_of_towers==0){
            res.send({"res":false,"msg":"Project Overview not not filled yet."})
            res.end();
          }
          if(getproject[0].no_of_floors==null || getproject[0].no_of_floors=='' || getproject[0].no_of_floors==0){
            res.send({"res":false,"msg":"Project Overview not not filled yet."})
            res.end();
          }
          if(getproject[0].config==null || getproject[0].config=='' || getproject[0].config==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].parking==null || getproject[0].parking=='' || getproject[0].parking==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].possession_type==null || getproject[0].possession_type=='' || getproject[0].possession_type==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].target_possession==null || getproject[0].target_possession=='' || getproject[0].target_possession==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].rera_possession==null || getproject[0].rera_possession=='' || getproject[0].rera_possession==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].area_range_min==null || getproject[0].area_range_min=='' || getproject[0].area_range_min==0){
            res.send({"res":false,"msg":"Project Overview not  filled yet."})
            res.end();
          }
          if(getproject[0].area_range_max==null || getproject[0].area_range_max=='' || getproject[0].area_range_max==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          let project_locations = await  db.query("SELECT project_id FROM `project_locations` WHERE project_id=:id",{"id":req.body.project_id},false);   
          if(project_locations.length==0){
            res.send({"res":false,"msg":"Project Location not filled yet."})
            res.end();
          }
          let project_images = await  db.query("SELECT project_id FROM `project_images` WHERE project_id=:id",{"id":req.body.project_id},false);   
          if(project_images.length==0){
            res.send({"res":false,"msg":"Project Images not uploaded yet."})
            res.end();
          }
          let docs = await  db.query("SELECT project_id FROM `docs` WHERE project_id=:id",{"id":req.body.project_id},false);   
          if(docs.length==0){
            res.send({"res":false,"msg":"Project docs not uploaded yet."})
            res.end();
          }
          let project_videos = await  db.query("SELECT project_id FROM `project_videos` WHERE project_id=:id",{"id":req.body.project_id},false);   
          if(project_videos.length==0){
            res.send({"res":false,"msg":"Project Videos not uploaded yet."})
            res.end();
          }
          let project_banks = await  db.query("SELECT project_id FROM `project_banks` WHERE project_id=:id",{"id":req.body.project_id},false);   
          if(project_banks.length==0){
            res.send({"res":false,"msg":"Project Banks not added yet."})
            res.end();
          }
          let project_schemes = await  db.query("SELECT project_id FROM `project_schemes` WHERE project_id=:id",{"id":req.body.project_id},false);   
          if(project_schemes.length==0){
            res.send({"res":false,"msg":"Payment Schemes not added yet."})
            res.end();
          }
        }
        await db.query("DELETE FROM `project_configs` WHERE project_id=:project_id;",{
          "project_id"   : req.body.project_id
        },false);
        for (let index = 0; index < req.files.length; index++) {
          const element = req.files[index];
          let unit_plan_img = await compress('./views/admin/uploads/unit_plans/',element)
          await db.query("insert into project_configs set project_id=:project_id,config_id=:config_id,carpet_area=:carpet_area,builtup_area=:builtup_area,price=:price,down_payment=:down_payment,parking_type=:parking_type,parking=:parking,unit_plan_img=:unit_plan_img",{
            "project_id"    : req.body.project_id,
            "config_id"     : req.body.config_id[index],
            "carpet_area"   : req.body.carpet_area[index],
            "builtup_area"  : (req.body.builtup_area[index]=='')?0:req.body.builtup_area[index],
            "price"         : req.body.price[index],
            "down_payment"  : req.body.downpayment[index],
            "parking_type"  : req.body.parking_type[index],
            "parking"       : req.body.parking[index],
            "unit_plan_img" : unit_plan_img
          },true)
          
        } 
        if(req.body.price.length!=0){
          let p1 = numDifferentiation('-'+Math.min(...req.body.price))
          let p2 = numDifferentiation('-'+Math.max(...req.body.price))
          let price = p1 +' - '+ p2 
          await db.query("update projects set overall_price_range=:price where id=:id",{"id":req.body.project_id,"price":price},false)
        }
        let msg = ''
        if(req.body.status==1){
          await db.query("update projects set draft_status=1,publish_status=0 where id =:project_id",{
            "project_id"    : req.body.project_id
          },true)
          msg="Project Saved in draft."
        }
        if(req.body.status==2){
          await db.query("update projects set publish_status=1,draft_status=0 where id =:project_id",{
            "project_id"    : req.body.project_id
          },true)
          msg="Project published."  
        }       
        res.send({"res":true,"msg": msg})
      } catch (error) {
        console.log(error)
      }
    },
    manage_configs: async(req,res)=>{
      let config = await db.query("SELECT * FROM configs  order by id desc", false, true);
      res.render('../views/admin/manage_config',{"config":config})
    },
    manage_payment_schemes: async(req,res)=>{
      let scheme = await db.query("SELECT * FROM payment_schemes order by id desc", false, true);
      res.render('../views/admin/manage_payment_schemes',{"scheme":scheme})
    },
    manage_amenities : async (req, res)=>{
      let internal = await db.query("SELECT * FROM amenities WHERE type=1 order by id desc", false, true);
      let external = await db.query("SELECT * FROM amenities WHERE type=2 order by id desc", false, true);
      res.render('../views/admin/manage_amenities',{"internal":internal, "external":external})
    },
    states_switch_btn: async(req, res)=>{
      let status = await db.query("SELECT status FROM state WHERE state_id=:state_id", {"state_id":req.params.state_id}, true);
      if(status[0].status){
        let status = await db.query("UPDATE state set status=0 where state_id=:state_id",{"state_id":req.params.state_id});
      }else{
        let status = await db.query("UPDATE state set status=1 where state_id=:state_id",{"state_id":req.params.state_id});
      }
      res.send({"res":true,"msg":"status changed successfully"})
    },
    city_switch_btn: async(req,res)=>{
      let status = await db.query("SELECT status FROM city WHERE city_id=:city_id", {"city_id":req.params.city_id}, true);
      if(status[0].status){
        let status = await db.query("UPDATE city set status=0 where city_id=:city_id",{"city_id":req.params.city_id});
      }else{
        let status = await db.query("UPDATE city set status=1 where city_id=:city_id",{"city_id":req.params.city_id});
      }
      res.send({"res":true,"msg":"status changed successfully"})
    },
    locality_switch_btn: async(req,res)=>{
      let status = await db.query("SELECT status FROM locality WHERE locality_id=:locality_id", {"locality_id":req.params.locality_id}, true);
      if(status[0].status){
        let status = await db.query("UPDATE locality set status=0 where locality_id=:locality_id",{"locality_id":req.params.locality_id});
      }else{
        let status = await db.query("UPDATE locality set status=1 where locality_id=:locality_id",{"locality_id":req.params.locality_id});
      }
      res.send({"res":true,"msg":"status changed successfully"})
    },
    internal_switch_btn:async(req, res)=>{
      let int_amenity = await db.query("SELECT status FROM amenities WHERE id=:int_id ",{"int_id":req.params.int_id,}, true);
      if(int_amenity[0].status){
        let status = await db.query("UPDATE amenities set status=0 where id=:int_id",{"int_id":req.params.int_id});
      }else{
        let status = await db.query("UPDATE amenities set status=1 where id=:int_id",{"int_id":req.params.int_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },
    external_switch_btn:async(req, res)=>{
      let ext_amenity = await db.query("SELECT status FROM amenities WHERE id=:ext_id ",{"ext_id":req.params.ext_id,}, true);
      if(ext_amenity[0].status){
        let status = await db.query("UPDATE amenities set status=0 where id=:ext_id",{"ext_id":req.params.ext_id});
      }else{
        let status = await db.query("UPDATE amenities set status=1 where id=:ext_id",{"ext_id":req.params.ext_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },
    seller_switch_btn:async(req,res)=>{
      let seller = await db.query("SELECT status FROM sellers WHERE seller_id=:slr_id ",{"slr_id":req.params.slr_id,}, true);
      if(seller[0].status){
        let status = await db.query("UPDATE sellers set status=0 where seller_id=:slr_id",{"slr_id":req.params.slr_id});
      }else{
        let status = await db.query("UPDATE sellers set status=1 where seller_id=:slr_id",{"slr_id":req.params.slr_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },
    poss_switch_btn:async(req,res)=>{
      let poss = await db.query("SELECT status FROM possession_type WHERE sno=:poss_id ",{"poss_id":req.params.poss_id,}, true);
      if(poss[0].status){
        let status = await db.query("UPDATE possession_type set status=0 where sno=:poss_id",{"poss_id":req.params.poss_id});
      }else{
        let status = await db.query("UPDATE possession_type set status=1 where sno=:poss_id",{"poss_id":req.params.poss_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },

    unit_switch_btn:async(req,res)=>{
      let unit = await db.query("SELECT status FROM unit_type WHERE sno=:unit_id ",{"unit_id":req.params.unit_id,}, true);
      if(unit[0].status){
        let status = await db.query("UPDATE unit_type set status=0 where sno=:unit_id",{"unit_id":req.params.unit_id});
      }else{
        let status = await db.query("UPDATE unit_type set status=1 where sno=:unit_id",{"unit_id":req.params.unit_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },

    scheme_switch_btn:async(req,res)=>{
      let scheme = await db.query("SELECT status FROM payment_schemes WHERE id=:scheme_id ",{"scheme_id":req.params.scheme_id,}, true);
      if(scheme[0].status){
        let status = await db.query("UPDATE payment_schemes set status=0 where id=:scheme_id",{"scheme_id":req.params.scheme_id});
      }else{
        let status = await db.query("UPDATE payment_schemes set status=1 where id=:scheme_id",{"scheme_id":req.params.scheme_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },
    config_switch_btn:async(req,res)=>{
      let config = await db.query("SELECT status FROM configs WHERE id=:config_id ",{"config_id":req.params.config_id,}, true);
      if(config[0].status){
        let status = await db.query("UPDATE configs set status=0 where id=:config_id",{"config_id":req.params.config_id});
      }else{
        let status = await db.query("UPDATE configs set status=1 where id=:config_id",{"config_id":req.params.config_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },
    bank_switch_btn:async(req,res)=>{
      let bank = await db.query("SELECT status FROM banks WHERE id=:bank_id ",{"bank_id":req.params.bank_id,}, true);
      if(bank[0].status){
        let status = await db.query("UPDATE banks set status=0 where id=:bank_id",{"bank_id":req.params.bank_id});
      }else{
        let status = await db.query("UPDATE banks set status=1 where id=:bank_id",{"bank_id":req.params.bank_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },
    save_project_basis:async(req, res)=>{
      try {
        if(req.body.project_id){
          let check_name = await db.query("select project_name from projects where project_name=:project_name AND id!=:id",{"project_name":req.body.project_name,"id":req.body.project_id})
          if(check_name.length>0){
            res.send({"res":false,"msg":"Project name already exist."})
            res.end();
          }else{
            let slug = slugGenrator(req.body.project_name,'')
            let save = await db.query("update projects set project_name=:project_name,slug=:slug,project_title=:project_title,project_desc=:project_desc,builder_id=:builder_id,about=:about, "+
            " meta_tags=:meta_tags where id=:project_id;",{
              "project_name" : req.body.project_name,
              "slug"         : slug,
              "project_title": req.body.project_title,
              "project_desc" : req.body.project_desc,
              "builder_id"   : req.body.builder_id,
              "about"        : req.body.about,
              "meta_tags"    : req.body.meta_tags,
              "project_id"   : req.body.project_id
            },false);
            res.send({"res":true,"msg":"Project Basics Updated."})
          }
          
        }else{
          let check_name = await db.query("select project_name from projects where project_name=:project_name",{"project_name":req.body.project_name})
          if(check_name.length>0){
            res.send({"res":false,"msg":"Project name already exist."})
            res.end();
          }else{
            let slug = slugGenrator(req.body.project_name,'')
            let save = await db.query("insert into projects set project_name=:project_name,slug=:slug,project_title=:project_title,project_desc=:project_desc,builder_id=:builder_id,about=:about, "+
            " meta_tags=:meta_tags;",{
              "project_name" : req.body.project_name,
              "slug"         : slug,
              "project_title": req.body.project_title,
              "project_desc" : req.body.project_desc,
              "builder_id"   : req.body.builder_id,
              "about"        : req.body.about,
              "meta_tags"    : req.body.meta_tags
            },false);
            if(save!=undefined){
              res.send({"res":true,"id":save.insertId,"msg":"Project Basics Addded Successfully!","cstat":1})
            }else{
              res.send({"res":false,"msg":"Error 566."})
            }
          }
        }
      } catch (error) {
        console.log(error)
      }
    },
    save_project_overview:async(req, res)=>{
      try {
        let chk = await db.query("SELECT * FROM `projects` WHERE id=:project_id",{"project_id":req.body.project_id}, true);
        if(chk.length>0){
          console.log(req.body);
          let save = await db.query("update projects set project_type=:project_type,unit_type=:unit_type,land_parcel=:land_parcel,no_of_towers=:no_of_towers,no_of_floors=:no_of_floors,config=:config, "+
          " possession_type=:possession_type,target_possession=:target_possession,rera_possession=:rera_possession,offer=:offer,seller_id=:seller_id, "+
          " area_range_min=:area_range_min,area_range_max=:area_range_max,saving_amt=:saving_amt,config=:config,parking=:parking"+
          " where id=:project_id;",{
            "project_type"      : req.body.project_type,
            "unit_type"         : req.body.unit_type,
            "land_parcel"       : req.body.land_parcel,
            "no_of_towers"      : req.body.no_of_towers,
            "no_of_floors"      : req.body.no_of_floors,
            "config"            : req.body.config_id.join(','),
            "possession_type"   : req.body.possession_type,
            "target_possession" : req.body.target_possession,
            "rera_possession"   : req.body.rera_possession,
            "offer"             : req.body.offer,
            "seller_id"         : req.body.seller_id.join(','),
            "area_range_min"    : req.body.area_range_min,
            "area_range_max"    : req.body.area_range_max,
            "saving_amt"        : req.body.saving_amt,
            "parking"           : req.body.parking_type.join(','),
            "project_id"        : req.body.project_id  
          },false);

          await db.query("DELETE FROM `project_rera` WHERE project_id=:project_id;",{
            "project_id"   : req.body.project_id
          },false);
          for (let index1 = 0; index1 < req.body.rera_no.length; index1++) {
            await db.query("insert into  project_rera set rera_no=:rera_no,rera_link=:rera_link,project_id=:project_id;",{
              "rera_no"      : req.body.rera_no[index1],
              "rera_link"    : req.body.rera_link[index1],
              "project_id"   : req.body.project_id
            },false);
          }
          await db.query("DELETE FROM `project_amenities` WHERE project_id=:project_id;",{
            "project_id"   : req.body.project_id
          },false);
          for (let index = 0; index < req.body.amenities.length; index++) {
            const element = req.body.amenities[index];
            await db.query("insert into  project_amenities set project_id=:project_id,amenities_id=:amenities_id",{
              "project_id"   : req.body.project_id,
              "amenities_id" : element
            },false); 
          }
          
          res.send({"res":true,"msg":"Overview Details Saved."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    save_project_location:async(req, res)=>{
      try {
        let chk = await db.query("SELECT * FROM `projects` WHERE id=:project_id",{"project_id":req.body.project_id}, true);
        if(chk.length>0){
          console.log(req.body);
          await db.query("DELETE FROM `project_locations` WHERE project_id=:project_id;",{
            "project_id"   : req.body.project_id
          },false).then(async (value) => {
            console.log(value);
            await db.query("insert into  project_locations set state_id=:state_id,city_id=:city_id,locality_id=:locality_id,street=:street,highlights=:highlights,link=:link,lat=:lat,lng=:lng,project_id=:project_id;",{
              "state_id"    : req.body.state_id,
              "city_id"     : req.body.city_id,
              "locality_id" : req.body.locality_id,
              "street"      : req.body.street,
              "highlights"  : req.body.key_points,
              "link"        : req.body.video,
              "lat"         : req.body.lat,
              "lng"        : req.body.lng,
              "project_id"  : req.body.project_id
            },false);
          })
           
          res.send({"res":true,"msg":"Location Saved."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    manage_unit_type: async(req, res)=>{
      let unit = await db.query("SELECT * FROM unit_type  order by sno desc", true, false);
      res.render('../views/admin/manage_unit_type',{"unit":unit})
    },
    add_unit_type:async(req, res)=>{
      try {
        let chk = await db.query("select sno from unit_type where name=:name",{"name":req.body.name});
        if(chk.length>0){
          res.send({"res":false,"msg":"Unit Type Name Alredy Exist."})
        }else{
          let save  = await db.query("insert into unit_type set name=:name",{"name":req.body.name},false)
          res.send({"res":true,"msg": "Unit Type Added Successfully.","name":req.body.name,"id":save.insertId})
        }
      } catch (error) {
        console.log(error)
      }
    },
    manage_possession_type: async(req, res)=>{
      let poss = await db.query("SELECT * FROM possession_type order by sno desc", true, false);
      res.render('../views/admin/manage_possession_type',{"poss":poss})
    },
    add_possession_type:async(req,res)=>{
      try {
        let chk = await db.query("select sno from possession_type where name=:name",{"name":req.body.name});
        if(chk.length>0){
          res.send({"res":false,"msg":"Possession Type Name Alredy Exist."})
        }else{
          let save  = await db.query("insert into possession_type set name=:name",{"name":req.body.name},false)
          res.send({"res":true,"msg": "Possession Type Added Successfully.","name":req.body.name,"id":save.insertId})
        }
      } catch (error) {
        console.log(error)
      }
    },

    manage_video_type:async(req,res)=>{
      let video = await db.query("SELECT * FROM video_type order by sno desc",true,false);
      res.render('../views/admin/manage_video_type',{"video":video})
    },

    add_video_type:async(req,res)=>{
      try {
        let chk = await db.query("select sno from video_type where name=:name",{"name":req.body.name});
        if(chk.length>0){
          res.send({"res":false,"msg":"Video Type Name Alredy Exist."})
        }else{
          let save  = await db.query("insert into video_type set name=:name",{"name":req.body.name},false)
          res.send({"res":true,"msg": "Video Type Added Successfully.","name":req.body.name,"id":save.insertId})
        }
      } catch (error) {
        console.log(error)
      }
    },
    video_switch_btn:async(req,res)=>{
      let video = await db.query("SELECT status FROM video_type WHERE sno=:vid_id ",{"vid_id":req.params.vid_id,}, true);
      if(video[0].status){
        let status = await db.query("UPDATE video_type set status=0 where sno=:vid_id",{"vid_id":req.params.vid_id});
      }else{
        let status = await db.query("UPDATE video_type set status=1 where sno=:vid_id",{"vid_id":req.params.vid_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },
    builder_switch_btn: async(req,res)=>{
      let builder = await db.query("SELECT status FROM builders WHERE id=:builder_id ",{"builder_id":req.params.builder_id,}, true);
      if(builder[0].status){
        let status = await db.query("UPDATE builders set status=0 where id=:builder_id",{"builder_id":req.params.builder_id});
      }else{
        let status = await db.query("UPDATE builders set status=1 where id=:builder_id",{"builder_id":req.params.builder_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },
    save_images: async (req, res) => {
      try {
        let chk = await db.query(
          "SELECT * FROM `projects` WHERE id=:project_id",
          { project_id: req.body.project_id },
          true
        );
        if (chk.length > 0) {
          let project_image = await compress(
            "./views/admin/uploads/project_images/",
            req.file
          );
         
          console.log("extension----------");
  
          console.log(project_image);
          await db.query(
            "insert into project_images set type=:type,img=:img,project_id=:project_id;",
            {
              img: project_image,
              type: req.body.type,
              project_id: req.body.project_id,
            
            },
            false
          );
          res.send({ res: true, msg: "Saved Successfully." });
        } else {
          res.send({ res: false, msg: "Project data not saved." });
        }
      } catch (error) {
        console.log(error);
      }
    },
    deleteProjectImg:async(req, res)=>{
      try {
        let getImg = await db.query("SELECT * FROM `project_images` WHERE project_id=:project_id AND type=:type",{"project_id":req.query.project_id,"type":req.query.type}, true);
        if(getImg.length>0){
          let pos = req.query.pos
          fs.unlinkSync(`./views/`+getImg[pos].img, (err) => {
            if(err){
              console.log(err);
            }else{
              console.log('deleted file '+`./views/`+getImg[pos].img)
            }
          })
          await db.query("DELETE FROM `project_images` WHERE project_id=:project_id AND type=:type AND id=:id;",{
            "project_id"   : req.query.project_id,
            "id"           : getImg[pos].id,
            "type":req.query.type
          },false);
          res.send({"res":true,"msg":"Deleted Successfully."})
        }else{
          res.send({"res":false})
        }
      } catch (error) {
        console.log(error)
      }
    },
    deleteProjectImgById:async(req, res)=>{
      try {
        let getImg = await db.query("SELECT * FROM `project_images` WHERE id=:id",{"id":req.params.id}, true);
        if(getImg.length>0){
          let pos = req.query.pos
          fs.unlinkSync(`./views/`+getImg[0].img, (err) => {
            if(err){
              console.log(err);
            }else{
              console.log('deleted file '+`./views/`+getImg[0].img)
            }
          })
          await db.query("DELETE FROM `project_images` WHERE id=:id;",{
            "project_id"   : req.query.project_id,
            "id"           : getImg[0].id
          },false);
          res.send({"res":true,"msg":"Deleted Successfully."})
        }else{
          res.send({"res":false})
        }
      } catch (error) {
        console.log(error)
      }
    },
    getAltbyId: async (req,res)=>{
      try {
        let altmsg = await db.query(`select img from project_images where id=:id`,{id:req.params.id});
        altmsg = altmsg[0].img;
 
        altmsg = altmsg.split('/');
        altmsg = altmsg[altmsg.length-1].split('--')[0];
 
        console.log("here---");
        console.log(altmsg);
        res.send({res:true,altmsg: altmsg})
      } catch (error) {
        console.log(error);
      }
   },
 
   saveAltbyId: async(req,res)=>{
      try {
        
       let imgpath = await db.query(`select img from project_images where id=:id`,{id:req.params.id});
       imgpath = imgpath[0].img;
 
       let oldpath = imgpath;
       imgpath = imgpath.split('/');
 
       console.log(imgpath)
       let fixedname  = imgpath[imgpath.length-1].split('--')[1];
       imgpath[imgpath.length-1] = req.params.altmsg+'--' + fixedname;
       let newpath = imgpath.join('/');
 
       console.log(newpath);
 
       fs.rename('views/'+oldpath, 'views/'+newpath, async (error) => {
         if (error) {
             
         
           console.log(error);
         }
         else {
           await db.query(`update project_images set img = :imgpath where id=:id`,{id:req.params.id, imgpath:newpath});
         }
       });
 
       
 
         res.send({"res": true,"msg": "success"});
      } catch (error) {
        console.log(error);
      }
   },
 
    getcities:async(req, res)=>{
      try {
        let data = await db.query("SELECT name,city_id FROM `city` WHERE state_id=:state_id",{"state_id":req.params.id}, true);
        res.send({"data":data})
      } catch (error) {
        console.log(error)
      }
    },

    getCities: async (req, res) => {
      let cities = await db.query(`select city_id, name from city`);
  
      // res.json("cities":cities);
      res.send({"cities":cities})

    },

    get_sellers_bycity: async (req, res) => {
      let cityCondition = "";
      if (req.query.cityid != "null" && req.query.cityid != undefined && req.query.cityid!=0)
        cityCondition = `and sellers.city_id = ${req.query.cityid}`;
      let sellers_byCity = await db.query(
        `select * from sellers where sellers.suspended=1 and status = 1 ${cityCondition} order by seller_id desc`
      );
  
      res.json(sellers_byCity);
    },
    getlocalities:async(req, res)=>{
      try {
        let data = await db.query("SELECT name,locality_id FROM `locality` WHERE state_id=:state_id AND city_id=:city_id",{"state_id":req.params.state_id,"city_id":req.params.city_id}, true);
        res.send({"data":data})
      } catch (error) {
        console.log(error)
      }
    },
    docs:[
      {
        name: 'brochure', maxCount: 1
      },
      {
        name: 'plan_kit', maxCount: 1
      },
      {
        name: 'price_sheet', maxCount: 1
      },
      {
        name: 'payment_schedule', maxCount: 1
      }
    ],
    save_docs:async(req, res)=>{
      try {
        let chk = await db.query("SELECT * FROM `projects` WHERE id=:project_id",{"project_id":req.body.project_id}, true);
        if(chk.length>0){
          let get = await db.query("SELECT doc FROM `docs` WHERE project_id=:project_id",{"project_id":req.body.project_id}, true);
          for (let index = 0; index < get.length; index++) {
            const element = get[index];
            fs.unlinkSync(`./views/`+element.doc, (err) => {
              if(err){
                console.log(err);
              }else{
                console.log('deleted file '+`./views/`+element.doc)
              }
            })
          }
          await db.query("DELETE FROM `docs` WHERE project_id=:project_id;",{
            "project_id"   : req.body.project_id
          },false);
          let brochure          = await move('./views/admin/uploads/temp/'+req.files.brochure[0].filename, './views/admin/uploads/docs/'+req.files.brochure[0].filename)
          let plan_kit          = await move('./views/admin/uploads/temp/'+req.files.plan_kit[0].filename, './views/admin/uploads/docs/'+req.files.plan_kit[0].filename)        
          let price_sheet       = await move('./views/admin/uploads/temp/'+req.files.price_sheet[0].filename, './views/admin/uploads/docs/'+req.files.price_sheet[0].filename)
          let payment_schedule  = await move('./views/admin/uploads/temp/'+req.files.payment_schedule[0].filename, './views/admin/uploads/docs/'+req.files.payment_schedule[0].filename)
            await db.query("insert into docs set type=:type,doc=:doc,project_id=:project_id;",{
              "doc"        : brochure,
              "type"       : 1,
              "project_id" : req.body.project_id
            },false);
            await db.query("insert into docs set type=:type,doc=:doc,project_id=:project_id;",{
              "doc"        : plan_kit,
              "type"       : 3,
              "project_id" : req.body.project_id
            },false);
            await db.query("insert into docs set type=:type,doc=:doc,project_id=:project_id;",{
              "doc"        : price_sheet,
              "type"       : 2,
              "project_id" : req.body.project_id
            },false);
            await db.query("insert into docs set type=:type,doc=:doc,project_id=:project_id;",{
              "doc"        : payment_schedule,
              "type"       : 4,
              "project_id" : req.body.project_id
            },false);
          res.send({"res":true,"msg":"Saved Successfully."})
        }else{
          res.send({"res":false,"msg":"Project data not saved."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    save_videos:async(req, res)=>{
      try {
        let chk = await db.query("SELECT * FROM `projects` WHERE id=:project_id",{"project_id":req.body.project_id}, true);
        if(chk.length>0){
          await db.query("DELETE FROM `project_videos` WHERE project_id=:project_id;",{
            "project_id"   : req.body.project_id
          },false);
          for (let index = 0; index < req.body.video_type.length; index++) {
            await db.query("insert into project_videos set type=:type,video=:video,project_id=:project_id;",{
              "video"      : req.body.video_link[index],
              "type"       : req.body.video_type[index],
              "project_id" : req.body.project_id
            },false);
          }

          if(req.body.tour){
            await db.query("insert into project_videos set type=:type,video=:video,project_id=:project_id;",{
              "video"      : req.body.tour,
              "type"       : 5,
              "project_id" : req.body.project_id
            },false);
          }

          if(req.body.video_type_custom!=''){
            for (let index2 = 0; index2 < req.body.video_type_custom.length; index2++) {
              await db.query("insert into project_videos set type=:type,video=:video,project_id=:project_id;",{
                "video"      : req.body.video_link_custom[index2],
                "type"       : req.body.video_type_custom[index2],
                "project_id" : req.body.project_id
              },false);
            }
          }
          
          res.send({"res":true,"msg":"Saved Successfully."})
        }else{
          res.send({"res":false,"msg":"Project data not saved."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    save_proscons:async(req,res)=>{
      try {
        let chk = await db.query("SELECT * FROM `projects` WHERE id=:project_id",{"project_id":req.body.project_id}, true);
        if(chk.length>0){
          await db.query("DELETE FROM `project_pros_cons` WHERE project_id=:project_id;",{
            "project_id"   : req.body.project_id
          },false);
            await db.query("insert into project_pros_cons set type=:type,tag=:tag,project_id=:project_id;",{
              "tag"        : req.body.pros,
              "type"         : 1,
              "project_id"  : req.body.project_id
            },false);
            await db.query("insert into project_pros_cons set type=:type,tag=:tag,project_id=:project_id;",{
              "tag"        : req.body.cons,
              "type"         : 2,
              "project_id"  : req.body.project_id
            },false);
          res.send({"res":true,"msg":"Saved Successfully."})
        }else{
          res.send({"res":false,"msg":"Project data not saved."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    save_payment_schemes:async(req,res)=>{
      try {
        let chk = await db.query("SELECT * FROM `projects` WHERE id=:project_id",{"project_id":req.body.project_id}, true);
        if(chk.length>0){
          await db.query("DELETE FROM `project_schemes` WHERE project_id=:project_id;",{
            "project_id"   : req.body.project_id
          },false);
          console.log(req.body);
          for (let index = 0; index <  req.body.scheme_id.length; index++) {
            await db.query("insert into project_schemes set scheme_id=:scheme_id,description=:description,project_id=:project_id;",{
              "scheme_id"   : req.body.scheme_id[index],
              "description"   : req.body.descr[index],
              "project_id"  : req.body.project_id
            },false);
          }
          // save banks
          await db.query("DELETE FROM `project_banks` WHERE project_id=:project_id;",{
            "project_id"   : req.body.project_id
          },false);
          for (let index1 = 0; index1 <  req.body.bank_id.length; index1++) {
            await db.query("insert into project_banks set bank_id=:bank_id,project_id=:project_id;",{
              "bank_id"   : req.body.bank_id[index1],
              "project_id"  : req.body.project_id
            },false);
          }
          res.send({"res":true,"msg":"Saved Successfully."})
        }else{
          res.send({"res":false,"msg":"Project data not saved."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    save_faqs:async(req,res)=>{
      try {
        let chk = await db.query("SELECT * FROM `projects` WHERE id=:project_id",{"project_id":req.body.project_id}, true);
        if(chk.length>0){
          await db.query("DELETE FROM `faqs` WHERE project_id=:project_id;",{
            "project_id"   : req.body.project_id
          },false);
          for (let index = 0; index <  req.body.qus.length; index++) {
            await db.query("insert into faqs set qus=:qus,ans=:ans,project_id=:project_id;",{
              "qus"   : req.body.qus[index],
              "ans"   : req.body.ans[index],
              "project_id"  : req.body.project_id
            },false);
          }
          res.send({"res":true,"msg":"Saved Successfully."})
        }else{
          res.send({"res":false,"msg":"Project data not saved."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    drafts:async(req,res)=>{
      let drafts = await db.query("SELECT project_configs.*,projects.project_name,projects.project_title,projects.draft_status,projects.publish_status,projects.overall_price_range FROM `project_configs` LEFT JOIN projects ON projects.id = project_configs.project_id WHERE projects.draft_status = 1 GROUP BY project_configs.project_id;",true,false);    
      let projects = await db.query("SELECT * FROM projects where publish_status=0 order by id desc",true,false); 
      res.render('../views/admin/drafts',{"projects":projects,"drafts":drafts})
    },
    published:async(req,res)=>{
      let projects = await db.query("SELECT project_configs.*,projects.project_name,projects.project_title,projects.draft_status,projects.publish_status,projects.overall_price_range FROM `project_configs` LEFT JOIN projects ON projects.id = project_configs.project_id GROUP BY project_configs.project_id ORDER BY id DESC;",true,false);    
      // console.log(projects);
      res.render('../views/admin/published',{"projects":projects})
    },
    edit_configuration:async(req,res)=>{
      let data = await db.query("SELECT project_configs.*,projects.project_name,projects.project_title,projects.about FROM `project_configs` "+
      " LEFT JOIN projects ON projects.id = project_configs.project_id where project_id=:project_id;",{"project_id":req.params.id},false);    
      let configs = await db.query("SELECT * FROM `configs` order by id desc;",false);
      res.render('../views/admin/edit_configuration',{"data":data,"configs":configs,"id":req.params.id})
    },
    edit_configurationPost: async (req,res)=>{
      try {
        if(req.body.status==2){
          let getproject = await  db.query("select publish_status,seller_id,project_type,unit_type,land_parcel,no_of_towers,no_of_floors,config,parking,possession_type,target_possession,rera_possession,area_range_min,area_range_max from projects where id=:id",{"id":req.params.id},false);   
          if(getproject[0].seller_id==null || getproject[0].seller_id=='' || getproject[0].seller_id==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].project_type==null || getproject[0].project_type=='' || getproject[0].project_type==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].unit_type==null || getproject[0].unit_type=='' || getproject[0].unit_type==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].land_parcel==null || getproject[0].land_parcel=='' || getproject[0].land_parcel==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].no_of_towers==null || getproject[0].no_of_towers=='' || getproject[0].no_of_towers==0){
            res.send({"res":false,"msg":"Project Overview not not filled yet."})
            res.end();
          }
          if(getproject[0].no_of_floors==null || getproject[0].no_of_floors=='' || getproject[0].no_of_floors==0){
            res.send({"res":false,"msg":"Project Overview not not filled yet."})
            res.end();
          }
          if(getproject[0].config==null || getproject[0].config=='' || getproject[0].config==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].parking==null || getproject[0].parking=='' || getproject[0].parking==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].possession_type==null || getproject[0].possession_type=='' || getproject[0].possession_type==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].target_possession==null || getproject[0].target_possession=='' || getproject[0].target_possession==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].rera_possession==null || getproject[0].rera_possession=='' || getproject[0].rera_possession==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          if(getproject[0].area_range_min==null || getproject[0].area_range_min=='' || getproject[0].area_range_min==0){
            res.send({"res":false,"msg":"Project Overview not  filled yet."})
            res.end();
          }
          if(getproject[0].area_range_max==null || getproject[0].area_range_max=='' || getproject[0].area_range_max==0){
            res.send({"res":false,"msg":"Project Overview not filled yet."})
            res.end();
          }
          let project_locations = await  db.query("SELECT project_id FROM `project_locations` WHERE project_id=:id",{"id":req.params.id},false);   
          if(project_locations.length==0){
            res.send({"res":false,"msg":"Project Location not filled yet."})
            res.end();
          }
          let project_images = await  db.query("SELECT project_id FROM `project_images` WHERE project_id=:id",{"id":req.params.id},false);   
          if(project_images.length==0){
            res.send({"res":false,"msg":"Project Images not uploaded yet."})
            res.end();
          }
          let docs = await  db.query("SELECT project_id FROM `docs` WHERE project_id=:id",{"id":req.params.id},false);   
          if(docs.length==0){
            res.send({"res":false,"msg":"Project docs not uploaded yet."})
            res.end();
          }
          let project_videos = await  db.query("SELECT project_id FROM `project_videos` WHERE project_id=:id",{"id":req.params.id},false);   
          if(project_videos.length==0){
            res.send({"res":false,"msg":"Project Videos not uploaded yet."})
            res.end();
          }
          let project_banks = await  db.query("SELECT project_id FROM `project_banks` WHERE project_id=:id",{"id":req.params.id},false);   
          if(project_banks.length==0){
            res.send({"res":false,"msg":"Project Banks not added yet."})
            res.end();
          }
          let project_schemes = await  db.query("SELECT project_id FROM `project_schemes` WHERE project_id=:id",{"id":req.params.id},false);   
          if(project_schemes.length==0){
            res.send({"res":false,"msg":"Payment Schemes not added yet."})
            res.end();
          }
        }
        var counter_image = 0
        for (let index = 0; index < req.body.config_id.length; index++) {
          if(req.body.id[index]!=undefined){
            await db.query("update project_configs set config_id=:config_id,carpet_area=:carpet_area,builtup_area=:builtup_area,price=:price,down_payment=:down_payment,parking_type=:parking_type,parking=:parking where project_id=:project_id AND id=:id",{
              "project_id"    : req.params.id,
              "id"            : req.body.id[index],
              "config_id"     : req.body.config_id[index],
              "carpet_area"   : req.body.carpet_area[index],
              "builtup_area"  : (req.body.builtup_area[index]=='')?0:req.body.builtup_area[index],
              "price"         : req.body.price[index],
              "down_payment"  : req.body.downpayment[index],
              "parking_type"  : req.body.parking_type[index],
              "parking"       : req.body.parking[index]
            },true)
            // update image
            if(req.body.imageid[index]!=''){
              const element = req.files[counter_image];
              let unit_plan_img = await compress('./views/admin/uploads/unit_plans/',element)
              await db.query("update project_configs set unit_plan_img=:unit_plan_img where project_id=:project_id AND id=:id",{
                "project_id"    : req.params.id,
                "id"            : req.body.imageid[index],
                "unit_plan_img" : unit_plan_img
              },true)
              counter_image++
            }

          }else{
            const element = req.files[counter_image];
            let unit_plan_img = await compress('./views/admin/uploads/unit_plans/',element)
            counter_image++
            await db.query("insert into project_configs set project_id=:project_id,config_id=:config_id,carpet_area=:carpet_area,builtup_area=:builtup_area,price=:price,down_payment=:down_payment,parking_type=:parking_type,parking=:parking,unit_plan_img=:unit_plan_img",{
              "project_id"    : req.params.id,
              "config_id"     : req.body.config_id[index],
              "carpet_area"   : req.body.carpet_area[index],
              "builtup_area"  : (req.body.builtup_area[index]=='')?0:req.body.builtup_area[index],
              "price"         : req.body.price[index],
              "down_payment"  : req.body.downpayment[index],
              "parking_type"  : req.body.parking_type[index],
              "parking"       : req.body.parking[index],
              "unit_plan_img" : unit_plan_img
            },true)
          }

          // if(req.body.config_id.length-1==index){
          //   let p1 = numDifferentiation('-'+req.body.price[0])
          //   let p2 = numDifferentiation('-'+req.body.price[req.body.config_id.length-1])
          //   let price = p1 +' - '+ p2 
          //   await db.query("update projects set overall_price_range=:price where id=:id",{"id":req.params.id,"price":price},false)
          // }
        }
        if(req.body.price.length!=0){
          let p1 = numDifferentiation('-'+Math.min(...req.body.price))
          let p2 = numDifferentiation('-'+Math.max(...req.body.price))
          let price = p1 +' - '+ p2 
          await db.query("update projects set overall_price_range=:price where id=:id",{"id":req.params.id,"price":price},false)
        }
        let msg = ''
        if(req.body.status==1){
          await db.query("update projects set draft_status=1,publish_status=0 where id =:project_id",{
            "project_id"    :  req.params.id
          },true)
          msg="Project Saved in draft."
        }
        if(req.body.status==2){
          await db.query("update projects set publish_status=1,draft_status=0 where id =:project_id",{
            "project_id"    :  req.params.id
          },true)
          msg="Project published."  
        }
        res.send({"res":true,"msg": msg})
      } catch (error) {
        console.log(error)
      }
    },
    delete_configuration:async(req,res)=>{
      try{
        let data = await db.query("select unit_plan_img,project_id from project_configs where id=:id",{
          "id":req.params.id
        },false)
        if(data.length>0){
          fs.unlink('./views/'+data[0].unit_plan_img, function (err) {
            console.log(err)
            if (err){
              console.log(err);
            }else{
              console.log('File deleted!');
            }
          });
         await db.query("delete from project_configs where id=:id",{
            "id":req.params.id
          },false)
          if(data.length==1){
            await db.query("update projects set draft_status=0,publish_status=0 where id=:id",{
              "id":data[0].project_id
            },false)
          }
        }
        res.send({"res":true})
      }catch(err){
        console.log(err)
      }
    },
    publish_project:async(req,res)=>{
      let getproject = await  db.query("select publish_status,seller_id,project_type,unit_type,land_parcel,no_of_towers,no_of_floors,config,parking,possession_type,target_possession,rera_possession,area_range_min,area_range_max from projects where id=:id",{"id":req.params.id},false);   
      if(getproject.length>0){
        
        let status = (getproject[0].publish_status==1)?0:1
        if(status){
          if(getproject[0].seller_id==null || getproject[0].seller_id=='' || getproject[0].seller_id==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].project_type==null || getproject[0].project_type=='' || getproject[0].project_type==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].unit_type==null || getproject[0].unit_type=='' || getproject[0].unit_type==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].land_parcel==null || getproject[0].land_parcel=='' || getproject[0].land_parcel==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].no_of_towers==null || getproject[0].no_of_towers=='' || getproject[0].no_of_towers==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].no_of_floors==null || getproject[0].no_of_floors=='' || getproject[0].no_of_floors==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].config==null || getproject[0].config=='' || getproject[0].config==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].parking==null || getproject[0].parking=='' || getproject[0].parking==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].possession_type==null || getproject[0].possession_type=='' || getproject[0].possession_type==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].target_possession==null || getproject[0].target_possession=='' || getproject[0].target_possession==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].rera_possession==null || getproject[0].rera_possession=='' || getproject[0].rera_possession==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].area_range_min==null || getproject[0].area_range_min=='' || getproject[0].area_range_min==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          if(getproject[0].area_range_max==null || getproject[0].area_range_max=='' || getproject[0].area_range_max==0){
            res.send({"res":false,"msg":"Seller not filled yet."})
            res.end();
          }
          let project_locations = await  db.query("SELECT project_id FROM `project_locations` WHERE project_id=:id",{"id":req.params.id},false);   
          if(project_locations.length==0){
            res.send({"res":false,"msg":"Project Location not filled yet."})
            res.end();
          }
          let project_images = await  db.query("SELECT project_id FROM `project_images` WHERE project_id=:id",{"id":req.params.id},false);   
          if(project_images.length==0){
            res.send({"res":false,"msg":"Project Images not uploaded yet."})
            res.end();
          }
          let docs = await  db.query("SELECT project_id FROM `docs` WHERE project_id=:id",{"id":req.params.id},false);   
          if(docs.length==0){
            res.send({"res":false,"msg":"Project docs not uploaded yet."})
            res.end();
          }
          let project_videos = await  db.query("SELECT project_id FROM `project_videos` WHERE project_id=:id",{"id":req.params.id},false);   
          if(project_videos.length==0){
            res.send({"res":false,"msg":"Project Videos not uploaded yet."})
            res.end();
          }
          let project_banks = await  db.query("SELECT project_id FROM `project_banks` WHERE project_id=:id",{"id":req.params.id},false);   
          if(project_banks.length==0){
            res.send({"res":false,"msg":"Project Banks not added yet."})
            res.end();
          }
          let project_schemes = await  db.query("SELECT project_id FROM `project_schemes` WHERE project_id=:id",{"id":req.params.id},false);   
          if(project_schemes.length==0){
            res.send({"res":false,"msg":"Payment Schemes not added yet."})
            res.end();
          }
          await db.query("update projects set publish_status=:status,draft_status=0 where id=:id",{"status":status,"id":req.params.id},false);    
          res.send({"res":true,"msg":"Project published."})
        }else{
          await db.query("update projects set publish_status=:status,draft_status=1 where id=:id",{"status":status,"id":req.params.id},false);    
          res.send({"res":true,"msg":"Project saved in draft."})
        }
      }
    },
    projects:async(req,res)=>{
      let projects = await db.query("SELECT * FROM projects order by id desc",true,false);    
      res.render('../views/admin/projects',{"projects":projects})
    },
    project_status:async(req,res)=>{
      let project = await db.query("SELECT publish_status FROM projects WHERE id=:pro_id ",{"pro_id":req.params.pro_id,}, true);
      if(project[0].publish_status){
        let status = await db.query("UPDATE projects set publish_status=0 where id=:pro_id",{"pro_id":req.params.pro_id});
      }else{
        let status = await db.query("UPDATE projects set publish_status=1 where id=:pro_id",{"pro_id":req.params.pro_id});
      }
      res.send({"res":true, "msg":"status changed successfully"})
    },
    edit_project: async (req, res) => {
      let builders = await db.query(
        "select id,builder_name from builders where status=1 order by id desc",
        false
      );
      let sellers = await db.query(
        "SELECT seller_id,name FROM `sellers` WHERE status=1 order by seller_id desc",
        false
      );
      let configs = await db.query(
        "SELECT * FROM `configs` order by id desc",
        false
      );
      let internal_amenities = await db.query(
        "SELECT * FROM `amenities` WHERE type=1 AND status=1 order by id desc;",
        false
      );
      let external_amenities = await db.query(
        "SELECT * FROM `amenities` WHERE type=2 AND status=1 order by id desc;",
        false
      );
      let states = await db.query(
        "SELECT * FROM `state` WHERE status=1 order by state_id desc;",
        false
      );
      let video_type = await db.query(
        " SELECT * FROM `video_type` WHERE status = 1 order by sno desc;",
        false
      );
      let banks = await db.query(
        " SELECT * FROM `banks` WHERE status=1  order by id desc;",
        false
      );
      let payment_schemes = await db.query(
        " SELECT * FROM `payment_schemes` WHERE status = 1  order by id desc;",
        false
      );
      let cities = await db.query(
        "SELECT id,name FROM cities  order by id desc",
        false,
        true
      );
      let parking_type = await db.query(
        "SELECT sno,name FROM parking_type where status = 1  order by sno desc",
        false,
        true
      );
      let project_type = await db.query(
        "SELECT sno,name FROM project_type  where status = 1  order by sno desc",
        false,
        true
      );
      let possession_type = await db.query(
        "SELECT sno,name FROM possession_type  where status = 1  order by sno desc",
        false,
        true
      );
      let unit_type = await db.query(
        "SELECT sno,name FROM unit_type  where status = 1  order by sno desc",
        false,
        true
      );
  
      let project_details = await db.query(
        "SELECT * FROM `projects` WHERE id = :id",
        { id: req.params.id },
        true
      );
      
      let project_int_amenities = await db.query(
        "SELECT amenities_id FROM `project_amenities` INNER JOIN amenities ON amenities.id = project_amenities.amenities_id WHERE project_amenities.project_id = :id AND amenities.type = 1",
        { id: req.params.id },
        true
      );
      let project_ext_amenities = await db.query(
        "SELECT amenities_id FROM `project_amenities` INNER JOIN amenities ON amenities.id = project_amenities.amenities_id WHERE project_amenities.project_id = :id AND amenities.type = 2",
        { id: req.params.id },
        true
      );
      let project_videos_360 = await db.query(
        "SELECT video FROM `project_videos` WHERE project_id = :id AND type =  5",
        { id: req.params.id },
        true
      );
      let project_videos = await db.query(
        "SELECT * FROM `project_videos` WHERE project_id = :id AND type !=  5",
        { id: req.params.id },
        true
      );
      let project_videos_normal = [];
      let project_videos_custom = [];
      if (project_videos.length > 0) {
        for (let index = 0; index < project_videos.length; index++) {
          const element = project_videos[index];
          if (isNumeric(element.type)) {
            project_videos_normal.push(element);
          } else {
            project_videos_custom.push(element);
          }
        }
      }
      let pros = await db.query(
        "SELECT * FROM `project_pros_cons` WHERE project_id = :id AND type = 1",
        { id: req.params.id },
        true
      );
      let cons = await db.query(
        "SELECT * FROM `project_pros_cons` WHERE project_id = :id AND type = 2",
        { id: req.params.id },
        true
      );
      let faqs = await db.query(
        "SELECT * FROM `faqs` WHERE project_id =  :id ",
        { id: req.params.id },
        true
      );
      let brochure = await db.query(
        "SELECT * FROM `docs` WHERE project_id =  :id AND type=1",
        { id: req.params.id },
        true
      );
      let plan_kit = await db.query(
        "SELECT * FROM `docs` WHERE project_id =  :id AND type=3",
        { id: req.params.id },
        true
      );
      let price_sheet = await db.query(
        "SELECT * FROM `docs` WHERE project_id =  :id AND type=2",
        { id: req.params.id },
        true
      );
      let payment_schedule = await db.query(
        "SELECT * FROM `docs` WHERE project_id =  :id AND type=4",
        { id: req.params.id },
        true
      );
      let project_images_ext = await db.query(
        "SELECT * FROM `project_images` WHERE project_id =  :id AND type=1",
        { id: req.params.id },
        true
      );
      let project_images_int = await db.query(
        "SELECT * FROM `project_images` WHERE project_id =  :id AND type=2",
        { id: req.params.id },
        true
      );
      let project_images_mas = await db.query(
        "SELECT * FROM `project_images` WHERE project_id =  :id AND type=3",
        { id: req.params.id },
        true
      );
      let project_images_flo = await db.query(
        "SELECT * FROM `project_images` WHERE project_id =  :id AND type=4",
        { id: req.params.id },
        true
      );
      let project_banks = await db.query(
        "SELECT bank_id FROM `project_banks` WHERE project_id =  :id ",
        { id: req.params.id },
        true
      );
      let project_locations = await db.query(
        "SELECT * FROM `project_locations` WHERE project_id = :id",
        { id: req.params.id },
        true
      );
      let project_rera = await db.query(
        "SELECT * FROM `project_rera` WHERE project_id = :id",
        { id: req.params.id },
        true
      );
      let project_schemes = await db.query(
        "SELECT * FROM `project_schemes` WHERE project_id =  :id AND scheme_id!=1",
        { id: req.params.id },
        true
      );
      let project_schemes1 = await db.query(
        "SELECT description FROM `project_schemes` WHERE project_id =  :id AND scheme_id=1",
        { id: req.params.id },
        true
      );
  
      let bank_ids = [];
      for (let index = 0; index < project_banks.length; index++) {
        const element = project_banks[index];
        bank_ids.push(element.bank_id);
      }
  
      let int_amenity = [];
      for (let index = 0; index < project_int_amenities.length; index++) {
        const element = project_int_amenities[index];
        int_amenity.push(element.amenities_id);
      }
      let ext_amenity = [];
      for (let index = 0; index < project_ext_amenities.length; index++) {
        const element = project_ext_amenities[index];
        ext_amenity.push(element.amenities_id);
      }
      console.log(project_details);
      res.render("../views/admin/edit_project2", {
        builders: builders,
        sellers: sellers,
        internal_amenities: internal_amenities,
        external_amenities: external_amenities,
        configs: configs,
        states: states,
        video_type: video_type,
        banks: banks,
        cities: cities,
        payment_schemes: payment_schemes,
        parking_type: parking_type,
        project_type: project_type,
        possession_type: possession_type,
        unit_type: unit_type,
        project_id: req.params.id,
        flag: 1,
        project_details: project_details,
  
        project_int_amenities: int_amenity,
        project_ext_amenities: ext_amenity,
        project_videos_360: project_videos_360,
        project_videos_normal: project_videos_normal,
        project_videos_custom: project_videos_custom,
        pros: pros,
        cons: cons,
        faqs: faqs,
        brochure: brochure,
        plan_kit: plan_kit,
        price_sheet: price_sheet,
        payment_schedule: payment_schedule,
        project_images_ext: project_images_ext,
        project_images_int: project_images_int,
        project_images_mas: project_images_mas,
        project_images_flo: project_images_flo,
        project_banks: bank_ids,
        project_locations: project_locations,
        project_rera: project_rera,
        project_schemes: project_schemes,
        project_schemes1: project_schemes1,
      });
    },
    manage_parking_type:async(req,res)=>{
      let parking_type = await db.query("select * from parking_type  ORDER BY sno DESC",false,true);
      res.render("../views/admin/manage_parking_type",{"parking_type":parking_type})
    },
    add_parking_type:async(req,res)=>{
      try {
        let chk = await db.query("select sno from parking_type where name=:name",{"name":req.body.name});
        if(chk.length>0){
          res.send({"res":false,"msg":"Parking Type Name Alredy Exist."})
        }else{
          let save  = await db.query("insert into parking_type set name=:name",{"name":req.body.name},false)
          res.send({"res":true,"msg": "Parking Type Added Successfully.","name":req.body.name,"id":save.insertId})
        }
      } catch (error) {
        console.log(error)
      }
    },
    manage_project_type:async(req,res)=>{
      let project_type = await db.query("select * from project_type  ORDER BY sno DESC",false,true);
      res.render("../views/admin/manage_project_type",{"project_type":project_type})
    },
    add_project_type:async(req,res)=>{
      try {
        let chk = await db.query("select sno from project_type where name=:name",{"name":req.body.name});
        if(chk.length>0){
          res.send({"res":false,"msg":"project Type Name Alredy Exist."})
        }else{
          let save  = await db.query("insert into project_type set name=:name",{"name":req.body.name},false)
          res.send({"res":true,"msg": "Project Type Added Successfully.","name":req.body.name,"id":save.insertId})
        }
      } catch (error) {
        console.log(error)
      }
    },
    getallcities:async(req,res)=>{
      let cities = await db.query("SELECT name FROM cities ", false, true);
      res.send({"cities":cities})
    },
    getstates:async(req,res)=>{
      let states = await db.query("SELECT state_id,name FROM state  where status=1", false, true);
      res.send({"states":states})
    },
    getschemes:async(req,res)=>{
      let schemes = await db.query("SELECT id,scheme FROM `payment_schemes` WHERE status=1 AND id!=1", false, true);
      res.send({"schemes":schemes})
    },
    getvideotype:async(req,res)=>{
      let videotype = await db.query("SELECT sno,name FROM `video_type` where status=1", false, true);
      res.send({"videotype":videotype})
    },
    change_status:async(req,res)=>{
      let getproject = await  db.query("select publish_status from projects where id=:id",{"id":req.params.id},false);   
      if(getproject.length>0){
        let status = (getproject[0].publish_status==1)?0:1
        if(status){
          await db.query("update projects set publish_status=:status where id=:id",{"status":status,"id":req.params.id},false);    
          res.send({"res":true,"msg":"Project published."})
        }else{
          await db.query("update projects set publish_status=:status where id=:id",{"status":status,"id":req.params.id},false);    
          res.send({"res":true,"msg":"Project unpublished."})
        }
      }
    },
    add_filter:async(req,res)=>{
      let cities = await db.query("SELECT city_id,name FROM city  where status=1", false, true);
      res.render('../views/admin/add_filter',{"cities":cities})
    },
    add_range:async(req,res)=>{
      let range_min = '';
      let range_max = '';
      let min_val = req.body.range_min;
      let max_val = req.body.range_max;
      let range = '';
      if(req.body.range_min==0){
        range_max = numDifferentiation('-'+req.body.range_max);
        range = 'Under '+range_max
      }else{
        range_min = numDifferentiation('-'+req.body.range_min);
        range_max = numDifferentiation('-'+req.body.range_max);
        range = range_min+' - '+range_max
      }
      let chk = await db.query("SELECT sno FROM `city_ranges` WHERE city_id=:city_id AND price_range=:range",{"city_id":req.body.city,"range":range}, true);
      if(chk.length>0){
        res.send({"res":false,"msg":"Range Alredy Exist."})
      }else{
        let save  = await db.query("insert into city_ranges set city_id=:city_id,price_range=:range,min_val=:min_val,max_val=:max_val",{"city_id":req.body.city,"range":range,"min_val":min_val,"max_val":max_val},false)
        res.send({"res":true,"msg": "Range Added Successfully.","name":range,"id":save.insertId,"city_id":req.body.city})
      }
    },
    getranges:async(req,res)=>{
      let ranges = await db.query("SELECT sno,price_range FROM `city_ranges`  WHERE city_id = :city_id AND status = 1",{"city_id":req.params.id}, true);
      res.send({"ranges":ranges})
    },
    save_filter:async(req,res)=>{
      let getid = await db.query("SELECT id FROM `filter` WHERE city_id=:city_id AND range_id=:range_id",{"city_id":req.body.city_id,"range_id":req.body.range_id}, true);
      if(getid.length>0){
        console.log(req.body.id);
        let save = await db.query("Update filter set project_ids=:project_ids where city_id=:city_id AND range_id=:range_id",
        {
          "city_id":req.body.city_id,
          "range_id":req.body.range_id,
          "project_ids":(req.body.id==undefined)?null:req.body.id.join(','),
        }, true);
        if(req.body.id==undefined){}else{
          await db.query("update projects set top_launches_status=1 where id IN("+req.body.id.join(',')+")",
          false, true);
        }
        res.send({"res":true,"msg":"Saved Successfully!"})
      }else{
        let save = await db.query("insert into filter set city_id=:city_id,range_id=:range_id,project_ids=:project_ids",
        {
          "city_id":req.body.city_id,
          "range_id":req.body.range_id,
          "project_ids":(req.body.id==undefined)?null:req.body.id.join(','),
        }, true);
        if(req.body.id==undefined){}else{
          await db.query("update projects set top_launches_status=1 where id IN("+req.body.id.join(',')+")",
          false, true);
        }
        res.send({"res":true,"msg":"Saved Successfully!"})
      }
    },
    getfilterprojects:async(req,res)=>{
      let getidsbyCityid = await db.query("SELECT project_id FROM `project_locations` WHERE city_id=:city_id;", {"city_id":req.params.city_id}, true); 
      let pids = []
      if(getidsbyCityid.length>0){
        for (let index = 0; index < getidsbyCityid.length; index++) {
          const element = getidsbyCityid[index];
          pids.push(element.project_id)
        }
      }
      let getRange = await db.query("SELECT price_range FROM `city_ranges` WHERE sno=:sno",{"sno":req.params.range_id},false)
      let price1 = 0;
      let price2 = 0;
      console.log(getRange[0].price_range.match('Under'));
      if(getRange[0].price_range.match('Under')!=null){
        price2 = onlyNumbers(getRange[0].price_range) * 100000
      }else{
        let prices = getRange[0].price_range.split('-')
        price1 = onlyNumbers(prices[0]) * 100000;
        price2 = onlyNumbers(prices[1]) * 100000;
      }
      let getidsbyPriceid = await db.query("SELECT project_id  FROM `project_configs` WHERE project_id IN(:ids) AND price BETWEEN :price1 AND :price2 GROUP by project_id;", {"ids":pids,"price1":price1,"price2":price2}, true); 
      console.log(getidsbyPriceid);
      let pids2 = []
      if(getidsbyPriceid.length>0){
        for (let index2 = 0; index2 < getidsbyPriceid.length; index2++) {
          const element = getidsbyPriceid[index2];
          pids2.push(element.project_id)
        }
      }
      console.log(pids);
      let projects=[]
      if(pids2.length>0){
        projects = await db.query("SELECT id,project_name FROM `projects` WHERE publish_status = 1 AND id IN (:ids)", {"ids":pids2}, true);
      }
      let getids = await db.query("SELECT project_ids FROM `filter` WHERE city_id=:city_id AND range_id=:range_id", {"city_id":req.params.city_id,"range_id":req.params.range_id}, true);
      let ids = []
      let projects_selected = []
      if(getids.length>0){
        if(getids[0].project_ids!=null){
          ids = getids[0].project_ids.split(',')
          ids = ids.filter(ids => ids.trim().length > 0);
          projects_selected = await db.query("SELECT id,project_name FROM `projects` WHERE id IN(:ids)",{"ids":ids}, true);
        }
      }
      res.send({"projects":projects,"ids":ids,"data":projects_selected})
    },
    manage_tabs:async(req,res)=>{
      let cities = await db.query("SELECT city_id,name FROM city  where status=1", false, true);
      res.render('../views/admin/manage_tabs',{"cities":cities}) 
    },
    removeTab:async(req,res)=>{
      let getids = await db.query("SELECT project_ids FROM `filter` WHERE id=:id", {"id":req.params.id}, true);
      let allids = getids[0].project_ids.split(',')
      let udate =  await db.query("update projects set top_launches_status=0 where id IN("+allids+")",
      false, true);
      let tabs = await db.query("DELETE FROM filter WHERE id=:id", {"id":req.params.id}, true);
      res.send(200) 
    },
    getrangeTabs:async(req,res)=>{
      let tabs = await db.query("SELECT *,(SELECT name from city WHERE city_id = filter.city_id) as city_name,(SELECT price_range from city_ranges WHERE sno = filter.range_id) as range_name FROM `filter` where city_id=:city_id ORDER BY data_order ASC", {"city_id":req.params.city_id}, true);
      res.send({"tabs":tabs}) 
    },
    update_order:async(req,res)=>{
      for (let index = 0; index < req.body.data.length; index++) {
        const element = req.body.data[index];
        let update = await db.query("UPDATE filter set data_order=:ord WHERE id=:id", {"id":element.id,"ord":element.ord}, true);
      }
      res.send(200) 
    },
    manage_topnew_launches:async(req,res)=>{
      let cities = await db.query("SELECT city_id,name FROM city where status=1", false, true);
      res.render('../views/admin/manage_topnew_launches',{"cities":cities}) 
    },
    add_topnew_launches:async(req,res)=>{
      let cities = await db.query("SELECT city_id,name FROM city where status=1", false, true);
      res.render('../views/admin/add_topnew_launches',{"cities":cities}) 
    },
    save_topnew_launches: async(req,res)=>{
      let deleteAll = await db.query("DELETE FROM `topnew_launches` WHERE city_id=:city_id",{"city_id":req.body.city_id}, true);
      
      if(req.body.id!=undefined){
        let ids = []
        for (let index = 0; index < req.body.id.length; index++) {
          const element = req.body.id[index];
          let save = await db.query("insert into topnew_launches set city_id=:city_id,project_id=:project_id",
          {
            "city_id":req.body.city_id,
            "project_id":element,
          }, true);
          ids.push(element)
        }
        await db.query("update projects set top_launches_status=2 where id IN("+ids+")",
        false, true);
      }
      res.send({"res":true,"msg":"Saved Successfully!"})
    },
    getcityprojects: async(req,res)=>{
      let getidsbyCityid = await db.query("SELECT project_id FROM `project_locations` WHERE city_id=:city_id;", {"city_id":req.params.city_id}, true); 
      let pids = []
      if(getidsbyCityid.length>0){
        for (let i = 0; i < getidsbyCityid.length; i++) {
          const element = getidsbyCityid[i];
          pids.push(element.project_id)
        }
      }
      let projects = []
      if(pids.length>0){
        projects = await db.query("SELECT id,project_name FROM `projects` WHERE publish_status = 1 AND id IN (:ids)", {"ids":pids}, true);
      }
      let getids = await db.query("SELECT project_id FROM `topnew_launches` WHERE city_id=:city_id", {"city_id":req.params.city_id}, true);
      console.log(getids);
      let ids = []
      for (let index = 0; index < getids.length; index++) {
        const element = getids[index];
        console.log(element);
        ids.push(element.project_id)
      }
      res.send({"res":true,"projects":projects,"ids":ids})
    },
    getTopnew:async(req,res)=>{
      let topnew = await db.query("SELECT *,(SELECT name from city WHERE city_id = topnew_launches.city_id) as city_name,(SELECT project_name from projects WHERE id = topnew_launches.project_id) as project_name FROM `topnew_launches` where city_id=:city_id ORDER BY ord ASC", {"city_id":req.params.city_id}, true);
      res.send({"topnew":topnew}) 
    },
    update_order_top_launches:async(req,res)=>{
      for (let index = 0; index < req.body.data.length; index++) {
        const element = req.body.data[index];
        let update = await db.query("UPDATE topnew_launches set ord=:ord WHERE id=:id", {"id":element.id,"ord":element.ord}, true);
      }
      res.send(200) 
    },
    removeTopnew:async(req,res)=>{
      let getids = await db.query("SELECT project_id FROM `topnew_launches` WHERE id=:id", {"id":req.params.id}, true);
      let allids=[];
      for (let index = 0; index < getids.length; index++) {
        const element = getids[index];
        allids.push(element.project_id)
      }
      let udate =  await db.query("update projects set top_launches_status=0 where id IN("+allids+")",
      false, true);
      let tabs = await db.query("DELETE FROM topnew_launches WHERE id=:id", {"id":req.params.id}, true);
      res.send(202) 
    },
    edit_seller: async (req,res)=>{
      try {
        console.log(req.body);
          let save = await db.query("update sellers set name=:name,email=:email,phone=:phone,datetime=:datetime where seller_id=:id",{
            "id"        : req.body.id,
            "name"      : req.body.name,
            "email"     : req.body.email,
            "phone"     : req.body.mobile,
            "datetime"  : moment().format('YYYY-MM-DD H:m:s')
          },true)
          res.send({"res":true,"msg": "Seller details updated successfully."})
      } catch (error) {
        console.log(error)
      }
    },
    removeSeller: async (req,res)=>{
      await db.query("DELETE FROM `sellers` WHERE seller_id=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    get_seller_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `sellers` WHERE seller_id = :id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_amenity: async (req,res)=>{
      try {
        if(req.file!=null){
            let img = await compress('./views/admin/uploads/amenities/',req.file)
            let save = await db.query("update amenities set name=:name,img=:img where id=:id",{
              "name"    : req.body.name,
              "img"     : img,
              "id"      : req.body.id  
            },true)
            res.send({"res":true,"msg": "Amenity Updated Successfully."})
        }else{
            let save = await db.query("update amenities set name=:name where id=:id",{
              "name"    : req.body.name,
              "id"      : req.body.id
            },true)
            res.send({"res":true,"msg": "Amenity Updated Successfully."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    removeAmenity: async (req,res)=>{
      await db.query("DELETE FROM `amenities` WHERE id=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    get_amenity_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `amenities` WHERE id = :id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_config: async (req,res)=>{
      try {
          let save = await db.query("update configs set name=:name where id=:id",{
            "name"    : req.body.name,
            "id"      : req.body.id
          },true)
          res.send({"res":true,"msg": "Config Updated Successfully."})
      } catch (error) {
        console.log(error)
      }
    },
    removeConfig: async (req,res)=>{
      await db.query("DELETE FROM `configs` WHERE id=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    get_config_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `configs` WHERE id = :id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_scheme: async (req,res)=>{
      try {
          let save = await db.query("update payment_schemes set scheme=:scheme where id=:id",{
            "scheme"    : req.body.name,
            "id"      : req.body.id
          },true)
          res.send({"res":true,"msg": "Scheme Updated Successfully."})
      } catch (error) {
        console.log(error)
      }
    },
    removeScheme: async (req,res)=>{
      await db.query("DELETE FROM `payment_schemes` WHERE id=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    get_scheme_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `payment_schemes` WHERE id = :id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_bank: async (req,res)=>{
      try {
        console.log(req.body);
        console.log(req.file);
        if(req.file!=null){
          let logo = await compress('./views/admin/uploads/banks/',req.file)
          let save = await db.query("update banks set name=:name,logo=:logo  where id=:id",{
            "name"    : req.body.name,
            "logo"    : logo,
            "id"      : req.body.id
          },true)
            res.send({"res":true,"msg": "Bank Updated Successfully."})
        }else{
            let save = await db.query("update banks set name=:name where id=:id",{
              "name"    : req.body.name,
              "id"      : req.body.id
            },true)
            res.send({"res":true,"msg": "Bank Updated Successfully."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    removeBank: async (req,res)=>{
      await db.query("DELETE FROM `banks` WHERE id=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    get_bank_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `banks` WHERE id=:id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_unit_type: async (req,res)=>{
      try {
        let save = await db.query("update unit_type set name=:name where sno=:id",{
          "name"    : req.body.name,
          "id"      : req.body.id
        },true)
        res.send({"res":true,"msg": "Unit Type Updated Successfully."})
      } catch (error) {
        console.log(error)
      }
    },
    removeUnit: async (req,res)=>{
      await db.query("DELETE FROM `unit_type` WHERE sno=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    get_unit_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `unit_type` WHERE sno=:id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_possession_type: async (req,res)=>{
      try {
          let save = await db.query("update possession_type set name=:name where sno=:id",{
            "name"    : req.body.name,
            "id"      : req.body.id
          },true)
          res.send({"res":true,"msg": "Possession Type Updated Successfully."})
      } catch (error) {
        console.log(error)
      }
    },
    removePossession: async (req,res)=>{
      await db.query("DELETE FROM `possession_type` WHERE sno=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    get_possession_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `possession_type` WHERE sno=:id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_video_type: async (req,res)=>{
      try {
        let save = await db.query("update video_type set name=:name where sno=:id",{
          "name"    : req.body.name,
          "id"      : req.body.id
        },true)
        res.send({"res":true,"msg": "Video Type Updated Successfully."})
      } catch (error) {
        console.log(error)
      }
    },
    removeVideo_type: async (req,res)=>{
      await db.query("DELETE FROM `video_type` WHERE sno=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    get_video_type_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `video_type` WHERE sno=:id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_parking_type: async (req,res)=>{
      try {
        let save = await db.query("update parking_type set name=:name where sno=:id",{
          "name"    : req.body.name,
          "id"      : req.body.id
        },true)
        res.send({"res":true,"msg": "Parking Type Updated Successfully."})
      } catch (error) {
        console.log(error)
      }
    },
    removeParking_type: async (req,res)=>{
      await db.query("DELETE FROM `parking_type` WHERE sno=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    parking_type_status: async (req,res)=>{
      getsttaus = await db.query("select status from `parking_type` WHERE sno=:id;",{
        "id"   : req.params.id
      },false);
      if(getsttaus.length>0){
        let status = (getsttaus[0].status==0)?1:0;
        await db.query("Update `parking_type` set status=:status WHERE sno=:id;",{
          "id"   : req.params.id,
          "status": status
        },false);
      }
      res.send(200)
    },
    get_parking_type_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `parking_type` WHERE sno=:id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_project_type: async (req,res)=>{
      try {
        let save = await db.query("update project_type set name=:name where sno=:id",{
          "name"    : req.body.name,
          "id"      : req.body.id
        },true)
        res.send({"res":true,"msg": "Project Type Updated Successfully."})
      } catch (error) {
        console.log(error)
      }
    },
    removeProject_type: async (req,res)=>{
      await db.query("DELETE FROM `project_type` WHERE sno=:id;",{
        "id"   : req.params.id
      },false);
      res.send(200)
    },
    project_type_status: async (req,res)=>{
      getsttaus = await db.query("select status from `project_type` WHERE sno=:id;",{
        "id"   : req.params.id
      },false);
      if(getsttaus.length>0){
        let status = (getsttaus[0].status==0)?1:0;
        await db.query("Update `project_type` set status=:status WHERE sno=:id;",{
          "id"   : req.params.id,
          "status": status
        },false);
      }
      res.send(200)
    },
    get_project_type_info: async (req,res)=>{
      let data = await db.query("SELECT * FROM `project_type` WHERE sno=:id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_state: async (req,res)=>{
      try {
        let save = await db.query("update state set name=:name where state_id=:id",{
          "name"    : req.body.state,
          "id"      : req.body.id
        },true)
        res.send({"res":true,"msg": "State Updated Successfully."})
      } catch (error) {
        console.log(error)
      }
    },
    get_state: async (req,res)=>{
      let data = await db.query("SELECT * FROM `state` WHERE state_id=:id",{"id":req.params.id});
      res.send({
        "res":true,
        "data":data
      })
    },
    edit_city: async (req,res)=>{
      try {
        let save = await db.query("update city set state_id=:state_id,name=:name,description=:description where city_id=:id",{
          "name"    : req.body.name,
          "state_id": req.body.state_id,
          "description": req.body.description,
          "id"      : req.body.id
        },true)
        res.send({"res":true,"msg": "City Updated Successfully."})
      } catch (error) {
        console.log(error)
      }
    },
    get_city: async (req,res)=>{
      let data = await db.query("SELECT * FROM `city` WHERE city_id=:id",{"id":req.params.id});
      let states = await db.query("SELECT state_id,name FROM state  where status=1", false, true);
      res.send({
        "res":true,
        "data":data,
        "states":states
      })
    },
    edit_locality: async (req,res)=>{
      try {
        let locality = await db.query("SELECT name FROM locality WHERE name=:name AND state_id=:state_id AND city_id=:city_id AND locality_id!=:id", {
          "name":req.body.name,
          "state_id" : req.body.state_id,
          "city_id" : req.body.city_id,
          "id":req.body.id
        }, true);
        if(locality.length>0){
          res.send({"res":false, "msg" :"Locality name already exist."})
        }else{
          let save = await db.query("update locality set name=:name,description=:description,state_id=:state_id,city_id=:city_id where locality_id=:id",{
            "name"    : req.body.name,
            "state_id": req.body.state_id,
            "city_id": req.body.city_id,
            "description": req.body.description,
            "id"      : req.body.id
          },true)
          res.send({"res":true,"msg": "Locality Updated Successfully."})
        }
      } catch (error) {
        console.log(error)
      }
    },
    get_locality: async (req,res)=>{
      let data = await db.query("SELECT * FROM `locality` WHERE locality_id=:id",{"id":req.params.id});
      let states = await db.query("SELECT state_id,name FROM state  where status=1", false, true);
      let cities = await db.query("SELECT city_id,name FROM `city` WHERE state_id=:state_id", {"state_id":data[0].state_id}, true);
      res.send({
        "res":true,
        "data":data,
        "states":states,
        "cities":cities
      })
    },
    add_city_head:async(req,res)=>{
      let cities = await db.query("SELECT city_id,name FROM city where status=1", false, true);
      let city_heads = await db.query("SELECT *,(SELECT name FROM city WHERE city_id = city_head.city_id) as cityname FROM `city_head` order by id desc", false, true);
      res.render('../views/admin/add_city_head',{"cities":cities,"city_heads":city_heads}) 
    },
    save_city_head: async(req,res)=>{
      let chk = await db.query("select * from city_head where city_id=:city_id ",
      {
        "city_id":req.body.city_id
      }, true);
      if(chk.length>0){
        res.send({"res":false,"msg":"City Head Already Exist!"})
      }else{
        fun.cryptPassword(req.body.password,async function(err,hash){
              if(err){
                res.send({"res":false,"msg":"Incorrect Password!"})
              }else{
                let save = await db.query("insert into city_head set city_id=:city_id,name=:name,email=:email,password=:password",
                {
                  "city_id":req.body.city_id,
                  "name":req.body.name,
                  "email":req.body.email,
                  "password":hash
                }, true);
                res.send({"res":true,"msg":"Saved Successfully!"})
              }
        })
        
      }
    },
    city_head_status:async(req,res)=>{
      let city_head = await  db.query("select status from city_head where id=:id",{"id":req.params.id},false);   
      if(city_head.length>0){
        let status = (city_head[0].status==1)?0:1
        if(status){
          await db.query("update city_head set status=:status where id=:id",{"status":status,"id":req.params.id},false);    
          res.send({"res":true,"msg":"City Head enabled."})
        }else{
          await db.query("update city_head set status=:status where id=:id",{"status":status,"id":req.params.id},false);    
          res.send({"res":true,"msg":"City Head disabled."})
        }
      }
    },
    getusertype:async(req,res)=>{
      let usertype = req.session.usertype
      if(usertype!=''){
        res.send({"res":true,"usertype":usertype})
      }else{
        res.send({"res":false,"usertype":usertype})
      }
    },
    deleteProject:async(req,res)=>{
      // await db.query("DELETE FROM `projects` WHERE id=:id;",{
      //   "id"   : req.params.id
      // },false);
      await db.query("DELETE FROM `project_configs` WHERE project_id=:id;",{
        "id"   : req.params.id
      },false);
      res.send({'res':true,"msg":"Project Deleted"})
    }
}


async function move(source,destination) {
  try {

     return new Promise(resolve => {
      fs.rename(source, destination, function (err) {
        if (err) {
          console.log(err);
        } else{
          console.log('Successfully moved!')
        }
      })
      let path = destination.split('./views/')
      const link = `${path[1]}`;
      resolve(link)
    })
  } catch (error) {
    console.log(error)
  }
}

// async function compress(path,file) {
//   try {

//      return new Promise(resolve => {
//       const { buffer ,mimetype,size} = file;
//       if(mimetype=='image/png'){
//         const timestamp = Date.now();
//         const ref = `${timestamp}-img.jpeg`;
//         let path2 = path.split('./views/')
//         const link = `${path2[1]}${ref}`;
//         if(size > 409600){
//           pngToJpeg({quality: 50})(buffer).then(output => fs.writeFileSync(path + ref, output));
//         }else{
//           pngToJpeg()(buffer).then(output => fs.writeFileSync(path + ref, output));

//         }
//         resolve(link)
//       }else{
//           const timestamp = Date.now();
//           const ref = `${timestamp}-img.webp`;
//           if(size > 409600){
//             sharp(buffer).webp({ quality: 50 }).toFile(path + ref);
//           }else{
//             sharp(buffer).toFile(path + ref);
//           }
//             let path2 = path.split('./views/')
//           const link = `${path2[1]}${ref}`;
//         resolve(link)
//       }
//     })
//   } catch (error) {
//     console.log(error)
//   }
// }

// async function compress(path, file) {
//   try {
//     return new Promise((resolve) => {
//       const { buffer, mimetype, size } = file;
//       if (mimetype == "image/png") {
//         const timestamp = Date.now();
//         const ref = `${timestamp}-img.webp`;
//         let path2 = path.split("./views/");
//         const link = `${path2[1]}${ref}`;

//         if (size > 409600) {
//           sharp(buffer)
//             .webp({ quality: 50 })
//             .toFile(path + ref);
//         } else {
//           console.log("not compressed------------------------");

//           // pngToJpeg({ quality: 100 })(buffer).then((output) => {
//           //   console.log("output-----------");
//           //   console.log(buffer);
//           //   console.log(output);
//           //   console.log(buffer == output);
//           //   fs.writeFileSync(path + ref, output);
//           // });

          
//           sharp(buffer)
//             .webp({ quality: 100 })
//             .toFile(path + ref);
//         }
//         resolve(link);
//       } else {
//         const timestamp = Date.now();
//         const ref = `${timestamp}-img.webp`;
//         if (size > 409600) {
//           sharp(buffer)
//             .webp({ quality: 50 })
//             .toFile(path + ref);
//         } else {
//           sharp(buffer).toFile(path + ref);
//         }
//         let path2 = path.split("./views/");
//         const link = `${path2[1]}${ref}`;
//         resolve(link);
//       }
//     });
//   } catch (error) {
//     console.log(error);
//   }
// }


async function compress(path, file) {
  try {
    return new Promise((resolve) => {
      const { buffer, mimetype, size,originalname } = file;
      
      if (mimetype == "image/png") {
        const timestamp = Date.now();
        const ref = `${originalname.split('.')[0]}--${timestamp}-img.webp`;
        let path2 = path.split("./views/");
        const link = `${path2[1]}${ref}`;

        if (size > 409600) {
          sharp(buffer)
            .webp({ quality: 50 })
            .toFile(path + ref);
        } else {
          console.log("not compressed------------------------");

          // pngToJpeg({ quality: 100 })(buffer).then((output) => {
          //   console.log("output-----------");
          //   console.log(buffer);
          //   console.log(output);
          //   console.log(buffer == output);
          //   fs.writeFileSync(path + ref, output);
          // });

          sharp(buffer)
            .webp({ quality: 100 })
            .toFile(path + ref);
        }
        resolve(link);
      } else {
        const timestamp = Date.now();
        const ref = `${originalname.split('.')[0]}--${timestamp}-img.webp`;
        if (size > 409600) {
          sharp(buffer)
            .webp({ quality: 50 })
            .toFile(path + ref);
        } else {
          sharp(buffer).toFile(path + ref);
        }
        let path2 = path.split("./views/");
        const link = `${path2[1]}${ref}`;
        resolve(link);
      }
    });
  } catch (error) {
    console.log(error);
  }
}

function numDifferentiation(value) {
  var val = Math.abs(value)
  if (val >= 10000000) {
    val = (val / 10000000).toFixed(2) + ' Cr';
  } else if (val >= 100000) {
    val = (val / 100000) + ' Lacs';
  }
  return val;
}

function onlyNumbers(text){
  return text.replace(/\D/g, "");
}

function isNumeric(num){
  return !isNaN(num)
}


function slugGenrator(name){
  let slug =  name.toString().trim().toLowerCase().replace(/\s+/g, "-").replace(/[^\w\-]+/g, "").replace(/\-\-+/g, "-").replace(/^-+/, "").replace(/-+$/, "");
  return slug;
}