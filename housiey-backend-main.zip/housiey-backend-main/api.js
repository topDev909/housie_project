const { body, validationResult } = require('express-validator');
const otpGenerator = require('otp-generator')
var moment = require("moment");
const jwt = require('jsonwebtoken');
let token_key = '1234567890qwertyuiopasdfghjklzxcvbnm';
var requests = require('requests');
var send_msgs = 1;
module.exports = {
    signup: async (req,res)=>{
        try {
            // const errors = validationResult(req);
            //if (!errors.isEmpty()) {
            //  return res.status(400).json({ errors: errors.array() });
            // }
            req.body.mobile = req.body.mobile.replace(/[^\d]/g, ''); 
            let getuser = await db.query("SELECT * FROM user_tbl where mobile=:mobile",{"mobile":req.body.mobile},true)
            if(getuser.length>0){
                //send opt here
                otp = otpGenerator.generate(6, {digits: true, upperCaseAlphabets: false, specialChars: false, lowerCaseAlphabets: false });
                let save = await db.query("update user_tbl set otp=:otp,reg_datetime=:reg_datetime where  mobile=:mobile",{"mobile":req.body.mobile,"otp":otp,"reg_datetime":moment().format('YYYY-MM-DD H:m:s')})
                let data = {
                    "name"  : getuser[0].name,
                    "email" : getuser[0].email,
                    "otp1"   : otp
                }
                let message = otp+' is your Housiey OTP';
                let mobile = req.body.mobile;
                if(send_msgs){
                    requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+mobile+'&dlttempid=1707164577497805580&message='+message, false)
                    .on('data', function (chunk) {
                    console.log(chunk)
                    })
                    .on('end', function (err) {
                        if (err) console.log('connection closed due to errors', err);
                        console.log('end');
                    });
                }
                // if(getuser[0].email){
                //     fun.nodemailer(getuser[0].email,'Housiey',message);
                // }
                if(getuser[0].status){
                    res.send({"res":true,"msg":"We've sent otp to your provided mobile no.","data":data,"signup_status":0})
                }else{
                    res.send({"res":true,"msg":"We've sent otp to your provided mobile no.","data":data,"signup_status":1})
                }
                
                res.send({"res":true,"msg":"We've sent otp to your provided mobile no.","data":data,"signup_status":0})
            }else{
                let otp = otpGenerator.generate(6, {digits: true, upperCaseAlphabets: false, specialChars: false, lowerCaseAlphabets: false });
                let save = await db.query("insert into user_tbl set mobile=:mobile,otp=:otp,reg_datetime=:reg_datetime",{"mobile":req.body.mobile,"otp":otp,"reg_datetime":moment().format('YYYY-MM-DD H:m:s')})
                let save_signup_enquiry = await db.query("INSERT INTO enquiries SET userid=:userid,city_id=:city_id,datetime=:datetime",{"userid":save.insertId,"city_id":req.body.city_id,"datetime":moment().format('YYYY-MM-DD H:m:s')})
                //send opt here
                let data = {
                    "otp1"   : otp
                }
                let message = otp+' is your Housiey OTP';
                let mobile = req.body.mobile;
                if(send_msgs){
                    requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+mobile+'&dlttempid=1707164577497805580&message='+message, false)
                    .on('data', function (chunk) {
                    console.log(chunk)
                    })
                    .on('end', function (err) {
                        if (err) console.log('connection closed due to errors', err);
                        console.log('end');
                    });
                }
                res.send({"res":true,"msg":"We've sent otp to your provided mobile no.","data":data,"signup_status":1})
            }
        } catch (error) {
            console.log(error);
        }
    },
    // signup: async (req,res)=>{
    //     try {
    //         const errors = validationResult(req);
    //         //if (!errors.isEmpty()) {
    //         //  return res.status(400).json({ errors: errors.array() });
    //         // }
    //         let getuser = await db.query("SELECT * FROM user_tbl where mobile=:mobile",{"mobile":req.body.mobile},true)
    //         if(getuser.length>0){
    //             res.send({"res":false,"msg":"Mobile no. already registered."})
    //         }else{
    //             let otp = otpGenerator.generate(6, {digits: true, upperCaseAlphabets: false, specialChars: false, lowerCaseAlphabets: false });
    //             let save = await db.query("insert into user_tbl set mobile=:mobile,otp=:otp,reg_datetime=:reg_datetime",{"mobile":req.body.mobile,"otp":otp,"reg_datetime":moment().format('YYYY-MM-DD H:m:s')})
    //             let save_signup_enquiry = await db.query("INSERT INTO enquiries SET userid=:userid,city_id=:city_id,datetime=:datetime",{"userid":save.insertId,"city_id":req.body.city_id,"datetime":moment().format('YYYY-MM-DD H:m:s')})
    //             //send opt here
    //             let data = {
    //                 "otp"   : otp
    //             }
    //             res.send({"res":true,"msg":"We've sent otp to your provided mobile no.","data":data})
    //         }
    //     } catch (error) {
    //         console.log(error);
    //     }
    // },
    login: async (req,res)=>{
        try {
            // const errors = validationResult(req);
            req.body.mobile = req.body.mobile.replace(/[^\d]/g, ''); 
            let getuser = await db.query("SELECT * FROM user_tbl where mobile=:mobile",{"mobile":req.body.mobile},true)
            if(getuser.length>0){
                //send opt here
                otp = otpGenerator.generate(6, {digits: true, upperCaseAlphabets: false, specialChars: false, lowerCaseAlphabets: false });
                let save = await db.query("update user_tbl set otp=:otp,reg_datetime=:reg_datetime where  mobile=:mobile",{"mobile":req.body.mobile,"otp":otp,"reg_datetime":moment().format('YYYY-MM-DD H:m:s')})
                let data = {
                    "name"  : getuser[0].name,
                    "email" : getuser[0].email,
                    "otp1"   : otp
                }
                let message = otp+' is your Housiey OTP';
                let mobile = req.body.mobile;
                if(send_msgs){
                    // console.log('here');
                    requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+mobile+'&dlttempid=1707164577497805580&message='+message, false)
                    .on('data', function (chunk) {
                    console.log(chunk)
                    })
                    .on('end', function (err) {
                        if (err) console.log('connection closed due to errors', err);
                        console.log('end');
                    });
                }
                // if(getuser[0].email){
                //     fun.nodemailer(getuser[0].email,'Housiey',message);
                // }
                res.send({"res":true,"msg":"We've sent otp to your provided mobile no.","data":data})
            }else{
                res.send({"res":false,"msg":"Mobile no. not registered."})
            }
        } catch (error) {
            console.log(error);
        }
    },
    
    verify_otp: async (req,res)=>{
        try {
            // const errors = validationResult(req);
            // if (!errors.isEmpty()) {
                // return res.status(400).json({ errors: errors.array() });
            // }
            console.log(req.body.mobile);
            req.body.mobile = req.body.mobile.replace(/[^\d]/g, ''); 
            let getuser = await db.query("SELECT otp,id FROM user_tbl where mobile=:mobile",{"mobile":req.body.mobile},true)
            if(getuser.length>0){
                //verify here
                if(parseInt(getuser[0].otp)==parseInt(req.body.otp)){
                    let update = await db.query("update user_tbl set name=:name,email=:email,status=1,update_datetime=:update_datetime where mobile=:mobile",{"mobile":req.body.mobile,"name":req.body.name,"email":req.body.email,"update_datetime":moment().format('YYYY-MM-DD H:m:s')})
                    let data = {
                        "id"  : getuser[0].id,
                        "mobile": req.body.mobile,
                        "name": req.body.name,
                        "email": req.body.email
                    }
                      var token = jwt.sign(data, token_key);

                      if(req.body.is_signup){
                          console.log('here');
                        let message = 'Greetings from Housiey !! Congratulations '+req.body.name+' for Sign Up on Housiey, Now enjoy Sign Up Perks - Unlimited Free Site Visit, Sign Up Bonus, Bottom Rate.... Thanks Housiey';
                        let mobile = req.body.mobile;
                        if(send_msgs){
                            requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+mobile+'&dlttempid=1707164700051366345&message='+message, false)
                            .on('data', function (chunk) {
                            console.log(chunk)
                            })
                            .on('end', function (err) {
                                if (err) console.log('connection closed due to errors', err);
                                console.log('end');
                            });
                        }
                        if(req.body.email){
                            fun.nodemailer(req.body.email,'Sign Up Done Successfully',`
                            <!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8"> <!-- utf-8 works for most cases -->
    <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
    <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
    <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <!-- CSS Reset : BEGIN -->
<style>
html,
body {
    margin: 0 auto !important;
    padding: 0 !important;
    height: 100% !important;
    width: 100% !important;
    background: #f1f1f1;
}

/* What it does: Stops email clients resizing small text. */
* {
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
}

/* What it does: Centers email on Android 4.4 */
div[style*="margin: 16px 0"] {
    margin: 0 !important;
}

/* What it does: Stops Outlook from adding extra spacing to tables. */
table,
td {
    mso-table-lspace: 0pt !important;
    mso-table-rspace: 0pt !important;
}

/* What it does: Fixes webkit padding issue. */
table {
    border-spacing: 0 !important;
    border-collapse: collapse !important;
    table-layout: fixed !important;
    margin: 0 auto !important;
}

/* What it does: Uses a better rendering method when resizing images in IE. */
img {
    -ms-interpolation-mode:bicubic;
}

/* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
a {
    text-decoration: none;
}

/* What it does: A work-around for email clients meddling in triggered links. */
*[x-apple-data-detectors],  /* iOS */
.unstyle-auto-detected-links *,
.aBn {
    border-bottom: 0 !important;
    cursor: default !important;
    color: inherit !important;
    text-decoration: none !important;
    font-size: inherit !important;
    font-family: inherit !important;
    font-weight: inherit !important;
    line-height: inherit !important;
}

/* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
.a6S {
    display: none !important;
    opacity: 0.01 !important;
}

/* What it does: Prevents Gmail from changing the text color in conversation threads. */
.im {
    color: inherit !important;
}

/* If the above doesn't work, add a .g-img class to any image in question. */
img.g-img + div {
    display: none !important;
}

/* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
/* Create one of these media queries for each additional viewport size you'd like to fix */

/* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
@media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
    u ~ div .email-container {
        min-width: 320px !important;
    }
}
/* iPhone 6, 6S, 7, 8, and X */
@media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
    u ~ div .email-container {
        min-width: 375px !important;
    }
}
/* iPhone 6+, 7+, and 8+ */
@media only screen and (min-device-width: 414px) {
    u ~ div .email-container {
        min-width: 414px !important;
    }
}

</style>

<!-- CSS Reset : END -->

<!-- Progressive Enhancements : BEGIN -->
<style>

  .primary{
	background: #0d0cb5;
}
.bg_white{
	background: #ffffff;
}
.bg_light{
	background: #fafafa;
}
.bg_black{
	background: #000000;
}
.bg_dark{
	background: rgba(0,0,0,.8);
}
.email-section{
	padding:2.5em;
}

/*BUTTON*/
.btn{
	padding: 5px 15px;
	display: inline-block;
}
.btn.btn-primary{
	border-radius: 5px;
	background: #0d0cb5;
	color: #ffffff;
}
.btn.btn-white{
	border-radius: 5px;
	background: #ffffff;
	color: #000000;
}
.btn.btn-white-outline{
	border-radius: 5px;
	background: transparent;
	border: 1px solid #fff;
	color: #fff;
}

h1,h2,h3,h4,h5,h6{
	font-family: 'Poppins', sans-serif;
	color: #000000;
	margin-top: 0;
}

body{
	font-family: 'Poppins', sans-serif;
	font-weight: 400;
	font-size: 15px;
	line-height: 1.8;
	color: rgba(0,0,0,.4);
}

a{
	color: #0d0cb5;
}

table{
}
/*LOGO*/

.logo h1{
	margin: 0;
}
.logo h1 a{
	color: #000000;
	font-size: 20px;
	font-weight: 700;
	text-transform: uppercase;
	font-family: 'Poppins', sans-serif;
}

.navigation{
	padding: 0;
}
.navigation li{
	list-style: none;
	display: inline-block;;
	margin-left: 5px;
	font-size: 13px;
	font-weight: 500;
}
.navigation li a{
	color: rgba(0,0,0,.4);
}

/*HERO*/
.hero{
	position: relative;
	z-index: 0;
}
.hero .overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	content: '';
	width: 100%;
	background: #000000;
	z-index: -1;
	opacity: .3;
}
.hero .icon{
}
.hero .icon a{
	display: block;
	width: 60px;
	margin: 0 auto;
}
.hero .text{
	color: rgba(255,255,255,.8);
}
.hero .text h2{
	color: #ffffff;
	font-size: 30px;
	margin-bottom: 0;
}


/*HEADING SECTION*/
.heading-section{
}
.heading-section h2{
	color: #000000;
	font-size: 20px;
	margin-top: 0;
	line-height: 1.4;
	font-weight: 700;
	text-transform: uppercase;
}
.heading-section .subheading{
	margin-bottom: 20px !important;
	display: inline-block;
	font-size: 13px;
	text-transform: uppercase;
	letter-spacing: 2px;
	color: rgba(0,0,0,.4);
	position: relative;
}
.heading-section .subheading::after{
	position: absolute;
	left: 0;
	right: 0;
	bottom: -10px;
	content: '';
	width: 100%;
	height: 2px;
	background: #0d0cb5;
	margin: 0 auto;
}

.heading-section-white{
	color: rgba(255,255,255,.8);
}
.heading-section-white h2{
	font-family: 
	line-height: 1;
	padding-bottom: 0;
}
.heading-section-white h2{
	color: #ffffff;
}
.heading-section-white .subheading{
	margin-bottom: 0;
	display: inline-block;
	font-size: 13px;
	text-transform: uppercase;
	letter-spacing: 2px;
	color: rgba(255,255,255,.4);
}


.icon{
	text-align: center;
}
.icon img{
}


/*SERVICES*/
.services{
	background: rgba(0,0,0,.03);
}
.text-services{
	padding: 10px 10px 0; 
	text-align: center;
}
.text-services h3{
	font-size: 16px;
	font-weight: 600;
}

.services-list{
	padding: 0;
	margin: 0 0 20px 0;
	width: 100%;
	float: left;
}

.services-list img{
	float: left;
}
.services-list .text{
	width: calc(100% - 60px);
	float: right;
}
.services-list h3{
	margin-top: 0;
	margin-bottom: 0;
}
.services-list p{
	margin: 0;
}

/*BLOG*/
.text-services .meta{
	text-transform: uppercase;
	font-size: 14px;
}

/*TESTIMONY*/
.text-testimony .name{
	margin: 0;
}
.text-testimony .position{
	color: rgba(0,0,0,.3);

}


/*VIDEO*/
.img{
	width: 100%;
	height: auto;
	position: relative;
}
.img .icon{
	position: absolute;
	top: 50%;
	left: 0;
	right: 0;
	bottom: 0;
	margin-top: -25px;
}
.img .icon a{
	display: block;
	width: 60px;
	position: absolute;
	top: 0;
	left: 50%;
	margin-left: -25px;
}



/*COUNTER*/
.counter{
	width: 100%;
	position: relative;
	z-index: 0;
}
.counter .overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	content: '';
	width: 100%;
	background: #000000;
	z-index: -1;
	opacity: .3;
}
.counter-text{
	text-align: center;
}
.counter-text .num{
	display: block;
	color: #ffffff;
	font-size: 34px;
	font-weight: 700;
}
.counter-text .name{
	display: block;
	color: rgba(255,255,255,.9);
	font-size: 13px;
}


/*FOOTER*/

.footer{
	color: rgba(255,255,255,.5);

}
.footer .heading{
	color: #ffffff;
	font-size: 20px;
}
.footer ul{
	margin: 0;
	padding: 0;
}
.footer ul li{
	list-style: none;
	margin-bottom: 10px;
}
.footer ul li a{
	color: rgba(255,255,255,1);
}


@media screen and (max-width: 500px) {

	.icon{
		text-align: left;
	}

	.text-services{
		padding-left: 0;
		padding-right: 20px;
		text-align: left;
	}

}
</style>


</head>

<body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
	<center style="width: 100%; background-color: #f1f1f1;">
   
    <div style="max-width: 600px; margin: 0 auto;" class="email-container">
    	<!-- BEGIN BODY -->
      <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
      	<tr>
          <td valign="top" class="bg_white" style="padding: 1em 0em;">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                <tr>
          			<td class="logo" style="text-align: center;">
			            <img src="`+base_url+`admin/uploads/logo/housiey-logo2.jpg" alt="Image" class="img-fluid mb-4" style="width: 200px;">
			          </td>	
          		</tr>
          		<tr>
          			<td class="logo" style="text-align: center;">
			            <img src="`+base_url+`admin/assets/images_mail/gift.png" alt="Image" class="img-fluid mb-4">
			          </td>	
          		</tr>
          		<tr>
          			<td>
			          	<h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 600;color:#234e70">Congratulatons,</h1>
			          </td>
          		</tr>
          		<tr>
          			<td>
			          	<p style="text-align: center;font-size: 18px;margin:0;color: #234e70;font-weight: 500;">you have successfully <span style="color: #0e8744;">Sign Up</span></p>
			          </td>
          		</tr>
          	</table>
          </td>
	      </tr><!-- end tr -->

	      <tr>
          <td valign="top" class="bg_white" style="padding: 1em 0em;">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
          		<tr>
          			<td>
			          	<p style="text-align: center;font-size: 18px;margin:0;font-weight: 500;color: #fff;">
			          	<span style="background: #234e70;padding: 10px;border-radius: 50px;">Enjoy your exclusive Sign Up Perks</span>
			          	</p>
			          </td>
          		</tr>
          	</table>
          </td>
	      </tr><!-- end tr -->

	      <tr>
		      <td class="bg_white">
		        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
		          <tr>
		            <td class="bg_white email-section">
		            	
		            	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
		            		<tr>
		            			<td valign="top" width="33.333%" style="padding-top: 20px;padding: 5px;background: #fff;" class="services">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">                    
                          <tr>
                            <td class="text-services" style="box-shadow: 0 8px 20px 0 rgb(62 28 131 / 10%);border-radius: 8px;">
                            	<img src="`+base_url+`admin/assets/images_mail/bonus.png" alt="Image" class="img-fluid mb-4" style="max-width: 35px;margin-bottom:5px;background: #ebedf3;padding: 10px 14px;;border-radius: 10px;">
                            	<h3 style="font-size: 13px;margin-bottom: 17px;text-align:center;">Refer Housiey & get bonus upto Rs 2lac</h3>
                             	<!-- <p>Far far away, behind the word mountains, far from the countries</p> -->
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td valign="top" width="33.333%" style="padding-top: 20px;padding: 5px; background: #fff;" class="services">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                          <tr>
                            <td class="text-services" style="box-shadow: 0 8px 20px 0 rgb(62 28 131 / 10%);border-radius: 8px;">
                            	<img src="`+base_url+`admin/assets/images_mail/free-cab.png" alt="Image" class="img-fluid mb-4" style="max-width: 40px;margin-bottom:8px;background: #ebedf3;padding: 12px;border-radius: 10px;">
                            	<h3 style="font-size: 13px;margin-bottom:40px;text-align:center;">Free Site Visit</h3>
                             	<!-- <p>Far far away, behind the word mountains, far from the countries</p> -->
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td valign="top" width="33.333%" style="padding-top: 20px;padding: 5px;background: #fff;" class="services">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                          
                          <tr>
                            <td class="text-services" style="box-shadow: 0 8px 20px 0 rgb(62 28 131 / 10%);border-radius: 8px;">
                            	<img src="`+base_url+`admin/assets/images_mail/bottom-rate.png" alt="Image" class="img-fluid mb-4" style="max-width: 35px;
                            	background: #ebedf3;padding: 8px 15px;border-radius: 10px;margin-bottom:6px;">
                            	<h3 style="font-size: 13px;margin-bottom: 15px;text-align:center;">Bottom Rate Guarantee</h3>
                              <!-- <p>Far far away, behind the word mountains, far from the countries</p> -->
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td valign="top" width="33.333%" style="padding-top: 20px;padding: 5px; background: #fff;" class="services">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                          
                          <tr>
                            <td class="text-services" style="box-shadow: 0 8px 20px 0 rgb(62 28 131 / 10%);border-radius: 8px;">
                            	<img src="`+base_url+`admin/assets/images_mail/manager.png" alt="Image" class="img-fluid mb-4" style="max-width: 38px;margin-bottom:6px;background: #ebedf3;padding: 11px 15px;border-radius: 10px;">
                            	<h3 style="font-size: 13px;text-align:center;">Relationship Manager</h3>
                             	<!-- <p>Far far away, behind the word mountains, far from the countries</p> -->
                            </td>
                          </tr>
                        </table>
                      </td>
                      
                    </tr>
		            	</table>
		            </td>
		          </tr><!-- end: tr -->
		          
		        </table>

		      </td>
		    </tr><!-- end:tr -->
      <!-- 1 Column Text + Button : END -->
      </table>
  

    </div>
  </center>
</body>
</html>
                            `);
                        }

                        if(req.body.page_type=='home' || req.body.page_type=='listing'){
                            if(send_msgs){
                                let msg = "Hello Ronak Pandya, Client - "+req.body.name+" - +"+mobile+" has done the Sign Up on Housiey. Kindly connect with the client. Cheers Housiey.com"
                                requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile=919975318739&dlttempid=1707164854056403600&message='+msg, false) //919975318739 
                                .on('data', function (chunk) {
                                console.log(chunk)
                                })
                                .on('end', function (err) {
                                    if (err) console.log('connection closed due to errors', err);
                                    console.log('end');
                                })
                            }
                            let msg = `<!DOCTYPE html>
                                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
                                    <head>
                                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                                        <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
                                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                                        <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
                                        <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                                    
                                        <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
                                    
                                        <!-- CSS Reset : BEGIN -->
                                    <style>
                                    html,
                                    body {
                                        margin: 0 auto !important;
                                        padding: 0 !important;
                                        height: 100% !important;
                                        width: 100% !important;
                                        background: #f1f1f1;
                                    }
                                    
                                    /* What it does: Stops email clients resizing small text. */
                                    * {
                                        -ms-text-size-adjust: 100%;
                                        -webkit-text-size-adjust: 100%;
                                    }
                                    
                                    /* What it does: Centers email on Android 4.4 */
                                    div[style*="margin: 16px 0"] {
                                        margin: 0 !important;
                                    }
                                    
                                    /* What it does: Stops Outlook from adding extra spacing to tables. */
                                    table,
                                    td {
                                        mso-table-lspace: 0pt !important;
                                        mso-table-rspace: 0pt !important;
                                    }
                                    
                                    /* What it does: Fixes webkit padding issue. */
                                    table {
                                        border-spacing: 0 !important;
                                        border-collapse: collapse !important;
                                        table-layout: fixed !important;
                                        margin: 0 auto !important;
                                    }
                                    
                                    /* What it does: Uses a better rendering method when resizing images in IE. */
                                    img {
                                        -ms-interpolation-mode:bicubic;
                                    }
                                    
                                    /* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
                                    a {
                                        text-decoration: none;
                                    }
                                    
                                    /* What it does: A work-around for email clients meddling in triggered links. */
                                    *[x-apple-data-detectors],  /* iOS */
                                    .unstyle-auto-detected-links *,
                                    .aBn {
                                        border-bottom: 0 !important;
                                        cursor: default !important;
                                        color: inherit !important;
                                        text-decoration: none !important;
                                        font-size: inherit !important;
                                        font-family: inherit !important;
                                        font-weight: inherit !important;
                                        line-height: inherit !important;
                                    }
                                    
                                    /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
                                    .a6S {
                                        display: none !important;
                                        opacity: 0.01 !important;
                                    }
                                    
                                    /* What it does: Prevents Gmail from changing the text color in conversation threads. */
                                    .im {
                                        color: inherit !important;
                                    }
                                    
                                    /* If the above doesn't work, add a .g-img class to any image in question. */
                                    img.g-img + div {
                                        display: none !important;
                                    }
                                    
                                    /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
                                    /* Create one of these media queries for each additional viewport size you'd like to fix */
                                    
                                    /* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
                                    @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
                                        u ~ div .email-container {
                                            min-width: 320px !important;
                                        }
                                    }
                                    /* iPhone 6, 6S, 7, 8, and X */
                                    @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
                                        u ~ div .email-container {
                                            min-width: 375px !important;
                                        }
                                    }
                                    /* iPhone 6+, 7+, and 8+ */
                                    @media only screen and (min-device-width: 414px) {
                                        u ~ div .email-container {
                                            min-width: 414px !important;
                                        }
                                    }
                                    
                                    </style>
                                    
                                    <!-- CSS Reset : END -->
                                    
                                    <!-- Progressive Enhancements : BEGIN -->
                                    <style>
                                    
                                      .primary{
                                        background: #0d0cb5;
                                    }
                                    .bg_white{
                                        background: #ffffff;
                                    }
                                    .bg_light{
                                        background: #fafafa;
                                    }
                                    .bg_black{
                                        background: #000000;
                                    }
                                    .bg_dark{
                                        background: rgba(0,0,0,.8);
                                    }
                                    .email-section{
                                        padding:2.5em;
                                    }
                                    
                                    /*BUTTON*/
                                    .btn{
                                        padding: 5px 15px;
                                        display: inline-block;
                                    }
                                    .btn.btn-primary{
                                        border-radius: 5px;
                                        background: #0d0cb5;
                                        color: #ffffff;
                                    }
                                    .btn.btn-white{
                                        border-radius: 5px;
                                        background: #ffffff;
                                        color: #000000;
                                    }
                                    .btn.btn-white-outline{
                                        border-radius: 5px;
                                        background: transparent;
                                        border: 1px solid #fff;
                                        color: #fff;
                                    }
                                    
                                    h1,h2,h3,h4,h5,h6{
                                        font-family: 'Poppins', sans-serif;
                                        color: #000000;
                                        margin-top: 0;
                                    }
                                    
                                    body{
                                        font-family: 'Poppins', sans-serif;
                                        font-weight: 400;
                                        font-size: 15px;
                                        line-height: 1.8;
                                        color: rgba(0,0,0,.4);
                                    }
                                    
                                    a{
                                        color: #0d0cb5;
                                    }
                                    
                                    table{
                                    }
                                    /*LOGO*/
                                    
                                    .logo h1{
                                        margin: 0;
                                    }
                                    .logo h1 a{
                                        color: #000000;
                                        font-size: 20px;
                                        font-weight: 700;
                                        text-transform: uppercase;
                                        font-family: 'Poppins', sans-serif;
                                    }
                                    
                                    .navigation{
                                        padding: 0;
                                    }
                                    .navigation li{
                                        list-style: none;
                                        display: inline-block;;
                                        margin-left: 5px;
                                        font-size: 13px;
                                        font-weight: 500;
                                    }
                                    .navigation li a{
                                        color: rgba(0,0,0,.4);
                                    }
                                    
                                    /*HERO*/
                                    .hero{
                                        position: relative;
                                        z-index: 0;
                                    }
                                    .hero .overlay{
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        content: '';
                                        width: 100%;
                                        background: #000000;
                                        z-index: -1;
                                        opacity: .3;
                                    }
                                    .hero .icon{
                                    }
                                    .hero .icon a{
                                        display: block;
                                        width: 60px;
                                        margin: 0 auto;
                                    }
                                    .hero .text{
                                        color: rgba(255,255,255,.8);
                                    }
                                    .hero .text h2{
                                        color: #ffffff;
                                        font-size: 30px;
                                        margin-bottom: 0;
                                    }
                                    
                                    
                                    /*HEADING SECTION*/
                                    .heading-section{
                                    }
                                    .heading-section h2{
                                        color: #000000;
                                        font-size: 20px;
                                        margin-top: 0;
                                        line-height: 1.4;
                                        font-weight: 700;
                                        text-transform: uppercase;
                                    }
                                    .heading-section .subheading{
                                        margin-bottom: 20px !important;
                                        display: inline-block;
                                        font-size: 13px;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        color: rgba(0,0,0,.4);
                                        position: relative;
                                    }
                                    .heading-section .subheading::after{
                                        position: absolute;
                                        left: 0;
                                        right: 0;
                                        bottom: -10px;
                                        content: '';
                                        width: 100%;
                                        height: 2px;
                                        background: #0d0cb5;
                                        margin: 0 auto;
                                    }
                                    
                                    .heading-section-white{
                                        color: rgba(255,255,255,.8);
                                    }
                                    .heading-section-white h2{
                                        font-family: 
                                        line-height: 1;
                                        padding-bottom: 0;
                                    }
                                    .heading-section-white h2{
                                        color: #ffffff;
                                    }
                                    .heading-section-white .subheading{
                                        margin-bottom: 0;
                                        display: inline-block;
                                        font-size: 13px;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        color: rgba(255,255,255,.4);
                                    }
                                    
                                    
                                    .icon{
                                        text-align: center;
                                    }
                                    .icon img{
                                    }
                                    
                                    
                                    /*SERVICES*/
                                    .services{
                                        background: rgba(0,0,0,.03);
                                    }
                                    .text-services{
                                        padding: 10px 10px 0; 
                                        text-align: center;
                                    }
                                    .text-services h3{
                                        font-size: 16px;
                                        font-weight: 600;
                                    }
                                    
                                    .services-list{
                                        padding: 0;
                                        margin: 0 0 20px 0;
                                        width: 100%;
                                        float: left;
                                    }
                                    
                                    .services-list img{
                                        float: left;
                                    }
                                    .services-list .text{
                                        width: calc(100% - 60px);
                                        float: right;
                                    }
                                    .services-list h3{
                                        margin-top: 0;
                                        margin-bottom: 0;
                                    }
                                    .services-list p{
                                        margin: 0;
                                    }
                                    
                                    /*BLOG*/
                                    .text-services .meta{
                                        text-transform: uppercase;
                                        font-size: 14px;
                                    }
                                    
                                    /*TESTIMONY*/
                                    .text-testimony .name{
                                        margin: 0;
                                    }
                                    .text-testimony .position{
                                        color: rgba(0,0,0,.3);
                                    
                                    }
                                    
                                    
                                    /*VIDEO*/
                                    .img{
                                        width: 100%;
                                        height: auto;
                                        position: relative;
                                    }
                                    .img .icon{
                                        position: absolute;
                                        top: 50%;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        margin-top: -25px;
                                    }
                                    .img .icon a{
                                        display: block;
                                        width: 60px;
                                        position: absolute;
                                        top: 0;
                                        left: 50%;
                                        margin-left: -25px;
                                    }
                                    
                                    
                                    
                                    /*COUNTER*/
                                    .counter{
                                        width: 100%;
                                        position: relative;
                                        z-index: 0;
                                    }
                                    .counter .overlay{
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        content: '';
                                        width: 100%;
                                        background: #000000;
                                        z-index: -1;
                                        opacity: .3;
                                    }
                                    .counter-text{
                                        text-align: center;
                                    }
                                    .counter-text .num{
                                        display: block;
                                        color: #ffffff;
                                        font-size: 34px;
                                        font-weight: 700;
                                    }
                                    .counter-text .name{
                                        display: block;
                                        color: rgba(255,255,255,.9);
                                        font-size: 13px;
                                    }
                                    
                                    
                                    /*FOOTER*/
                                    
                                    .footer{
                                        color: rgba(255,255,255,.5);
                                    
                                    }
                                    .footer .heading{
                                        color: #ffffff;
                                        font-size: 20px;
                                    }
                                    .footer ul{
                                        margin: 0;
                                        padding: 0;
                                    }
                                    .footer ul li{
                                        list-style: none;
                                        margin-bottom: 10px;
                                    }
                                    .footer ul li a{
                                        color: rgba(255,255,255,1);
                                    }
                                    
                                    
                                    @media screen and (max-width: 500px) {
                                    
                                        .icon{
                                            text-align: left;
                                        }
                                    
                                        .text-services{
                                            padding-left: 0;
                                            padding-right: 20px;
                                            text-align: left;
                                        }
                                    
                                    }
                                    </style>
                                    
                                    
                                    </head>
                                    
                                    <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
                                        <center style="width: 100%; background-color: #f1f1f1;">
                                        
                                        <div style="max-width: 600px; margin: 0 auto;" class="email-container">
                                            <!-- BEGIN BODY -->
                                          <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
                                              <tr>
                                              <td valign="top" class="bg_white">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                                                      
                                                      <tr style="background: #234e70">
                                                          <td>
                                                              <h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 500;color:#fff;">`+req.body.name+` would like to talk to you</h1>
                                                          </td>
                                                      </tr>
                                                      
                                                  </table>
                                              </td>
                                            </tr><!-- end tr -->
                                    
                                            <tr>
                                              <td valign="top" class="bg_white" style="padding-top: 15px">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      <tr >
                                                          <td style="padding:10px">
                                                              <h2 style="margin-bottom: 0">Hello Ronak Pandya</h2><br>
                                                              <p style="margin: 0px;font-weight:500">We have recieved an interest from our user:</p>
                                                        </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                          <tr>
                                              <td valign="top" class="bg_white" style="font-weight:600;color:#234E70;">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Name: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                         `+req.body.name+`
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Email: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                            `+req.body.email+`
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Mobile: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                         `+req.body.mobile+`
                                                         </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                          <!-- 1 Column Text + Button : END -->
                                          </table>
                                        
                                    
                                        </div>
                                      </center>
                                    </body>
                                    </html>`
                            fun.nodemailer('housiey.inquiry@gmail.com','Housiey',msg);
                        }
                        if(req.body.page_type=='details'){
                            let projects = await db.query("SELECT project_name,seller_id FROM `projects` WHERE id IN("+req.body.project_id+")");
                            projects_names = projects[0].project_name
                            let sellers_ids = []
                            if(projects[0].seller_id){
                                var getsellers = projects[0].seller_id.split(',')
                                for (let j = 0; j < getsellers.length; j++) {
                                    sellers_ids.push(getsellers[j])
                                }
                            }
                            sellerInfo = await db.query("SELECT email,phone,name FROM sellers WHERE  seller_id IN("+sellers_ids+")",false);
                            // to seller
                            if(send_msgs){
                                for (let l = 0; l < sellerInfo.length; l++) {
                                    const element = sellerInfo[l];
                                    let msg = "Hello "+element.name+", Client - "+req.body.name+" - "+mobile+" has enquired for "+projects_names+", Kindly connect with the client. Cheers Housiey.com"
                                    requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+element.mobile+'&dlttempid=1707164854056403600&message='+msg, false)
                                    .on('data', function (chunk) {
                                    console.log(chunk)
                                    })
                                    .on('end', function (err) {
                                        if (err) console.log('connection closed due to errors', err);
                                        console.log('end');
                                    });
                                }
                            }
                            for (let x = 0; x < sellerInfo.length; x++) {
                                if(sellerInfo[x].email){
                                    let msg = `<!DOCTYPE html>
                                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
                                    <head>
                                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                                        <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
                                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                                        <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
                                        <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                                    
                                        <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
                                    
                                        <!-- CSS Reset : BEGIN -->
                                    <style>
                                    html,
                                    body {
                                        margin: 0 auto !important;
                                        padding: 0 !important;
                                        height: 100% !important;
                                        width: 100% !important;
                                        background: #f1f1f1;
                                    }
                                    
                                    /* What it does: Stops email clients resizing small text. */
                                    * {
                                        -ms-text-size-adjust: 100%;
                                        -webkit-text-size-adjust: 100%;
                                    }
                                    
                                    /* What it does: Centers email on Android 4.4 */
                                    div[style*="margin: 16px 0"] {
                                        margin: 0 !important;
                                    }
                                    
                                    /* What it does: Stops Outlook from adding extra spacing to tables. */
                                    table,
                                    td {
                                        mso-table-lspace: 0pt !important;
                                        mso-table-rspace: 0pt !important;
                                    }
                                    
                                    /* What it does: Fixes webkit padding issue. */
                                    table {
                                        border-spacing: 0 !important;
                                        border-collapse: collapse !important;
                                        table-layout: fixed !important;
                                        margin: 0 auto !important;
                                    }
                                    
                                    /* What it does: Uses a better rendering method when resizing images in IE. */
                                    img {
                                        -ms-interpolation-mode:bicubic;
                                    }
                                    
                                    /* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
                                    a {
                                        text-decoration: none;
                                    }
                                    
                                    /* What it does: A work-around for email clients meddling in triggered links. */
                                    *[x-apple-data-detectors],  /* iOS */
                                    .unstyle-auto-detected-links *,
                                    .aBn {
                                        border-bottom: 0 !important;
                                        cursor: default !important;
                                        color: inherit !important;
                                        text-decoration: none !important;
                                        font-size: inherit !important;
                                        font-family: inherit !important;
                                        font-weight: inherit !important;
                                        line-height: inherit !important;
                                    }
                                    
                                    /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
                                    .a6S {
                                        display: none !important;
                                        opacity: 0.01 !important;
                                    }
                                    
                                    /* What it does: Prevents Gmail from changing the text color in conversation threads. */
                                    .im {
                                        color: inherit !important;
                                    }
                                    
                                    /* If the above doesn't work, add a .g-img class to any image in question. */
                                    img.g-img + div {
                                        display: none !important;
                                    }
                                    
                                    /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
                                    /* Create one of these media queries for each additional viewport size you'd like to fix */
                                    
                                    /* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
                                    @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
                                        u ~ div .email-container {
                                            min-width: 320px !important;
                                        }
                                    }
                                    /* iPhone 6, 6S, 7, 8, and X */
                                    @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
                                        u ~ div .email-container {
                                            min-width: 375px !important;
                                        }
                                    }
                                    /* iPhone 6+, 7+, and 8+ */
                                    @media only screen and (min-device-width: 414px) {
                                        u ~ div .email-container {
                                            min-width: 414px !important;
                                        }
                                    }
                                    
                                    </style>
                                    
                                    <!-- CSS Reset : END -->
                                    
                                    <!-- Progressive Enhancements : BEGIN -->
                                    <style>
                                    
                                      .primary{
                                        background: #0d0cb5;
                                    }
                                    .bg_white{
                                        background: #ffffff;
                                    }
                                    .bg_light{
                                        background: #fafafa;
                                    }
                                    .bg_black{
                                        background: #000000;
                                    }
                                    .bg_dark{
                                        background: rgba(0,0,0,.8);
                                    }
                                    .email-section{
                                        padding:2.5em;
                                    }
                                    
                                    /*BUTTON*/
                                    .btn{
                                        padding: 5px 15px;
                                        display: inline-block;
                                    }
                                    .btn.btn-primary{
                                        border-radius: 5px;
                                        background: #0d0cb5;
                                        color: #ffffff;
                                    }
                                    .btn.btn-white{
                                        border-radius: 5px;
                                        background: #ffffff;
                                        color: #000000;
                                    }
                                    .btn.btn-white-outline{
                                        border-radius: 5px;
                                        background: transparent;
                                        border: 1px solid #fff;
                                        color: #fff;
                                    }
                                    
                                    h1,h2,h3,h4,h5,h6{
                                        font-family: 'Poppins', sans-serif;
                                        color: #000000;
                                        margin-top: 0;
                                    }
                                    
                                    body{
                                        font-family: 'Poppins', sans-serif;
                                        font-weight: 400;
                                        font-size: 15px;
                                        line-height: 1.8;
                                        color: rgba(0,0,0,.4);
                                    }
                                    
                                    a{
                                        color: #0d0cb5;
                                    }
                                    
                                    table{
                                    }
                                    /*LOGO*/
                                    
                                    .logo h1{
                                        margin: 0;
                                    }
                                    .logo h1 a{
                                        color: #000000;
                                        font-size: 20px;
                                        font-weight: 700;
                                        text-transform: uppercase;
                                        font-family: 'Poppins', sans-serif;
                                    }
                                    
                                    .navigation{
                                        padding: 0;
                                    }
                                    .navigation li{
                                        list-style: none;
                                        display: inline-block;;
                                        margin-left: 5px;
                                        font-size: 13px;
                                        font-weight: 500;
                                    }
                                    .navigation li a{
                                        color: rgba(0,0,0,.4);
                                    }
                                    
                                    /*HERO*/
                                    .hero{
                                        position: relative;
                                        z-index: 0;
                                    }
                                    .hero .overlay{
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        content: '';
                                        width: 100%;
                                        background: #000000;
                                        z-index: -1;
                                        opacity: .3;
                                    }
                                    .hero .icon{
                                    }
                                    .hero .icon a{
                                        display: block;
                                        width: 60px;
                                        margin: 0 auto;
                                    }
                                    .hero .text{
                                        color: rgba(255,255,255,.8);
                                    }
                                    .hero .text h2{
                                        color: #ffffff;
                                        font-size: 30px;
                                        margin-bottom: 0;
                                    }
                                    
                                    
                                    /*HEADING SECTION*/
                                    .heading-section{
                                    }
                                    .heading-section h2{
                                        color: #000000;
                                        font-size: 20px;
                                        margin-top: 0;
                                        line-height: 1.4;
                                        font-weight: 700;
                                        text-transform: uppercase;
                                    }
                                    .heading-section .subheading{
                                        margin-bottom: 20px !important;
                                        display: inline-block;
                                        font-size: 13px;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        color: rgba(0,0,0,.4);
                                        position: relative;
                                    }
                                    .heading-section .subheading::after{
                                        position: absolute;
                                        left: 0;
                                        right: 0;
                                        bottom: -10px;
                                        content: '';
                                        width: 100%;
                                        height: 2px;
                                        background: #0d0cb5;
                                        margin: 0 auto;
                                    }
                                    
                                    .heading-section-white{
                                        color: rgba(255,255,255,.8);
                                    }
                                    .heading-section-white h2{
                                        font-family: 
                                        line-height: 1;
                                        padding-bottom: 0;
                                    }
                                    .heading-section-white h2{
                                        color: #ffffff;
                                    }
                                    .heading-section-white .subheading{
                                        margin-bottom: 0;
                                        display: inline-block;
                                        font-size: 13px;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        color: rgba(255,255,255,.4);
                                    }
                                    
                                    
                                    .icon{
                                        text-align: center;
                                    }
                                    .icon img{
                                    }
                                    
                                    
                                    /*SERVICES*/
                                    .services{
                                        background: rgba(0,0,0,.03);
                                    }
                                    .text-services{
                                        padding: 10px 10px 0; 
                                        text-align: center;
                                    }
                                    .text-services h3{
                                        font-size: 16px;
                                        font-weight: 600;
                                    }
                                    
                                    .services-list{
                                        padding: 0;
                                        margin: 0 0 20px 0;
                                        width: 100%;
                                        float: left;
                                    }
                                    
                                    .services-list img{
                                        float: left;
                                    }
                                    .services-list .text{
                                        width: calc(100% - 60px);
                                        float: right;
                                    }
                                    .services-list h3{
                                        margin-top: 0;
                                        margin-bottom: 0;
                                    }
                                    .services-list p{
                                        margin: 0;
                                    }
                                    
                                    /*BLOG*/
                                    .text-services .meta{
                                        text-transform: uppercase;
                                        font-size: 14px;
                                    }
                                    
                                    /*TESTIMONY*/
                                    .text-testimony .name{
                                        margin: 0;
                                    }
                                    .text-testimony .position{
                                        color: rgba(0,0,0,.3);
                                    
                                    }
                                    
                                    
                                    /*VIDEO*/
                                    .img{
                                        width: 100%;
                                        height: auto;
                                        position: relative;
                                    }
                                    .img .icon{
                                        position: absolute;
                                        top: 50%;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        margin-top: -25px;
                                    }
                                    .img .icon a{
                                        display: block;
                                        width: 60px;
                                        position: absolute;
                                        top: 0;
                                        left: 50%;
                                        margin-left: -25px;
                                    }
                                    
                                    
                                    
                                    /*COUNTER*/
                                    .counter{
                                        width: 100%;
                                        position: relative;
                                        z-index: 0;
                                    }
                                    .counter .overlay{
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        content: '';
                                        width: 100%;
                                        background: #000000;
                                        z-index: -1;
                                        opacity: .3;
                                    }
                                    .counter-text{
                                        text-align: center;
                                    }
                                    .counter-text .num{
                                        display: block;
                                        color: #ffffff;
                                        font-size: 34px;
                                        font-weight: 700;
                                    }
                                    .counter-text .name{
                                        display: block;
                                        color: rgba(255,255,255,.9);
                                        font-size: 13px;
                                    }
                                    
                                    
                                    /*FOOTER*/
                                    
                                    .footer{
                                        color: rgba(255,255,255,.5);
                                    
                                    }
                                    .footer .heading{
                                        color: #ffffff;
                                        font-size: 20px;
                                    }
                                    .footer ul{
                                        margin: 0;
                                        padding: 0;
                                    }
                                    .footer ul li{
                                        list-style: none;
                                        margin-bottom: 10px;
                                    }
                                    .footer ul li a{
                                        color: rgba(255,255,255,1);
                                    }
                                    
                                    
                                    @media screen and (max-width: 500px) {
                                    
                                        .icon{
                                            text-align: left;
                                        }
                                    
                                        .text-services{
                                            padding-left: 0;
                                            padding-right: 20px;
                                            text-align: left;
                                        }
                                    
                                    }
                                    </style>
                                    
                                    
                                    </head>
                                    
                                    <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
                                        <center style="width: 100%; background-color: #f1f1f1;">
                                        
                                        <div style="max-width: 600px; margin: 0 auto;" class="email-container">
                                            <!-- BEGIN BODY -->
                                          <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
                                              <tr>
                                              <td valign="top" class="bg_white">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                                                      
                                                      <tr style="background: #234e70">
                                                          <td>
                                                              <h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 500;color:#fff;">`+req.body.name+` would like to talk to you</h1>
                                                          </td>
                                                      </tr>
                                                      
                                                  </table>
                                              </td>
                                            </tr><!-- end tr -->
                                    
                                            <tr>
                                              <td valign="top" class="bg_white" style="padding-top: 15px">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      <tr >
                                                          <td style="padding:10px">
                                                              <h2 style="margin-bottom: 0">Hello `+sellerInfo[x].name+`</h2><br>
                                                              <p style="margin: 0px;font-weight:500">We have recieved an interest from our user:</p>
                                                        </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                          <tr>
                                              <td valign="top" class="bg_white" style="font-weight:600;color:#234E70;">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Name: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                         `+req.body.name+`
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Email: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                            `+req.body.email+`
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Mobile: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                         `+req.body.mobile+`
                                                         </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                    
                                    
                                              <tr>
                                              <td valign="top" class="bg_white">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      
                                                      <tr>
                                                          <td style="padding: 10px">
                                                               <span style="font-weight: 600;padding-left:5px;">Who would like to talk to you regarding residential project <b style="color:#234E70;">`+projects_names+`</b></span>
                                                              </p>
                                                         </td>
                                                      </tr>
                                                      
                                                  </table>
                                              </td>
                                            </tr><!-- end tr -->
                                    
                                    
                                            
                                    
                                         
                                          <!-- 1 Column Text + Button : END -->
                                          </table>
                                        
                                    
                                        </div>
                                      </center>
                                    </body>
                                    </html>`
                                    fun.nodemailer(sellerInfo[x].email,'Housiey',msg);
                                    fun.nodemailer('enquiry.housiey@gmail.com','Housiey',msg);
                                }
                            }
                        }

                      }
                      console.log('------------------------------here------------------------------');
                    res.send({"res":true,"msg":"otp verified!","token":token})
                }else{
                    res.send({"res":false,"msg":"Invalid Otp!"})
                }  
            }else{
                res.send({"res":false,"msg":"Invalid Terms!"})
            }
        } catch (error) {
            console.log(error);
        }
    },
    verify_otp_old: async (req,res)=>{
        try {
            // const errors = validationResult(req);
            // if (!errors.isEmpty()) {
                // return res.status(400).json({ errors: errors.array() });
            // }
    
            req.body.mobile = req.body.mobile.replace(/[^\d]/g, ''); 
            let getuser = await db.query("SELECT otp,id FROM user_tbl where mobile=:mobile",{"mobile":req.body.mobile},true)
            if(getuser.length>0){
                //verify here
                if(parseInt(getuser[0].otp)==parseInt(req.body.otp)){
                    let update = await db.query("update user_tbl set name=:name,email=:email,status=1,update_datetime=:update_datetime where mobile=:mobile",{"mobile":req.body.mobile,"name":req.body.name,"email":req.body.email,"update_datetime":moment().format('YYYY-MM-DD H:m:s')})
                    let data = {
                        "id"  : getuser[0].id,
                        "mobile": req.body.mobile,
                        "name": req.body.name,
                        "email": req.body.email
                    }
                      var token = jwt.sign(data, token_key);

                      if(req.body.is_signup){
                     
                        let message = 'Greetings from Housiey !! Congratulations '+req.body.name+' for Sign Up on Housiey, Now enjoy Sign Up Perks - Unlimited Free Site Visit, Sign Up Bonus, Bottom Rate.... Thanks Housiey';
                        let mobile = req.body.mobile;
                        if(send_msgs){
                            requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+mobile+'&dlttempid=1707164700051366345&message='+message, false)
                            .on('data', function (chunk) {
                            console.log(chunk)
                            })
                            .on('end', function (err) {
                                if (err) console.log('connection closed due to errors', err);
                                console.log('end');
                            });
                        }
                        if(req.body.email){
                            fun.nodemailer(req.body.email,'Sign Up Done Successfully',`
                            <!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8"> <!-- utf-8 works for most cases -->
    <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
    <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
    <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <!-- CSS Reset : BEGIN -->
<style>
html,
body {
    margin: 0 auto !important;
    padding: 0 !important;
    height: 100% !important;
    width: 100% !important;
    background: #f1f1f1;
}

/* What it does: Stops email clients resizing small text. */
* {
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
}

/* What it does: Centers email on Android 4.4 */
div[style*="margin: 16px 0"] {
    margin: 0 !important;
}

/* What it does: Stops Outlook from adding extra spacing to tables. */
table,
td {
    mso-table-lspace: 0pt !important;
    mso-table-rspace: 0pt !important;
}

/* What it does: Fixes webkit padding issue. */
table {
    border-spacing: 0 !important;
    border-collapse: collapse !important;
    table-layout: fixed !important;
    margin: 0 auto !important;
}

/* What it does: Uses a better rendering method when resizing images in IE. */
img {
    -ms-interpolation-mode:bicubic;
}

/* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
a {
    text-decoration: none;
}

/* What it does: A work-around for email clients meddling in triggered links. */
*[x-apple-data-detectors],  /* iOS */
.unstyle-auto-detected-links *,
.aBn {
    border-bottom: 0 !important;
    cursor: default !important;
    color: inherit !important;
    text-decoration: none !important;
    font-size: inherit !important;
    font-family: inherit !important;
    font-weight: inherit !important;
    line-height: inherit !important;
}

/* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
.a6S {
    display: none !important;
    opacity: 0.01 !important;
}

/* What it does: Prevents Gmail from changing the text color in conversation threads. */
.im {
    color: inherit !important;
}

/* If the above doesn't work, add a .g-img class to any image in question. */
img.g-img + div {
    display: none !important;
}

/* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
/* Create one of these media queries for each additional viewport size you'd like to fix */

/* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
@media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
    u ~ div .email-container {
        min-width: 320px !important;
    }
}
/* iPhone 6, 6S, 7, 8, and X */
@media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
    u ~ div .email-container {
        min-width: 375px !important;
    }
}
/* iPhone 6+, 7+, and 8+ */
@media only screen and (min-device-width: 414px) {
    u ~ div .email-container {
        min-width: 414px !important;
    }
}

</style>

<!-- CSS Reset : END -->

<!-- Progressive Enhancements : BEGIN -->
<style>

  .primary{
	background: #0d0cb5;
}
.bg_white{
	background: #ffffff;
}
.bg_light{
	background: #fafafa;
}
.bg_black{
	background: #000000;
}
.bg_dark{
	background: rgba(0,0,0,.8);
}
.email-section{
	padding:2.5em;
}

/*BUTTON*/
.btn{
	padding: 5px 15px;
	display: inline-block;
}
.btn.btn-primary{
	border-radius: 5px;
	background: #0d0cb5;
	color: #ffffff;
}
.btn.btn-white{
	border-radius: 5px;
	background: #ffffff;
	color: #000000;
}
.btn.btn-white-outline{
	border-radius: 5px;
	background: transparent;
	border: 1px solid #fff;
	color: #fff;
}

h1,h2,h3,h4,h5,h6{
	font-family: 'Poppins', sans-serif;
	color: #000000;
	margin-top: 0;
}

body{
	font-family: 'Poppins', sans-serif;
	font-weight: 400;
	font-size: 15px;
	line-height: 1.8;
	color: rgba(0,0,0,.4);
}

a{
	color: #0d0cb5;
}

table{
}
/*LOGO*/

.logo h1{
	margin: 0;
}
.logo h1 a{
	color: #000000;
	font-size: 20px;
	font-weight: 700;
	text-transform: uppercase;
	font-family: 'Poppins', sans-serif;
}

.navigation{
	padding: 0;
}
.navigation li{
	list-style: none;
	display: inline-block;;
	margin-left: 5px;
	font-size: 13px;
	font-weight: 500;
}
.navigation li a{
	color: rgba(0,0,0,.4);
}

/*HERO*/
.hero{
	position: relative;
	z-index: 0;
}
.hero .overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	content: '';
	width: 100%;
	background: #000000;
	z-index: -1;
	opacity: .3;
}
.hero .icon{
}
.hero .icon a{
	display: block;
	width: 60px;
	margin: 0 auto;
}
.hero .text{
	color: rgba(255,255,255,.8);
}
.hero .text h2{
	color: #ffffff;
	font-size: 30px;
	margin-bottom: 0;
}


/*HEADING SECTION*/
.heading-section{
}
.heading-section h2{
	color: #000000;
	font-size: 20px;
	margin-top: 0;
	line-height: 1.4;
	font-weight: 700;
	text-transform: uppercase;
}
.heading-section .subheading{
	margin-bottom: 20px !important;
	display: inline-block;
	font-size: 13px;
	text-transform: uppercase;
	letter-spacing: 2px;
	color: rgba(0,0,0,.4);
	position: relative;
}
.heading-section .subheading::after{
	position: absolute;
	left: 0;
	right: 0;
	bottom: -10px;
	content: '';
	width: 100%;
	height: 2px;
	background: #0d0cb5;
	margin: 0 auto;
}

.heading-section-white{
	color: rgba(255,255,255,.8);
}
.heading-section-white h2{
	font-family: 
	line-height: 1;
	padding-bottom: 0;
}
.heading-section-white h2{
	color: #ffffff;
}
.heading-section-white .subheading{
	margin-bottom: 0;
	display: inline-block;
	font-size: 13px;
	text-transform: uppercase;
	letter-spacing: 2px;
	color: rgba(255,255,255,.4);
}


.icon{
	text-align: center;
}
.icon img{
}


/*SERVICES*/
.services{
	background: rgba(0,0,0,.03);
}
.text-services{
	padding: 10px 10px 0; 
	text-align: center;
}
.text-services h3{
	font-size: 16px;
	font-weight: 600;
}

.services-list{
	padding: 0;
	margin: 0 0 20px 0;
	width: 100%;
	float: left;
}

.services-list img{
	float: left;
}
.services-list .text{
	width: calc(100% - 60px);
	float: right;
}
.services-list h3{
	margin-top: 0;
	margin-bottom: 0;
}
.services-list p{
	margin: 0;
}

/*BLOG*/
.text-services .meta{
	text-transform: uppercase;
	font-size: 14px;
}

/*TESTIMONY*/
.text-testimony .name{
	margin: 0;
}
.text-testimony .position{
	color: rgba(0,0,0,.3);

}


/*VIDEO*/
.img{
	width: 100%;
	height: auto;
	position: relative;
}
.img .icon{
	position: absolute;
	top: 50%;
	left: 0;
	right: 0;
	bottom: 0;
	margin-top: -25px;
}
.img .icon a{
	display: block;
	width: 60px;
	position: absolute;
	top: 0;
	left: 50%;
	margin-left: -25px;
}



/*COUNTER*/
.counter{
	width: 100%;
	position: relative;
	z-index: 0;
}
.counter .overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	content: '';
	width: 100%;
	background: #000000;
	z-index: -1;
	opacity: .3;
}
.counter-text{
	text-align: center;
}
.counter-text .num{
	display: block;
	color: #ffffff;
	font-size: 34px;
	font-weight: 700;
}
.counter-text .name{
	display: block;
	color: rgba(255,255,255,.9);
	font-size: 13px;
}


/*FOOTER*/

.footer{
	color: rgba(255,255,255,.5);

}
.footer .heading{
	color: #ffffff;
	font-size: 20px;
}
.footer ul{
	margin: 0;
	padding: 0;
}
.footer ul li{
	list-style: none;
	margin-bottom: 10px;
}
.footer ul li a{
	color: rgba(255,255,255,1);
}


@media screen and (max-width: 500px) {

	.icon{
		text-align: left;
	}

	.text-services{
		padding-left: 0;
		padding-right: 20px;
		text-align: left;
	}

}
</style>


</head>

<body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
	<center style="width: 100%; background-color: #f1f1f1;">
   
    <div style="max-width: 600px; margin: 0 auto;" class="email-container">
    	<!-- BEGIN BODY -->
      <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
      	<tr>
          <td valign="top" class="bg_white" style="padding: 1em 0em;">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                <tr>
          			<td class="logo" style="text-align: center;">
			            <img src="`+base_url+`admin/uploads/logo/housiey-logo2.jpg" alt="Image" class="img-fluid mb-4" style="width: 200px;">
			          </td>	
          		</tr>
          		<tr>
          			<td class="logo" style="text-align: center;">
			            <img src="`+base_url+`admin/assets/images_mail/gift.png" alt="Image" class="img-fluid mb-4">
			          </td>	
          		</tr>
          		<tr>
          			<td>
			          	<h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 600;color:#234e70">Congratulatons,</h1>
			          </td>
          		</tr>
          		<tr>
          			<td>
			          	<p style="text-align: center;font-size: 18px;margin:0;color: #234e70;font-weight: 500;">you have successfully <span style="color: #0e8744;">Sign Up</span></p>
			          </td>
          		</tr>
          	</table>
          </td>
	      </tr><!-- end tr -->

	      <tr>
          <td valign="top" class="bg_white" style="padding: 1em 0em;">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
          		<tr>
          			<td>
			          	<p style="text-align: center;font-size: 18px;margin:0;font-weight: 500;color: #fff;">
			          	<span style="background: #234e70;padding: 10px;border-radius: 50px;">Enjoy your exclusive Sign Up Perks</span>
			          	</p>
			          </td>
          		</tr>
          	</table>
          </td>
	      </tr><!-- end tr -->

	      <tr>
		      <td class="bg_white">
		        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
		          <tr>
		            <td class="bg_white email-section">
		            	
		            	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
		            		<tr>
		            			<td valign="top" width="33.333%" style="padding-top: 20px;padding: 5px;background: #fff;" class="services">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">                    
                          <tr>
                            <td class="text-services" style="box-shadow: 0 8px 20px 0 rgb(62 28 131 / 10%);border-radius: 8px;">
                            	<img src="`+base_url+`admin/assets/images_mail/bonus.png" alt="Image" class="img-fluid mb-4" style="max-width: 35px;margin-bottom:5px;background: #ebedf3;padding: 10px 14px;;border-radius: 10px;">
                            	<h3 style="font-size: 13px;margin-bottom: 17px;text-align:center;">Refer Housiey & get bonus upto Rs 2lac</h3>
                             	<!-- <p>Far far away, behind the word mountains, far from the countries</p> -->
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td valign="top" width="33.333%" style="padding-top: 20px;padding: 5px; background: #fff;" class="services">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                          <tr>
                            <td class="text-services" style="box-shadow: 0 8px 20px 0 rgb(62 28 131 / 10%);border-radius: 8px;">
                            	<img src="`+base_url+`admin/assets/images_mail/free-cab.png" alt="Image" class="img-fluid mb-4" style="max-width: 40px;margin-bottom:8px;background: #ebedf3;padding: 12px;border-radius: 10px;">
                            	<h3 style="font-size: 13px;margin-bottom:40px;text-align:center;">Free Site Visit</h3>
                             	<!-- <p>Far far away, behind the word mountains, far from the countries</p> -->
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td valign="top" width="33.333%" style="padding-top: 20px;padding: 5px;background: #fff;" class="services">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                          
                          <tr>
                            <td class="text-services" style="box-shadow: 0 8px 20px 0 rgb(62 28 131 / 10%);border-radius: 8px;">
                            	<img src="`+base_url+`admin/assets/images_mail/bottom-rate.png" alt="Image" class="img-fluid mb-4" style="max-width: 35px;
                            	background: #ebedf3;padding: 8px 15px;border-radius: 10px;margin-bottom:6px;">
                            	<h3 style="font-size: 13px;margin-bottom: 15px;text-align:center;">Bottom Rate Guarantee</h3>
                              <!-- <p>Far far away, behind the word mountains, far from the countries</p> -->
                            </td>
                          </tr>
                        </table>
                      </td>
                      <td valign="top" width="33.333%" style="padding-top: 20px;padding: 5px; background: #fff;" class="services">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                          
                          <tr>
                            <td class="text-services" style="box-shadow: 0 8px 20px 0 rgb(62 28 131 / 10%);border-radius: 8px;">
                            	<img src="`+base_url+`admin/assets/images_mail/manager.png" alt="Image" class="img-fluid mb-4" style="max-width: 38px;margin-bottom:6px;background: #ebedf3;padding: 11px 15px;border-radius: 10px;">
                            	<h3 style="font-size: 13px;text-align:center;">Relationship Manager</h3>
                             	<!-- <p>Far far away, behind the word mountains, far from the countries</p> -->
                            </td>
                          </tr>
                        </table>
                      </td>
                      
                    </tr>
		            	</table>
		            </td>
		          </tr><!-- end: tr -->
		          
		        </table>

		      </td>
		    </tr><!-- end:tr -->
      <!-- 1 Column Text + Button : END -->
      </table>
  

    </div>
  </center>
</body>
</html>
                            `);
                        }

                        if(req.body.page_type=='home' || req.body.page_type=='listing'){

                            let projects = await db.query("SELECT project_name,seller_id FROM `projects` WHERE id IN("+req.body.project_id+")");
                            projects_names = projects[0].project_name
                            let sellers_ids = []
                            if(projects[0].seller_id){
                                var getsellers = projects[0].seller_id.split(',')
                                for (let j = 0; j < getsellers.length; j++) {
                                    sellers_ids.push(getsellers[j])
                                }
                            }
                            sellerInfo = await db.query("SELECT email,phone,name FROM sellers WHERE  seller_id IN("+sellers_ids+")",false);
                            // to seller
                            if(send_msgs){
                                for (let l = 0; l < sellerInfo.length; l++) {
                                    const element = sellerInfo[l];
                                    let msg = "Hello "+element.name+", Client - "+req.body.name+" - "+mobile+" has enquired for "+projects_names+", Kindly connect with the client. Cheers Housiey.com"
                                    requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+element.mobile+'&dlttempid=1707164854056403600&message='+msg, false)
                                    .on('data', function (chunk) {
                                    console.log(chunk)
                                    })
                                    .on('end', function (err) {
                                        if (err) console.log('connection closed due to errors', err);
                                        console.log('end');
                                    });
                                }
                            }

                            for (let x = 0; x < sellerInfo.length; x++) {
                                if(sellerInfo[x].email){
                                    let msg = `<!DOCTYPE html>
                                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
                                    <head>
                                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                                        <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
                                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                                        <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
                                        <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                                    
                                        <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
                                    
                                        <!-- CSS Reset : BEGIN -->
                                    <style>
                                    html,
                                    body {
                                        margin: 0 auto !important;
                                        padding: 0 !important;
                                        height: 100% !important;
                                        width: 100% !important;
                                        background: #f1f1f1;
                                    }
                                    
                                    /* What it does: Stops email clients resizing small text. */
                                    * {
                                        -ms-text-size-adjust: 100%;
                                        -webkit-text-size-adjust: 100%;
                                    }
                                    
                                    /* What it does: Centers email on Android 4.4 */
                                    div[style*="margin: 16px 0"] {
                                        margin: 0 !important;
                                    }
                                    
                                    /* What it does: Stops Outlook from adding extra spacing to tables. */
                                    table,
                                    td {
                                        mso-table-lspace: 0pt !important;
                                        mso-table-rspace: 0pt !important;
                                    }
                                    
                                    /* What it does: Fixes webkit padding issue. */
                                    table {
                                        border-spacing: 0 !important;
                                        border-collapse: collapse !important;
                                        table-layout: fixed !important;
                                        margin: 0 auto !important;
                                    }
                                    
                                    /* What it does: Uses a better rendering method when resizing images in IE. */
                                    img {
                                        -ms-interpolation-mode:bicubic;
                                    }
                                    
                                    /* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
                                    a {
                                        text-decoration: none;
                                    }
                                    
                                    /* What it does: A work-around for email clients meddling in triggered links. */
                                    *[x-apple-data-detectors],  /* iOS */
                                    .unstyle-auto-detected-links *,
                                    .aBn {
                                        border-bottom: 0 !important;
                                        cursor: default !important;
                                        color: inherit !important;
                                        text-decoration: none !important;
                                        font-size: inherit !important;
                                        font-family: inherit !important;
                                        font-weight: inherit !important;
                                        line-height: inherit !important;
                                    }
                                    
                                    /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
                                    .a6S {
                                        display: none !important;
                                        opacity: 0.01 !important;
                                    }
                                    
                                    /* What it does: Prevents Gmail from changing the text color in conversation threads. */
                                    .im {
                                        color: inherit !important;
                                    }
                                    
                                    /* If the above doesn't work, add a .g-img class to any image in question. */
                                    img.g-img + div {
                                        display: none !important;
                                    }
                                    
                                    /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
                                    /* Create one of these media queries for each additional viewport size you'd like to fix */
                                    
                                    /* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
                                    @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
                                        u ~ div .email-container {
                                            min-width: 320px !important;
                                        }
                                    }
                                    /* iPhone 6, 6S, 7, 8, and X */
                                    @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
                                        u ~ div .email-container {
                                            min-width: 375px !important;
                                        }
                                    }
                                    /* iPhone 6+, 7+, and 8+ */
                                    @media only screen and (min-device-width: 414px) {
                                        u ~ div .email-container {
                                            min-width: 414px !important;
                                        }
                                    }
                                    
                                    </style>
                                    
                                    <!-- CSS Reset : END -->
                                    
                                    <!-- Progressive Enhancements : BEGIN -->
                                    <style>
                                    
                                      .primary{
                                        background: #0d0cb5;
                                    }
                                    .bg_white{
                                        background: #ffffff;
                                    }
                                    .bg_light{
                                        background: #fafafa;
                                    }
                                    .bg_black{
                                        background: #000000;
                                    }
                                    .bg_dark{
                                        background: rgba(0,0,0,.8);
                                    }
                                    .email-section{
                                        padding:2.5em;
                                    }
                                    
                                    /*BUTTON*/
                                    .btn{
                                        padding: 5px 15px;
                                        display: inline-block;
                                    }
                                    .btn.btn-primary{
                                        border-radius: 5px;
                                        background: #0d0cb5;
                                        color: #ffffff;
                                    }
                                    .btn.btn-white{
                                        border-radius: 5px;
                                        background: #ffffff;
                                        color: #000000;
                                    }
                                    .btn.btn-white-outline{
                                        border-radius: 5px;
                                        background: transparent;
                                        border: 1px solid #fff;
                                        color: #fff;
                                    }
                                    
                                    h1,h2,h3,h4,h5,h6{
                                        font-family: 'Poppins', sans-serif;
                                        color: #000000;
                                        margin-top: 0;
                                    }
                                    
                                    body{
                                        font-family: 'Poppins', sans-serif;
                                        font-weight: 400;
                                        font-size: 15px;
                                        line-height: 1.8;
                                        color: rgba(0,0,0,.4);
                                    }
                                    
                                    a{
                                        color: #0d0cb5;
                                    }
                                    
                                    table{
                                    }
                                    /*LOGO*/
                                    
                                    .logo h1{
                                        margin: 0;
                                    }
                                    .logo h1 a{
                                        color: #000000;
                                        font-size: 20px;
                                        font-weight: 700;
                                        text-transform: uppercase;
                                        font-family: 'Poppins', sans-serif;
                                    }
                                    
                                    .navigation{
                                        padding: 0;
                                    }
                                    .navigation li{
                                        list-style: none;
                                        display: inline-block;;
                                        margin-left: 5px;
                                        font-size: 13px;
                                        font-weight: 500;
                                    }
                                    .navigation li a{
                                        color: rgba(0,0,0,.4);
                                    }
                                    
                                    /*HERO*/
                                    .hero{
                                        position: relative;
                                        z-index: 0;
                                    }
                                    .hero .overlay{
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        content: '';
                                        width: 100%;
                                        background: #000000;
                                        z-index: -1;
                                        opacity: .3;
                                    }
                                    .hero .icon{
                                    }
                                    .hero .icon a{
                                        display: block;
                                        width: 60px;
                                        margin: 0 auto;
                                    }
                                    .hero .text{
                                        color: rgba(255,255,255,.8);
                                    }
                                    .hero .text h2{
                                        color: #ffffff;
                                        font-size: 30px;
                                        margin-bottom: 0;
                                    }
                                    
                                    
                                    /*HEADING SECTION*/
                                    .heading-section{
                                    }
                                    .heading-section h2{
                                        color: #000000;
                                        font-size: 20px;
                                        margin-top: 0;
                                        line-height: 1.4;
                                        font-weight: 700;
                                        text-transform: uppercase;
                                    }
                                    .heading-section .subheading{
                                        margin-bottom: 20px !important;
                                        display: inline-block;
                                        font-size: 13px;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        color: rgba(0,0,0,.4);
                                        position: relative;
                                    }
                                    .heading-section .subheading::after{
                                        position: absolute;
                                        left: 0;
                                        right: 0;
                                        bottom: -10px;
                                        content: '';
                                        width: 100%;
                                        height: 2px;
                                        background: #0d0cb5;
                                        margin: 0 auto;
                                    }
                                    
                                    .heading-section-white{
                                        color: rgba(255,255,255,.8);
                                    }
                                    .heading-section-white h2{
                                        font-family: 
                                        line-height: 1;
                                        padding-bottom: 0;
                                    }
                                    .heading-section-white h2{
                                        color: #ffffff;
                                    }
                                    .heading-section-white .subheading{
                                        margin-bottom: 0;
                                        display: inline-block;
                                        font-size: 13px;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        color: rgba(255,255,255,.4);
                                    }
                                    
                                    
                                    .icon{
                                        text-align: center;
                                    }
                                    .icon img{
                                    }
                                    
                                    
                                    /*SERVICES*/
                                    .services{
                                        background: rgba(0,0,0,.03);
                                    }
                                    .text-services{
                                        padding: 10px 10px 0; 
                                        text-align: center;
                                    }
                                    .text-services h3{
                                        font-size: 16px;
                                        font-weight: 600;
                                    }
                                    
                                    .services-list{
                                        padding: 0;
                                        margin: 0 0 20px 0;
                                        width: 100%;
                                        float: left;
                                    }
                                    
                                    .services-list img{
                                        float: left;
                                    }
                                    .services-list .text{
                                        width: calc(100% - 60px);
                                        float: right;
                                    }
                                    .services-list h3{
                                        margin-top: 0;
                                        margin-bottom: 0;
                                    }
                                    .services-list p{
                                        margin: 0;
                                    }
                                    
                                    /*BLOG*/
                                    .text-services .meta{
                                        text-transform: uppercase;
                                        font-size: 14px;
                                    }
                                    
                                    /*TESTIMONY*/
                                    .text-testimony .name{
                                        margin: 0;
                                    }
                                    .text-testimony .position{
                                        color: rgba(0,0,0,.3);
                                    
                                    }
                                    
                                    
                                    /*VIDEO*/
                                    .img{
                                        width: 100%;
                                        height: auto;
                                        position: relative;
                                    }
                                    .img .icon{
                                        position: absolute;
                                        top: 50%;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        margin-top: -25px;
                                    }
                                    .img .icon a{
                                        display: block;
                                        width: 60px;
                                        position: absolute;
                                        top: 0;
                                        left: 50%;
                                        margin-left: -25px;
                                    }
                                    
                                    
                                    
                                    /*COUNTER*/
                                    .counter{
                                        width: 100%;
                                        position: relative;
                                        z-index: 0;
                                    }
                                    .counter .overlay{
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        content: '';
                                        width: 100%;
                                        background: #000000;
                                        z-index: -1;
                                        opacity: .3;
                                    }
                                    .counter-text{
                                        text-align: center;
                                    }
                                    .counter-text .num{
                                        display: block;
                                        color: #ffffff;
                                        font-size: 34px;
                                        font-weight: 700;
                                    }
                                    .counter-text .name{
                                        display: block;
                                        color: rgba(255,255,255,.9);
                                        font-size: 13px;
                                    }
                                    
                                    
                                    /*FOOTER*/
                                    
                                    .footer{
                                        color: rgba(255,255,255,.5);
                                    
                                    }
                                    .footer .heading{
                                        color: #ffffff;
                                        font-size: 20px;
                                    }
                                    .footer ul{
                                        margin: 0;
                                        padding: 0;
                                    }
                                    .footer ul li{
                                        list-style: none;
                                        margin-bottom: 10px;
                                    }
                                    .footer ul li a{
                                        color: rgba(255,255,255,1);
                                    }
                                    
                                    
                                    @media screen and (max-width: 500px) {
                                    
                                        .icon{
                                            text-align: left;
                                        }
                                    
                                        .text-services{
                                            padding-left: 0;
                                            padding-right: 20px;
                                            text-align: left;
                                        }
                                    
                                    }
                                    </style>
                                    
                                    
                                    </head>
                                    
                                    <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
                                        <center style="width: 100%; background-color: #f1f1f1;">
                                        
                                        <div style="max-width: 600px; margin: 0 auto;" class="email-container">
                                            <!-- BEGIN BODY -->
                                          <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
                                              <tr>
                                              <td valign="top" class="bg_white">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                                                      
                                                      <tr style="background: #234e70">
                                                          <td>
                                                              <h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 500;color:#fff;">`+req.body.name+` would like to talk to you</h1>
                                                          </td>
                                                      </tr>
                                                      
                                                  </table>
                                              </td>
                                            </tr><!-- end tr -->
                                    
                                            <tr>
                                              <td valign="top" class="bg_white" style="padding-top: 15px">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      <tr >
                                                          <td style="padding:10px">
                                                              <h2 style="margin-bottom: 0">Hello `+sellerInfo[x].name+`</h2><br>
                                                              <p style="margin: 0px;font-weight:500">We have recieved an interest from our user:</p>
                                                        </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                          <tr>
                                              <td valign="top" class="bg_white" style="font-weight:600;color:#234E70;">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Name: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                         `+req.body.name+`
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Email: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                            `+req.body.email+`
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Mobile: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                         `+req.body.mobile+`
                                                         </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                    
                                    
                                              <tr>
                                              <td valign="top" class="bg_white">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      
                                                      <tr>
                                                          <td style="padding: 10px">
                                                               <span style="font-weight: 600;padding-left:5px;">Who would like to talk to you regarding residential project <b style="color:#234E70;">`+projects_names+`</b></span>
                                                              </p>
                                                         </td>
                                                      </tr>
                                                      
                                                  </table>
                                              </td>
                                            </tr><!-- end tr -->
                                    
                                    
                                            
                                    
                                         
                                          <!-- 1 Column Text + Button : END -->
                                          </table>
                                        
                                    
                                        </div>
                                      </center>
                                    </body>
                                    </html>`
                                    fun.nodemailer(sellerInfo[x].email,'Housiey',msg);
                                    fun.nodemailer('enquiry.housiey@gmail.com','Housiey',msg);
                                }
                            }

                           
                            let msg = `<!DOCTYPE html>
                                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
                                    <head>
                                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                                        <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
                                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                                        <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
                                        <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                                    
                                        <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
                                    
                                        <!-- CSS Reset : BEGIN -->
                                    <style>
                                    html,
                                    body {
                                        margin: 0 auto !important;
                                        padding: 0 !important;
                                        height: 100% !important;
                                        width: 100% !important;
                                        background: #f1f1f1;
                                    }
                                    
                                    /* What it does: Stops email clients resizing small text. */
                                    * {
                                        -ms-text-size-adjust: 100%;
                                        -webkit-text-size-adjust: 100%;
                                    }
                                    
                                    /* What it does: Centers email on Android 4.4 */
                                    div[style*="margin: 16px 0"] {
                                        margin: 0 !important;
                                    }
                                    
                                    /* What it does: Stops Outlook from adding extra spacing to tables. */
                                    table,
                                    td {
                                        mso-table-lspace: 0pt !important;
                                        mso-table-rspace: 0pt !important;
                                    }
                                    
                                    /* What it does: Fixes webkit padding issue. */
                                    table {
                                        border-spacing: 0 !important;
                                        border-collapse: collapse !important;
                                        table-layout: fixed !important;
                                        margin: 0 auto !important;
                                    }
                                    
                                    /* What it does: Uses a better rendering method when resizing images in IE. */
                                    img {
                                        -ms-interpolation-mode:bicubic;
                                    }
                                    
                                    /* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
                                    a {
                                        text-decoration: none;
                                    }
                                    
                                    /* What it does: A work-around for email clients meddling in triggered links. */
                                    *[x-apple-data-detectors],  /* iOS */
                                    .unstyle-auto-detected-links *,
                                    .aBn {
                                        border-bottom: 0 !important;
                                        cursor: default !important;
                                        color: inherit !important;
                                        text-decoration: none !important;
                                        font-size: inherit !important;
                                        font-family: inherit !important;
                                        font-weight: inherit !important;
                                        line-height: inherit !important;
                                    }
                                    
                                    /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
                                    .a6S {
                                        display: none !important;
                                        opacity: 0.01 !important;
                                    }
                                    
                                    /* What it does: Prevents Gmail from changing the text color in conversation threads. */
                                    .im {
                                        color: inherit !important;
                                    }
                                    
                                    /* If the above doesn't work, add a .g-img class to any image in question. */
                                    img.g-img + div {
                                        display: none !important;
                                    }
                                    
                                    /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
                                    /* Create one of these media queries for each additional viewport size you'd like to fix */
                                    
                                    /* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
                                    @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
                                        u ~ div .email-container {
                                            min-width: 320px !important;
                                        }
                                    }
                                    /* iPhone 6, 6S, 7, 8, and X */
                                    @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
                                        u ~ div .email-container {
                                            min-width: 375px !important;
                                        }
                                    }
                                    /* iPhone 6+, 7+, and 8+ */
                                    @media only screen and (min-device-width: 414px) {
                                        u ~ div .email-container {
                                            min-width: 414px !important;
                                        }
                                    }
                                    
                                    </style>
                                    
                                    <!-- CSS Reset : END -->
                                    
                                    <!-- Progressive Enhancements : BEGIN -->
                                    <style>
                                    
                                      .primary{
                                        background: #0d0cb5;
                                    }
                                    .bg_white{
                                        background: #ffffff;
                                    }
                                    .bg_light{
                                        background: #fafafa;
                                    }
                                    .bg_black{
                                        background: #000000;
                                    }
                                    .bg_dark{
                                        background: rgba(0,0,0,.8);
                                    }
                                    .email-section{
                                        padding:2.5em;
                                    }
                                    
                                    /*BUTTON*/
                                    .btn{
                                        padding: 5px 15px;
                                        display: inline-block;
                                    }
                                    .btn.btn-primary{
                                        border-radius: 5px;
                                        background: #0d0cb5;
                                        color: #ffffff;
                                    }
                                    .btn.btn-white{
                                        border-radius: 5px;
                                        background: #ffffff;
                                        color: #000000;
                                    }
                                    .btn.btn-white-outline{
                                        border-radius: 5px;
                                        background: transparent;
                                        border: 1px solid #fff;
                                        color: #fff;
                                    }
                                    
                                    h1,h2,h3,h4,h5,h6{
                                        font-family: 'Poppins', sans-serif;
                                        color: #000000;
                                        margin-top: 0;
                                    }
                                    
                                    body{
                                        font-family: 'Poppins', sans-serif;
                                        font-weight: 400;
                                        font-size: 15px;
                                        line-height: 1.8;
                                        color: rgba(0,0,0,.4);
                                    }
                                    
                                    a{
                                        color: #0d0cb5;
                                    }
                                    
                                    table{
                                    }
                                    /*LOGO*/
                                    
                                    .logo h1{
                                        margin: 0;
                                    }
                                    .logo h1 a{
                                        color: #000000;
                                        font-size: 20px;
                                        font-weight: 700;
                                        text-transform: uppercase;
                                        font-family: 'Poppins', sans-serif;
                                    }
                                    
                                    .navigation{
                                        padding: 0;
                                    }
                                    .navigation li{
                                        list-style: none;
                                        display: inline-block;;
                                        margin-left: 5px;
                                        font-size: 13px;
                                        font-weight: 500;
                                    }
                                    .navigation li a{
                                        color: rgba(0,0,0,.4);
                                    }
                                    
                                    /*HERO*/
                                    .hero{
                                        position: relative;
                                        z-index: 0;
                                    }
                                    .hero .overlay{
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        content: '';
                                        width: 100%;
                                        background: #000000;
                                        z-index: -1;
                                        opacity: .3;
                                    }
                                    .hero .icon{
                                    }
                                    .hero .icon a{
                                        display: block;
                                        width: 60px;
                                        margin: 0 auto;
                                    }
                                    .hero .text{
                                        color: rgba(255,255,255,.8);
                                    }
                                    .hero .text h2{
                                        color: #ffffff;
                                        font-size: 30px;
                                        margin-bottom: 0;
                                    }
                                    
                                    
                                    /*HEADING SECTION*/
                                    .heading-section{
                                    }
                                    .heading-section h2{
                                        color: #000000;
                                        font-size: 20px;
                                        margin-top: 0;
                                        line-height: 1.4;
                                        font-weight: 700;
                                        text-transform: uppercase;
                                    }
                                    .heading-section .subheading{
                                        margin-bottom: 20px !important;
                                        display: inline-block;
                                        font-size: 13px;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        color: rgba(0,0,0,.4);
                                        position: relative;
                                    }
                                    .heading-section .subheading::after{
                                        position: absolute;
                                        left: 0;
                                        right: 0;
                                        bottom: -10px;
                                        content: '';
                                        width: 100%;
                                        height: 2px;
                                        background: #0d0cb5;
                                        margin: 0 auto;
                                    }
                                    
                                    .heading-section-white{
                                        color: rgba(255,255,255,.8);
                                    }
                                    .heading-section-white h2{
                                        font-family: 
                                        line-height: 1;
                                        padding-bottom: 0;
                                    }
                                    .heading-section-white h2{
                                        color: #ffffff;
                                    }
                                    .heading-section-white .subheading{
                                        margin-bottom: 0;
                                        display: inline-block;
                                        font-size: 13px;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        color: rgba(255,255,255,.4);
                                    }
                                    
                                    
                                    .icon{
                                        text-align: center;
                                    }
                                    .icon img{
                                    }
                                    
                                    
                                    /*SERVICES*/
                                    .services{
                                        background: rgba(0,0,0,.03);
                                    }
                                    .text-services{
                                        padding: 10px 10px 0; 
                                        text-align: center;
                                    }
                                    .text-services h3{
                                        font-size: 16px;
                                        font-weight: 600;
                                    }
                                    
                                    .services-list{
                                        padding: 0;
                                        margin: 0 0 20px 0;
                                        width: 100%;
                                        float: left;
                                    }
                                    
                                    .services-list img{
                                        float: left;
                                    }
                                    .services-list .text{
                                        width: calc(100% - 60px);
                                        float: right;
                                    }
                                    .services-list h3{
                                        margin-top: 0;
                                        margin-bottom: 0;
                                    }
                                    .services-list p{
                                        margin: 0;
                                    }
                                    
                                    /*BLOG*/
                                    .text-services .meta{
                                        text-transform: uppercase;
                                        font-size: 14px;
                                    }
                                    
                                    /*TESTIMONY*/
                                    .text-testimony .name{
                                        margin: 0;
                                    }
                                    .text-testimony .position{
                                        color: rgba(0,0,0,.3);
                                    
                                    }
                                    
                                    
                                    /*VIDEO*/
                                    .img{
                                        width: 100%;
                                        height: auto;
                                        position: relative;
                                    }
                                    .img .icon{
                                        position: absolute;
                                        top: 50%;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        margin-top: -25px;
                                    }
                                    .img .icon a{
                                        display: block;
                                        width: 60px;
                                        position: absolute;
                                        top: 0;
                                        left: 50%;
                                        margin-left: -25px;
                                    }
                                    
                                    
                                    
                                    /*COUNTER*/
                                    .counter{
                                        width: 100%;
                                        position: relative;
                                        z-index: 0;
                                    }
                                    .counter .overlay{
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        content: '';
                                        width: 100%;
                                        background: #000000;
                                        z-index: -1;
                                        opacity: .3;
                                    }
                                    .counter-text{
                                        text-align: center;
                                    }
                                    .counter-text .num{
                                        display: block;
                                        color: #ffffff;
                                        font-size: 34px;
                                        font-weight: 700;
                                    }
                                    .counter-text .name{
                                        display: block;
                                        color: rgba(255,255,255,.9);
                                        font-size: 13px;
                                    }
                                    
                                    
                                    /*FOOTER*/
                                    
                                    .footer{
                                        color: rgba(255,255,255,.5);
                                    
                                    }
                                    .footer .heading{
                                        color: #ffffff;
                                        font-size: 20px;
                                    }
                                    .footer ul{
                                        margin: 0;
                                        padding: 0;
                                    }
                                    .footer ul li{
                                        list-style: none;
                                        margin-bottom: 10px;
                                    }
                                    .footer ul li a{
                                        color: rgba(255,255,255,1);
                                    }
                                    
                                    
                                    @media screen and (max-width: 500px) {
                                    
                                        .icon{
                                            text-align: left;
                                        }
                                    
                                        .text-services{
                                            padding-left: 0;
                                            padding-right: 20px;
                                            text-align: left;
                                        }
                                    
                                    }
                                    </style>
                                    
                                    
                                    </head>
                                    
                                    <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
                                        <center style="width: 100%; background-color: #f1f1f1;">
                                        
                                        <div style="max-width: 600px; margin: 0 auto;" class="email-container">
                                            <!-- BEGIN BODY -->
                                          <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
                                              <tr>
                                              <td valign="top" class="bg_white">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                                                      
                                                      <tr style="background: #234e70">
                                                          <td>
                                                              <h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 500;color:#fff;">`+req.body.name+` would like to talk to you</h1>
                                                          </td>
                                                      </tr>
                                                      
                                                  </table>
                                              </td>
                                            </tr><!-- end tr -->
                                    
                                            <tr>
                                              <td valign="top" class="bg_white" style="padding-top: 15px">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      <tr >
                                                          <td style="padding:10px">
                                                              <h2 style="margin-bottom: 0">Hello Ronak Pandya</h2><br>
                                                              <p style="margin: 0px;font-weight:500">We have recieved an interest from our user:</p>
                                                        </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                          <tr>
                                              <td valign="top" class="bg_white" style="font-weight:600;color:#234E70;">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Name: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                         `+req.body.name+`
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Email: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                            `+req.body.email+`
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Mobile: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                         `+req.body.mobile+`
                                                         </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                          <!-- 1 Column Text + Button : END -->
                                          </table>
                                        
                                    
                                        </div>
                                      </center>
                                    </body>
                                    </html>`
                            fun.nodemailer('housiey.inquiry@gmail.com','Housiey',msg);
                        }
                        if(req.body.page_type=='details'){
                            let projects = await db.query("SELECT project_name,seller_id FROM `projects` WHERE id IN("+req.body.project_id+")");
                            projects_names = projects[0].project_name
                            let sellers_ids = []
                            if(projects[0].seller_id){
                                var getsellers = projects[0].seller_id.split(',')
                                for (let j = 0; j < getsellers.length; j++) {
                                    sellers_ids.push(getsellers[j])
                                }
                            }
                            sellerInfo = await db.query("SELECT email,phone,name FROM sellers WHERE  seller_id IN("+sellers_ids+")",false);
                            // to seller
                            if(send_msgs){
                                for (let l = 0; l < sellerInfo.length; l++) {
                                    const element = sellerInfo[l];
                                    let msg = "Hello "+element.name+", Client - "+req.body.name+" - "+mobile+" has enquired for "+projects_names+", Kindly connect with the client. Cheers Housiey.com"
                                    requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+element.mobile+'&dlttempid=1707164854056403600&message='+msg, false)
                                    .on('data', function (chunk) {
                                    console.log(chunk)
                                    })
                                    .on('end', function (err) {
                                        if (err) console.log('connection closed due to errors', err);
                                        console.log('end');
                                    });
                                }
                            }
                            for (let x = 0; x < sellerInfo.length; x++) {
                                if(sellerInfo[x].email){
                                    let msg = `<!DOCTYPE html>
                                    <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
                                    <head>
                                        <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                                        <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
                                        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                                        <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
                                        <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                                    
                                        <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
                                    
                                        <!-- CSS Reset : BEGIN -->
                                    <style>
                                    html,
                                    body {
                                        margin: 0 auto !important;
                                        padding: 0 !important;
                                        height: 100% !important;
                                        width: 100% !important;
                                        background: #f1f1f1;
                                    }
                                    
                                    /* What it does: Stops email clients resizing small text. */
                                    * {
                                        -ms-text-size-adjust: 100%;
                                        -webkit-text-size-adjust: 100%;
                                    }
                                    
                                    /* What it does: Centers email on Android 4.4 */
                                    div[style*="margin: 16px 0"] {
                                        margin: 0 !important;
                                    }
                                    
                                    /* What it does: Stops Outlook from adding extra spacing to tables. */
                                    table,
                                    td {
                                        mso-table-lspace: 0pt !important;
                                        mso-table-rspace: 0pt !important;
                                    }
                                    
                                    /* What it does: Fixes webkit padding issue. */
                                    table {
                                        border-spacing: 0 !important;
                                        border-collapse: collapse !important;
                                        table-layout: fixed !important;
                                        margin: 0 auto !important;
                                    }
                                    
                                    /* What it does: Uses a better rendering method when resizing images in IE. */
                                    img {
                                        -ms-interpolation-mode:bicubic;
                                    }
                                    
                                    /* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
                                    a {
                                        text-decoration: none;
                                    }
                                    
                                    /* What it does: A work-around for email clients meddling in triggered links. */
                                    *[x-apple-data-detectors],  /* iOS */
                                    .unstyle-auto-detected-links *,
                                    .aBn {
                                        border-bottom: 0 !important;
                                        cursor: default !important;
                                        color: inherit !important;
                                        text-decoration: none !important;
                                        font-size: inherit !important;
                                        font-family: inherit !important;
                                        font-weight: inherit !important;
                                        line-height: inherit !important;
                                    }
                                    
                                    /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
                                    .a6S {
                                        display: none !important;
                                        opacity: 0.01 !important;
                                    }
                                    
                                    /* What it does: Prevents Gmail from changing the text color in conversation threads. */
                                    .im {
                                        color: inherit !important;
                                    }
                                    
                                    /* If the above doesn't work, add a .g-img class to any image in question. */
                                    img.g-img + div {
                                        display: none !important;
                                    }
                                    
                                    /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
                                    /* Create one of these media queries for each additional viewport size you'd like to fix */
                                    
                                    /* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
                                    @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
                                        u ~ div .email-container {
                                            min-width: 320px !important;
                                        }
                                    }
                                    /* iPhone 6, 6S, 7, 8, and X */
                                    @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
                                        u ~ div .email-container {
                                            min-width: 375px !important;
                                        }
                                    }
                                    /* iPhone 6+, 7+, and 8+ */
                                    @media only screen and (min-device-width: 414px) {
                                        u ~ div .email-container {
                                            min-width: 414px !important;
                                        }
                                    }
                                    
                                    </style>
                                    
                                    <!-- CSS Reset : END -->
                                    
                                    <!-- Progressive Enhancements : BEGIN -->
                                    <style>
                                    
                                      .primary{
                                        background: #0d0cb5;
                                    }
                                    .bg_white{
                                        background: #ffffff;
                                    }
                                    .bg_light{
                                        background: #fafafa;
                                    }
                                    .bg_black{
                                        background: #000000;
                                    }
                                    .bg_dark{
                                        background: rgba(0,0,0,.8);
                                    }
                                    .email-section{
                                        padding:2.5em;
                                    }
                                    
                                    /*BUTTON*/
                                    .btn{
                                        padding: 5px 15px;
                                        display: inline-block;
                                    }
                                    .btn.btn-primary{
                                        border-radius: 5px;
                                        background: #0d0cb5;
                                        color: #ffffff;
                                    }
                                    .btn.btn-white{
                                        border-radius: 5px;
                                        background: #ffffff;
                                        color: #000000;
                                    }
                                    .btn.btn-white-outline{
                                        border-radius: 5px;
                                        background: transparent;
                                        border: 1px solid #fff;
                                        color: #fff;
                                    }
                                    
                                    h1,h2,h3,h4,h5,h6{
                                        font-family: 'Poppins', sans-serif;
                                        color: #000000;
                                        margin-top: 0;
                                    }
                                    
                                    body{
                                        font-family: 'Poppins', sans-serif;
                                        font-weight: 400;
                                        font-size: 15px;
                                        line-height: 1.8;
                                        color: rgba(0,0,0,.4);
                                    }
                                    
                                    a{
                                        color: #0d0cb5;
                                    }
                                    
                                    table{
                                    }
                                    /*LOGO*/
                                    
                                    .logo h1{
                                        margin: 0;
                                    }
                                    .logo h1 a{
                                        color: #000000;
                                        font-size: 20px;
                                        font-weight: 700;
                                        text-transform: uppercase;
                                        font-family: 'Poppins', sans-serif;
                                    }
                                    
                                    .navigation{
                                        padding: 0;
                                    }
                                    .navigation li{
                                        list-style: none;
                                        display: inline-block;;
                                        margin-left: 5px;
                                        font-size: 13px;
                                        font-weight: 500;
                                    }
                                    .navigation li a{
                                        color: rgba(0,0,0,.4);
                                    }
                                    
                                    /*HERO*/
                                    .hero{
                                        position: relative;
                                        z-index: 0;
                                    }
                                    .hero .overlay{
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        content: '';
                                        width: 100%;
                                        background: #000000;
                                        z-index: -1;
                                        opacity: .3;
                                    }
                                    .hero .icon{
                                    }
                                    .hero .icon a{
                                        display: block;
                                        width: 60px;
                                        margin: 0 auto;
                                    }
                                    .hero .text{
                                        color: rgba(255,255,255,.8);
                                    }
                                    .hero .text h2{
                                        color: #ffffff;
                                        font-size: 30px;
                                        margin-bottom: 0;
                                    }
                                    
                                    
                                    /*HEADING SECTION*/
                                    .heading-section{
                                    }
                                    .heading-section h2{
                                        color: #000000;
                                        font-size: 20px;
                                        margin-top: 0;
                                        line-height: 1.4;
                                        font-weight: 700;
                                        text-transform: uppercase;
                                    }
                                    .heading-section .subheading{
                                        margin-bottom: 20px !important;
                                        display: inline-block;
                                        font-size: 13px;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        color: rgba(0,0,0,.4);
                                        position: relative;
                                    }
                                    .heading-section .subheading::after{
                                        position: absolute;
                                        left: 0;
                                        right: 0;
                                        bottom: -10px;
                                        content: '';
                                        width: 100%;
                                        height: 2px;
                                        background: #0d0cb5;
                                        margin: 0 auto;
                                    }
                                    
                                    .heading-section-white{
                                        color: rgba(255,255,255,.8);
                                    }
                                    .heading-section-white h2{
                                        font-family: 
                                        line-height: 1;
                                        padding-bottom: 0;
                                    }
                                    .heading-section-white h2{
                                        color: #ffffff;
                                    }
                                    .heading-section-white .subheading{
                                        margin-bottom: 0;
                                        display: inline-block;
                                        font-size: 13px;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        color: rgba(255,255,255,.4);
                                    }
                                    
                                    
                                    .icon{
                                        text-align: center;
                                    }
                                    .icon img{
                                    }
                                    
                                    
                                    /*SERVICES*/
                                    .services{
                                        background: rgba(0,0,0,.03);
                                    }
                                    .text-services{
                                        padding: 10px 10px 0; 
                                        text-align: center;
                                    }
                                    .text-services h3{
                                        font-size: 16px;
                                        font-weight: 600;
                                    }
                                    
                                    .services-list{
                                        padding: 0;
                                        margin: 0 0 20px 0;
                                        width: 100%;
                                        float: left;
                                    }
                                    
                                    .services-list img{
                                        float: left;
                                    }
                                    .services-list .text{
                                        width: calc(100% - 60px);
                                        float: right;
                                    }
                                    .services-list h3{
                                        margin-top: 0;
                                        margin-bottom: 0;
                                    }
                                    .services-list p{
                                        margin: 0;
                                    }
                                    
                                    /*BLOG*/
                                    .text-services .meta{
                                        text-transform: uppercase;
                                        font-size: 14px;
                                    }
                                    
                                    /*TESTIMONY*/
                                    .text-testimony .name{
                                        margin: 0;
                                    }
                                    .text-testimony .position{
                                        color: rgba(0,0,0,.3);
                                    
                                    }
                                    
                                    
                                    /*VIDEO*/
                                    .img{
                                        width: 100%;
                                        height: auto;
                                        position: relative;
                                    }
                                    .img .icon{
                                        position: absolute;
                                        top: 50%;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        margin-top: -25px;
                                    }
                                    .img .icon a{
                                        display: block;
                                        width: 60px;
                                        position: absolute;
                                        top: 0;
                                        left: 50%;
                                        margin-left: -25px;
                                    }
                                    
                                    
                                    
                                    /*COUNTER*/
                                    .counter{
                                        width: 100%;
                                        position: relative;
                                        z-index: 0;
                                    }
                                    .counter .overlay{
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        content: '';
                                        width: 100%;
                                        background: #000000;
                                        z-index: -1;
                                        opacity: .3;
                                    }
                                    .counter-text{
                                        text-align: center;
                                    }
                                    .counter-text .num{
                                        display: block;
                                        color: #ffffff;
                                        font-size: 34px;
                                        font-weight: 700;
                                    }
                                    .counter-text .name{
                                        display: block;
                                        color: rgba(255,255,255,.9);
                                        font-size: 13px;
                                    }
                                    
                                    
                                    /*FOOTER*/
                                    
                                    .footer{
                                        color: rgba(255,255,255,.5);
                                    
                                    }
                                    .footer .heading{
                                        color: #ffffff;
                                        font-size: 20px;
                                    }
                                    .footer ul{
                                        margin: 0;
                                        padding: 0;
                                    }
                                    .footer ul li{
                                        list-style: none;
                                        margin-bottom: 10px;
                                    }
                                    .footer ul li a{
                                        color: rgba(255,255,255,1);
                                    }
                                    
                                    
                                    @media screen and (max-width: 500px) {
                                    
                                        .icon{
                                            text-align: left;
                                        }
                                    
                                        .text-services{
                                            padding-left: 0;
                                            padding-right: 20px;
                                            text-align: left;
                                        }
                                    
                                    }
                                    </style>
                                    
                                    
                                    </head>
                                    
                                    <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
                                        <center style="width: 100%; background-color: #f1f1f1;">
                                        
                                        <div style="max-width: 600px; margin: 0 auto;" class="email-container">
                                            <!-- BEGIN BODY -->
                                          <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
                                              <tr>
                                              <td valign="top" class="bg_white">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                                                      
                                                      <tr style="background: #234e70">
                                                          <td>
                                                              <h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 500;color:#fff;">`+req.body.name+` would like to talk to you</h1>
                                                          </td>
                                                      </tr>
                                                      
                                                  </table>
                                              </td>
                                            </tr><!-- end tr -->
                                    
                                            <tr>
                                              <td valign="top" class="bg_white" style="padding-top: 15px">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      <tr >
                                                          <td style="padding:10px">
                                                              <h2 style="margin-bottom: 0">Hello `+sellerInfo[x].name+`</h2><br>
                                                              <p style="margin: 0px;font-weight:500">We have recieved an interest from our user:</p>
                                                        </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                          <tr>
                                              <td valign="top" class="bg_white" style="font-weight:600;color:#234E70;">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Name: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                         `+req.body.name+`
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Email: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                            `+req.body.email+`
                                                         </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="padding: 10px">
                                                              Mobile: 
                                                         </td>
                                                         <td style="padding: 10px">
                                                         `+req.body.mobile+`
                                                         </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                    
                                    
                                              <tr>
                                              <td valign="top" class="bg_white">
                                                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                      
                                                      <tr>
                                                          <td style="padding: 10px">
                                                               <span style="font-weight: 600;padding-left:5px;">Who would like to talk to you regarding residential project <b style="color:#234E70;">`+projects_names+`</b></span>
                                                              </p>
                                                         </td>
                                                      </tr>
                                                      
                                                  </table>
                                              </td>
                                            </tr><!-- end tr -->
                                    
                                    
                                            
                                    
                                         
                                          <!-- 1 Column Text + Button : END -->
                                          </table>
                                        
                                    
                                        </div>
                                      </center>
                                    </body>
                                    </html>`
                                    fun.nodemailer(sellerInfo[x].email,'Housiey',msg);
                                    fun.nodemailer('enquiry.housiey@gmail.com','Housiey',msg);
                                }
                            }
                        }

                      }
                      console.log('------------------------------here------------------------------');
                    res.send({"res":true,"msg":"otp verified!","token":token})
                }else{
                    res.send({"res":false,"msg":"Invalid Otp!"})
                }  
            }else{
                res.send({"res":false,"msg":"Invalid Terms!"})
            }
        } catch (error) {
            console.log(error);
        }
    },


    top_range_tabs: async (req,res)=>{
        try {
            let tabs = await db.query("SELECT range_id,city_id,(SELECT price_range from city_ranges WHERE sno = filter.range_id) as price_raneg,(SELECT min_val from city_ranges WHERE sno = filter.range_id) as min_val,(SELECT max_val from city_ranges WHERE sno = filter.range_id) as max_val FROM `filter` WHERE city_id=:city_id ORDER BY data_order asc", {"city_id":req.params.city_id}, true);
            res.send({"tabs":tabs}) 
        } catch (error) {
            console.log(error);
        }
    },
    top_range_projects: async (req,res)=>{
        try {
            let tabs = await db.query("SELECT project_ids FROM `filter` WHERE city_id=:city_id AND range_id=:range_id", {"city_id":req.params.city_id,"range_id":req.params.range_id}, true);
            let ids = []
            if(tabs.length>0){
                ids = tabs[0].project_ids.split(',')
            }
            let projects = await db.query("SELECT project_name,projects.id as p_id,slug,area_range_max,config,overall_price_range,builder_id,project_locations.locality_id, "+
            " (SELECT name from possession_type where sno = projects.possession_type) as possession, "+
            " (SELECT builder_name from builders where id = projects.builder_id) as builder, "+
            " (SELECT name from locality where locality_id = project_locations.locality_id) as location, "+
            " (SELECT  img FROM project_images WHERE project_id = projects.id AND type IN(1) ) as image "+
            " FROM `projects` "+
            " LEFT JOIN project_locations ON project_locations.project_id = projects.id "+
            " WHERE projects.id IN(:ids)", {"ids":ids}, true);
            res.send({"projects":projects}) 
        } catch (error) {
            console.log(error);
        }
    },
    top_launches_projects: async (req,res)=>{
        try {
            let getids = await db.query("SELECT project_id FROM `topnew_launches` WHERE city_id=:city_id order by ord ASC", {"city_id":req.params.city_id,"range_id":req.params.range_id}, true);
            let ids = []
            for (let index = 0; index < getids.length; index++) {
                const element = getids[index];
                ids.push(element.project_id)
            }
            let projects = await db.query("SELECT project_name,projects.id as p_id,slug,area_range_max,config,overall_price_range,builder_id,project_locations.locality_id, "+
            " (SELECT name from possession_type where sno = projects.possession_type) as possession, "+
            " (SELECT builder_name from builders where id = projects.builder_id) as builder, "+
            " (SELECT name from locality where locality_id = project_locations.locality_id) as location, "+
            " (SELECT  img FROM project_images WHERE project_id = projects.id AND type IN(1) ) as image "+
            " FROM `projects` "+
            " LEFT JOIN project_locations ON project_locations.project_id = projects.id "+
            " WHERE projects.id IN(:ids)", {"ids":ids}, true);
            res.send({"projects":projects}) 
        } catch (error) {
            console.log(error);
        }
    },
    getcities: async (req,res)=>{
        try {
            let cities = await db.query("SELECT city_id,name,default_city FROM `city` where status=1", false, true);
            res.send({"cities":cities}) 
        } catch (error) {
            console.log(error);
        }
    },
    getbuilderslogo: async (req,res)=>{
        try {
            let logos =[]
            if(req.query.city){
                logos = await db.query("SELECT id,logo FROM `builders`", false, true);
            }else{
                logos = await db.query("SELECT id,logo FROM `builders` where cities like :city", {"city":'%'+req.query.city+'%'}, true);
            }
            res.send({"logos":logos}) 
        } catch (error) {
            console.log(error);
        }
    },
    getbuilder: async (req,res)=>{
        try {
            let builder_info = await db.query("SELECT * FROM `builders` where id=:id", {"id":req.params.id}, true);
            if(builder_info.length>0){
                res.send({"res":true,"builder_info":builder_info}) 
            }else{
                res.send({"res":false,"msg":"Incorrect Builder Id!"}) 
            }
        } catch (error) {
            console.log(error);
        }
    },
    getbuilderById: async (req,res)=>{
        try {
            let getid = await db.query("SELECT name FROM `city` WHERE city_id=:city_id", {"city_id":req.params.city_id}, true);
            let cityname = (getid.length>0)?getid[0].name:'';
            let builder_info = await db.query("SELECT * FROM `builders` where cities LIKE :cityname", {"cityname":'%'+cityname+'%'}, true);
            if(builder_info.length>0){
                res.send({"res":true,"builder_info":builder_info}) 
            }else{
                res.send({"res":false,"msg":"Incorrect Builder Id!"}) 
            }
        } catch (error) {
            console.log(error);
        }
    },
    search: async (req,res)=>{
        try {
            let getids = await db.query("SELECT project_id FROM `project_locations`  WHERE city_id =:city_id",{"city_id":req.params.city_id},false)
            let getbuildersids = await db.query("SELECT id FROM `builders`  WHERE builder_name =:builder_name",{"builder_name":'%'+req.params.keyword+'%'},false)
            let ids=[]
            let builderids=[]
            if(getids.length>0){
                for (let index = 0; index < getids.length; index++) {
                    const element = getids[index];
                    ids.push(element.project_id)
                }
                for (let index1 = 0; index1 < getbuildersids.length; index1++) {
                    const element = getbuildersids[index1];
                    builderids.push(element.id)
                }
            }
            let cond1=''
            if(builderids.length>0){
                cond1+=' OR builder_id IN(:builderids)'
            }
            // let projects = await db.query("SELECT project_name,slug FROM `projects` WHERE project_name LIKE :keyword AND id IN(:ids)"+cond1, {"keyword":'%'+req.params.keyword+'%',"ids":ids,"builderids":builderids}, true);
            let projects = await db.query("SELECT projects.id,project_name,slug,(select name from locality where locality_id = project_locations.locality_id) as locality "+
            " FROM `projects` "+
            " LEFT JOIN project_locations ON project_locations.project_id = projects.id "+
            " WHERE publish_status = 1 AND project_name LIKE :keyword AND project_locations.city_id=:city_id"+cond1, {"keyword":'%'+req.params.keyword+'%',"city_id":req.params.city_id}, true);
            let locality = await db.query("SELECT locality_id,name FROM `locality` WHERE city_id=:city_id AND name LIKE :keyword ", {"keyword":'%'+req.params.keyword+'%',"city_id":req.params.city_id}, true);
            let cityname = await db.query("SELECT name FROM `city` WHERE city_id=:city_id", {"city_id":req.params.city_id}, true);
            cityname = (cityname.length>0)?cityname[0].name:''
            let builders = await db.query("SELECT id,builder_name FROM `builders` WHERE builder_name LIKE :keyword AND cities LIKE :cityname", {"keyword":'%'+req.params.keyword+'%',"cityname":'%'+cityname+'%'}, true);
            res.send({"res":true,"projects":projects,"locality":locality,"builders":builders})
        } catch (error) {
            console.log(error);
        }
    },
    getproject: async (req,res)=>{
        try {
             let project = await db.query("SELECT id,project_name,slug,project_title,project_desc,meta_tags,about,land_parcel,no_of_towers,no_of_floors,config,target_possession,rera_possession,area_range_min,area_range_max,saving_amt,overall_price_range,offer,builder_id,seller_id "+
            " ,(SELECT builder_name from builders WHERE id = projects.builder_id) as builder_name "+
            " ,(SELECT logo from builders WHERE id = projects.builder_id) as builder_logo "+
            " ,(SELECT established_year from builders WHERE id = projects.builder_id) as builder_established_year "+
            " ,(SELECT rera_no from project_rera WHERE project_id = projects.id LIMIT 1) as rera "+
            " FROM `projects` WHERE slug=:slug AND publish_status = 1",{"slug":req.params.slug})
            let images = []
            let int_amenities = []
            let ext_amenities = []
            let pros = []
            let cons = []
            let address = ''
            let project_videos = []
            let master_plan = ''
            let floor_plan = ''
            let conigs = []
            let conigs_deatils = []
            let schemes = []
            let tour_video = ''
            let faqs = []
            let brocher = []
            let price_sheet = []
            let plan_kit = []
            let payment_schedule = []
            let location = []
            let banks = []
            let response = false;
            let similer_projects=[]
            let rera_details=[]
            let sellerInfo=[]
            if(project.length>0){
                response = true
                images = await db.query("SELECT type,img FROM `project_images` WHERE project_id=:project_id AND type IN(1,2)",{"project_id":project[0].id})
                amenityids = await db.query("SELECT amenities_id FROM `project_amenities` WHERE project_id=:project_id",{"project_id":project[0].id})
                amen_ids = []
                for (let index = 0; index < amenityids.length; index++) {
                    amen_ids.push(amenityids[index].amenities_id)
                }
                int_amenities = await db.query("SELECT name,img FROM `amenities` WHERE id IN(:amen_ids) AND type = 1",{"amen_ids":amen_ids})
                ext_amenities = await db.query("SELECT name,img FROM `amenities` WHERE id IN(:amen_ids) AND type = 2",{"amen_ids":amen_ids})
                pros = await db.query("SELECT type,tag FROM `project_pros_cons` WHERE project_id=:project_id AND type = 1",{"project_id":project[0].id})
                cons = await db.query("SELECT type,tag FROM `project_pros_cons` WHERE project_id=:project_id AND type = 2",{"project_id":project[0].id})
                address = await db.query("SELECT (SELECT name FROM locality WHERE locality_id = project_locations.locality_id) as locality,(SELECT name FROM city WHERE city_id = project_locations.city_id) as city FROM `project_locations` WHERE project_id=:project_id",{"project_id":project[0].id})
                address = (address.length>0)?address[0].locality+', '+address[0].city:''
                project_videos = await db.query("SELECT video,(select name from video_type  where sno = project_videos.type) as type FROM `project_videos` WHERE project_id=:project_id AND type != 5",{"project_id":project[0].id})
                console.log('-------------------------------------------------------------------');
                console.log(project_videos);
                master_plan = await db.query("SELECT img FROM `project_images` WHERE project_id=:project_id AND type IN(3)",{"project_id":project[0].id})
                // master_plan = (master_plan.length>0)?master_plan[0].img:''
                floor_plan = await db.query("SELECT img FROM `project_images` WHERE project_id=:project_id AND type IN(4)",{"project_id":project[0].id})
                // floor_plan = (floor_plan.length>0)?floor_plan[0].img:''
                conigs = await db.query("SELECT config_id,(SELECT name FROM `configs` WHERE id = project_configs.config_id) as config_name FROM `project_configs` where project_id=:project_id GROUP BY config_id",{"project_id":project[0].id})
                for (let index = 0; index < conigs.length; index++) {
                    const element = conigs[index];
                    conigsdeatils = await db.query("SELECT carpet_area,builtup_area,price,down_payment,parking_type,parking,unit_plan_img FROM `project_configs` WHERE project_id=:project_id AND config_id=:config_id",{"project_id":project[0].id,"config_id":element.config_id})    
                    if(conigsdeatils.length>0){
                        conigs_deatils.push(conigsdeatils);
                    }
                    
                }
                schemes = await db.query("SELECT (SELECT scheme from payment_schemes WHERE id = project_schemes.scheme_id) as scheme_name,description FROM `project_schemes` WHERE project_id = :project_id",{"project_id":project[0].id})
                Tour = await db.query("SELECT video FROM `project_videos` WHERE project_id=:project_id AND type =5",{"project_id":project[0].id})
                if(Tour.length>0){
                    tour_video = Tour[0].video
                }
                faqs = await db.query("SELECT qus,ans FROM `faqs` WHERE project_id=:project_id",{"project_id":project[0].id})
                brocher = await db.query("SELECT doc FROM `docs` WHERE project_id=:project_id AND type=1",{"project_id":project[0].id})
                brocher = (brocher.length>0)?brocher[0].doc:''
                price_sheet = await db.query("SELECT doc FROM `docs` WHERE project_id=:project_id AND type=2",{"project_id":project[0].id})
                price_sheet = (price_sheet.length>0)?price_sheet[0].doc:''
                plan_kit = await db.query("SELECT doc FROM `docs` WHERE project_id=:project_id AND type=3",{"project_id":project[0].id})
                plan_kit = (plan_kit.length>0)?plan_kit[0].doc:''
                payment_schedule = await db.query("SELECT doc FROM `docs` WHERE project_id=:project_id AND type=4",{"project_id":project[0].id})
                payment_schedule = (payment_schedule.length>0)?payment_schedule[0].doc:''
                location = await db.query("SELECT (SELECT name FROM state WHERE state_id=project_locations.state_id) as state "+
                " ,(SELECT name FROM city WHERE city_id=project_locations.city_id) as city "+
                " ,(SELECT name FROM locality WHERE locality_id=project_locations.locality_id) as locality, "+
                " street,highlights,link,lat,lng "+
                " FROM `project_locations` WHERE project_id=:project_id",{"project_id":project[0].id})
                bankIds = await db.query("SELECT bank_id FROM `project_banks` WHERE project_id=:project_id",{"project_id":project[0].id})
                bank_ids = []
                for (let index = 0; index < bankIds.length; index++) {
                    bank_ids.push(bankIds[index].bank_id)
                }
                if(bankIds.length>0){
                    banks = await db.query("SELECT name,logo FROM `banks` WHERE id IN(:bankIds)",{"bankIds":bank_ids})    
                }

                // similer project
                let getdata = await db.query("SELECT city_id,locality_id,(select MAX(price) from project_configs WHERE project_id=project_locations.project_id) as max_price, "+
                " (select MIN(price) from project_configs WHERE project_id=project_locations.project_id) as min_price "+
                " FROM `project_locations` WHERE project_id=:id",{"id":project[0].id})
                let pids=[]
                let allIds = []
                if(getdata.length>0){
                    // by city and price only
                    getPidsByCity_id = await db.query("SELECT projects.id FROM `projects` "+
                    " LEFT JOIN project_configs ON project_configs.project_id=projects.id "+
                    " LEFT JOIN project_locations ON project_locations.project_id=projects.id "+
                    " WHERE project_locations.city_id=:city_id AND project_configs.price BETWEEN :min_price AND :max_price",
                    {
                        "city_id":getdata[0].city_id,
                        "min_price":getdata[0].min_price,
                        "max_price":getdata[0].max_price,
                    });
                    for (let index = 0; index < getPidsByCity_id.length; index++) {
                        const element = getPidsByCity_id[index];
                        pids.push(element.id)
                    }
                    // by city, locality and price only
                    getPidsByCity_id_locality_id = await db.query("SELECT  projects.id FROM `projects` "+
                    " LEFT JOIN project_configs ON project_configs.project_id=projects.id "+
                    " LEFT JOIN project_locations ON project_locations.project_id=projects.id "+
                    " WHERE project_locations.city_id=:city_id AND project_locations.locality_id=:locality_id AND project_configs.price BETWEEN :min_price AND :max_price",
                    {
                        "city_id":getdata[0].city_id,
                        "locality_id":getdata[0].locality_id,
                        "min_price":getdata[0].min_price,
                        "max_price":getdata[0].max_price,
                    });
                    for (let index = 0; index < getPidsByCity_id_locality_id.length; index++) {
                        const element = getPidsByCity_id_locality_id[index];
                        pids.push(element.id)
                    }

                    allIds = [ ...new Set(pids)]  
                    allIds.pop(project[0].id)
                    let similer_projects = [];
                    if(allIds){
                        let mysql = `
                        SELECT projects.id,project_name,slug,area_range_min,area_range_max,config,overall_price_range,target_possession, "+
                         (SELECT builder_name from builders where id=projects.builder_id) as builder, 
                         (SELECT  img FROM project_images WHERE project_id = projects.id AND type IN(1) ) as images, 
                         (SELECT name from locality where locality_id = project_locations.locality_id) as location 
                         FROM projects 
                         LEFT JOIN project_locations ON project_locations.project_id=projects.id 
                         WHERE projects.id IN(${allIds}) LIMIT 5
                        `;
                        similer_projects = await db.query(mysql,false);
                    }
           
                }
                rera_details = await db.query("SELECT rera_no,rera_link FROM `project_rera` WHERE project_id=:project_id",{"project_id":project[0].id}) 
                if(project[0].seller_id){
                    sellerInfo = await db.query("SELECT * FROM sellers WHERE  seller_id IN("+project[0].seller_id.split(',')+")",false);
                }
            }
            res.send({"res":response,"project":project,"sellerInfo":sellerInfo,"images":images,"int_amenities":int_amenities,"ext_amenities":ext_amenities,"pros":pros,"cons":cons,
            "address":address,"project_videos":project_videos,"master_plan":master_plan,"floor_plan":floor_plan,"conigs":conigs,
            "conigs_deatils":conigs_deatils,"schemes":schemes,"tour_video":tour_video,"brocher":brocher,"price_sheet":price_sheet,
            "plan_kit":plan_kit,"payment_schedule":payment_schedule,"faqs":faqs,"location":location,"banks":banks,"similer_projects":similer_projects,"rera_details":rera_details})
        } catch (error) {
            res.send({status:false,res:response,project:[]})
            console.log(error);
        }
    },
    listing: async (req,res)=>{
        try {
            let cond1=''
            if(req.query.config){
                config=req.query.config.split(',')
                config=config.join('|')
                cond1+=` AND CONCAT(",", project_configs.config_id, ",") REGEXP ",(`+config+`),"`
            }
                
            let cond2=''
            if(req.query.budget){
                let budget = req.query.budget.split(',')
                cond2+=" AND project_configs.price BETWEEN "+budget[0]+" AND "+budget[1]  
            }
            let cond3=''
            if(req.query.scheme_id){
                scheme_id=req.query.scheme_id.split(',')
                scheme_id=scheme_id.join('|')
                cond3+=` AND CONCAT(",", project_schemes.scheme_id, ",") REGEXP ",(`+scheme_id+`),"`
            }
            let cond4=''
            if(req.query.possession_type){
                possession_type=req.query.possession_type.split(',')
                possession_type=possession_type.join('|')
                cond4+=` AND CONCAT(",", possession_type.sno, ",") REGEXP ",(`+possession_type+`),"`
            }
            let cond5=''
            let location_details = []
            if(req.query.city_id){
                cond5+=" AND project_locations.city_id="+req.query.city_id
                location_details = await db.query("SELECT name,description FROM `city` WHERE city_id = :city_id ",{"city_id":req.query.city_id})
            }
            let cond6=''
            let locality_join = "";
            if(req.query.locality_id){
                locality_join = " LEFT JOIN locality ON locality.locality_id = project_locations.locality_id ";
                // cond6+=" AND project_locations.locality_id="+req.query.locality_id
                cond6+=" AND locality.name='"+req.query.locality_id+"'"
                location_details = await db.query("SELECT name,description FROM `locality` WHERE name= :name ",{"name":req.query.locality_id})
            }
            let cond7=''
            let builder_join = "";
            let builder_details = []
            if(req.query.builder_id){
                // builder_id=req.query.builder_id.split(',')
                // builder_id=builder_id.join('|')
                // cond7+=` AND CONCAT(",", builders.builder_name, ",") REGEXP ",(`+builder_id+`),"`
                builder_join = " LEFT JOIN builders ON builders.id = projects.builder_id ";
                cond7+=` AND builders.builder_name = '`+req.query.builder_id+`'`
                builder_details = await db.query("SELECT id,builder_name,logo,description FROM builders where builder_name = :builder_name",{"builder_name":req.query.builder_id})
            }
            let cond8=''
            if(req.query.downPayment){
                let down_payment = req.query.downPayment
                cond8+=" AND project_configs.down_payment BETWEEN 0 AND "+down_payment
            }

            let cond9=''
            if(req.query.size){
                let size = req.query.size.split(',')
                cond9+=" AND project_configs.carpet_area BETWEEN "+size[0]+" AND "+size[1] 
            }

            let cond10=''
            if(req.query.offer){
                cond10+= (req.query.offer==1)?" AND offer IS NOT NULL AND offer != ''":""
            }

            let cond11=' ORDER BY projects.top_launches_status DESC '
            // let cond11='  '
            if(req.query.order_by_price){
                cond11 =" ORDER BY min_price  "+req.query.order_by_price
            }

             let start=0
             let limit=10
            if(req.query.start){
                start=req.query.start
            }
            let limit_cond =" LIMIT "+start+","+limit

        let ToalProjects = await db.query("SELECT projects.id "+
        " FROM `projects` "+
        " LEFT JOIN project_locations ON project_locations.project_id = projects.id "+
        " LEFT JOIN possession_type ON possession_type.sno = projects.possession_type "+
        " LEFT JOIN project_configs ON project_configs.project_id = projects.id "+
        " LEFT JOIN project_schemes ON project_schemes.project_id = projects.id "+
        builder_join+
        locality_join+
        " where projects.publish_status=1"+
        cond1+cond2+cond3+cond4+cond5+cond6+cond7+cond8+cond9+cond10+
        " GROUP BY projects.id "
        , false, true);
        ToalProjects=ToalProjects.length
        let projects = await db.query("SELECT projects.id,project_name,slug,area_range_min,area_range_max,config,overall_price_range,saving_amt,offer,publish_datetime,target_possession,rera_possession,top_launches_status, "+
            " (SELECT COUNT(video) FROM project_videos WHERE project_id = projects.id AND type=5) as video_three_sixty , "+
            " (SELECT COUNT(video) FROM project_videos WHERE project_id = projects.id AND type!=5 AND video!='') as video, "+
            " (SELECT name from possession_type where sno = projects.possession_type) as possession, "+
            " (SELECT name from locality where locality_id = project_locations.locality_id) as location,project_locations.locality_id, "+
            " (SELECT  img FROM project_images WHERE project_id = projects.id AND type IN(1) ) as images, "+
            " (SELECT  MIN(price) FROM project_configs WHERE project_id = projects.id) as min_price, "+
            "  (SELECT  CONCAT( "+
            "      '[', "+
            "    GROUP_CONCAT( "+
            "      JSON_OBJECT( "+
            "        'id', id, "+
            "        'builder_name', builder_name "+
            "        )  "+
            "     ), "+
            "    ']'  "+
            "  ) AS builder FROM builders WHERE id = projects.builder_id) as builder, "+
            "  (SELECT  CONCAT( "+
            "      '[', "+
            "    GROUP_CONCAT( "+
            "      JSON_OBJECT( "+
            "        'config', (SELECT name FROM configs WHERE id=project_configs.config_id), "+
            "        'area', carpet_area, "+
            "         'price', price "+
            "        )  "+
            "     ), "+
            "    ']'  "+
            "  ) AS list FROM project_configs WHERE project_id = projects.id) as configs, "+
            "  (SELECT  CONCAT( "+
            "      '[', "+
            "    GROUP_CONCAT( "+
            "      JSON_OBJECT( "+
            "        'name', name, "+
            "         'phone', phone "+
            "        )  "+
            "     ), "+
            "    ']'  "+
            "  ) AS list FROM sellers WHERE seller_id In (projects.seller_id)) as sellers_info "+
            " FROM `projects` "+
            " LEFT JOIN project_locations ON project_locations.project_id = projects.id "+
            " LEFT JOIN possession_type ON possession_type.sno = projects.possession_type "+
            " LEFT JOIN project_configs ON project_configs.project_id = projects.id "+
            " LEFT JOIN project_schemes ON project_schemes.project_id = projects.id "+
            builder_join+
            locality_join+
            " where projects.publish_status=1"+
            cond1+cond2+cond3+cond4+cond5+cond6+cond7+cond8+cond9+cond10+
            " GROUP BY projects.id "+cond11
            , false, true);


            let city='',locality='';

            if(req.query.city_id!=null && req.query.city_id!=undefined && req.query.city_id!=''){
            city = await db.query(`select name from city where city_id = ${req.query.city_id}`)
            city = city[0].name;
            }
            
            if(req.query.locality_id!=null && req.query.locality_id!=undefined && req.query.locality_id!=''){
            locality = await db.query(`select name from locality where name = "${req.query.locality_id}"`)
            locality = locality[0].name;
            }

            let url = 'https://dst.com/in/'
            if(city.length>0){
                 url +=city;
            }

            if(locality.length>0){
                url+='/'+locality;
            }

            url+='/projects';
            let metaData = await db.query(`select * from urlmeta_tbl where url = "${url}" `);
            
            metaData = metaData[0];

            if(metaData == undefined){
                metaData={};
            }

            res.send({"res":true,"projects":projects,"location_details":location_details,"builder_details":builder_details,"ToalProjects":ToalProjects, "metaData":metaData});

            // res.send({"res":true,"projects":projects,"location_details":location_details,"builder_details":builder_details,"ToalProjects":ToalProjects})
        } catch (error) {
            console.log(error);
        }
    },

    getMeta: async(req,res)=>{
        try {

            let city='',locality='';

            if(req.query.city_id!=null && req.query.city_id!=undefined && req.query.city_id!=''){
            city = await db.query(`select name from city where name = "${req.query.city_id}"`)
            city = city[0].name;
            }
            
            if(req.query.locality_id!=null && req.query.locality_id!=undefined && req.query.locality_id!=''){
            locality = await db.query(`select name from locality where  name = "${req.query.locality_id}"`)
            locality = locality[0].name;
            }

            let url = 'https://dst.com/in/'
            if(city.length>0){
                 url +=city;
            }

            if(locality.length>0){
                url+='/'+locality;
            }

            url+='/projects';
            let metaData = await db.query(`select * from urlmeta_tbl where url = "${url}" `);
            
            metaData = metaData[0];

            console.log("hereeeeeee")
            console.log(metaData);

            if(metaData == undefined){
                metaData={};
            }



            res.send({"metaData":metaData});

            
        } catch (error) {
            console.log(error)
        }
    },

    listingNew : async (req,res)=>{

        try {
            let cond1 = '';
            if(req.query.config){
                config=req.query.config.split(',')
                config=config.join('|')
                cond1+=` AND CONCAT(",", project_configs.config_id, ",") REGEXP ",(`+config+`),"`
            }
            
            if(req.query.flat){
                let flat=req.query.flat.split(',')
                flat=flat.join('|')
                cond1+=` AND CONCAT(",", projects.config, ",") REGEXP ",(`+flat+`),"`
            }

            let cond2='';
            // req.query.budget
            if(req.query.budget){
                let budget = req.query.budget.split(',');
                if(budget.length > 1 && budget[0]!=budget[1] ){
                    cond2+=" AND project_configs.price BETWEEN "+budget[0]+" AND "+budget[1];  
                }else{
                    cond2+=" AND project_configs.price < "+budget[0];
                }
            }

            let cond3=''
            if(req.query.scheme_id){
                scheme_id=req.query.scheme_id.split(',')
                scheme_id=scheme_id.join('|')
                cond3+=` AND CONCAT(",", project_schemes.scheme_id, ",") REGEXP ",(`+scheme_id+`),"`
            }
            let cond4=''
            if(req.query.possession_type){
                possession_type=req.query.possession_type.split(',')
                possession_type=possession_type.join('|')
                cond4+=` AND CONCAT(",", possession_type.sno, ",") REGEXP ",(`+possession_type+`),"`
            }
            let cond5=''
            let location_details = []
            if(req.query.city_id){
                cond5+=" AND project_locations.city_id="+req.query.city_id
                location_details = await db.query("SELECT name,description FROM `city` WHERE city_id = :city_id ",{"city_id":req.query.city_id})
            }
            let cond6=''
            let locality_join = "";
            if(req.query.locality_id){
                locality_join = " LEFT JOIN locality ON locality.locality_id = project_locations.locality_id ";
                // cond6+=" AND project_locations.locality_id="+req.query.locality_id
                cond6+=" AND locality.name='"+req.query.locality_id+"'"
                location_details = await db.query("SELECT name,description FROM `locality` WHERE name= :name ",{"name":req.query.locality_id})
            }
            let cond7=''
            let builder_join = "";
            let builder_details = []
            if(req.query.builder_id){
                // builder_id=req.query.builder_id.split(',')
                // builder_id=builder_id.join('|')
                // cond7+=` AND CONCAT(",", builders.builder_name, ",") REGEXP ",(`+builder_id+`),"`
                builder_join = " LEFT JOIN builders ON builders.id = projects.builder_id ";
                cond7+=` AND builders.builder_name = '`+req.query.builder_id+`'`
                builder_details = await db.query("SELECT id,builder_name,logo,description FROM builders where builder_name = :builder_name",{"builder_name":req.query.builder_id})
            }
            let cond8=''
            if(req.query.downPayment){
                let down_payment = req.query.downPayment
                cond8+=" AND project_configs.down_payment BETWEEN 0 AND "+down_payment
            }

            let cond9=''
            if(req.query.size){
                let size = req.query.size.split(',')
                cond9+=" AND project_configs.carpet_area BETWEEN "+size[0]+" AND "+size[1] 
            }

            let cond10=''
            if(req.query.offer){
                cond10+= (req.query.offer==1)?" AND offer IS NOT NULL AND offer != ''":""
            }

            let cond11=' ORDER BY projects.top_launches_status DESC ';
            // let cond11='  '
            if(req.query.order_by_price){
                cond11 =" ORDER BY min_price  "+req.query.order_by_price
            }

             let start=0
             let limit=10
            if(req.query.start){
                start=req.query.start
            }
            let limit_cond =" LIMIT "+start+","+limit

        let ToalProjects = await db.query("SELECT projects.id "+
        " FROM `projects` "+
        " LEFT JOIN project_locations ON project_locations.project_id = projects.id "+
        " LEFT JOIN possession_type ON possession_type.sno = projects.possession_type "+
        " LEFT JOIN project_configs ON project_configs.project_id = projects.id "+
        " LEFT JOIN project_schemes ON project_schemes.project_id = projects.id "+
        builder_join+
        locality_join+
        " where projects.publish_status=1"+
        cond1+cond2+cond3+cond4+cond5+cond6+cond7+cond8+cond9+cond10+
        " GROUP BY projects.id "
        , false, true);
        
        // ToalProjects=ToalProjects.length

        let projects = await db.query("SELECT projects.id,project_name,slug,area_range_min,area_range_max,config,overall_price_range,saving_amt,offer,publish_datetime,target_possession,rera_possession,top_launches_status, "+
            " (SELECT COUNT(video) FROM project_videos WHERE project_id = projects.id AND type=5) as video_three_sixty , "+
            " (SELECT COUNT(video) FROM project_videos WHERE project_id = projects.id AND type!=5 AND video!='') as video, "+
            " (SELECT name from possession_type where sno = projects.possession_type) as possession, "+
            " (SELECT name from locality where locality_id = project_locations.locality_id) as location,project_locations.locality_id, "+
            " (SELECT  img FROM project_images WHERE project_id = projects.id AND type IN(1) ) as images, "+
            " (SELECT  MIN(price) FROM project_configs WHERE project_id = projects.id) as min_price, "+
            "  (SELECT  CONCAT( "+
            "      '[', "+
            "    GROUP_CONCAT( "+
            "      JSON_OBJECT( "+
            "        'id', id, "+
            "        'builder_name', builder_name "+
            "        )  "+
            "     ), "+
            "    ']'  "+
            "  ) AS builder FROM builders WHERE id = projects.builder_id) as builder, "+
            "  (SELECT  CONCAT( "+
            "      '[', "+
            "    GROUP_CONCAT( "+
            "      JSON_OBJECT( "+
            "        'config', (SELECT name FROM configs WHERE id=project_configs.config_id), "+
            "        'area', carpet_area, "+
            "         'price', price "+
            "        )  "+
            "     ), "+
            "    ']'  "+
            "  ) AS list FROM project_configs WHERE project_id = projects.id) as configs, "+
            "  (SELECT  CONCAT( "+
            "      '[', "+
            "    GROUP_CONCAT( "+
            "      JSON_OBJECT( "+
            "        'name', name, "+
            "         'phone', phone "+
            "        )  "+
            "     ), "+
            "    ']'  "+
            "  ) AS list FROM sellers WHERE seller_id In (projects.seller_id)) as sellers_info "+
            " FROM `projects` "+
            " LEFT JOIN project_locations ON project_locations.project_id = projects.id "+
            " LEFT JOIN possession_type ON possession_type.sno = projects.possession_type "+
            " LEFT JOIN project_configs ON project_configs.project_id = projects.id "+
            " LEFT JOIN project_schemes ON project_schemes.project_id = projects.id "+
            builder_join+
            locality_join+
            " where projects.publish_status=1"+
            cond1+cond2+cond3+cond4+cond5+cond6+cond7+cond8+cond9+cond10+
            " GROUP BY projects.id "+cond11
            , false, true);
            res.send({"res":true,"projects":projects,"location_details":location_details,"builder_details":builder_details,"ToalProjects":ToalProjects})
        } catch (error) {
            console.log(error);
        }


    },
    TestAPi : async (req,res)=>{
        try{
            let sql = `SELECT CONCAT( '[', GROUP_CONCAT( 
                JSON_OBJECT ( 'config', (SELECT name FROM configs WHERE configs.id=project_configs.config_id), 'area', carpet_area, 'price', price ) 
                ), ']' ) AS list
                FROM project_configs WHERE project_id = 129 ;`;
            let ToalProjects = await db.query(sql,false,false);
            res.send({data:ToalProjects})
        }catch(e){
            res.send({status:false,msg:'This is testing from Developer'});
        }
    },
    save_enquiry: async (req,res)=>{
        try {
            let headers = req.headers
            if(!headers || !headers.auth || headers.auth==='undefined'){
            res.send({"res":false,"err":"Invalid Auth"})
            }
            let data = jwt.verify(headers.auth, token_key);


            if(data){
                let ids = req.body.project_id.split(',')
                for (let index = 0; index < ids.length; index++) {
                    const element = ids[index];
                    let save_signup_enquiry = await db.query("INSERT INTO enquiries SET userid=:userid,city_id=:city_id,project_id=:project_id,enquiry_datetime=:enquiry_datetime,source=:source,type=:type,datetime=:datetime",
                    {
                        "userid"            : data.id,
                        "city_id"           : req.body.city_id,
                        "project_id"        : element,
                        "source"            : req.body.source,
                        "type"              : req.body.type,
                        "enquiry_datetime"  : moment(req.body.enquiry_datetime).format('YYYY-MM-DD H:m:s'),
                        "datetime"          : moment().format('YYYY-MM-DD H:m:s'),
                    })
                }
				
                let query = await db.query("SELECT seller_id FROM projects WHERE id IN("+req.body.project_id.split(',')+")",false);
                let sellers_ids = []
                for (let l = 0; l < query.length; l++) {
                    const element = query[l];
                    if(element.seller_id){
                        var getsellers = element.seller_id.split(',')
                        for (let j = 0; j < getsellers.length; j++) {
                            sellers_ids.push(getsellers[j])
                        }
                    }
                }
                sellerInfo = await db.query("SELECT * FROM sellers WHERE  seller_id IN("+sellers_ids+")",false);
			
                
                   

				
				
                
                    let enq_date =  moment(req.body.enquiry_datetime).format('Do MMM YY')
                    let enq_time =  moment(req.body.enquiry_datetime).format('LT');
                    let username =  await db.query("select name,mobile,email from user_tbl where id=:id",{"id":data.id});
                    let name     =  username[0].name;
                    let email    =  req.body.email;
                    let mobile   =  req.body.mobile;
                    let projects =  await db.query("SELECT project_name,slug,(SELECT name FROM `locality` WHERE locality_id=project_locations.locality_id ) as locality,(SELECT name FROM `city` WHERE city_id=project_locations.city_id ) as city FROM `projects` LEFT JOIN project_locations ON project_locations.project_id = projects.id WHERE projects.id IN("+req.body.project_id+")");
                    projects_names = []
                    projects_details = []
                    mail_projects_details = ``
                    for (let a = 0; a < projects.length; a++) {
                        const element = projects[a];
                        projects_names.push(element.project_name)
                        projects_details.push({"name":element.project_name,"url":'/'+element.city+'/'+element.locality+'/'+element.slug})
                        mail_projects_details+=`<a href="https://dst.com/in`+'/'+element.city+'/'+element.locality+'/'+element.slug+`" style="background: #234e70;color:#fff;padding: 10px;border-radius: 50px;">`+element.project_name+`</a>`
                    }
                    projects_names = projects_names.join(',')
                    let img = ``
                    if(req.body.source=='zoom'){
                        img=`zoom.png`
                    }else if(req.body.source=='gmeet'){
                        img=`gmeet.png`
                    }else if(req.body.source=='teams'){
                        img=`teams.png`
                    }
                    
                    if(req.body.type==2){
                        let representative = sellerInfo[0].name+' - '+sellerInfo[0].phone
                        let message = 'Greetings from Housiey !!, Your Online Presentation has been scheduled for -'+projects_names+', Date - '+enq_date+', Time- '+enq_time+' on '+req.body.source+'. Meeting links will be shared soon in your email.For any queries, Kindly contact our representative '+representative+' Thanks Housiey';
                        // to user
                        if(send_msgs){
                            requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+mobile+'&dlttempid=1707164672024767506&message='+message, false)
                            .on('data', function (chunk) {
                            console.log(chunk)
                            })
                            .on('end', function (err) {
                                if (err) console.log('connection closed due to errors', err);
                                console.log('end');
                            });
                        }
                      
                        if(email){
                            fun.nodemailer(email,'Online Presentation Scheduled Successfully',`
                            <!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8"> <!-- utf-8 works for most cases -->
    <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
    <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
    <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <!-- CSS Reset : BEGIN -->
<style>
html,
body {
    margin: 0 auto !important;
    padding: 0 !important;
    height: 100% !important;
    width: 100% !important;
    background: #f1f1f1;
}

/* What it does: Stops email clients resizing small text. */
* {
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
}

/* What it does: Centers email on Android 4.4 */
div[style*="margin: 16px 0"] {
    margin: 0 !important;
}

/* What it does: Stops Outlook from adding extra spacing to tables. */
table,
td {
    mso-table-lspace: 0pt !important;
    mso-table-rspace: 0pt !important;
}

/* What it does: Fixes webkit padding issue. */
table {
    border-spacing: 0 !important;
    border-collapse: collapse !important;
    table-layout: fixed !important;
    margin: 0 auto !important;
}

/* What it does: Uses a better rendering method when resizing images in IE. */
img {
    -ms-interpolation-mode:bicubic;
}

/* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
a {
    text-decoration: none;
}

/* What it does: A work-around for email clients meddling in triggered links. */
*[x-apple-data-detectors],  /* iOS */
.unstyle-auto-detected-links *,
.aBn {
    border-bottom: 0 !important;
    cursor: default !important;
    color: inherit !important;
    text-decoration: none !important;
    font-size: inherit !important;
    font-family: inherit !important;
    font-weight: inherit !important;
    line-height: inherit !important;
}

/* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
.a6S {
    display: none !important;
    opacity: 0.01 !important;
}

/* What it does: Prevents Gmail from changing the text color in conversation threads. */
.im {
    color: inherit !important;
}

/* If the above doesn't work, add a .g-img class to any image in question. */
img.g-img + div {
    display: none !important;
}

/* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
/* Create one of these media queries for each additional viewport size you'd like to fix */

/* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
@media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
    u ~ div .email-container {
        min-width: 320px !important;
    }
}
/* iPhone 6, 6S, 7, 8, and X */
@media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
    u ~ div .email-container {
        min-width: 375px !important;
    }
}
/* iPhone 6+, 7+, and 8+ */
@media only screen and (min-device-width: 414px) {
    u ~ div .email-container {
        min-width: 414px !important;
    }
}

</style>

<!-- CSS Reset : END -->

<!-- Progressive Enhancements : BEGIN -->
<style>

  .primary{
	background: #0d0cb5;
}
.bg_white{
	background: #ffffff;
}
.bg_light{
	background: #fafafa;
}
.bg_black{
	background: #000000;
}
.bg_dark{
	background: rgba(0,0,0,.8);
}
.email-section{
	padding:2.5em;
}

/*BUTTON*/
.btn{
	padding: 5px 15px;
	display: inline-block;
}
.btn.btn-primary{
	border-radius: 5px;
	background: #0d0cb5;
	color: #ffffff;
}
.btn.btn-white{
	border-radius: 5px;
	background: #ffffff;
	color: #000000;
}
.btn.btn-white-outline{
	border-radius: 5px;
	background: transparent;
	border: 1px solid #fff;
	color: #fff;
}

h1,h2,h3,h4,h5,h6{
	font-family: 'Poppins', sans-serif;
	color: #000000;
	margin-top: 0;
}

body{
	font-family: 'Poppins', sans-serif;
	font-weight: 400;
	font-size: 15px;
	line-height: 1.8;
	color: rgba(0,0,0,.4);
}

a{
	color: #0d0cb5;
}

table{
}
/*LOGO*/

.logo h1{
	margin: 0;
}
.logo h1 a{
	color: #000000;
	font-size: 20px;
	font-weight: 700;
	text-transform: uppercase;
	font-family: 'Poppins', sans-serif;
}

.navigation{
	padding: 0;
}
.navigation li{
	list-style: none;
	display: inline-block;;
	margin-left: 5px;
	font-size: 13px;
	font-weight: 500;
}
.navigation li a{
	color: rgba(0,0,0,.4);
}

/*HERO*/
.hero{
	position: relative;
	z-index: 0;
}
.hero .overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	content: '';
	width: 100%;
	background: #000000;
	z-index: -1;
	opacity: .3;
}
.hero .icon{
}
.hero .icon a{
	display: block;
	width: 60px;
	margin: 0 auto;
}
.hero .text{
	color: rgba(255,255,255,.8);
}
.hero .text h2{
	color: #ffffff;
	font-size: 30px;
	margin-bottom: 0;
}


/*HEADING SECTION*/
.heading-section{
}
.heading-section h2{
	color: #000000;
	font-size: 20px;
	margin-top: 0;
	line-height: 1.4;
	font-weight: 700;
	text-transform: uppercase;
}
.heading-section .subheading{
	margin-bottom: 20px !important;
	display: inline-block;
	font-size: 13px;
	text-transform: uppercase;
	letter-spacing: 2px;
	color: rgba(0,0,0,.4);
	position: relative;
}
.heading-section .subheading::after{
	position: absolute;
	left: 0;
	right: 0;
	bottom: -10px;
	content: '';
	width: 100%;
	height: 2px;
	background: #0d0cb5;
	margin: 0 auto;
}

.heading-section-white{
	color: rgba(255,255,255,.8);
}
.heading-section-white h2{
	font-family: 
	line-height: 1;
	padding-bottom: 0;
}
.heading-section-white h2{
	color: #ffffff;
}
.heading-section-white .subheading{
	margin-bottom: 0;
	display: inline-block;
	font-size: 13px;
	text-transform: uppercase;
	letter-spacing: 2px;
	color: rgba(255,255,255,.4);
}


.icon{
	text-align: center;
}
.icon img{
}


/*SERVICES*/
.services{
	background: rgba(0,0,0,.03);
}
.text-services{
	padding: 10px 10px 0; 
	text-align: center;
}
.text-services h3{
	font-size: 16px;
	font-weight: 600;
}

.services-list{
	padding: 0;
	margin: 0 0 20px 0;
	width: 100%;
	float: left;
}

.services-list img{
	float: left;
}
.services-list .text{
	width: calc(100% - 60px);
	float: right;
}
.services-list h3{
	margin-top: 0;
	margin-bottom: 0;
}
.services-list p{
	margin: 0;
}

/*BLOG*/
.text-services .meta{
	text-transform: uppercase;
	font-size: 14px;
}

/*TESTIMONY*/
.text-testimony .name{
	margin: 0;
}
.text-testimony .position{
	color: rgba(0,0,0,.3);

}


/*VIDEO*/
.img{
	width: 100%;
	height: auto;
	position: relative;
}
.img .icon{
	position: absolute;
	top: 50%;
	left: 0;
	right: 0;
	bottom: 0;
	margin-top: -25px;
}
.img .icon a{
	display: block;
	width: 60px;
	position: absolute;
	top: 0;
	left: 50%;
	margin-left: -25px;
}



/*COUNTER*/
.counter{
	width: 100%;
	position: relative;
	z-index: 0;
}
.counter .overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	content: '';
	width: 100%;
	background: #000000;
	z-index: -1;
	opacity: .3;
}
.counter-text{
	text-align: center;
}
.counter-text .num{
	display: block;
	color: #ffffff;
	font-size: 34px;
	font-weight: 700;
}
.counter-text .name{
	display: block;
	color: rgba(255,255,255,.9);
	font-size: 13px;
}


/*FOOTER*/

.footer{
	color: rgba(255,255,255,.5);

}
.footer .heading{
	color: #ffffff;
	font-size: 20px;
}
.footer ul{
	margin: 0;
	padding: 0;
}
.footer ul li{
	list-style: none;
	margin-bottom: 10px;
}
.footer ul li a{
	color: rgba(255,255,255,1);
}


@media screen and (max-width: 500px) {

	.icon{
		text-align: left;
	}

	.text-services{
		padding-left: 0;
		padding-right: 20px;
		text-align: left;
	}

}
</style>


</head>

<body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
	<center style="width: 100%; background-color: #f1f1f1;">
   
    <div style="max-width: 600px; margin: 0 auto;" class="email-container">
    	<!-- BEGIN BODY -->
      <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
      	<tr>
          <td valign="top" class="bg_white">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                <tr>
          			<td class="logo" style="text-align: center;">
			            <img src="`+base_url+`admin/uploads/logo/housiey-logo2.jpg" alt="Image" class="img-fluid mb-4" style="width: 200px;">
			          </td>	
          		</tr>
          		<tr>
          			<td class="logo" style="text-align: center;">
			            <img src="`+base_url+`admin/assets/images_mail/right1.png" alt="Image" class="img-fluid mb-4">
			          </td>	
          		</tr>
          		<tr>
          			<td>
			          	<h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 500;color:#0e8744;">Online Presentation booked Successfully</h1>
			          </td>
          		</tr>
          		
          	</table>
          </td>
	    </tr><!-- end tr -->

	    <tr>
          <td valign="top" class="bg_white">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
          		<tr>
          			<td>
          				<span style="padding: 10px;font-weight: 500;">Online Presentation Booked for</span>
			          	<p style="font-size: 12px;padding: 0px 10px;font-weight: 500;color: #fff;">
			          `+mail_projects_details+`
			          	</p>
			          </td>
          		</tr>
          	</table>
          </td>
      </tr>
      <tr>
          <td valign="top" class="bg_white">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
          		<tr>
          			<td style="padding: 10px">
	      				<span style="font-weight: 500;">Date & Time</span><br>
			          	<span style="padding-left:10px;color: #234E70;"><img class="calendar" src="`+base_url+`admin/assets/images_mail/calendar.png" width="20px" style="vertical-align:sub"> `+moment(req.body.enquiry_datetime).format("h:mm a ddd, DD MMMM YYYY")+`</span>
			          	</p>
			         </td>
			         <td style="padding: 10px">
	      				<span style="font-weight: 500;">Source</span><br>
			          	<span style="padding-left:10px;color: #234E70;"><img class="calendar" src="`+base_url+`admin/assets/images_mail/`+img+`" width="20px" style="vertical-align:sub"> `+req.body.source+`</span>
			          	</p>
			         </td>
          		</tr>
          	</table>
          </td>
      </tr>


      	<tr>
          <td valign="top" class="bg_white">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
          		
          		<tr>
          			<td style="padding: 10px">
	      				 <span style="color:#234E70;padding-left:5px;"><img class="ola" src="`+base_url+`admin/assets/images_mail/bell.png" width="30px" style="vertical-align:bottom"> Meeting details will be shared 1 hr before the scheduled time</span>
			          	</p>
			         </td>
          		</tr>
          		<tr>
          			<td style="padding: 10px">
	      				 <span style="font-weight:600">For any queries, kindly contact your Housiey Relationship Manager</span><br><br>
	      				 <span style="font-weight:500;color:#234E70;"><img src="`+base_url+`admin/assets/images_mail/user.png" width="25px" style="vertical-align: sub;"> `+representative+` <a href="https://api.whatsapp.com/send?phone=91`+sellerInfo[0].phone+`&text=Hello, *`+sellerInfo[0].name+`* Need More Details about the *`+projects_names+`*" class="btn btn-chat" style="float: right;padding: 5px 10px;background: #0e8744;color: #fff;border-radius: 50px;"><i class="fab fa-whatsapp"></i> Live Chat with RM</a></span>
			          	</p>
			         </td>
          		</tr>
          	</table>
          </td>
	    </tr><!-- end tr -->


	    

	 
      <!-- 1 Column Text + Button : END -->
      </table>
    

    </div>
  </center>
</body>
</html>
                            `);
                        }

                        // to seller 
                        if(send_msgs){
                            let email = []
                            for (let x = 0; x < sellerInfo.length; x++) {
                                const element = sellerInfo[x];
                                email.push(element.email)
                                let msg = "Hello "+element.name+", Client - "+name+" - "+mobile+" has scheduled the VC for "+projects_names+", Date - "+enq_date+", Time- "+enq_time+". Preferred Platform - "+req.body.source+". Kindly connect with the client. Cheers Housiey.com"
                                requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+element.phone+'&dlttempid=1707164839205630617&message='+msg, false)
                                // requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile=917415308156&dlttempid=1707164839205630617&message='+msg, false)
                                .on('data', function (chunk) {
                                console.log(chunk)
                                })
                                .on('end', function (err) {
                                    if (err) console.log('connection closed due to errors', err);
                                    console.log('end');
                                });
                            }
                        }
                        for (let x = 0; x < sellerInfo.length; x++) {
                            if(sellerInfo[x].email){
                                let msg = `<!DOCTYPE html>
                                <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
                                <head>
                                    <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                                    <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
                                    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                                    <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
                                    <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                                
                                    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
                                
                                    <!-- CSS Reset : BEGIN -->
                                <style>
                                html,
                                body {
                                    margin: 0 auto !important;
                                    padding: 0 !important;
                                    height: 100% !important;
                                    width: 100% !important;
                                    background: #f1f1f1;
                                }
                                
                                /* What it does: Stops email clients resizing small text. */
                                * {
                                    -ms-text-size-adjust: 100%;
                                    -webkit-text-size-adjust: 100%;
                                }
                                
                                /* What it does: Centers email on Android 4.4 */
                                div[style*="margin: 16px 0"] {
                                    margin: 0 !important;
                                }
                                
                                /* What it does: Stops Outlook from adding extra spacing to tables. */
                                table,
                                td {
                                    mso-table-lspace: 0pt !important;
                                    mso-table-rspace: 0pt !important;
                                }
                                
                                /* What it does: Fixes webkit padding issue. */
                                table {
                                    border-spacing: 0 !important;
                                    border-collapse: collapse !important;
                                    table-layout: fixed !important;
                                    margin: 0 auto !important;
                                }
                                
                                /* What it does: Uses a better rendering method when resizing images in IE. */
                                img {
                                    -ms-interpolation-mode:bicubic;
                                }
                                
                                /* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
                                a {
                                    text-decoration: none;
                                }
                                
                                /* What it does: A work-around for email clients meddling in triggered links. */
                                *[x-apple-data-detectors],  /* iOS */
                                .unstyle-auto-detected-links *,
                                .aBn {
                                    border-bottom: 0 !important;
                                    cursor: default !important;
                                    color: inherit !important;
                                    text-decoration: none !important;
                                    font-size: inherit !important;
                                    font-family: inherit !important;
                                    font-weight: inherit !important;
                                    line-height: inherit !important;
                                }
                                
                                /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
                                .a6S {
                                    display: none !important;
                                    opacity: 0.01 !important;
                                }
                                
                                /* What it does: Prevents Gmail from changing the text color in conversation threads. */
                                .im {
                                    color: inherit !important;
                                }
                                
                                /* If the above doesn't work, add a .g-img class to any image in question. */
                                img.g-img + div {
                                    display: none !important;
                                }
                                
                                /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
                                /* Create one of these media queries for each additional viewport size you'd like to fix */
                                
                                /* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
                                @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
                                    u ~ div .email-container {
                                        min-width: 320px !important;
                                    }
                                }
                                /* iPhone 6, 6S, 7, 8, and X */
                                @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
                                    u ~ div .email-container {
                                        min-width: 375px !important;
                                    }
                                }
                                /* iPhone 6+, 7+, and 8+ */
                                @media only screen and (min-device-width: 414px) {
                                    u ~ div .email-container {
                                        min-width: 414px !important;
                                    }
                                }
                                
                                </style>
                                
                                <!-- CSS Reset : END -->
                                
                                <!-- Progressive Enhancements : BEGIN -->
                                <style>
                                
                                  .primary{
                                    background: #0d0cb5;
                                }
                                .bg_white{
                                    background: #ffffff;
                                }
                                .bg_light{
                                    background: #fafafa;
                                }
                                .bg_black{
                                    background: #000000;
                                }
                                .bg_dark{
                                    background: rgba(0,0,0,.8);
                                }
                                .email-section{
                                    padding:2.5em;
                                }
                                
                                /*BUTTON*/
                                .btn{
                                    padding: 5px 15px;
                                    display: inline-block;
                                }
                                .btn.btn-primary{
                                    border-radius: 5px;
                                    background: #0d0cb5;
                                    color: #ffffff;
                                }
                                .btn.btn-white{
                                    border-radius: 5px;
                                    background: #ffffff;
                                    color: #000000;
                                }
                                .btn.btn-white-outline{
                                    border-radius: 5px;
                                    background: transparent;
                                    border: 1px solid #fff;
                                    color: #fff;
                                }
                                
                                h1,h2,h3,h4,h5,h6{
                                    font-family: 'Poppins', sans-serif;
                                    color: #000000;
                                    margin-top: 0;
                                }
                                
                                body{
                                    font-family: 'Poppins', sans-serif;
                                    font-weight: 400;
                                    font-size: 15px;
                                    line-height: 1.8;
                                    color: rgba(0,0,0,.4);
                                }
                                
                                a{
                                    color: #0d0cb5;
                                }
                                
                                table{
                                }
                                /*LOGO*/
                                
                                .logo h1{
                                    margin: 0;
                                }
                                .logo h1 a{
                                    color: #000000;
                                    font-size: 20px;
                                    font-weight: 700;
                                    text-transform: uppercase;
                                    font-family: 'Poppins', sans-serif;
                                }
                                
                                .navigation{
                                    padding: 0;
                                }
                                .navigation li{
                                    list-style: none;
                                    display: inline-block;;
                                    margin-left: 5px;
                                    font-size: 13px;
                                    font-weight: 500;
                                }
                                .navigation li a{
                                    color: rgba(0,0,0,.4);
                                }
                                
                                /*HERO*/
                                .hero{
                                    position: relative;
                                    z-index: 0;
                                }
                                .hero .overlay{
                                    position: absolute;
                                    top: 0;
                                    left: 0;
                                    right: 0;
                                    bottom: 0;
                                    content: '';
                                    width: 100%;
                                    background: #000000;
                                    z-index: -1;
                                    opacity: .3;
                                }
                                .hero .icon{
                                }
                                .hero .icon a{
                                    display: block;
                                    width: 60px;
                                    margin: 0 auto;
                                }
                                .hero .text{
                                    color: rgba(255,255,255,.8);
                                }
                                .hero .text h2{
                                    color: #ffffff;
                                    font-size: 30px;
                                    margin-bottom: 0;
                                }
                                
                                
                                /*HEADING SECTION*/
                                .heading-section{
                                }
                                .heading-section h2{
                                    color: #000000;
                                    font-size: 20px;
                                    margin-top: 0;
                                    line-height: 1.4;
                                    font-weight: 700;
                                    text-transform: uppercase;
                                }
                                .heading-section .subheading{
                                    margin-bottom: 20px !important;
                                    display: inline-block;
                                    font-size: 13px;
                                    text-transform: uppercase;
                                    letter-spacing: 2px;
                                    color: rgba(0,0,0,.4);
                                    position: relative;
                                }
                                .heading-section .subheading::after{
                                    position: absolute;
                                    left: 0;
                                    right: 0;
                                    bottom: -10px;
                                    content: '';
                                    width: 100%;
                                    height: 2px;
                                    background: #0d0cb5;
                                    margin: 0 auto;
                                }
                                
                                .heading-section-white{
                                    color: rgba(255,255,255,.8);
                                }
                                .heading-section-white h2{
                                    font-family: 
                                    line-height: 1;
                                    padding-bottom: 0;
                                }
                                .heading-section-white h2{
                                    color: #ffffff;
                                }
                                .heading-section-white .subheading{
                                    margin-bottom: 0;
                                    display: inline-block;
                                    font-size: 13px;
                                    text-transform: uppercase;
                                    letter-spacing: 2px;
                                    color: rgba(255,255,255,.4);
                                }
                                
                                
                                .icon{
                                    text-align: center;
                                }
                                .icon img{
                                }
                                
                                
                                /*SERVICES*/
                                .services{
                                    background: rgba(0,0,0,.03);
                                }
                                .text-services{
                                    padding: 10px 10px 0; 
                                    text-align: center;
                                }
                                .text-services h3{
                                    font-size: 16px;
                                    font-weight: 600;
                                }
                                
                                .services-list{
                                    padding: 0;
                                    margin: 0 0 20px 0;
                                    width: 100%;
                                    float: left;
                                }
                                
                                .services-list img{
                                    float: left;
                                }
                                .services-list .text{
                                    width: calc(100% - 60px);
                                    float: right;
                                }
                                .services-list h3{
                                    margin-top: 0;
                                    margin-bottom: 0;
                                }
                                .services-list p{
                                    margin: 0;
                                }
                                
                                /*BLOG*/
                                .text-services .meta{
                                    text-transform: uppercase;
                                    font-size: 14px;
                                }
                                
                                /*TESTIMONY*/
                                .text-testimony .name{
                                    margin: 0;
                                }
                                .text-testimony .position{
                                    color: rgba(0,0,0,.3);
                                
                                }
                                
                                
                                /*VIDEO*/
                                .img{
                                    width: 100%;
                                    height: auto;
                                    position: relative;
                                }
                                .img .icon{
                                    position: absolute;
                                    top: 50%;
                                    left: 0;
                                    right: 0;
                                    bottom: 0;
                                    margin-top: -25px;
                                }
                                .img .icon a{
                                    display: block;
                                    width: 60px;
                                    position: absolute;
                                    top: 0;
                                    left: 50%;
                                    margin-left: -25px;
                                }
                                
                                
                                
                                /*COUNTER*/
                                .counter{
                                    width: 100%;
                                    position: relative;
                                    z-index: 0;
                                }
                                .counter .overlay{
                                    position: absolute;
                                    top: 0;
                                    left: 0;
                                    right: 0;
                                    bottom: 0;
                                    content: '';
                                    width: 100%;
                                    background: #000000;
                                    z-index: -1;
                                    opacity: .3;
                                }
                                .counter-text{
                                    text-align: center;
                                }
                                .counter-text .num{
                                    display: block;
                                    color: #ffffff;
                                    font-size: 34px;
                                    font-weight: 700;
                                }
                                .counter-text .name{
                                    display: block;
                                    color: rgba(255,255,255,.9);
                                    font-size: 13px;
                                }
                                
                                
                                /*FOOTER*/
                                
                                .footer{
                                    color: rgba(255,255,255,.5);
                                
                                }
                                .footer .heading{
                                    color: #ffffff;
                                    font-size: 20px;
                                }
                                .footer ul{
                                    margin: 0;
                                    padding: 0;
                                }
                                .footer ul li{
                                    list-style: none;
                                    margin-bottom: 10px;
                                }
                                .footer ul li a{
                                    color: rgba(255,255,255,1);
                                }
                                
                                
                                @media screen and (max-width: 500px) {
                                
                                    .icon{
                                        text-align: left;
                                    }
                                
                                    .text-services{
                                        padding-left: 0;
                                        padding-right: 20px;
                                        text-align: left;
                                    }
                                
                                }
                                </style>
                                
                                
                                </head>
                                
                                <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
                                    <center style="width: 100%; background-color: #f1f1f1;">
                                    
                                    <div style="max-width: 600px; margin: 0 auto;" class="email-container">
                                        <!-- BEGIN BODY -->
                                      <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
                                          <tr>
                                          <td valign="top" class="bg_white">
                                              <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                                                  
                                                  <tr style="background: #234e70">
                                                      <td>
                                                          <h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 500;color:#fff;">`+name+` would like to talk to you</h1>
                                                      </td>
                                                  </tr>
                                                  
                                              </table>
                                          </td>
                                        </tr><!-- end tr -->
                                
                                        <tr>
                                          <td valign="top" class="bg_white" style="padding-top: 15px">
                                              <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                  <tr >
                                                      <td style="padding:10px">
                                                          <h2 style="margin-bottom: 0">Hello `+sellerInfo[x].name+`</h2><br>
                                                          <p style="margin: 0px;font-weight:500">We have recieved an interest from our user:</p>
                                                    </td>
                                                  </tr>
                                              </table>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td valign="top" class="bg_white" style="font-weight:600;color:#234E70;">
                                              <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                  <tr>
                                                      <td style="padding: 10px">
                                                          Name: 
                                                     </td>
                                                     <td style="padding: 10px">
                                                     `+name+`
                                                     </td>
                                                  </tr>
                                                  <tr>
                                                      <td style="padding: 10px">
                                                          Email: 
                                                     </td>
                                                     <td style="padding: 10px">
                                                        `+email+`
                                                     </td>
                                                  </tr>
                                                  <tr>
                                                      <td style="padding: 10px">
                                                          Mobile: 
                                                     </td>
                                                     <td style="padding: 10px">
                                                     `+mobile+`
                                                     </td>
                                                  </tr>
                                              </table>
                                          </td>
                                      </tr>
                                
                                
                                          <tr>
                                          <td valign="top" class="bg_white">
                                              <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                  
                                                  <tr>
                                                      <td style="padding: 10px">
                                                           <span style="font-weight: 600;padding-left:5px;">Who would like to talk to you regarding residential project <b style="color:#234E70;">`+projects_names+`</b></span>
                                                          </p>
                                                     </td>
                                                  </tr>
                                                  
                                              </table>
                                          </td>
                                        </tr><!-- end tr -->
                                
                                
                                        
                                
                                     
                                      <!-- 1 Column Text + Button : END -->
                                      </table>
                                    
                                
                                    </div>
                                  </center>
                                </body>
                                </html>`
                                fun.nodemailer(sellerInfo[x].email,'Housiey',msg);
                                fun.nodemailer('enquiry.housiey@gmail.com','Housiey',msg);
                            }
                        }
                    }
                    // res.send({status:false,msg:'Invalid Selles Person',sellerInfo:sellerInfo});
                    // return;

                    if(parseInt(req.body.type)==1){


                        let cab             = (req.body.source=="Not-Required")?'No':'Yes'
                        let representative  = sellerInfo[0].name+' - '+sellerInfo[0].phone
                        let message  ='';
                        let cabTemID = 0;
                        if(cab=='Yes'){
                            message = 'Hello '+name+', Greetings from Housiey !!,.Your site visit has been scheduled for - '+projects_names+', Date - '+enq_date+', Time- '+enq_time+', Cab details will be shared 1hr before the scheduled time For any queries, Kindly contact our representative '+sellerInfo[0].name+' - '+sellerInfo[0].phone+'. Thanks Housiey';
                            cabTemID = '1707166315367900684'
                        }else{
                            
                            message = `Hello ${name}, Greetings from Housiey !!,.Your site visit has been scheduled for - ${projects_names}, Date - ${enq_date}, Time- ${enq_time}, For any queries, Kindly contact our representative ${sellerInfo[0].name} - ${sellerInfo[0].phone} . Thanks Housiey.com`
                            cabTemID = '1707166314942545859';
                        }

                        if(send_msgs){
                            requests(`https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile=${mobile}&dlttempid=${cabTemID}&message=`+message, false)
                            .on('data', function (chunk) {
                                console.log(chunk)
                            })
                            .on('end', function (err) {
                                if (err) console.log('connection closed due to errors', err);
                                console.log('end');
                            });
                        }
                        if(email){
                            console.log('there------------------------');
                            fun.nodemailer(email,'Site Visit Scheduled Successfully',`
                            <!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8"> <!-- utf-8 works for most cases -->
    <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
    <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
    <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <!-- CSS Reset : BEGIN -->
<style>
html,
body {
    margin: 0 auto !important;
    padding: 0 !important;
    height: 100% !important;
    width: 100% !important;
    background: #f1f1f1;
}

/* What it does: Stops email clients resizing small text. */
* {
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
}

/* What it does: Centers email on Android 4.4 */
div[style*="margin: 16px 0"] {
    margin: 0 !important;
}

/* What it does: Stops Outlook from adding extra spacing to tables. */
table,
td {
    mso-table-lspace: 0pt !important;
    mso-table-rspace: 0pt !important;
}

/* What it does: Fixes webkit padding issue. */
table {
    border-spacing: 0 !important;
    border-collapse: collapse !important;
    table-layout: fixed !important;
    margin: 0 auto !important;
}

/* What it does: Uses a better rendering method when resizing images in IE. */
img {
    -ms-interpolation-mode:bicubic;
}

/* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
a {
    text-decoration: none;
}

/* What it does: A work-around for email clients meddling in triggered links. */
*[x-apple-data-detectors],  /* iOS */
.unstyle-auto-detected-links *,
.aBn {
    border-bottom: 0 !important;
    cursor: default !important;
    color: inherit !important;
    text-decoration: none !important;
    font-size: inherit !important;
    font-family: inherit !important;
    font-weight: inherit !important;
    line-height: inherit !important;
}

/* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
.a6S {
    display: none !important;
    opacity: 0.01 !important;
}

/* What it does: Prevents Gmail from changing the text color in conversation threads. */
.im {
    color: inherit !important;
}

/* If the above doesn't work, add a .g-img class to any image in question. */
img.g-img + div {
    display: none !important;
}

/* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
/* Create one of these media queries for each additional viewport size you'd like to fix */

/* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
@media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
    u ~ div .email-container {
        min-width: 320px !important;
    }
}
/* iPhone 6, 6S, 7, 8, and X */
@media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
    u ~ div .email-container {
        min-width: 375px !important;
    }
}
/* iPhone 6+, 7+, and 8+ */
@media only screen and (min-device-width: 414px) {
    u ~ div .email-container {
        min-width: 414px !important;
    }
}

</style>

<!-- CSS Reset : END -->

<!-- Progressive Enhancements : BEGIN -->
<style>

  .primary{
	background: #0d0cb5;
}
.bg_white{
	background: #ffffff;
}
.bg_light{
	background: #fafafa;
}
.bg_black{
	background: #000000;
}
.bg_dark{
	background: rgba(0,0,0,.8);
}
.email-section{
	padding:2.5em;
}

/*BUTTON*/
.btn{
	padding: 5px 15px;
	display: inline-block;
}
.btn.btn-primary{
	border-radius: 5px;
	background: #0d0cb5;
	color: #ffffff;
}
.btn.btn-white{
	border-radius: 5px;
	background: #ffffff;
	color: #000000;
}
.btn.btn-white-outline{
	border-radius: 5px;
	background: transparent;
	border: 1px solid #fff;
	color: #fff;
}

h1,h2,h3,h4,h5,h6{
	font-family: 'Poppins', sans-serif;
	color: #000000;
	margin-top: 0;
}

body{
	font-family: 'Poppins', sans-serif;
	font-weight: 400;
	font-size: 15px;
	line-height: 1.8;
	color: rgba(0,0,0,.4);
}

a{
	color: #0d0cb5;
}

table{
}
/*LOGO*/

.logo h1{
	margin: 0;
}
.logo h1 a{
	color: #000000;
	font-size: 20px;
	font-weight: 700;
	text-transform: uppercase;
	font-family: 'Poppins', sans-serif;
}

.navigation{
	padding: 0;
}
.navigation li{
	list-style: none;
	display: inline-block;;
	margin-left: 5px;
	font-size: 13px;
	font-weight: 500;
}
.navigation li a{
	color: rgba(0,0,0,.4);
}

/*HERO*/
.hero{
	position: relative;
	z-index: 0;
}
.hero .overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	content: '';
	width: 100%;
	background: #000000;
	z-index: -1;
	opacity: .3;
}
.hero .icon{
}
.hero .icon a{
	display: block;
	width: 60px;
	margin: 0 auto;
}
.hero .text{
	color: rgba(255,255,255,.8);
}
.hero .text h2{
	color: #ffffff;
	font-size: 30px;
	margin-bottom: 0;
}


/*HEADING SECTION*/
.heading-section{
}
.heading-section h2{
	color: #000000;
	font-size: 20px;
	margin-top: 0;
	line-height: 1.4;
	font-weight: 700;
	text-transform: uppercase;
}
.heading-section .subheading{
	margin-bottom: 20px !important;
	display: inline-block;
	font-size: 13px;
	text-transform: uppercase;
	letter-spacing: 2px;
	color: rgba(0,0,0,.4);
	position: relative;
}
.heading-section .subheading::after{
	position: absolute;
	left: 0;
	right: 0;
	bottom: -10px;
	content: '';
	width: 100%;
	height: 2px;
	background: #0d0cb5;
	margin: 0 auto;
}

.heading-section-white{
	color: rgba(255,255,255,.8);
}
.heading-section-white h2{
	font-family: 
	line-height: 1;
	padding-bottom: 0;
}
.heading-section-white h2{
	color: #ffffff;
}
.heading-section-white .subheading{
	margin-bottom: 0;
	display: inline-block;
	font-size: 13px;
	text-transform: uppercase;
	letter-spacing: 2px;
	color: rgba(255,255,255,.4);
}


.icon{
	text-align: center;
}
.icon img{
}


/*SERVICES*/
.services{
	background: rgba(0,0,0,.03);
}
.text-services{
	padding: 10px 10px 0; 
	text-align: center;
}
.text-services h3{
	font-size: 16px;
	font-weight: 600;
}

.services-list{
	padding: 0;
	margin: 0 0 20px 0;
	width: 100%;
	float: left;
}

.services-list img{
	float: left;
}
.services-list .text{
	width: calc(100% - 60px);
	float: right;
}
.services-list h3{
	margin-top: 0;
	margin-bottom: 0;
}
.services-list p{
	margin: 0;
}

/*BLOG*/
.text-services .meta{
	text-transform: uppercase;
	font-size: 14px;
}

/*TESTIMONY*/
.text-testimony .name{
	margin: 0;
}
.text-testimony .position{
	color: rgba(0,0,0,.3);

}


/*VIDEO*/
.img{
	width: 100%;
	height: auto;
	position: relative;
}
.img .icon{
	position: absolute;
	top: 50%;
	left: 0;
	right: 0;
	bottom: 0;
	margin-top: -25px;
}
.img .icon a{
	display: block;
	width: 60px;
	position: absolute;
	top: 0;
	left: 50%;
	margin-left: -25px;
}



/*COUNTER*/
.counter{
	width: 100%;
	position: relative;
	z-index: 0;
}
.counter .overlay{
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	content: '';
	width: 100%;
	background: #000000;
	z-index: -1;
	opacity: .3;
}
.counter-text{
	text-align: center;
}
.counter-text .num{
	display: block;
	color: #ffffff;
	font-size: 34px;
	font-weight: 700;
}
.counter-text .name{
	display: block;
	color: rgba(255,255,255,.9);
	font-size: 13px;
}


/*FOOTER*/

.footer{
	color: rgba(255,255,255,.5);

}
.footer .heading{
	color: #ffffff;
	font-size: 20px;
}
.footer ul{
	margin: 0;
	padding: 0;
}
.footer ul li{
	list-style: none;
	margin-bottom: 10px;
}
.footer ul li a{
	color: rgba(255,255,255,1);
}


@media screen and (max-width: 500px) {

	.icon{
		text-align: left;
	}

	.text-services{
		padding-left: 0;
		padding-right: 20px;
		text-align: left;
	}

}
</style>


</head>

<body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
	<center style="width: 100%; background-color: #f1f1f1;">
   
    <div style="max-width: 600px; margin: 0 auto;" class="email-container">
    	<!-- BEGIN BODY -->
      <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
      	<tr>
          <td valign="top" class="bg_white">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                <tr>
          			<td class="logo" style="text-align: center;">
			            <img src="`+base_url+`admin/uploads/logo/housiey-logo2.jpg" alt="Image" class="img-fluid mb-4" style="width: 200px;">
			          </td>	
          		</tr>
          		<tr>
          			<td class="logo" style="text-align: center;">
			            <img src="`+base_url+`admin/assets/images_mail/right1.png" alt="Image" class="img-fluid mb-4">
			          </td>	
          		</tr>
          		<tr>
          			<td>
			          	<h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 500;color:#0e8744;">Free Site Visit booked Successfully</h1>
			          </td>
          		</tr>
          		
          	</table>
          </td>
	    </tr><!-- end tr -->

	    <tr>
          <td valign="top" class="bg_white">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
          		<tr>
          			<td>
          				<span style="padding: 10px;font-weight: 500;">Site Visit Booked for</span>
			          	<p style="font-size: 12px;padding: 0px 10px;font-weight: 500;color: #fff;">
			          `+mail_projects_details+`
			          	</p>
			          </td>
          		</tr>
          	</table>
          </td>
      </tr>
      <tr>
          <td valign="top" class="bg_white">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
          		<tr>
          			<td style="padding: 10px">
	      				<span style="font-weight: 500;">Date & Time</span><br>
			          	<span style="padding-left:10px;color: #234E70;"><img class="calendar" src="`+base_url+`admin/assets/images_mail/calendar.png" width="20px" style="vertical-align:sub"> `+moment(req.body.enquiry_datetime).format("h:mm a ddd, DD MMMM YYYY")+`</span>
			          	</p>
			         </td>
          		</tr>
          	</table>
          </td>
      </tr>


      	<tr>
          <td valign="top" class="bg_white">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
          		
          		<tr>
          			<td style="padding: 10px">
                      <span style="color:#234E70;padding-left:5px;"><img class="ola" src="`+base_url+`admin/assets/images_mail/ola.png" width="30px" style="vertical-align:bottom"> Cab details will be shared 1 hr before the scheduled time</span>
			          	</p>
			         </td>
          		</tr>
          		<tr>
          			<td style="padding: 10px">
	      				 <span style="font-weight:600">For any queries, kindly contact your Housiey Relationship Manager</span><br><br>
	      				 <span style="font-weight:500;color:#234E70;"><img src="`+base_url+`admin/assets/images_mail/user.png" width="25px" style="vertical-align: sub;"> `+representative+` <a href="https://api.whatsapp.com/send?phone=91`+sellerInfo[0].phone+`&text=Hello, *`+sellerInfo[0].name+`* Need More Details about the *`+projects_names+`*" class="btn btn-chat" style="float: right;padding: 5px 10px;background: #0e8744;color: #fff;border-radius: 50px;"><i class="fab fa-whatsapp"></i> Live Chat with RM</a></span>
			          	</p>
			         </td>
          		</tr>
          	</table>
          </td>
	    </tr><!-- end tr -->


	    

	 
      <!-- 1 Column Text + Button : END -->
      </table>
    

    </div>
  </center>
</body>
</html>
                            `);
                        }
                        
                        // to seller 
                        if(send_msgs){
                            let email = []
                            for (let x = 0; x < sellerInfo.length; x++) {
                                const element = sellerInfo[x];
                                email.push(element.email)
                                let msg = "Hello "+element.name+", Client - "+name+" - "+mobile+" has scheduled the site visit for "+projects_names+", Date - "+enq_date+", Time- "+enq_time+". Cab required - "+cab+". Kindly connect with the client. Cheers Housiey.com";


                                requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+element.phone+'&dlttempid=1707166315357486429&message='+msg, false)
                                .on('data', function (chunk) {
                                console.log(chunk)
                                })
                                .on('end', function (err) {
                                    if (err) console.log('connection closed due to errors', err);
                                    console.log('end');
                                });
                            }
                        }
                        for (let x = 0; x < sellerInfo.length; x++) {
                            if(sellerInfo[x].email){
                                let msg = `<!DOCTYPE html>
                                <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
                                <head>
                                    <meta charset="utf-8"> <!-- utf-8 works for most cases -->
                                    <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
                                    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
                                    <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
                                    <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->
                                
                                    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
                                
                                    <!-- CSS Reset : BEGIN -->
                                <style>
                                html,
                                body {
                                    margin: 0 auto !important;
                                    padding: 0 !important;
                                    height: 100% !important;
                                    width: 100% !important;
                                    background: #f1f1f1;
                                }
                                
                                /* What it does: Stops email clients resizing small text. */
                                * {
                                    -ms-text-size-adjust: 100%;
                                    -webkit-text-size-adjust: 100%;
                                }
                                
                                /* What it does: Centers email on Android 4.4 */
                                div[style*="margin: 16px 0"] {
                                    margin: 0 !important;
                                }
                                
                                /* What it does: Stops Outlook from adding extra spacing to tables. */
                                table,
                                td {
                                    mso-table-lspace: 0pt !important;
                                    mso-table-rspace: 0pt !important;
                                }
                                
                                /* What it does: Fixes webkit padding issue. */
                                table {
                                    border-spacing: 0 !important;
                                    border-collapse: collapse !important;
                                    table-layout: fixed !important;
                                    margin: 0 auto !important;
                                }
                                
                                /* What it does: Uses a better rendering method when resizing images in IE. */
                                img {
                                    -ms-interpolation-mode:bicubic;
                                }
                                
                                /* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
                                a {
                                    text-decoration: none;
                                }
                                
                                /* What it does: A work-around for email clients meddling in triggered links. */
                                *[x-apple-data-detectors],  /* iOS */
                                .unstyle-auto-detected-links *,
                                .aBn {
                                    border-bottom: 0 !important;
                                    cursor: default !important;
                                    color: inherit !important;
                                    text-decoration: none !important;
                                    font-size: inherit !important;
                                    font-family: inherit !important;
                                    font-weight: inherit !important;
                                    line-height: inherit !important;
                                }
                                
                                /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
                                .a6S {
                                    display: none !important;
                                    opacity: 0.01 !important;
                                }
                                
                                /* What it does: Prevents Gmail from changing the text color in conversation threads. */
                                .im {
                                    color: inherit !important;
                                }
                                
                                /* If the above doesn't work, add a .g-img class to any image in question. */
                                img.g-img + div {
                                    display: none !important;
                                }
                                
                                /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
                                /* Create one of these media queries for each additional viewport size you'd like to fix */
                                
                                /* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
                                @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
                                    u ~ div .email-container {
                                        min-width: 320px !important;
                                    }
                                }
                                /* iPhone 6, 6S, 7, 8, and X */
                                @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
                                    u ~ div .email-container {
                                        min-width: 375px !important;
                                    }
                                }
                                /* iPhone 6+, 7+, and 8+ */
                                @media only screen and (min-device-width: 414px) {
                                    u ~ div .email-container {
                                        min-width: 414px !important;
                                    }
                                }
                                
                                </style>
                                
                                <!-- CSS Reset : END -->
                                
                                <!-- Progressive Enhancements : BEGIN -->
                                <style>
                                
                                  .primary{
                                    background: #0d0cb5;
                                }
                                .bg_white{
                                    background: #ffffff;
                                }
                                .bg_light{
                                    background: #fafafa;
                                }
                                .bg_black{
                                    background: #000000;
                                }
                                .bg_dark{
                                    background: rgba(0,0,0,.8);
                                }
                                .email-section{
                                    padding:2.5em;
                                }
                                
                                /*BUTTON*/
                                .btn{
                                    padding: 5px 15px;
                                    display: inline-block;
                                }
                                .btn.btn-primary{
                                    border-radius: 5px;
                                    background: #0d0cb5;
                                    color: #ffffff;
                                }
                                .btn.btn-white{
                                    border-radius: 5px;
                                    background: #ffffff;
                                    color: #000000;
                                }
                                .btn.btn-white-outline{
                                    border-radius: 5px;
                                    background: transparent;
                                    border: 1px solid #fff;
                                    color: #fff;
                                }
                                
                                h1,h2,h3,h4,h5,h6{
                                    font-family: 'Poppins', sans-serif;
                                    color: #000000;
                                    margin-top: 0;
                                }
                                
                                body{
                                    font-family: 'Poppins', sans-serif;
                                    font-weight: 400;
                                    font-size: 15px;
                                    line-height: 1.8;
                                    color: rgba(0,0,0,.4);
                                }
                                
                                a{
                                    color: #0d0cb5;
                                }
                                
                                table{
                                }
                                /*LOGO*/
                                
                                .logo h1{
                                    margin: 0;
                                }
                                .logo h1 a{
                                    color: #000000;
                                    font-size: 20px;
                                    font-weight: 700;
                                    text-transform: uppercase;
                                    font-family: 'Poppins', sans-serif;
                                }
                                
                                .navigation{
                                    padding: 0;
                                }
                                .navigation li{
                                    list-style: none;
                                    display: inline-block;;
                                    margin-left: 5px;
                                    font-size: 13px;
                                    font-weight: 500;
                                }
                                .navigation li a{
                                    color: rgba(0,0,0,.4);
                                }
                                
                                /*HERO*/
                                .hero{
                                    position: relative;
                                    z-index: 0;
                                }
                                .hero .overlay{
                                    position: absolute;
                                    top: 0;
                                    left: 0;
                                    right: 0;
                                    bottom: 0;
                                    content: '';
                                    width: 100%;
                                    background: #000000;
                                    z-index: -1;
                                    opacity: .3;
                                }
                                .hero .icon{
                                }
                                .hero .icon a{
                                    display: block;
                                    width: 60px;
                                    margin: 0 auto;
                                }
                                .hero .text{
                                    color: rgba(255,255,255,.8);
                                }
                                .hero .text h2{
                                    color: #ffffff;
                                    font-size: 30px;
                                    margin-bottom: 0;
                                }
                                
                                
                                /*HEADING SECTION*/
                                .heading-section{
                                }
                                .heading-section h2{
                                    color: #000000;
                                    font-size: 20px;
                                    margin-top: 0;
                                    line-height: 1.4;
                                    font-weight: 700;
                                    text-transform: uppercase;
                                }
                                .heading-section .subheading{
                                    margin-bottom: 20px !important;
                                    display: inline-block;
                                    font-size: 13px;
                                    text-transform: uppercase;
                                    letter-spacing: 2px;
                                    color: rgba(0,0,0,.4);
                                    position: relative;
                                }
                                .heading-section .subheading::after{
                                    position: absolute;
                                    left: 0;
                                    right: 0;
                                    bottom: -10px;
                                    content: '';
                                    width: 100%;
                                    height: 2px;
                                    background: #0d0cb5;
                                    margin: 0 auto;
                                }
                                
                                .heading-section-white{
                                    color: rgba(255,255,255,.8);
                                }
                                .heading-section-white h2{
                                    font-family: 
                                    line-height: 1;
                                    padding-bottom: 0;
                                }
                                .heading-section-white h2{
                                    color: #ffffff;
                                }
                                .heading-section-white .subheading{
                                    margin-bottom: 0;
                                    display: inline-block;
                                    font-size: 13px;
                                    text-transform: uppercase;
                                    letter-spacing: 2px;
                                    color: rgba(255,255,255,.4);
                                }
                                
                                
                                .icon{
                                    text-align: center;
                                }
                                .icon img{
                                }
                                
                                
                                /*SERVICES*/
                                .services{
                                    background: rgba(0,0,0,.03);
                                }
                                .text-services{
                                    padding: 10px 10px 0; 
                                    text-align: center;
                                }
                                .text-services h3{
                                    font-size: 16px;
                                    font-weight: 600;
                                }
                                
                                .services-list{
                                    padding: 0;
                                    margin: 0 0 20px 0;
                                    width: 100%;
                                    float: left;
                                }
                                
                                .services-list img{
                                    float: left;
                                }
                                .services-list .text{
                                    width: calc(100% - 60px);
                                    float: right;
                                }
                                .services-list h3{
                                    margin-top: 0;
                                    margin-bottom: 0;
                                }
                                .services-list p{
                                    margin: 0;
                                }
                                
                                /*BLOG*/
                                .text-services .meta{
                                    text-transform: uppercase;
                                    font-size: 14px;
                                }
                                
                                /*TESTIMONY*/
                                .text-testimony .name{
                                    margin: 0;
                                }
                                .text-testimony .position{
                                    color: rgba(0,0,0,.3);
                                
                                }
                                
                                
                                /*VIDEO*/
                                .img{
                                    width: 100%;
                                    height: auto;
                                    position: relative;
                                }
                                .img .icon{
                                    position: absolute;
                                    top: 50%;
                                    left: 0;
                                    right: 0;
                                    bottom: 0;
                                    margin-top: -25px;
                                }
                                .img .icon a{
                                    display: block;
                                    width: 60px;
                                    position: absolute;
                                    top: 0;
                                    left: 50%;
                                    margin-left: -25px;
                                }
                                
                                
                                
                                /*COUNTER*/
                                .counter{
                                    width: 100%;
                                    position: relative;
                                    z-index: 0;
                                }
                                .counter .overlay{
                                    position: absolute;
                                    top: 0;
                                    left: 0;
                                    right: 0;
                                    bottom: 0;
                                    content: '';
                                    width: 100%;
                                    background: #000000;
                                    z-index: -1;
                                    opacity: .3;
                                }
                                .counter-text{
                                    text-align: center;
                                }
                                .counter-text .num{
                                    display: block;
                                    color: #ffffff;
                                    font-size: 34px;
                                    font-weight: 700;
                                }
                                .counter-text .name{
                                    display: block;
                                    color: rgba(255,255,255,.9);
                                    font-size: 13px;
                                }
                                
                                
                                /*FOOTER*/
                                
                                .footer{
                                    color: rgba(255,255,255,.5);
                                
                                }
                                .footer .heading{
                                    color: #ffffff;
                                    font-size: 20px;
                                }
                                .footer ul{
                                    margin: 0;
                                    padding: 0;
                                }
                                .footer ul li{
                                    list-style: none;
                                    margin-bottom: 10px;
                                }
                                .footer ul li a{
                                    color: rgba(255,255,255,1);
                                }
                                
                                
                                @media screen and (max-width: 500px) {
                                
                                    .icon{
                                        text-align: left;
                                    }
                                
                                    .text-services{
                                        padding-left: 0;
                                        padding-right: 20px;
                                        text-align: left;
                                    }
                                
                                }
                                </style>
                                
                                
                                </head>
                                
                                <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
                                    <center style="width: 100%; background-color: #f1f1f1;">
                                   
                                    <div style="max-width: 600px; margin: 0 auto;" class="email-container">
                                        <!-- BEGIN BODY -->
                                      <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background-color: #fff;">
                                          <tr>
                                          <td valign="top" class="bg_white">
                                              <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-bottom: 2px solid #234e70">
                                                  
                                                  <tr style="background: #234e70">
                                                      <td>
                                                          <h1 style="text-align: center;font-size: 22px;margin:0;font-weight: 500;color:#fff;">`+name+` would like to talk to you</h1>
                                                      </td>
                                                  </tr>
                                                  
                                              </table>
                                          </td>
                                        </tr><!-- end tr -->
                                
                                        <tr>
                                          <td valign="top" class="bg_white" style="padding-top: 15px">
                                              <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                  <tr >
                                                      <td style="padding:10px">
                                                          <h2 style="margin-bottom: 0">Hello `+sellerInfo[x].name+`</h2><br>
                                                          <p style="margin: 0px;font-weight:500">We have recieved an interest from our user:</p>
                                                    </td>
                                                  </tr>
                                              </table>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td valign="top" class="bg_white" style="font-weight:600;color:#234E70;">
                                              <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                  <tr>
                                                      <td style="padding: 10px">
                                                          Name: 
                                                     </td>
                                                     <td style="padding: 10px">
                                                     `+name+`
                                                     </td>
                                                  </tr>
                                                  <tr>
                                                      <td style="padding: 10px">
                                                          Email: 
                                                     </td>
                                                     <td style="padding: 10px">
                                                        `+email+`
                                                     </td>
                                                  </tr>
                                                  <tr>
                                                      <td style="padding: 10px">
                                                          Mobile: 
                                                     </td>
                                                     <td style="padding: 10px">
                                                     `+mobile+`
                                                     </td>
                                                  </tr>
                                              </table>
                                          </td>
                                      </tr>
                                
                                
                                          <tr>
                                          <td valign="top" class="bg_white">
                                              <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                                                  
                                                  <tr>
                                                      <td style="padding: 10px">
                                                           <span style="font-weight: 600;padding-left:5px;">Who would like to talk to you regarding residential project <b style="color:#234E70;">`+projects_names+`</b></span>
                                                          </p>
                                                     </td>
                                                  </tr>
                                                  
                                              </table>
                                          </td>
                                        </tr><!-- end tr -->
                                
                                
                                        
                                
                                     
                                      <!-- 1 Column Text + Button : END -->
                                      </table>
                                    
                                
                                    </div>
                                  </center>
                                </body>
                                </html>`
                                fun.nodemailer(sellerInfo[x].email,'Housiey',msg);
                                fun.nodemailer('enquiry.housiey@gmail.com','Housiey',msg);
                            }
                        }
                    }
                
				res.send({"res":true,"msg":"Enquiry Saved Successfully, We will connect with you soon!","seller_info":sellerInfo,"projects_details":projects_details})
            }else{
                res.send({"res":false,"err":"Invalid Auth"})
            }
        } catch (error) {
            console.log(error);
            res.send({res:false,msg:'Something Went Wrong Please Try Again '+error});
        }
    },
    get_schemes: async (req,res)=>{
        try {
            schemes = await db.query("SELECT id,scheme FROM `payment_schemes` WHERE status=1",false)
            res.send({"res":true,"schemes":schemes})
        } catch (error) {
            res.send({res:false,msg:'Something Went Wrong Please Try Again'});
        }
    },
    get_possession_type: async (req,res)=>{
        try {
            possession_types = await db.query("SELECT sno,name FROM `possession_type` WHERE status=1",false)
            res.send({"res":true,"possession_types":possession_types})
        } catch (error) {
            res.send({res:false,msg:'Something Went Wrong Please Try Again'});;
        }
    },
    get_configs: async (req,res)=>{
        try {
            configs = await db.query("SELECT id,name FROM `configs` WHERE status=1",false)
            res.send({"res":true,"configs":configs})
        } catch (error) {
            res.send({res:false,msg:'Something Went Wrong Please Try Again'});
        }
    },
    get_filters: async (req,res)=>{
        try {
            schemes = await db.query("SELECT id,scheme FROM `payment_schemes`",false)
            configs = await db.query("SELECT id,name FROM `configs`",false)
            possession_types = await db.query("SELECT sno,name FROM `possession_type`",false)
            let min_max_details=[]
            if(req.query.city_id){
                min_max_details = await db.query("SELECT MIN(project_configs.price) as min_price,MAX(project_configs.price) as max_price,MIN(project_configs.carpet_area) as min_area,MAX(project_configs.carpet_area) as max_area,project_locations.city_id FROM `project_configs` "+
                " LEFT JOIN project_locations ON project_locations.project_id= project_configs.project_id "+
                " LEFT JOIN projects ON projects.id= project_configs.project_id  "+
                " WHERE project_locations.city_id=:city_id  AND projects.publish_status=1",{"city_id":req.query.city_id})
            }else{  
                let getdefaultcity = await db.query("SELECT city_id FROM `city` WHERE default_city=1",false)
                let cityid = (getdefaultcity.length>0)?getdefaultcity[0].city_id:10
                min_max_details = await db.query("SELECT MIN(project_configs.price) as min_price,MAX(project_configs.price) as max_price,MIN(project_configs.carpet_area) as min_area,MAX(project_configs.carpet_area) as max_area,project_locations.city_id FROM `project_configs` "+
                " LEFT JOIN project_locations ON project_locations.project_id= project_configs.project_id "+
                " LEFT JOIN projects ON projects.id= project_configs.project_id  "+
                " WHERE project_locations.city_id=:city_id AND projects.publish_status=1",{"city_id":cityid})
            }
            let range_vals=[]
            if(req.query.range_id){
                range_vals = await db.query("SELECT min_val,max_val FROM `city_ranges` WHERE sno=:range_id",{"range_id":req.query.range_id})
            }
			
			res.send({"res":true,"schemes":schemes,"configs":configs,"possession_types":possession_types,"min_max_details":min_max_details,"range_vals":range_vals})
			
			
        } catch (error) {
            res.send({res:false,msg:'Something Went Wrong Please Try Again'});
        }
    },
    get_default_city: async (req,res)=>{
        try {
            let data = await db.query("SELECT * FROM `city` WHERE default_city=1",false)
            if(data.length==0){
                data = await db.query("SELECT * FROM `city` LIMIT 1",false)
            }
            res.send({"res":true,"data":data})
        } catch (error) {
            res.send({res:false,msg:'Something Went Wrong Please Try Again'});
        }
    },
    get_similer_projects: async (req,res)=>{
        try {
            let getdata = await db.query("SELECT city_id,locality_id,(select MAX(price) from project_configs WHERE project_id=project_locations.project_id) as max_price, "+
            " (select MIN(price) from project_configs WHERE project_id=project_locations.project_id) as min_price "+
            " FROM `project_locations` WHERE project_id=:id",{"id":req.params.pid})
            let pids=[]
            let allIds = []
            if(getdata.length>0){
                // by city and price only
                getPidsByCity_id = await db.query("SELECT projects.id FROM `projects` "+
                " LEFT JOIN project_configs ON project_configs.project_id=projects.id "+
                " LEFT JOIN project_locations ON project_locations.project_id=projects.id "+
                " WHERE project_locations.city_id=:city_id AND project_configs.price BETWEEN :min_price AND :max_price AND publish_status = 1",
                {
                    "city_id":getdata[0].city_id,
                    "min_price":getdata[0].min_price,
                    "max_price":getdata[0].max_price,
                });
                for (let index = 0; index < getPidsByCity_id.length; index++) {
                    const element = getPidsByCity_id[index];
                    pids.push(element.id)
                }
                // by city, locality and price only
                getPidsByCity_id_locality_id = await db.query("SELECT  projects.id FROM `projects` "+
                " LEFT JOIN project_configs ON project_configs.project_id=projects.id "+
                " LEFT JOIN project_locations ON project_locations.project_id=projects.id "+
                " WHERE project_locations.city_id=:city_id AND project_locations.locality_id=:locality_id AND project_configs.price BETWEEN :min_price AND :max_price AND publish_status = 1",
                {
                    "city_id":getdata[0].city_id,
                    "locality_id":getdata[0].locality_id,
                    "min_price":getdata[0].min_price,
                    "max_price":getdata[0].max_price,
                });
                for (let index = 0; index < getPidsByCity_id_locality_id.length; index++) {
                    const element = getPidsByCity_id_locality_id[index];
                    pids.push(element.id)
                }

                allIds = [ ...new Set(pids)]  
                allIds.pop(req.params.pid)
                let getprojects = [];
                if(allIds.length>0){
                    getprojects = await db.query("SELECT projects.id,project_name,slug,area_range_min,area_range_max,config,overall_price_range,target_possession, "+
                    " (SELECT builder_name from builders where id=projects.builder_id) as builder, "+
                    " (SELECT  img FROM project_images WHERE project_id = projects.id AND type IN(1) ) as images, "+
                    " (SELECT name from locality where locality_id = project_locations.locality_id) as location "+
                    " FROM `projects` "+
                    " LEFT JOIN project_locations ON project_locations.project_id=projects.id "+
                    " WHERE projects.id IN("+allIds+")");
                }else{
                    getPidsByCity_id_locality_id = await db.query("SELECT  projects.id FROM `projects` "+
                    " LEFT JOIN project_configs ON project_configs.project_id=projects.id "+
                    " LEFT JOIN project_locations ON project_locations.project_id=projects.id "+
                    " WHERE project_locations.city_id=:city_id AND project_locations.locality_id=:locality_id AND publish_status = 1",
                    {
                        "city_id":getdata[0].city_id,
                        "locality_id":getdata[0].locality_id
                    });
                    for (let index = 0; index < getPidsByCity_id_locality_id.length; index++) {
                        const element = getPidsByCity_id_locality_id[index];
                        pids.push(element.id)
                    }
                    allIds = [ ...new Set(pids)]  
                    allIds.pop(req.params.pid)
                    if(allIds.length>0){
                        getprojects = await db.query("SELECT projects.id,project_name,slug,area_range_min,area_range_max,config,overall_price_range,target_possession, "+
                        " (SELECT builder_name from builders where id=projects.builder_id) as builder, "+
                        " (SELECT  img FROM project_images WHERE project_id = projects.id AND type IN(1) ) as images, "+
                        " (SELECT name from locality where locality_id = project_locations.locality_id) as location "+
                        " FROM `projects` "+
                        " LEFT JOIN project_locations ON project_locations.project_id=projects.id "+
                        " WHERE projects.id IN("+allIds+")");
                    }
                }
                res.send({"res":true,"projects":getprojects})
            }else{res.send({"res":true,"projects":[]})}
            
        } catch (error) {
            res.send({res:false,msg:'Something Went Wrong Please Try Again'});
        }
    },
	getSellerDetailsByProjectID: async (req,res)=>{
		try{
			let query = await db.query("SELECT seller_id FROM projects WHERE id="+req.params.id,false);
			let seller_id = query[0].seller_id;
			let sellerInfo = await db.query("SELECT * FROM sellers WHERE  seller_id IN("+seller_id+")",false);
			res.send({"res":true,"data":sellerInfo});
		}catch(err){
			res.send({res:false,msg:'Something Went Wrong Please Try Again'});
		}
	},
    testing: async (req,res)=>{
        try {
            let email="sahushivam730@gmail.com"
            if(email){
                fun.nodemailer(email,'Housiey','Hello shivam, Thank you for contacting Housiey. For any queries related to etc, Kindly contact our representative represesadantative Thanks Housiey');
            }
            res.send(200)
        } catch (error) {
            console.log(error);
        }
    },
	download_doc: async (req,res)=>{
        try {
            let headers = req.headers
            if(!headers || !headers.auth || headers.auth==='undefined'){
            res.send({"res":false,"err":"Invalid Auth"})
            }
            let data = jwt.verify(headers.auth, token_key);
            let ENqUserId = data.id;
            


            if(data){
                let username = await db.query("select name,mobile,email from user_tbl where id=:id",{"id":data.id});
                let name = username[0].name;
                let email = username[0].email;
                let mobile = username[0].mobile;
                let projects = await db.query("SELECT project_name,seller_id FROM `projects` WHERE id IN("+req.params.project_id+")");
                projects_names = projects[0].project_name
                let sellers_ids = []
                if(projects[0].seller_id){
                    var getsellers = projects[0].seller_id.split(',')
                    for (let j = 0; j < getsellers.length; j++) {
                        sellers_ids.push(getsellers[j])
                    }
                }
                let sellerInfo      = await db.query("SELECT email,phone,name FROM sellers WHERE  seller_id IN("+sellers_ids+")",false);
                let representative  = sellerInfo[0].name+' - '+sellerInfo[0].phone
                let message         = 'Hello '+name+', Thank you for contacting Housiey. For any queries related to '+projects_names+', Kindly contact our representative '+representative+' Thanks Housiey';
                if(send_msgs){
                    requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+mobile+'&dlttempid=1707164700082614486&message='+message, false)
                    .on('data', function (chunk) {
                    console.log(chunk)
                    })
                    .on('end', function (err) {
                        if (err) console.log('connection closed due to errors', err);
                        console.log('end');
                    });
                }
                if(email){
                    fun.nodemailer(email,'Housiey',message);
                }


                let LocationInfo = await db.query("SELECT city_id FROM project_locations WHERE project_id="+req.params.project_id,false);
                let CityId  = LocationInfo[0].city_id;
                let source = (headers.source)?headers.source:'';
                
                let save_signup_enquiry = await db.query("INSERT INTO enquiries SET userid=:userid,city_id=:city_id,project_id=:project_id,enquiry_datetime=:enquiry_datetime,source=:source,type=:type,datetime=:datetime",
                {
                    "userid"            : ENqUserId,
                    "city_id"           : CityId,
                    "project_id"        : req.params.project_id,
                    "source"            : source,
                    "type"              : 3,
                    "enquiry_datetime"  : moment().format('YYYY-MM-DD H:m:s'),
                    "datetime"          : moment().format('YYYY-MM-DD H:m:s'),
                })




                // to seller
                if(send_msgs){
                    for (let l = 0; l < sellerInfo.length; l++) {
                        const element = sellerInfo[l];
                        let msg = "Hello "+element.name+", Client - "+name+" - "+mobile+" has enquired for "+projects_names+", Kindly connect with the client. Cheers Housiey.com"
                        requests('https://www.txtguru.in/imobile/api.php?username=housiey.com&password=59678510&source=HOUSIY&dmobile='+element.phone+'&dlttempid=1707164839141032167&message='+msg, false)
                        .on('data', function (chunk) {
                        console.log(chunk)
                        })
                        .on('end', function (err) {
                            if (err) console.log('connection closed due to errors', err);
                            console.log('end');
                        });
                    }
                    
                }
                if(email){
                    for (let z = 0; z < sellerInfo.length; z++) {
                        if(sellerInfo[z].email){
                            let msg = "Hello "+sellerInfo[z].name+", Client - "+name+" - "+mobile+" has enquired for "+projects_names+", Kindly connect with the client. Cheers Housiey.com"
                            fun.nodemailer(sellerInfo[z].email,'Housiey',msg);
                        }
                    }
                }                
				res.send({"res":true,"msg":message})
            }else{
                res.send({"res":false,"err":"Invalid Auth"})
            }
        } catch(err){
            console.log(err);
			res.send({res:false,msg:'Something Went Wrong Please Try Again Error:'+err.message});
		}
	},
    get_config_by_id: async (req,res)=>{
        try {
            let cond=``
            if(req.query.carpet_area){
                cond+=` AND carpet_area=`+req.query.carpet_area
            }
            let data = await db.query("SELECT carpet_area,builtup_area,price,down_payment,parking_type,parking,unit_plan_img FROM `project_configs` WHERE project_id=:project_id AND config_id=:config_id"+cond,{"project_id":req.params.pid,"config_id":req.params.cid});
            if(data.length>0){
                res.send({res:true,data:data});
            }else{
                res.send({res:false,msg:"data not found",data:data});
            }
        } catch(err){
            console.log(err);
			res.send({res:false,msg:'Something Went Wrong Please Try Again',data:[]});
		}
	},


    deleteNumber: async(req,res)=>{
        try{
            const mobile    = req.params.mobile;
            let sql         = `DELETE FROM user_tbl WHERE mobile='${mobile}'`;
            let query       = await db.query(sql,false,false);
            
            let sql2        = 'SELECT mobile FROM user_tbl';
            let query2      = await db.query(sql2,false,false);

            res.send({status:true,msg:'Deleted Successfully',"query2":query2});
        }catch(e){
            res.send({status:true,msg:'Server Error: '+e.message});
        }
    },

//     getProjectDetails: async(req,res)=>{

//         let accesskey = req.headers["access-key"];
      
//         if(accesskey=="2sVczXSONy"){
// // project_locations
//             let sql = `
//             SELECT *,
//             (SELECT builder_name from builders WHERE projects.builder_id=builders.id) as builder_name
//             FROM projects WHERE slug ="Testing-Title-for-the-Project";
//             `;
//           let projectDetails = await db.query(`Select *, from projects where slug = "${req.params.slug}" `)
//           res.json({
//             "status": true,
//             "Msg": "Successfuly fetched details",
//             "Project_Details": projectDetails
//           });
//         }
//         else{
//           res.json({
//             "status": false,
//             "Msg": "Please provide a valid key."
//           })
//         }   
//       }


getProjectDetails: async (req, res) => {
    let accesskey = req.headers["access-key"];

    if (accesskey == "2sVczXSONy") {
      let project = await db.query(
        "SELECT id,project_name,slug,project_title,project_desc,meta_tags,about,land_parcel,no_of_towers,no_of_floors,config,target_possession,rera_possession,area_range_min,area_range_max,saving_amt,overall_price_range,offer,builder_id,seller_id " +
          " ,(SELECT builder_name from builders WHERE id = projects.builder_id) as builder_name " +
          " ,(SELECT logo from builders WHERE id = projects.builder_id) as builder_logo " +
          " ,(SELECT established_year from builders WHERE id = projects.builder_id) as builder_established_year " +
          " ,(SELECT rera_no from project_rera WHERE project_id = projects.id LIMIT 1) as rera " +
          " FROM `projects` WHERE slug=:slug AND publish_status = 1",
        { slug: req.params.slug }
      );
      
      let address = "";
      let conigs = [];
      let conigs_deatils = [];
      let response = false;

      if (project.length > 0) {
        response = true;
        
        address = await db.query(
          "SELECT (SELECT name FROM locality WHERE locality_id = project_locations.locality_id) as locality,(SELECT name FROM city WHERE city_id = project_locations.city_id) as city FROM `project_locations` WHERE project_id=:project_id",
          { project_id: project[0].id }
        );
        address =
          address.length > 0
            ? address[0].locality + ", " + address[0].city
            : "";

            console.log("hereeeee",address)
            console.log(address)
        conigs = await db.query(
          "SELECT config_id,(SELECT name FROM `configs` WHERE id = project_configs.config_id) as config_name FROM `project_configs` where project_id=:project_id GROUP BY config_id",
          { project_id: project[0].id }
        );
        for (let index = 0; index < conigs.length; index++) {
          const element = conigs[index];
          conigsdeatils = await db.query(
            "SELECT carpet_area,builtup_area,price,down_payment,parking_type,parking,unit_plan_img FROM `project_configs` WHERE project_id=:project_id AND config_id=:config_id",
            { project_id: project[0].id, config_id: element.config_id }
          );
          if (conigsdeatils.length > 0) {
            conigs_deatils.push(conigsdeatils);
          }
        }
        location = await db.query(
          "SELECT (SELECT name FROM state WHERE state_id=project_locations.state_id) as state " +
            " ,(SELECT name FROM city WHERE city_id=project_locations.city_id) as city " +
            " ,(SELECT name FROM locality WHERE locality_id=project_locations.locality_id) as locality, " +
            " street,highlights,link,lat,lng " +
            " FROM `project_locations` WHERE project_id=:project_id",
          { project_id: project[0].id }
        );
      }
      
     
      project[0]["address"] = address;
      project[0]["configs_deatils"]=conigs_deatils;
      project[0]["configs"]=conigs;
      project[0]["location"]=location;

      let locality = project[0]['location'][0]['locality'].toLowerCase();
      let city = project[0]['location'][0]['city'].toLowerCase();

      project[0]["single_project_url"]=`https://dst.com/in/${city}/${locality}/${project[0]['slug']}`;
      project[0]["locality_project_url"]=`https://dst.com/in/${city}/${locality}/projects`;
      project[0]["city_project_url"]=`https://dst.com/in/${city}/projects`;


      res.json({
        status: true,
        Msg: "Successfuly fetched details",
        Project_Details: project,
      });
    } else {
      res.json({
        status: false,
        Msg: "Please provide a valid key.",
      });
    }
  }
}


function isArray (ar) {
  return ar instanceof Array
      || Array.isArray(ar)
      || (ar && ar !== Object.prototype && isArray(ar.__proto__));
}
